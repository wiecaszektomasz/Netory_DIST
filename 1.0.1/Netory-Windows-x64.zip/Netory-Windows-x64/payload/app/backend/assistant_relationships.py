"""Local relationship reports from the authorized snapshot; no provider calls."""
import re


def relationship_answer(context, question):
    if not re.search(r'\b(dependencies|relationships|depends? on|related to)\b', question, re.I):
        return None
    if re.search(r'\b(add|create|update|change|set|assign|remove|delete|connect|disconnect)\b', question, re.I):
        return None
    from backend.infrastructure_graph import InfrastructureGraph
    infrastructure = InfrastructureGraph(context)
    assets = infrastructure.assets
    named = [assets[key] for key in infrastructure.select_assets(question)]
    if len(named) != 1:
        return None
    asset = named[0]
    aid = asset['id']
    lines = []
    def name(key):
        return assets.get(key, {}).get('name', 'unresolved asset reference')
    def add(label, detail):
        line = f'- {label}: {detail}'
        if line not in lines:
            lines.append(line)
    for link in context.get('connections', []):
        if link['device_a_id'] == aid:
            add('Cable', f"port {link['port_a']} ↔ {name(link['device_b_id'])} port {link['port_b']}")
        elif link['device_b_id'] == aid:
            add('Cable', f"port {link['port_b']} ↔ {name(link['device_a_id'])} port {link['port_a']}")
    for lag in context.get('lags', []):
        a, b = lag.get('ports_a') or [], lag.get('ports_b') or []
        if any(port['deviceId'] == aid for port in a + b):
            detail = lambda ports: ', '.join(f"{name(port['deviceId'])} port {port['port']}" for port in ports)
            add('LAG', f"{lag.get('name', lag['id'])}: {detail(a)} ↔ {detail(b)}")
    if asset.get('backup_power_enabled') and asset.get('backup_ups_id'):
        add('Backup UPS', name(asset['backup_ups_id']))
    if asset.get('hypervisor_id'):
        add('Hosted on', name(asset['hypervisor_id']))
    for other in assets.values():
        if other.get('backup_power_enabled') and other.get('backup_ups_id') == aid:
            add('Supplies backup power to', other['name'])
            for vm in assets.values():
                if vm.get('hypervisor_id') == other['id']:
                    add('Indirect hosting dependency', f"{vm['name']} hosted on {other['name']}")
        if other.get('hypervisor_id') == aid:
            add('Hosts VM', other['name'])
    for collection, members, member_key, label in (
        ('stacks', 'stack_members', 'stack_id', 'Stack'),
        ('clusters', 'cluster_members', 'cluster_id', 'Server cluster'),
    ):
        records = {row['id']: row for row in context.get(collection, [])}
        ids = {row[member_key] for row in context.get(members, []) if row['asset_id'] == aid}
        if collection == 'clusters' and asset.get('hypervisor_cluster_id'):
            ids.add(asset['hypervisor_cluster_id'])
        for key in sorted(ids):
            peers = [name(row['asset_id']) for row in context.get(members, []) if row[member_key] == key]
            add(label, f"{records.get(key, {}).get('name', 'unresolved reference')} (members: {', '.join(peers) or 'not recorded'})")
    if asset.get('rack_enabled') and asset.get('rack_id'):
        rack = next((row for row in context.get('racks', []) if row['id'] == asset['rack_id']), None)
        if rack:
            room = next((row for row in context.get('rooms', []) if row['id'] == rack.get('room_id')), None)
            add('Rack placement', f"{rack['name']}, unit {asset.get('rack_start_u') or 'not recorded'}" + (f", room {room['name']}" if room else ''))
    for license in context.get('licenses', []):
        if aid in (license.get('assigned_asset_ids') or []):
            add('Assigned license', license['product'])
    for vlan in context.get('vlans', []):
        if vlan.get('master_device_id') == aid:
            add('VLAN master', f"{vlan['name']} (VLAN {vlan['vlan_number']})")
    for network in context.get('networks', []):
        parent = network.get('parent_interface') or {}
        if network.get('parent_device_id') == aid or (isinstance(parent, dict) and parent.get('deviceId') == aid):
            add('Attached network', f"{network['name']} ({network.get('network_type', 'network')})")
    restricted = context.get('assistant_access', {}).get('read_disabled', [])
    suffix = (' Restricted sections are excluded: ' + ', '.join(restricted) + '.') if restricted else ''
    return (f"Recorded relationships for {asset['name']} ({asset['type']}):\n\n"
            + '\n'.join(lines or ['- No relationships are recorded in the available sections.']) + '\n\n'
            'These relationship types are distinct: a cable, shared rack, stack or cluster membership does not by itself establish outage dependency. '
            'Service dependencies and live health require additional data.' + suffix)
