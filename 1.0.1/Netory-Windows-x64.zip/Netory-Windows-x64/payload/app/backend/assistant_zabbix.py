"""Credential-free assistant context and reviewed Zabbix operations."""
import re
from typing import Literal

from fastapi import HTTPException
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select, update

from backend import assistant_config
from backend.asset_types import ASSET_TYPES
from backend.models import Environment, ZabbixIntegration


class ActionFields(BaseModel):
    model_config = ConfigDict(extra='forbid')
    connection_id: str = Field(min_length=1, max_length=36)
    host_ids: list[str] = Field(default_factory=list, max_length=500)
    asset_types: dict[str, str] = Field(default_factory=dict, max_length=500)


class ZabbixAction(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation: Literal['zabbix_import', 'zabbix_sync']
    fields: ActionFields


def validate_action(item):
    action = ZabbixAction.model_validate(item)
    fields = action.fields
    if action.operation == 'zabbix_import':
        if not fields.host_ids or any(not value.isdigit() or len(value) > 20 for value in fields.host_ids):
            raise ValueError('Zabbix import requires exact discovered host IDs')
    elif fields.host_ids or fields.asset_types:
        raise ValueError('Zabbix sync updates linked hosts only')
    if set(fields.asset_types) - set(fields.host_ids) or any(value not in set(ASSET_TYPES) - {'Monitor', 'Patch panel'} for value in fields.asset_types.values()):
        raise ValueError('Invalid Zabbix host type overrides')
    return action


def enforce_write():
    # Sync also updates OS metadata and default port VLAN configuration.
    for section in ('integrations', 'assets', 'operating_systems', 'vlans'):
        if not assistant_config.section_allowed(section, 'write'):
            raise HTTPException(403, f'Global assistant configuration disables Zabbix changes to {section}.')


def summary(db, environment_id):
    if not assistant_config.section_allowed('integrations'):
        return []
    row = db.scalar(select(ZabbixIntegration).where(ZabbixIntegration.environment_id == environment_id))
    if not row:
        return []
    return [dict(provider='zabbix', connection_id=row.id, url=row.url, enabled=row.enabled,
                 interval_minutes=row.interval_minutes, linked_host_count=len(row.mappings or {}),
                 last_sync=row.last_sync.isoformat() if row.last_sync else None, last_error=row.last_error)]


def live_context(db, user, environment_id, question, context):
    if not re.search(r'\bzabbix\b|\bintegrations?\b', question, re.I):
        return context
    context['zabbix_help'] = 'Connection settings and API tokens are managed in Integrations > Connection settings. Review discovered hosts opens a searchable table with per-host import types. CPU, RAM, OS, hostname, IP and network port counts synchronize when collected items are supported. Never request or expose API tokens in chat.'
    if not assistant_config.section_allowed('integrations'):
        return context
    if not re.search(r'host|discover|import|test|connection|sync', question, re.I):
        return context
    from backend.main import environment_access
    from backend.zabbix import discover_hosts, test_zabbix_connection
    try:
        environment_access(db, user, environment_id, write=True)
        if re.search(r'\btest\b', question, re.I):
            context['zabbix_test'] = test_zabbix_connection(environment_id, user=user, db=db)
        if re.search(r'host|discover|import', question, re.I):
            hosts = discover_hosts(environment_id, user=user, db=db)
            context['zabbix_hosts'] = hosts[:500]
            context['zabbix_discovery'] = {'total': len(hosts), 'shown': min(len(hosts), 500), 'partial': len(hosts) > 500}
    except HTTPException as error:
        context['zabbix_status'] = {'available': False, 'message': error.detail}
    return context


def validate_discovered(changes, context):
    for change in changes:
        if not change['operation'].startswith('zabbix_'):
            continue
        fields = change['fields']
        sources = context.get('integrations', [])
        if not any(source['connection_id'] == fields['connection_id'] for source in sources):
            raise ValueError('Zabbix proposal references a connection outside the current snapshot')
        if change['operation'] == 'zabbix_import':
            available = {host['id'] for host in context.get('zabbix_hosts', []) if not host['imported']}
            if set(fields['host_ids']) - available:
                raise ValueError('Import only unlinked hosts discovered in the current environment')


def apply_action(db, user, environment, proposal):
    from backend.main import read_inventory
    from backend.zabbix import sync
    enforce_write()
    change = proposal['changes'][0]
    fields = change['fields']
    result = db.execute(update(Environment).where(Environment.id == environment.id, Environment.revision == proposal['revision'])
                        .values(revision=Environment.revision).execution_options(synchronize_session=False))
    if result.rowcount != 1:
        raise HTTPException(409, 'Client data changed. Request a new Zabbix proposal.')
    row = db.get(ZabbixIntegration, fields['connection_id'])
    if not row or row.environment_id != environment.id:
        raise HTTPException(409, 'Zabbix connection changed. Request a new proposal.')
    db.refresh(row, with_for_update=True)
    sync(db, row, fields['host_ids'] if change['operation'] == 'zabbix_import' else None,
         user=user, asset_types=fields['asset_types'])
    db.refresh(environment)
    return {'revision': environment.revision, 'data': read_inventory(db, environment.id)}
