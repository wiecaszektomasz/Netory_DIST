from datetime import date
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from backend.languages import available_languages


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=1, max_length=1024)


class EnvironmentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class EnvironmentRename(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class MembershipCreate(BaseModel):
    user_id: str = Field(min_length=1, max_length=36)
    role: str = Field(pattern="^(editor|viewer)$")


class MembershipUpdate(BaseModel):
    role: str = Field(pattern="^(editor|viewer)$")


class UserCreate(BaseModel):
    username: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=14, max_length=1024)
    is_admin: bool = False


class AssistantPermissionUpdate(BaseModel):
    assistant_write_enabled: bool = Field(strict=True)


class UserStatusUpdate(BaseModel):
    is_active: bool


class UserPasswordReset(BaseModel):
    password: str = Field(min_length=14, max_length=1024)


class UserPasswordChange(BaseModel):
    current_password: str = Field(min_length=1, max_length=1024)
    new_password: str = Field(min_length=14, max_length=1024)


class DashboardPreferences(BaseModel):
    metrics: list[Literal['assets', 'vlans', 'licenses', 'servers', 'networks', 'accounts', 'rooms', 'maintenance']] = Field(max_length=8)
    widgets: list[Literal['recent', 'licenses', 'warranties', 'status', 'types', 'locations', 'os', 'licenseUsage', 'completeness']] = Field(max_length=9)
    reminderDays: int = Field(default=90, ge=1, le=365)
    rowLimit: int = Field(default=6, ge=3, le=20)


class UserPreferencesUpdate(BaseModel):
    language: str | None = Field(default=None, min_length=2, max_length=35, pattern="^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$")

    @field_validator("language")
    @classmethod
    def installed_language(cls, value):
        if value is not None and value not in available_languages():
            raise ValueError("Choose an installed language")
        return value

    theme: str | None = Field(default=None, pattern="^(default|ocean|midnight)$")
    dashboard: DashboardPreferences | None = None
    environmentId: str | None = Field(default=None, min_length=1, max_length=36)


class LicenseInput(BaseModel):
    net_price: str | None = None
    cost_estimate_id: str | None = Field(default=None, max_length=36)
    product: str = Field(min_length=1, max_length=240)
    vendor: str | None = Field(default=None, max_length=240)
    license_key: str | None = Field(default=None, max_length=512)
    type: str | None = Field(default=None, max_length=80)
    seats: int | None = Field(default=None, ge=0)
    assigned: int | None = Field(default=None, ge=0)
    assigned_asset_ids: list[str] = Field(default_factory=list)
    expiry: date | None = None
    owner: str | None = Field(default=None, max_length=240)
    notes: str | None = None


class InventoryState(BaseModel):
    rooms: list[dict] | None = None
    racks: list[dict] | None = None
    assets: list[dict] = Field(default_factory=list)
    vlans: list[dict] = Field(default_factory=list)
    lans: list[dict] = Field(default_factory=list)
    wlans: list[dict] = Field(default_factory=list)
    stacks: list[dict] = Field(default_factory=list)
    clusters: list[dict] = Field(default_factory=list)
    lags: list[dict] = Field(default_factory=list)
    licenses: list[dict] = Field(default_factory=list)
    hypervisors: list[dict] = Field(default_factory=list)
    accounts: list[dict] = Field(default_factory=list)
    connections: list[dict] = Field(default_factory=list)

class LoginProtectionUpdate(BaseModel):
    enabled: bool = Field(strict=True)
    max_failed_attempts: int = Field(ge=1, le=100, strict=True)
    block_minutes: int = Field(ge=1, le=1440, strict=True)


class AuditRetentionUpdate(BaseModel):
    retention_days: int = Field(ge=1, le=3650, strict=True)


class SessionSettingsUpdate(BaseModel):
    idle_timeout_minutes: int = Field(ge=1, le=1440, strict=True)


class MapSettingsUpdate(BaseModel):
    layout: Literal['physical', 'elk']
