"""Resolve exact, unique inventory names only within the selected snapshot."""

REFERENCE_FIELDS = {
    'assets': {'hypervisorId': 'assets', 'hypervisorClusterId': 'clusters',
               'rackId': 'racks', 'backupUpsId': 'assets'},
    'licenses': {'assignedAssetIds': 'assets'},
    'racks': {'roomId': 'rooms'},
    'vlans': {'masterDeviceId': 'assets'},
    'wlans': {'parentDeviceId': 'assets', 'vlanInterfaceId': 'vlans'},
    'stacks': {'memberAssetIds': 'assets'},
    'clusters': {'memberAssetIds': 'assets'},
    'lags': {'deviceAId': 'assets', 'deviceBId': 'assets',
             'stackAId': 'stacks', 'stackBId': 'stacks'},
}


def resolve_import_references(state, changes):
    def resolve(section, value):
        if value in ('', None):
            return value
        records = state.get(section, [])
        if any(record['id'] == value for record in records):
            return value
        matches = [record['id'] for record in records
                   if record.get('name', '').strip().casefold() == value.strip().casefold()]
        if len(matches) != 1:
            reason = 'ambiguous' if matches else 'not found'
            raise ValueError(f'Inventory reference is {reason} in this environment; use an existing {section} record ID')
        return matches[0]

    for change in changes:
        fields = change['fields']
        for field, section in REFERENCE_FIELDS.get(change.get('section', 'assets'), {}).items():
            if field not in fields:
                continue
            value = fields[field]
            fields[field] = ([resolve(section, member) for member in value]
                             if isinstance(value, list) else resolve(section, value))
            if isinstance(fields[field], list) and len(fields[field]) != len(set(fields[field])):
                raise ValueError(f'Duplicate references in {field}')
        section = change.get('section', 'assets')
        parent = fields.get('parentInterface')
        if section in ('lans', 'wlans') and parent:
            field, target = ('vlanId', 'vlans') if parent['type'] == 'vlan' else ('deviceId', 'assets')
            parent[field] = resolve(target, parent[field])
        if section == 'lags':
            for field in ('membersA', 'membersB'):
                for member in fields.get(field, []):
                    member['deviceId'] = resolve('assets', member['deviceId'])
