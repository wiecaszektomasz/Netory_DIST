from datetime import datetime, timezone
from urllib.parse import urlsplit
from uuid import uuid4
from typing import Literal

import httpx
from cryptography.fernet import Fernet, InvalidToken
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field, SecretStr
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.audit import AuditedRoute
from backend.config import settings
from backend.db import get_db
from backend.models import AIProvider, AISettings, Environment
from backend.security import require_admin

router = APIRouter(prefix="/api/settings/ai", route_class=AuditedRoute, dependencies=[Depends(require_admin)])
ENDPOINTS = {"openrouter": "https://openrouter.ai/api/v1", "openai": "https://api.openai.com/v1", "anthropic": "https://api.anthropic.com/v1", "gemini": "https://generativelanguage.googleapis.com/v1beta"}


class ProviderInput(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    vendor: Literal["openai", "anthropic", "gemini", "openrouter", "compatible"]
    base_url: str = Field(default="", max_length=500)
    api_key: SecretStr | None = Field(default=None)
    remove_key: bool = False
    model: str = Field(default="", max_length=200)
    enabled: bool = False
    environment_ids: list[str] = Field(default_factory=list, max_length=1000)
    request_limit: int = Field(default=100, ge=1, le=10000, strict=True)


class DefaultInput(BaseModel):
    provider_id: str | None = None


def cipher():
    try:
        return Fernet(settings.ai_encryption_key.encode("ascii"))
    except (ValueError, UnicodeError):
        raise HTTPException(503, "AI key encryption is not configured on this server") from None


def endpoint(vendor, value):
    if vendor in ENDPOINTS:
        return ENDPOINTS[vendor]
    value = value.strip().rstrip("/")
    try:
        url = urlsplit(value)
        allowed = {host.strip().lower() for host in settings.ai_allowed_hosts.split(",") if host.strip()}
        if url.scheme != "https" or url.hostname not in allowed or url.username or url.password or url.query or url.fragment or url.port not in (None, 443):
            raise ValueError()
    except ValueError:
        raise HTTPException(422, "Use an HTTPS API URL on a server-approved host") from None
    return value


def public_provider(row, default_id):
    today = datetime.now(timezone.utc).date()
    return {"id": row.id, "name": row.name, "vendor": row.vendor, "base_url": row.base_url,
        "has_key": bool(row.api_key_encrypted), "model": row.model, "enabled": row.enabled,
        "environment_ids": row.environment_ids, "request_limit": row.request_limit,
        "models": row.models, "test_status": row.test_status, "tested_at": row.tested_at,
        "requests_today": row.requests_today if row.usage_date == today else 0,
        "total_requests": row.total_requests, "is_default": row.id == default_id}


def policy(db):
    row = db.scalar(select(AISettings).where(AISettings.id == 1).with_for_update())
    if row is None:
        row = AISettings(id=1)
        db.add(row)
        db.flush()
    return row


@router.get("/providers")
def list_ai_providers(db: Session = Depends(get_db)):
    config = db.get(AISettings, 1)
    return {"providers": [public_provider(row, config.default_provider_id if config else None)
        for row in db.scalars(select(AIProvider).order_by(AIProvider.name))],
        "environments": [{"id": row.id, "name": row.name} for row in db.scalars(select(Environment).order_by(Environment.name))],
        "allowed_hosts": [host.strip() for host in settings.ai_allowed_hosts.split(",") if host.strip()],
        "encryption_ready": bool(settings.ai_encryption_key),
        "allow_insecure_http": settings.ai_allow_insecure_http}


def save_provider(db, payload, row=None):
    config = policy(db)
    url = endpoint(payload.vendor, payload.base_url)
    name = payload.name.strip()
    model = payload.model.strip()
    if not name:
        raise HTTPException(422, "Connection name is required")
    if len(payload.environment_ids) != len(set(payload.environment_ids)):
        raise HTTPException(422, "Environment selection contains duplicates")
    existing = set(db.scalars(select(Environment.id).where(Environment.id.in_(payload.environment_ids))))
    if existing != set(payload.environment_ids):
        raise HTTPException(422, "Choose existing environments")
    key = payload.api_key.get_secret_value().strip() if payload.api_key is not None else ""
    if len(key) > 4096 or any(ord(char) < 33 or ord(char) > 126 for char in key):
        raise HTTPException(422, "API key contains spaces, hidden characters, or non-ASCII characters. Copy only the key, without quotes, from the provider.")
    if key and payload.remove_key:
        raise HTTPException(422, "Choose either replace or remove the key")
    encrypted = row.api_key_encrypted if row else None
    connection_changed = not row or row.vendor != payload.vendor or row.base_url != url or bool(key) or payload.remove_key
    if row and (row.vendor != payload.vendor or row.base_url != url):
        encrypted = None
    if payload.remove_key:
        encrypted = None
    elif key:
        encrypted = cipher().encrypt(key.encode()).decode()
    if payload.enabled and (not encrypted or not model):
        raise HTTPException(422, "Enabled connections require an API key and model")
    if not row:
        row = AIProvider(id=str(uuid4()), models=[], test_status="untested", requests_today=0, total_requests=0)
        db.add(row)
    for field, value in {"name": name, "vendor": payload.vendor, "base_url": url,
        "api_key_encrypted": encrypted, "model": model, "enabled": payload.enabled,
        "environment_ids": payload.environment_ids, "request_limit": payload.request_limit}.items():
        setattr(row, field, value)
    if connection_changed:
        row.models, row.test_status, row.tested_at = [], "untested", None
    if config.default_provider_id == row.id and not row.enabled:
        config.default_provider_id = None
    db.commit()
    return public_provider(row, config.default_provider_id)


@router.post("/providers", status_code=201)
def create_ai_provider(payload: ProviderInput, request: Request, db: Session = Depends(get_db)):
    require_secure_key_transport(request, payload)
    return save_provider(db, payload)


@router.put("/providers/{provider_id}")
def update_ai_provider(provider_id: str, payload: ProviderInput, request: Request, db: Session = Depends(get_db)):
    require_secure_key_transport(request, payload)
    row = db.get(AIProvider, provider_id)
    if not row:
        raise HTTPException(404, "AI connection not found")
    return save_provider(db, payload, row)


@router.delete("/providers/{provider_id}", status_code=204)
def delete_ai_provider(provider_id: str, db: Session = Depends(get_db)):
    config = policy(db)
    row = db.get(AIProvider, provider_id)
    if not row:
        raise HTTPException(404, "AI connection not found")
    if config.default_provider_id == provider_id:
        config.default_provider_id = None
        db.flush()
    db.delete(row)
    db.commit()
    return Response(status_code=204)


@router.put("/default")
def update_ai_default(payload: DefaultInput, db: Session = Depends(get_db)):
    config = policy(db)
    if payload.provider_id:
        row = db.get(AIProvider, payload.provider_id)
        if not row or not row.enabled or not row.api_key_encrypted or not row.model:
            raise HTTPException(422, "Choose an enabled connection with an API key and model")
    config.default_provider_id = payload.provider_id
    db.commit()
    return {"provider_id": config.default_provider_id}


def fetch_models(row, key):
    if not key or any(ord(char) < 33 or ord(char) > 126 for char in key):
        return [], "Saved API key contains spaces, hidden characters, or non-ASCII characters. Replace it with a fresh copy of the key, without quotes, from the provider."
    base = endpoint(row.vendor, row.base_url)
    headers = {"Authorization": f"Bearer {key}"}
    params = {}
    if row.vendor == "anthropic":
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01"}
        params = {"limit": 100}
    elif row.vendor == "gemini":
        headers = {"x-goog-api-key": key}
        params = {"pageSize": 1000}
    try:
        with httpx.Client(timeout=15, follow_redirects=False, trust_env=False) as client:
            response = client.get(base + "/models", headers=headers, params=params)
        if response.status_code in (401, 403):
            return [], "Authentication failed. Check the API key and account permissions."
        if response.status_code == 429:
            return [], "Provider rate limit reached. Try again later."
        if response.status_code != 200:
            return [], f"Provider returned HTTP {response.status_code}. Check the API URL and account."
        result = response.json()
        if row.vendor == "gemini":
            models = [item["name"].removeprefix("models/") for item in result.get("models", [])
                if "generateContent" in item.get("supportedGenerationMethods", [])]
        else:
            models = [item["id"] for item in result.get("data", [])]
        models = sorted({model for model in models if isinstance(model, str) and 0 < len(model) <= 200})
        return models, None if models else "Connected, but no usable models were returned."
    except (httpx.HTTPError, ValueError, KeyError, TypeError, AttributeError):
        # Provider error bodies may contain credentials; never relay or log them.
        return [], "Could not reach the provider or read its model list. Check the API URL and try again."


@router.post("/providers/{provider_id}/test")
def test_ai_provider(provider_id: str, db: Session = Depends(get_db)):
    row = db.scalar(select(AIProvider).where(AIProvider.id == provider_id).with_for_update())
    if not row or not row.api_key_encrypted:
        raise HTTPException(422, "Save an API key before testing")
    today = datetime.now(timezone.utc).date()
    if row.usage_date != today:
        row.usage_date, row.requests_today = today, 0
    if row.requests_today >= row.request_limit:
        raise HTTPException(429, "Daily request limit reached for this connection")
    try:
        key = cipher().decrypt(row.api_key_encrypted.encode()).decode()
    except (InvalidToken, UnicodeError):
        raise HTTPException(503, "Stored API key could not be decrypted") from None
    row.requests_today += 1
    row.total_requests += 1
    models, error = fetch_models(row, key)
    row.models, row.test_status = models, "failed" if error else "connected"
    row.tested_at = datetime.now(timezone.utc)
    db.commit()
    return {"ok": not error, "message": error or "Connected. Models loaded.", "models": models}


def require_secure_key_transport(request, payload):
    if payload.api_key and payload.api_key.get_secret_value() and request.url.scheme != "https" and not settings.ai_allow_insecure_http:
        raise HTTPException(422, "API keys require an HTTPS connection")
