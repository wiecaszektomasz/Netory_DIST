"""Add optional warranty expiry dates to assets."""
from alembic import op
import sqlalchemy as sa
revision = "0021_asset_warranty"
down_revision = "0020_device_kind"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assets", sa.Column("warranty_expiry", sa.Date(), nullable=True))


def downgrade():
    op.drop_column("assets", "warranty_expiry")
