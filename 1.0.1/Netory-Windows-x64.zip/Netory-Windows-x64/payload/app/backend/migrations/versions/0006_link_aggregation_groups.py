"""Add link aggregation groups.

Revision ID: 0006_link_aggregation_groups
Revises: 0005_device_stacks
"""
from alembic import op
import sqlalchemy as sa


revision = "0006_link_aggregation_groups"
down_revision = "0005_device_stacks"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "link_aggregation_groups",
        sa.Column("id", sa.String(length=80), nullable=False),
        sa.Column("environment_id", sa.String(length=36), nullable=False),
        sa.Column("name", sa.String(length=120), nullable=False),
        sa.Column("device_a_id", sa.String(length=80), nullable=False),
        sa.Column("ports_a", sa.JSON(), nullable=False),
        sa.Column("device_b_id", sa.String(length=80), nullable=False),
        sa.Column("ports_b", sa.JSON(), nullable=False),
        sa.ForeignKeyConstraint(["environment_id"], ["environments.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(
            ["device_a_id", "environment_id"],
            ["assets.id", "assets.environment_id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["device_b_id", "environment_id"],
            ["assets.id", "assets.environment_id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id", "environment_id"),
        sa.UniqueConstraint("environment_id", "name"),
    )
    op.create_index(
        op.f("ix_link_aggregation_groups_environment_id"),
        "link_aggregation_groups",
        ["environment_id"],
        unique=False,
    )


def downgrade():
    op.drop_index(op.f("ix_link_aggregation_groups_environment_id"), table_name="link_aggregation_groups")
    op.drop_table("link_aggregation_groups")
