"""Allow link aggregation endpoints to use device stacks.

Revision ID: 0007_stack_lag_endpoints
Revises: 0006_link_aggregation_groups
"""
from alembic import op
import sqlalchemy as sa


revision = "0007_stack_lag_endpoints"
down_revision = "0006_link_aggregation_groups"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("link_aggregation_groups") as batch_op:
        batch_op.add_column(sa.Column("stack_a_id", sa.String(length=80), nullable=True))
        batch_op.add_column(sa.Column("stack_b_id", sa.String(length=80), nullable=True))
        batch_op.create_foreign_key(
            "fk_lag_stack_a_environment",
            "device_stacks",
            ["stack_a_id", "environment_id"],
            ["id", "environment_id"],
            ondelete="CASCADE",
        )
        batch_op.create_foreign_key(
            "fk_lag_stack_b_environment",
            "device_stacks",
            ["stack_b_id", "environment_id"],
            ["id", "environment_id"],
            ondelete="CASCADE",
        )

    connection = op.get_bind()
    lags = sa.table(
        "link_aggregation_groups",
        sa.column("id", sa.String(length=80)),
        sa.column("environment_id", sa.String(length=36)),
        sa.column("device_a_id", sa.String(length=80)),
        sa.column("ports_a", sa.JSON()),
        sa.column("device_b_id", sa.String(length=80)),
        sa.column("ports_b", sa.JSON()),
    )
    for lag in connection.execute(sa.select(
        lags.c.id, lags.c.environment_id, lags.c.device_a_id,
        lags.c.ports_a, lags.c.device_b_id, lags.c.ports_b
    )).all():
        ports_a = lag.ports_a
        ports_b = lag.ports_b
        if ports_a and not isinstance(ports_a[0], dict):
            ports_a = [{"deviceId": lag.device_a_id, "port": port} for port in ports_a]
        if ports_b and not isinstance(ports_b[0], dict):
            ports_b = [{"deviceId": lag.device_b_id, "port": port} for port in ports_b]
        connection.execute(
            lags.update().where(
                sa.and_(lags.c.id == lag.id, lags.c.environment_id == lag.environment_id)
            ).values(ports_a=ports_a, ports_b=ports_b)
        )


def downgrade():
    with op.batch_alter_table("link_aggregation_groups") as batch_op:
        batch_op.drop_constraint("fk_lag_stack_b_environment", type_="foreignkey")
        batch_op.drop_constraint("fk_lag_stack_a_environment", type_="foreignkey")
        batch_op.drop_column("stack_b_id")
        batch_op.drop_column("stack_a_id")
