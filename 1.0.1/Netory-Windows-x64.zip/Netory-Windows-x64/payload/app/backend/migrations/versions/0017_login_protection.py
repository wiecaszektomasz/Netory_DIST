"""Persist login blocking and superuser-managed policy."""
from alembic import op
import sqlalchemy as sa

revision = "0017_login_protection"
down_revision = "0016_wlan_passwords"
branch_labels = None
depends_on = None


def upgrade():
    policy = op.create_table(
        "login_protection_settings",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("max_failed_attempts", sa.Integer(), nullable=False),
        sa.Column("block_minutes", sa.Integer(), nullable=False),
    )
    op.bulk_insert(policy, [{"id": 1, "enabled": True, "max_failed_attempts": 5, "block_minutes": 15}])
    op.create_table(
        "login_attempts",
        sa.Column("username_hash", sa.String(64), primary_key=True),
        sa.Column("failed_attempts", sa.Integer(), nullable=False),
        sa.Column("reset_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("blocked_until", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_login_attempts_reset_at", "login_attempts", ["reset_at"])


def downgrade():
    op.drop_index("ix_login_attempts_reset_at", table_name="login_attempts")
    op.drop_table("login_attempts")
    op.drop_table("login_protection_settings")
