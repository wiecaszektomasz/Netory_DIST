"""Add custom peripheral device kind."""
from alembic import op
import sqlalchemy as sa
revision = "0020_device_kind"
down_revision = "0019_activity_messages"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assets", sa.Column("device_kind", sa.String(120), nullable=True))


def downgrade():
    op.drop_column("assets", "device_kind")
