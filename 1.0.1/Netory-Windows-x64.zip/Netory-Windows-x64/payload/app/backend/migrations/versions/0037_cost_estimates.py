"""Client cost estimates and independent inventory pricing."""
from alembic import op
import sqlalchemy as sa

revision = '0037_cost_estimates'
down_revision = '0036_asset_trash'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('cost_estimates',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name', sa.String(240), nullable=False),
        sa.Column('project_number', sa.String(120), nullable=False, server_default=''),
        sa.Column('valid_until', sa.Date(), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False, server_default='PLN'),
        sa.Column('tax_basis_points', sa.Integer(), nullable=False, server_default='2300'),
        sa.Column('custom_items', sa.JSON(), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False, server_default='1'),
        sa.UniqueConstraint('environment_id', 'name'))
    op.create_index('ix_cost_estimates_environment_id', 'cost_estimates', ['environment_id'])
    op.create_table('cost_pricing',
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('section', sa.String(16), primary_key=True),
        sa.Column('record_id', sa.String(80), primary_key=True),
        sa.Column('estimate_id', sa.String(36), sa.ForeignKey('cost_estimates.id', ondelete='SET NULL'), nullable=True),
        sa.Column('net_price', sa.String(24), nullable=True))
    op.create_index('ix_cost_pricing_estimate_id', 'cost_pricing', ['estimate_id'])


def downgrade():
    op.drop_table('cost_pricing')
    op.drop_table('cost_estimates')
