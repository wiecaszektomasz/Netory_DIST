"""Optional room assignment for every asset."""
from alembic import op
import sqlalchemy as sa

revision = '0044_asset_rooms'
down_revision = '0043_notes_board'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('assets', sa.Column('room_id', sa.String(80), nullable=True))


def downgrade():
    op.drop_column('assets', 'room_id')
