"""Private per-user report configurations."""
from alembic import op
import sqlalchemy as sa

revision = '0046_report_configurations'
down_revision = '0045_cabinet_asset_rooms'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('report_configurations',
        sa.Column('user_id', sa.String(36), sa.ForeignKey('users.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('items', sa.JSON(), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False))
    op.create_index('ix_report_configurations_environment_id', 'report_configurations', ['environment_id'])


def downgrade():
    op.drop_table('report_configurations')
