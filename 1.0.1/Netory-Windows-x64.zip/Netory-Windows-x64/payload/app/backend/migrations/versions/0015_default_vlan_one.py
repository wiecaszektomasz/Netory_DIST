"""Create the predefined default VLAN 1.

Revision ID: 0015_default_vlan_one
Revises: 0014_asset_port_vlans
"""
from uuid import uuid4

from alembic import op
import sqlalchemy as sa


revision = "0015_default_vlan_one"
down_revision = "0014_asset_port_vlans"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("vlans", sa.Column("is_default", sa.Boolean(), nullable=False, server_default=sa.false()))
    connection = op.get_bind()
    environments = sa.table("environments", sa.column("id", sa.String()))
    vlans = sa.table(
        "vlans",
        sa.column("id", sa.String()),
        sa.column("environment_id", sa.String()),
        sa.column("name", sa.String()),
        sa.column("vlan_number", sa.Integer()),
        sa.column("master_device_id", sa.String()),
        sa.column("purpose", sa.String()),
        sa.column("is_default", sa.Boolean()),
    )
    assets = sa.table(
        "assets",
        sa.column("id", sa.String()),
        sa.column("environment_id", sa.String()),
        sa.column("port_count", sa.Integer()),
        sa.column("port_vlans", sa.JSON()),
    )
    for (environment_id,) in connection.execute(sa.select(environments.c.id)):
        existing = connection.execute(
            sa.select(vlans.c.id)
            .where(
                vlans.c.environment_id == environment_id,
                vlans.c.vlan_number == 1,
                vlans.c.master_device_id.is_(None),
            )
        ).first()
        if existing:
            connection.execute(
                vlans.update()
                .where(vlans.c.environment_id == environment_id, vlans.c.id == existing.id)
                .values(is_default=True)
            )
        else:
            connection.execute(vlans.insert().values(
                id=str(uuid4()),
                environment_id=environment_id,
                name="Default VLAN",
                vlan_number=1,
                master_device_id=None,
                purpose="Predefined default VLAN; untagged on ports by default",
                is_default=True,
            ))
    for asset in connection.execute(sa.select(
        assets.c.id, assets.c.environment_id, assets.c.port_count, assets.c.port_vlans
    )):
        port_vlans = asset.port_vlans or {}
        for port in range(1, asset.port_count + 1):
            config = port_vlans.setdefault(str(port), {"untaggedVlan": 1, "taggedVlans": []})
            if config.get("untaggedVlan") is None:
                config["untaggedVlan"] = 1
                config["taggedVlans"] = [vlan for vlan in config.get("taggedVlans", []) if vlan != 1]
        connection.execute(
            assets.update()
            .where(assets.c.id == asset.id, assets.c.environment_id == asset.environment_id)
            .values(port_vlans=port_vlans)
        )


def downgrade():
    op.drop_column("vlans", "is_default")
