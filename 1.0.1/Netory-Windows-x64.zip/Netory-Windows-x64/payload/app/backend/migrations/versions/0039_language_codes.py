"""Allow language codes including regional variants."""
from alembic import op
import sqlalchemy as sa

revision = '0039_language_codes'
down_revision = '0038_user_language'
branch_labels = None
depends_on = None


def upgrade():
    # SQLite does not enforce VARCHAR lengths; avoid rebuilding the referenced users table.
    if op.get_bind().dialect.name != 'sqlite':
        op.alter_column('users', 'language', existing_type=sa.String(2), type_=sa.String(35), existing_nullable=False, existing_server_default='en')


def downgrade():
    op.execute(sa.text("UPDATE users SET language = 'en' WHERE length(language) > 2"))
    if op.get_bind().dialect.name != 'sqlite':
        op.alter_column('users', 'language', existing_type=sa.String(35), type_=sa.String(2), existing_nullable=False, existing_server_default='en')
