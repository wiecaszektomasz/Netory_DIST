"""Add device stacks and stack membership.

Revision ID: 0005_device_stacks
Revises: 0004_lan_wlan_networks
"""
from alembic import op
import sqlalchemy as sa


revision = "0005_device_stacks"
down_revision = "0004_lan_wlan_networks"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "device_stacks",
        sa.Column("id", sa.String(length=80), nullable=False),
        sa.Column("environment_id", sa.String(length=36), nullable=False),
        sa.Column("name", sa.String(length=240), nullable=False),
        sa.Column("device_type", sa.String(length=80), nullable=False),
        sa.ForeignKeyConstraint(["environment_id"], ["environments.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id", "environment_id"),
        sa.UniqueConstraint("environment_id", "name"),
    )
    op.create_index(op.f("ix_device_stacks_environment_id"), "device_stacks", ["environment_id"], unique=False)
    op.create_table(
        "device_stack_members",
        sa.Column("stack_id", sa.String(length=80), nullable=False),
        sa.Column("asset_id", sa.String(length=80), nullable=False),
        sa.Column("environment_id", sa.String(length=36), nullable=False),
        sa.Column("member_order", sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(
            ["stack_id", "environment_id"],
            ["device_stacks.id", "device_stacks.environment_id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["asset_id", "environment_id"],
            ["assets.id", "assets.environment_id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("stack_id", "asset_id", "environment_id"),
        sa.UniqueConstraint("environment_id", "asset_id"),
        sa.UniqueConstraint("environment_id", "stack_id", "member_order"),
    )
    op.create_index(
        op.f("ix_device_stack_members_environment_id"),
        "device_stack_members",
        ["environment_id"],
        unique=False,
    )


def downgrade():
    op.drop_index(op.f("ix_device_stack_members_environment_id"), table_name="device_stack_members")
    op.drop_table("device_stack_members")
    op.drop_index(op.f("ix_device_stacks_environment_id"), table_name="device_stacks")
    op.drop_table("device_stacks")
