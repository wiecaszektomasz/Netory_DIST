"""Physical-server management-controller inventory."""
from alembic import op
import sqlalchemy as sa

revision = '0042_management_controller'
down_revision = '0041_zabbix_integrations'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('assets', sa.Column('management_controller', sa.JSON(), nullable=True))


def downgrade():
    op.drop_column('assets', 'management_controller')
