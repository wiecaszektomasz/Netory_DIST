"""Add exact WLAN device and VLAN references."""
from alembic import op
import sqlalchemy as sa
revision = "0026_wlan_device_vlan"
down_revision = "0025_strict_network_addresses"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("network_definitions", sa.Column("parent_device_id", sa.String(80), nullable=True))
    op.add_column("network_definitions", sa.Column("vlan_interface_id", sa.String(80), nullable=True))
    connection = op.get_bind()
    networks = sa.table("network_definitions", sa.column("id", sa.String), sa.column("environment_id", sa.String), sa.column("network_type", sa.String), sa.column("vlan_number", sa.Integer), sa.column("vlan_interface_id", sa.String))
    vlans = sa.table("vlans", sa.column("id", sa.String), sa.column("environment_id", sa.String), sa.column("vlan_number", sa.Integer))
    for record_id, environment_id, number in connection.execute(sa.select(networks.c.id, networks.c.environment_id, networks.c.vlan_number).where(networks.c.network_type == "WLAN", networks.c.vlan_number.is_not(None))).all():
        matches = connection.execute(sa.select(vlans.c.id).where(vlans.c.environment_id == environment_id, vlans.c.vlan_number == number)).scalars().all()
        if len(matches) == 1:
            connection.execute(networks.update().where(networks.c.id == record_id, networks.c.environment_id == environment_id).values(vlan_interface_id=matches[0]))


def downgrade():
    with op.batch_alter_table("network_definitions") as batch:
        batch.drop_column("vlan_interface_id")
        batch.drop_column("parent_device_id")
