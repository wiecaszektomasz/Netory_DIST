"""Environment-local rooms and cabinet room assignments."""
from alembic import op
import sqlalchemy as sa
revision = '0031_rooms'
down_revision = '0030_rack_cabinets'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('rooms',
        sa.Column('id', sa.String(80), primary_key=True),
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('name', sa.String(240), nullable=False))
    op.add_column('rack_cabinets', sa.Column('room_id', sa.String(80)))


def downgrade():
    op.drop_column('rack_cabinets', 'room_id')
    op.drop_table('rooms')
