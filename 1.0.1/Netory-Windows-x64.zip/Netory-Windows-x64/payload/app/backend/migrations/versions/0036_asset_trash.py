"""Retain deleted assets until a superadmin permanently removes them."""
from alembic import op
import sqlalchemy as sa

revision = '0036_asset_trash'
down_revision = '0035_dashboard_preferences'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('trashed_assets',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('asset_id', sa.String(80), nullable=False),
        sa.Column('environment_id', sa.String(36), nullable=False),
        sa.Column('environment_name', sa.String(120), nullable=False),
        sa.Column('name', sa.String(240), nullable=False),
        sa.Column('type', sa.String(80), nullable=False),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('deleted_by_id', sa.String(36), nullable=True),
        sa.Column('deleted_by_username', sa.String(120), nullable=False),
        sa.Column('deleted_by_admin', sa.Boolean(), nullable=False),
        sa.Column('snapshot', sa.JSON(), nullable=False),
    )
    op.create_index('ix_trashed_assets_environment_id', 'trashed_assets', ['environment_id'])
    op.create_index('ix_trashed_assets_deleted_at', 'trashed_assets', ['deleted_at'])


def downgrade():
    op.drop_table('trashed_assets')
