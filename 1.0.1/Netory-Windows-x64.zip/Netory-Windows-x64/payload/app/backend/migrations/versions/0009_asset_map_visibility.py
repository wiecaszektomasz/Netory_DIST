"""Allow assets without connections to be shown on the network map.

Revision ID: 0009_asset_map_visibility
Revises: 0008_vlan_ids_per_master_device
"""
from alembic import op
import sqlalchemy as sa


revision = "0009_asset_map_visibility"
down_revision = "0008_vlan_ids_per_master_device"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "assets",
        sa.Column("show_on_map", sa.Boolean(), server_default=sa.false(), nullable=False),
    )


def downgrade():
    op.drop_column("assets", "show_on_map")
