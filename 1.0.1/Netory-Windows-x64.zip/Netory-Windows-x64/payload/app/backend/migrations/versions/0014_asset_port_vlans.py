"""Store tagged and untagged VLAN configuration per asset port.

Revision ID: 0014_asset_port_vlans
Revises: 0013_asset_port_types
"""
from alembic import op
import sqlalchemy as sa


revision = "0014_asset_port_vlans"
down_revision = "0013_asset_port_types"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assets", sa.Column("port_vlans", sa.JSON(), nullable=True))


def downgrade():
    op.drop_column("assets", "port_vlans")
