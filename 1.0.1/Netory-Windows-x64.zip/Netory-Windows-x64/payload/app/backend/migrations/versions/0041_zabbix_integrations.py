"""Client-scoped Zabbix data sources."""
from alembic import op
import sqlalchemy as sa
revision = '0041_zabbix_integrations'
down_revision = '0040_map_settings'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('zabbix_integrations',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), nullable=False, unique=True),
        sa.Column('url', sa.String(500), nullable=False),
        sa.Column('token_encrypted', sa.Text(), nullable=False),
        sa.Column('enabled', sa.Boolean(), nullable=False),
        sa.Column('interval_minutes', sa.Integer(), nullable=False),
        sa.Column('mappings', sa.JSON(), nullable=False),
        sa.Column('last_sync', sa.DateTime(timezone=True)),
        sa.Column('last_error', sa.String(240)))


def downgrade():
    op.drop_table('zabbix_integrations')
