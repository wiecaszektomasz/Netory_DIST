"""Normalize stored host CIDRs to network addresses without changing their ranges."""
from ipaddress import ip_network
from alembic import op
import sqlalchemy as sa

revision = "0025_strict_network_addresses"
down_revision = "0024_network_parent_interface"
branch_labels = None
depends_on = None


def upgrade():
    connection = op.get_bind()
    changed_environments = set()
    for name in ("network_definitions", "vlans"):
        table = sa.table(name, sa.column("id", sa.String), sa.column("environment_id", sa.String), sa.column("network", sa.String))
        rows = list(connection.execute(sa.select(table.c.id, table.c.environment_id, table.c.network)))
        for record_id, environment_id, value in rows:
            if not value or "/" not in value:
                continue
            try:
                correct = str(ip_network(value, strict=False))
            except ValueError:
                continue
            if value != correct:
                connection.execute(table.update().where(table.c.id == record_id, table.c.environment_id == environment_id).values(network=correct))
                changed_environments.add(environment_id)
    if changed_environments:
        environments = sa.table("environments", sa.column("id", sa.String), sa.column("revision", sa.Integer))
        connection.execute(environments.update().where(environments.c.id.in_(changed_environments)).values(revision=environments.c.revision + 1))


def downgrade():
    # The previous host spelling cannot be recovered; subnet ranges are unchanged.
    pass
