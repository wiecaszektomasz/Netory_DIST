"""Add per-user application theme preferences.

Revision ID: 0012_user_preferences
Revises: 0011_lag_aggregation_type
"""
from alembic import op
import sqlalchemy as sa


revision = "0012_user_preferences"
down_revision = "0011_lag_aggregation_type"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "users",
        sa.Column("theme", sa.String(length=16), nullable=False, server_default="default"),
    )


def downgrade():
    op.drop_column("users", "theme")
