"""Add physical server clusters and virtual server cluster assignments."""
from alembic import op
import sqlalchemy as sa

revision = "0022_server_clusters"
down_revision = "0021_asset_warranty"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assets", sa.Column("hypervisor_cluster_id", sa.String(80), nullable=True))
    op.create_table(
        "server_clusters",
        sa.Column("id", sa.String(80), nullable=False),
        sa.Column("environment_id", sa.String(36), nullable=False),
        sa.Column("name", sa.String(240), nullable=False),
        sa.Column("show_on_map", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("location", sa.String(240), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(["environment_id"], ["environments.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id", "environment_id"),
        sa.UniqueConstraint("environment_id", "name"),
    )
    op.create_index("ix_server_clusters_environment_id", "server_clusters", ["environment_id"])
    op.create_table(
        "server_cluster_members",
        sa.Column("cluster_id", sa.String(80), nullable=False),
        sa.Column("asset_id", sa.String(80), nullable=False),
        sa.Column("environment_id", sa.String(36), nullable=False),
        sa.Column("member_order", sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(["cluster_id", "environment_id"], ["server_clusters.id", "server_clusters.environment_id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["asset_id", "environment_id"], ["assets.id", "assets.environment_id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("cluster_id", "asset_id", "environment_id"),
        sa.UniqueConstraint("environment_id", "asset_id"),
        sa.UniqueConstraint("environment_id", "cluster_id", "member_order"),
    )
    op.create_index("ix_server_cluster_members_environment_id", "server_cluster_members", ["environment_id"])


def downgrade():
    op.drop_table("server_cluster_members")
    op.drop_table("server_clusters")
    op.drop_column("assets", "hypervisor_cluster_id")
