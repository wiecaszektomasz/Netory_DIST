"""Allow VLAN IDs to repeat across different master devices.

Revision ID: 0008_vlan_ids_per_master_device
Revises: 0007_stack_lag_endpoints
"""
from alembic import op
import sqlalchemy as sa


revision = "0008_vlan_ids_per_master_device"
down_revision = "0007_stack_lag_endpoints"
branch_labels = None
depends_on = None


def upgrade():
    connection = op.get_bind()
    unique_constraints = sa.inspect(connection).get_unique_constraints("vlans")
    existing_name = next(
        constraint["name"]
        for constraint in unique_constraints
        if constraint["column_names"] == ["environment_id", "vlan_number"]
    )
    with op.batch_alter_table(
        "vlans",
        naming_convention={"uq": "uq_%(table_name)s_%(column_0_name)s"},
    ) as batch_op:
        batch_op.drop_constraint(existing_name or "uq_vlans_environment_id", type_="unique")
        batch_op.create_unique_constraint(
            "uq_vlans_environment_number_master",
            ["environment_id", "vlan_number", "master_device_id"],
        )


def downgrade():
    with op.batch_alter_table(
        "vlans",
        naming_convention={"uq": "uq_%(table_name)s_%(column_0_name)s"},
    ) as batch_op:
        batch_op.drop_constraint("uq_vlans_environment_number_master", type_="unique")
        batch_op.create_unique_constraint(
            "uq_vlans_environment_id",
            ["environment_id", "vlan_number"],
        )
