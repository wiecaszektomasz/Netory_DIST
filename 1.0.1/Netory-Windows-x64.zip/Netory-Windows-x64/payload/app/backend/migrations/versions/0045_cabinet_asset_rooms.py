"""Cabinet placement is the single source of room assignment."""
from alembic import op
import sqlalchemy as sa

revision = '0045_cabinet_asset_rooms'
down_revision = '0044_asset_rooms'
branch_labels = None
depends_on = None


def upgrade():
    assets = sa.table('assets', sa.column('rack_id'), sa.column('room_id'))
    op.execute(assets.update().where(assets.c.rack_id.is_not(None), assets.c.rack_id != '').values(room_id=None))


def downgrade():
    # Redundant room assignments cannot be reconstructed; cabinet membership remains.
    pass
