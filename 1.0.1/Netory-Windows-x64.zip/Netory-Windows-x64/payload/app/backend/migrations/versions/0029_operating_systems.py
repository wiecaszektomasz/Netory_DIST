"""Operating system catalog and server lifecycle metadata."""
from alembic import op
import sqlalchemy as sa

revision = '0029_operating_systems'
down_revision = '0028_assistant_write_permission'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('operating_systems',
        sa.Column('id', sa.String(80), primary_key=True),
        sa.Column('name', sa.String(240), nullable=False, unique=True),
        sa.Column('family', sa.String(16), nullable=False),
        sa.Column('eol', sa.Date()),
        sa.Column('support_notes', sa.String(1000)),
        sa.Column('source_url', sa.String(1000)))
    op.add_column('assets', sa.Column('os_catalog_id', sa.String(80)))
    op.add_column('assets', sa.Column('os_family', sa.String(16)))
    op.add_column('assets', sa.Column('os_eol', sa.Date()))


def downgrade():
    op.drop_column('assets', 'os_eol')
    op.drop_column('assets', 'os_family')
    op.drop_column('assets', 'os_catalog_id')
    op.drop_table('operating_systems')
