"""Add a static or dynamic mode to link aggregation groups.

Revision ID: 0011_lag_aggregation_type
Revises: 0010_vm_map_visibility
"""
from alembic import op
import sqlalchemy as sa


revision = "0011_lag_aggregation_type"
down_revision = "0010_vm_map_visibility"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "link_aggregation_groups",
        sa.Column("aggregation_type", sa.String(length=16), nullable=False, server_default="Static"),
    )


def downgrade():
    op.drop_column("link_aggregation_groups", "aggregation_type")
