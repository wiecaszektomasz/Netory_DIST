"""Add configurable session inactivity timeout, preserving existing sessions."""
from alembic import op
import sqlalchemy as sa
revision = "0023_session_timeout"
down_revision = "0022_server_clusters"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("user_sessions", sa.Column("last_activity_at", sa.DateTime(timezone=True), nullable=True))
    op.execute(sa.text("UPDATE user_sessions SET last_activity_at = CURRENT_TIMESTAMP"))
    with op.batch_alter_table("user_sessions") as batch:
        batch.alter_column("last_activity_at", existing_type=sa.DateTime(timezone=True), nullable=False)
    table = op.create_table("session_settings", sa.Column("id", sa.Integer(), primary_key=True), sa.Column("idle_timeout_minutes", sa.Integer(), nullable=False))
    op.bulk_insert(table, [{"id": 1, "idle_timeout_minutes": 30}])


def downgrade():
    op.drop_table("session_settings")
    with op.batch_alter_table("user_sessions") as batch:
        batch.drop_column("last_activity_at")
