"""Add LAN and WLAN network inventory records.

Revision ID: 0004_lan_wlan_networks
Revises: 0003_asset_internet_ports
"""
from alembic import op
import sqlalchemy as sa


revision = "0004_lan_wlan_networks"
down_revision = "0003_asset_internet_ports"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "network_definitions",
        sa.Column("id", sa.String(length=80), nullable=False),
        sa.Column("environment_id", sa.String(length=36), nullable=False),
        sa.Column("network_type", sa.String(length=8), nullable=False),
        sa.Column("name", sa.String(length=240), nullable=False),
        sa.Column("ssid", sa.String(length=240), nullable=True),
        sa.Column("security", sa.String(length=80), nullable=True),
        sa.Column("auth_server", sa.String(length=240), nullable=True),
        sa.Column("network", sa.String(length=120), nullable=True),
        sa.Column("gateway", sa.String(length=64), nullable=True),
        sa.Column("dns_servers", sa.Text(), nullable=True),
        sa.Column("dhcp", sa.Text(), nullable=True),
        sa.Column("vlan_number", sa.Integer(), nullable=True),
        sa.Column("location", sa.String(length=240), nullable=True),
        sa.Column("purpose", sa.String(length=240), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(["environment_id"], ["environments.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id", "environment_id"),
        sa.UniqueConstraint("environment_id", "network_type", "name"),
    )
    op.create_index(
        op.f("ix_network_definitions_environment_id"),
        "network_definitions",
        ["environment_id"],
        unique=False,
    )


def downgrade():
    op.drop_index(op.f("ix_network_definitions_environment_id"), table_name="network_definitions")
    op.drop_table("network_definitions")
