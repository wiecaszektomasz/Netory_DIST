"""Rack cabinets and physical asset placements."""
from alembic import op
import sqlalchemy as sa
revision = '0030_rack_cabinets'
down_revision = '0029_operating_systems'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('rack_cabinets',
        sa.Column('id', sa.String(80), primary_key=True),
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('name', sa.String(240), nullable=False),
        sa.Column('capacity_u', sa.Integer(), nullable=False),
        sa.Column('location', sa.String(240)))
    op.add_column('assets', sa.Column('rack_enabled', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('assets', sa.Column('rack_units', sa.Integer()))
    op.add_column('assets', sa.Column('rack_id', sa.String(80)))
    op.add_column('assets', sa.Column('rack_start_u', sa.Integer()))


def downgrade():
    for column in ['rack_start_u', 'rack_id', 'rack_units', 'rack_enabled']:
        op.drop_column('assets', column)
    op.drop_table('rack_cabinets')
