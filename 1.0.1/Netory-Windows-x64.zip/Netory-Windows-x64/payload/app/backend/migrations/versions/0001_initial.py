"""Initial Stackroom schema.

Revision ID: 0001_initial
Revises:
"""
from alembic import op
import sqlalchemy as sa


revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("username", sa.String(120), nullable=False),
        sa.Column("password_hash", sa.String(512), nullable=False),
        sa.Column("is_admin", sa.Boolean(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("username"),
    )
    op.create_index("ix_users_username", "users", ["username"])
    op.create_table(
        "environments",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(80), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "user_sessions",
        sa.Column("token_hash", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_user_sessions_user_id", "user_sessions", ["user_id"])
    op.create_index("ix_user_sessions_expires_at", "user_sessions", ["expires_at"])
    op.create_table(
        "environment_memberships",
        sa.Column("id", sa.Integer(), autoincrement=True, primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), nullable=False),
        sa.Column("role", sa.String(16), nullable=False),
        sa.UniqueConstraint("user_id", "environment_id"),
    )
    op.create_index("ix_environment_memberships_user_id", "environment_memberships", ["user_id"])
    op.create_index("ix_environment_memberships_environment_id", "environment_memberships", ["environment_id"])
    op.create_table(
        "assets",
        sa.Column("id", sa.String(80), primary_key=True),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("name", sa.String(240), nullable=False),
        sa.Column("type", sa.String(80), nullable=False),
        sa.Column("status", sa.String(40), nullable=False),
        sa.Column("hostname", sa.String(240)),
        sa.Column("manufacturer", sa.String(240)),
        sa.Column("serial", sa.String(160)),
        sa.Column("location", sa.String(240)),
        sa.Column("ip", sa.String(64)),
        sa.Column("port_count", sa.Integer(), nullable=False),
        sa.Column("cpu", sa.String(240)),
        sa.Column("ram", sa.String(160)),
        sa.Column("storage", sa.String(240)),
        sa.Column("os", sa.String(240)),
        sa.Column("hypervisor", sa.String(240)),
        sa.Column("hypervisor_id", sa.String(80)),
        sa.Column("vlan", sa.String(120)),
        sa.Column("notes", sa.Text()),
        sa.UniqueConstraint("environment_id", "name"),
    )
    op.create_index("ix_assets_environment_id", "assets", ["environment_id"])
    op.create_table(
        "vlans",
        sa.Column("id", sa.String(80), primary_key=True),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("name", sa.String(240), nullable=False),
        sa.Column("vlan_number", sa.Integer(), nullable=False),
        sa.Column("network", sa.String(120)),
        sa.Column("gateway", sa.String(64)),
        sa.Column("master_device_id", sa.String(80)),
        sa.Column("location", sa.String(240)),
        sa.Column("purpose", sa.String(240)),
        sa.Column("notes", sa.Text()),
        sa.UniqueConstraint("environment_id", "vlan_number"),
    )
    op.create_index("ix_vlans_environment_id", "vlans", ["environment_id"])
    op.create_table(
        "licenses",
        sa.Column("id", sa.String(80), primary_key=True),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("product", sa.String(240), nullable=False),
        sa.Column("vendor", sa.String(240)),
        sa.Column("license_key", sa.String(512)),
        sa.Column("type", sa.String(80)),
        sa.Column("seats", sa.Integer()),
        sa.Column("assigned", sa.Integer()),
        sa.Column("expiry", sa.Date()),
        sa.Column("owner", sa.String(240)),
        sa.Column("notes", sa.Text()),
    )
    op.create_index("ix_licenses_environment_id", "licenses", ["environment_id"])
    op.create_table(
        "hypervisors",
        sa.Column("id", sa.String(80), primary_key=True),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("name", sa.String(240), nullable=False),
        sa.Column("platform", sa.String(120), nullable=False),
        sa.Column("version", sa.String(120)),
        sa.Column("management_ip", sa.String(64)),
        sa.Column("cluster", sa.String(240)),
        sa.Column("location", sa.String(240)),
        sa.Column("capacity", sa.String(240)),
        sa.Column("notes", sa.Text()),
    )
    op.create_index("ix_hypervisors_environment_id", "hypervisors", ["environment_id"])
    op.create_table(
        "special_accounts",
        sa.Column("id", sa.String(80), primary_key=True),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("name", sa.String(240), nullable=False),
        sa.Column("system", sa.String(240), nullable=False),
        sa.Column("username", sa.String(240)),
        sa.Column("account_type", sa.String(80)),
        sa.Column("owner", sa.String(240)),
        sa.Column("vault", sa.String(240)),
        sa.Column("rotation", sa.Date()),
        sa.Column("notes", sa.Text()),
    )
    op.create_index("ix_special_accounts_environment_id", "special_accounts", ["environment_id"])
    op.create_table(
        "network_connections",
        sa.Column("id", sa.String(80), primary_key=True),
        sa.Column("environment_id", sa.String(36), sa.ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("device_a_id", sa.String(80), nullable=False),
        sa.Column("port_a", sa.Integer(), nullable=False),
        sa.Column("device_b_id", sa.String(80), nullable=False),
        sa.Column("port_b", sa.Integer(), nullable=False),
        sa.UniqueConstraint("environment_id", "device_a_id", "port_a"),
        sa.UniqueConstraint("environment_id", "device_b_id", "port_b"),
    )
    op.create_index("ix_network_connections_environment_id", "network_connections", ["environment_id"])


def downgrade():
    op.drop_table("network_connections")
    op.drop_index("ix_special_accounts_environment_id", table_name="special_accounts")
    op.drop_table("special_accounts")
    op.drop_index("ix_hypervisors_environment_id", table_name="hypervisors")
    op.drop_table("hypervisors")
    op.drop_index("ix_licenses_environment_id", table_name="licenses")
    op.drop_table("licenses")
    op.drop_index("ix_vlans_environment_id", table_name="vlans")
    op.drop_table("vlans")
    op.drop_index("ix_assets_environment_id", table_name="assets")
    op.drop_table("assets")
    op.drop_index("ix_environment_memberships_environment_id", table_name="environment_memberships")
    op.drop_index("ix_environment_memberships_user_id", table_name="environment_memberships")
    op.drop_table("environment_memberships")
    op.drop_index("ix_user_sessions_expires_at", table_name="user_sessions")
    op.drop_index("ix_user_sessions_user_id", table_name="user_sessions")
    op.drop_table("user_sessions")
    op.drop_table("environments")
    op.drop_index("ix_users_username", table_name="users")
    op.drop_table("users")