"""Allow superadmins to grant writable AI chat independently of admin privileges."""
from alembic import op
import sqlalchemy as sa

revision = "0028_assistant_write_permission"
down_revision = "0027_ai_providers"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("users", sa.Column("assistant_write_enabled", sa.Boolean(), nullable=False, server_default=sa.false()))


def downgrade():
    op.drop_column("users", "assistant_write_enabled")
