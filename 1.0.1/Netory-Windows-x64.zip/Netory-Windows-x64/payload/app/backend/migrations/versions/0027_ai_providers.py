"""Add encrypted AI provider connections and administration settings."""
from alembic import op
import sqlalchemy as sa

revision = "0027_ai_providers"
down_revision = "0026_wlan_device_vlan"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("ai_providers",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("vendor", sa.String(24), nullable=False),
        sa.Column("base_url", sa.String(500), nullable=False),
        sa.Column("api_key_encrypted", sa.Text()),
        sa.Column("model", sa.String(200), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("environment_ids", sa.JSON(), nullable=False),
        sa.Column("request_limit", sa.Integer(), nullable=False),
        sa.Column("models", sa.JSON(), nullable=False),
        sa.Column("test_status", sa.String(24), nullable=False),
        sa.Column("tested_at", sa.DateTime(timezone=True)),
        sa.Column("usage_date", sa.Date()),
        sa.Column("requests_today", sa.Integer(), nullable=False),
        sa.Column("total_requests", sa.Integer(), nullable=False))
    table = op.create_table("ai_settings", sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("default_provider_id", sa.String(36), sa.ForeignKey("ai_providers.id", ondelete="SET NULL")))
    op.bulk_insert(table, [{"id": 1, "default_provider_id": None}])


def downgrade():
    op.drop_table("ai_settings")
    op.drop_table("ai_providers")
