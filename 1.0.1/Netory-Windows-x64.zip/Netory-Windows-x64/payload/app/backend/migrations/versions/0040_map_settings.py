"""Global network map layout controlled by superadmins."""
from alembic import op
import sqlalchemy as sa

revision = '0040_map_settings'
down_revision = '0039_language_codes'
branch_labels = None
depends_on = None


def upgrade():
    table = op.create_table('map_settings',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('layout', sa.String(16), nullable=False, server_default='elk'))
    op.bulk_insert(table, [{'id': 1, 'layout': 'elk'}])


def downgrade():
    op.drop_table('map_settings')
