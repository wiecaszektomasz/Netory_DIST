"""Show existing virtual machines on the network map by default.

Revision ID: 0010_vm_map_visibility
Revises: 0009_asset_map_visibility
"""
from alembic import op
import sqlalchemy as sa


revision = "0010_vm_map_visibility"
down_revision = "0009_asset_map_visibility"
branch_labels = None
depends_on = None


def upgrade():
    assets = sa.table(
        "assets",
        sa.column("type", sa.String(length=80)),
        sa.column("show_on_map", sa.Boolean()),
    )
    op.get_bind().execute(
        assets.update()
        .where(assets.c.type == "Virtual server")
        .values(show_on_map=True)
    )


def downgrade():
    pass
