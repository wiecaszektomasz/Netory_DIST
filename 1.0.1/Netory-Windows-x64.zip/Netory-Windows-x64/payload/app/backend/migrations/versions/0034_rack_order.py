"""Cabinet order within rooms."""
from alembic import op
import sqlalchemy as sa
revision = '0034_rack_order'
down_revision = '0033_backup_power'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('rack_cabinets', sa.Column('display_order', sa.Integer(), nullable=False, server_default='1'))


def downgrade():
    op.drop_column('rack_cabinets', 'display_order')
