"""Device backup power and UPS assignments."""
from alembic import op
import sqlalchemy as sa
revision = '0033_backup_power'
down_revision = '0032_ups_parameters'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('assets', sa.Column('backup_power_enabled', sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column('assets', sa.Column('backup_ups_id', sa.String(80)))


def downgrade():
    op.drop_column('assets', 'backup_ups_id')
    op.drop_column('assets', 'backup_power_enabled')
