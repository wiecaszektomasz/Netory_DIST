"""Add physical or VLAN parent interfaces to networks."""
from alembic import op
import sqlalchemy as sa
revision = "0024_network_parent_interface"
down_revision = "0023_session_timeout"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("network_definitions", sa.Column("parent_interface", sa.JSON(), nullable=True))


def downgrade():
    with op.batch_alter_table("network_definitions") as batch:
        batch.drop_column("parent_interface")
