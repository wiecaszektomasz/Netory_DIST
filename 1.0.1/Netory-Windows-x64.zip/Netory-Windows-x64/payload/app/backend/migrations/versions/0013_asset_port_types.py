"""Store configurable port types per device.

Revision ID: 0013_asset_port_types
Revises: 0012_user_preferences
"""
from alembic import op
import sqlalchemy as sa


revision = "0013_asset_port_types"
down_revision = "0012_user_preferences"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assets", sa.Column("port_types", sa.JSON(), nullable=True))


def downgrade():
    op.drop_column("assets", "port_types")
