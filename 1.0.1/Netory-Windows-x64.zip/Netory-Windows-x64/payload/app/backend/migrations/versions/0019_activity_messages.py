"""Add readable application activity messages."""
from alembic import op
import sqlalchemy as sa
revision = "0019_activity_messages"
down_revision = "0018_audit_logs"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("audit_logs", sa.Column("message", sa.Text(), nullable=True))


def downgrade():
    op.drop_column("audit_logs", "message")
