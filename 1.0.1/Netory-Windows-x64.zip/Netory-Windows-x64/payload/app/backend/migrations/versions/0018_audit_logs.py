"""Add activity logs and retention policy."""
from alembic import op
import sqlalchemy as sa
revision = "0018_audit_logs"
down_revision = "0017_login_protection"
branch_labels = None
depends_on = None


def upgrade():
    settings = op.create_table("audit_settings", sa.Column("id", sa.Integer(), primary_key=True), sa.Column("retention_days", sa.Integer(), nullable=False))
    op.bulk_insert(settings, [{"id": 1, "retention_days": 90}])
    op.create_table("audit_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("user_id", sa.String(36)),
        sa.Column("username", sa.String(120), nullable=False),
        sa.Column("is_admin", sa.Boolean(), nullable=False),
        sa.Column("action", sa.String(120), nullable=False),
        sa.Column("method", sa.String(8), nullable=False),
        sa.Column("resource", sa.String(240), nullable=False),
        sa.Column("target_ids", sa.JSON(), nullable=False),
        sa.Column("status_code", sa.Integer(), nullable=False),
    )
    op.create_index("ix_audit_logs_created_at", "audit_logs", ["created_at"])


def downgrade():
    op.drop_index("ix_audit_logs_created_at", table_name="audit_logs")
    op.drop_table("audit_logs")
    op.drop_table("audit_settings")
