"""Per-account interface language."""
from alembic import op
import sqlalchemy as sa

revision = '0038_user_language'
down_revision = '0037_cost_estimates'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('users', sa.Column('language', sa.String(2), nullable=False, server_default='en'))


def downgrade():
    op.drop_column('users', 'language')
