"""Personal dashboard preferences, including viewer accounts."""
from alembic import op
import sqlalchemy as sa
revision = '0035_dashboard_preferences'
down_revision = '0034_rack_order'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('users', sa.Column('dashboard', sa.JSON(), nullable=True))


def downgrade():
    op.drop_column('users', 'dashboard')
