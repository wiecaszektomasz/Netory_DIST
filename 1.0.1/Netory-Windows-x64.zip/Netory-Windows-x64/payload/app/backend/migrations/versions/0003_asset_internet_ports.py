"""Store ports connected directly to the Internet.

Revision ID: 0003_asset_internet_ports
Revises: 0002_license_asset_assignments
"""
from alembic import op
import sqlalchemy as sa


revision = "0003_asset_internet_ports"
down_revision = "0002_license_asset_assignments"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("assets", sa.Column("internet_ports", sa.JSON(), nullable=True))


def downgrade():
    op.drop_column("assets", "internet_ports")
