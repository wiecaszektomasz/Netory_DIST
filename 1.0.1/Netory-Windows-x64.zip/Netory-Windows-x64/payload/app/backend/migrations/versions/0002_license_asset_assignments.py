"""Store device assignments for software licenses.

Revision ID: 0002_license_asset_assignments
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa


revision = "0002_license_asset_assignments"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("licenses", sa.Column("assigned_asset_ids", sa.JSON(), nullable=True))


def downgrade():
    op.drop_column("licenses", "assigned_asset_ids")
