"""UPS inventory parameters."""
from alembic import op
import sqlalchemy as sa
revision = '0032_ups_parameters'
down_revision = '0031_rooms'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('assets', sa.Column('ups_parameters', sa.JSON(), nullable=True))


def downgrade():
    op.drop_column('assets', 'ups_parameters')
