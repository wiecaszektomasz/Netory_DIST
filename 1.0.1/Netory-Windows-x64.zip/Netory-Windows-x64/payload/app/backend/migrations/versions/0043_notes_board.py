"""Shared client notes board."""
from alembic import op
import sqlalchemy as sa

revision = '0043_notes_board'
down_revision = '0042_management_controller'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('board_notes',
        sa.Column('id', sa.String(36), primary_key=True),
        sa.Column('environment_id', sa.String(36), sa.ForeignKey('environments.id', ondelete='CASCADE'), nullable=False),
        sa.Column('author_id', sa.String(36), sa.ForeignKey('users.id', ondelete='SET NULL')),
        sa.Column('author_name', sa.String(120), nullable=False),
        sa.Column('content', sa.String(500), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('version', sa.Integer(), nullable=False))
    op.create_index('ix_board_notes_environment_id', 'board_notes', ['environment_id'])


def downgrade():
    op.drop_index('ix_board_notes_environment_id', table_name='board_notes')
    op.drop_table('board_notes')
