"""Add encrypted per-network WLAN passwords."""
from alembic import op
import sqlalchemy as sa

revision = "0016_wlan_passwords"
down_revision = "0015_default_vlan_one"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("network_definitions", sa.Column("wifi_password_encrypted", sa.Text(), nullable=True))


def downgrade():
    op.drop_column("network_definitions", "wifi_password_encrypted")
