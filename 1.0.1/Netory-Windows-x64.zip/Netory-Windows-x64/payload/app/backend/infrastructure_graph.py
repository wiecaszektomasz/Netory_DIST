"""Shared local infrastructure model built only from an authorized snapshot.

Relationships retain their type and direction. Network reachability is separate
from hosting, power, placement and logical membership; none implies live health.
"""
from collections import deque
import re

TRANSIT_TYPES = {'Router', 'Switch', 'Firewall', 'Firewall / UTM', 'Network device', 'Patch panel'}
GATEWAY_TYPES = {'Router', 'Firewall', 'Firewall / UTM'}
ASSET_GROUPS = {
    'servers': {'Physical server', 'Virtual server'}, 'hosts': {'Physical server'},
    'vms': {'Virtual server'}, 'switches': {'Switch'}, 'routers': {'Router'},
    'firewalls': {'Firewall', 'Firewall / UTM'}, 'storage': {'Storage'},
    'ups': {'UPS'}, 'printers': {'Printer'}, 'computers': {'Computer'},
    'access points': {'Access point', 'Access Point'},
}


class InfrastructureGraph:
    def __init__(self, snapshot):
        self.snapshot = snapshot
        self.assets = {row['id']: row for row in snapshot.get('assets', [])}
        self.records = {}
        self.edges = []
        self.network = {key: set() for key in self.assets}
        self._edge_keys = set()
        for section in ('assets', 'stacks', 'clusters', 'racks', 'rooms', 'licenses', 'vlans', 'networks', 'hypervisors'):
            for row in snapshot.get(section, []):
                self.records[(section, row['id'])] = row
        for link in snapshot.get('connections', []):
            a, b = link['device_a_id'], link['device_b_id']
            self._network_link(a, b)
            self._add(('assets', a), ('assets', b), 'cable',
                      f"ports {link['port_a']} ↔ {link['port_b']}")
        for lag in snapshot.get('lags', []):
            for a, b in zip(lag.get('ports_a') or [], lag.get('ports_b') or []):
                self._network_link(a['deviceId'], b['deviceId'])
                self._add(('assets', a['deviceId']), ('assets', b['deviceId']), 'LAG member',
                          f"{lag.get('name', lag['id'])}: ports {a['port']} ↔ {b['port']}")
        for section, members, key, kind in (
            ('stacks', 'stack_members', 'stack_id', 'stack membership'),
            ('clusters', 'cluster_members', 'cluster_id', 'cluster membership'),
        ):
            grouped = {}
            for member in snapshot.get(members, []):
                self._add(('assets', member['asset_id']), (section, member[key]), kind)
                grouped.setdefault(member[key], []).append(member['asset_id'])
            if section == 'stacks':
                for group in grouped.values():
                    for a in group:
                        for b in group:
                            if a != b and self.assets.get(a, {}).get('type') == 'Switch' and self.assets.get(b, {}).get('type') == 'Switch':
                                self._network_link(a, b)
        for aid, asset in self.assets.items():
            source = ('assets', aid)
            if asset.get('backup_power_enabled'):
                self._add(source, ('assets', asset.get('backup_ups_id')), 'backup power')
            self._add(source, ('assets', asset.get('hypervisor_id')), 'hosted on')
            self._add(source, ('clusters', asset.get('hypervisor_cluster_id')), 'assigned hosting cluster')
            if asset.get('rack_enabled'):
                self._add(source, ('racks', asset.get('rack_id')), 'rack placement', f"unit {asset.get('rack_start_u') or 'unknown'}")
            # Management VLAN and port membership are distinct from cables.
            for vlan in snapshot.get('vlans', []):
                number = vlan.get('vlan_number')
                if str(asset.get('vlan', '')).strip() == str(number):
                    self._add(source, ('vlans', vlan['id']), 'management VLAN')
                configs = (asset.get('port_vlans') or {}).values()
                if any(number == config.get('untaggedVlan') or number in config.get('taggedVlans', []) for config in configs):
                    self._add(source, ('vlans', vlan['id']), 'port VLAN membership')
                if vlan.get('master_device_id') == aid:
                    self._add(source, ('vlans', vlan['id']), 'VLAN master')
        for rack in snapshot.get('racks', []):
            self._add(('racks', rack['id']), ('rooms', rack.get('room_id')), 'room placement')
        for license in snapshot.get('licenses', []):
            for aid in license.get('assigned_asset_ids') or []:
                self._add(('assets', aid), ('licenses', license['id']), 'license assignment')
        for network in snapshot.get('networks', []):
            parent = network.get('parent_interface') or {}
            aid = network.get('parent_device_id') or (parent.get('deviceId') if isinstance(parent, dict) else None)
            self._add(('networks', network['id']), ('assets', aid), 'network attachment')
            self._add(('networks', network['id']), ('vlans', network.get('vlan_interface_id')), 'network VLAN reference')

    def _network_link(self, a, b):
        if a in self.network and b in self.network:
            self.network[a].add(b)
            self.network[b].add(a)

    def _add(self, source, target, kind, detail=''):
        key = source, target, kind, detail
        if source in self.records and target in self.records and key not in self._edge_keys:
            self._edge_keys.add(key)
            self.edges.append({'source': source, 'target': target, 'kind': kind, 'detail': detail})

    def name(self, node):
        row = self.records[node]
        return row.get('name') or row.get('product') or node[1]

    def select_assets(self, question):
        """Exact names/hostnames/IPs first; group words never override a named asset."""
        named = []
        for aid, asset in self.assets.items():
            if any(isinstance(asset.get(field), str) and asset[field] and re.search(
                    r'(?<![\w.-])' + re.escape(asset[field]) + (r'(?![\w.-])' if field == 'ip' else r'(?![\w-])'), question, re.I)
                   for field in ('name', 'hostname', 'ip')):
                named.append(aid)
        if named:
            return named
        types = set()
        for group, candidates in ASSET_GROUPS.items():
            if re.search(r'\b' + (re.escape(group[:-1]) + 's?' if group.endswith('s') and group != 'ups' else re.escape(group)) + r'\b', question, re.I):
                types.update(candidates)
        if types:
            return [key for key, asset in self.assets.items() if asset.get('type') in types]
        if re.search(r'\b(all|every)\s+(assets?|devices?)\b', question, re.I):
            return list(self.assets)
        return []

    def reachable(self, blocked=None):
        reached = {key for key, asset in self.assets.items() if asset.get('type') in GATEWAY_TYPES and key != blocked}
        pending = list(reached)
        while pending:
            current = pending.pop()
            if self.assets[current].get('type') not in TRANSIT_TYPES:
                continue
            for neighbor in self.network[current] - reached - {blocked}:
                reached.add(neighbor)
                pending.append(neighbor)
        return reached

    def upstream_path(self, source):
        """One recorded path; end hosts cannot serve as transit devices."""
        if source not in self.assets:
            return []
        pending, previous = deque([source]), {source: None}
        while pending:
            current = pending.popleft()
            if self.assets[current].get('type') in GATEWAY_TYPES:
                path = []
                while current is not None:
                    path.append(current)
                    current = previous[current]
                return path[::-1]
            if current != source and self.assets[current].get('type') not in TRANSIT_TYPES:
                continue
            for neighbor in sorted(self.network[current]):
                if neighbor not in previous:
                    previous[neighbor] = current
                    pending.append(neighbor)
        return []

    def related_edges(self, aid):
        """Direct evidence plus hosting/power/placement context, never generic reachability."""
        node = ('assets', aid)
        direct = [edge for edge in self.edges if node in (edge['source'], edge['target'])]
        dependency_kinds = {'hosted on', 'backup power', 'rack placement', 'room placement', 'assigned hosting cluster'}
        providers = {edge['target'] for edge in direct if edge['source'] == node and edge['kind'] in dependency_kinds}
        pending = list(providers)
        while pending:
            current = pending.pop()
            for edge in self.edges:
                if edge['source'] == current and edge['kind'] in dependency_kinds and edge['target'] not in providers:
                    providers.add(edge['target'])
                    pending.append(edge['target'])
        return direct + [edge for edge in self.edges if edge not in direct and (
            edge['source'] in providers or (edge['kind'] in ('cable', 'LAG member') and edge['target'] in providers))]
