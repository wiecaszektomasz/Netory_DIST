"""Clone inventory identities while preserving references inside the copy."""
from copy import deepcopy
from uuid import uuid4


def copy_inventory(inventory):
    copied = deepcopy(inventory)
    ids = {section: {row['id']: str(uuid4()) for row in rows}
           for section, rows in copied.items() if rows is not None}

    def ref(value, section):
        return ids[section].get(value, value)

    for section, rows in copied.items():
        for row in rows or []:
            row['id'] = ids[section][row['id']]
            row.pop('overlaps', None)
            row.pop('costEstimateId', None)
            row.pop('netPrice', None)
    if 'rooms' in ids:
        for rack in copied.get('racks') or []:
            rack['roomId'] = ref(rack.get('roomId', ''), 'rooms')
    for row in copied['assets']:
        if 'rooms' in ids:
            row['roomId'] = ref(row.get('roomId', ''), 'rooms')
        if 'racks' in ids:
            row['rackId'] = ref(row.get('rackId', ''), 'racks')
        row['backupUpsId'] = ref(row.get('backupUpsId', ''), 'assets')
        row['hypervisorId'] = ref(row.get('hypervisorId', ''), 'assets')
        row['hypervisorClusterId'] = ref(row.get('hypervisorClusterId', ''), 'clusters')
    for row in copied['vlans']:
        row['masterDeviceId'] = ref(row.get('masterDeviceId', ''), 'assets')
        row.pop('linkedNetworks', None)
    for row in copied['lans']:
        parent = row.get('parentInterface')
        if parent:
            for key, section in [('deviceId', 'assets'), ('vlanId', 'vlans')]:
                if key in parent:
                    parent[key] = ref(parent[key], section)
    for row in copied['wlans']:
        row['parentDeviceId'] = ref(row.get('parentDeviceId', ''), 'assets')
        row['vlanInterfaceId'] = ref(row.get('vlanInterfaceId', ''), 'vlans')
    for section, field in [('stacks', 'memberAssetIds'), ('clusters', 'memberAssetIds'), ('licenses', 'assignedAssetIds')]:
        for row in copied[section]:
            row[field] = [ref(value, 'assets') for value in row.get(field, [])]
    for section in ['connections', 'lags']:
        for row in copied[section]:
            for side in ['A', 'B']:
                row[f'device{side}Id'] = ref(row.get(f'device{side}Id', ''), 'assets')
                if section == 'lags':
                    row[f'stack{side}Id'] = ref(row.get(f'stack{side}Id', ''), 'stacks')
                    for member in row.get(f'members{side}', []):
                        member['deviceId'] = ref(member['deviceId'], 'assets')
    return copied
