import argparse
from getpass import getpass
from uuid import uuid4

from sqlalchemy import select

from backend.db import SessionLocal
from backend.models import User
from backend.security import hash_password


def add_user(username: str, is_admin: bool):
    username = username.strip().lower()
    if not username:
        raise SystemExit("Username cannot be blank")
    password = getpass("Password (minimum 14 characters): ")
    if len(password) < 14:
        raise SystemExit("Password must be at least 14 characters")
    confirmation = getpass("Confirm password: ")
    if password != confirmation:
        raise SystemExit("Passwords do not match")
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.username == username)):
            raise SystemExit("That username already exists")
        db.add(User(id=str(uuid4()), username=username, password_hash=hash_password(password), is_admin=is_admin))
        db.commit()
    print(f"Created {'administrator' if is_admin else 'user'} {username}")


def main():
    parser = argparse.ArgumentParser(description="Manage Netory user accounts")
    parser.add_argument("username")
    parser.add_argument("--admin", action="store_true", help="Create an administrator account")
    args = parser.parse_args()
    add_user(args.username, args.admin)


if __name__ == "__main__":
    main()