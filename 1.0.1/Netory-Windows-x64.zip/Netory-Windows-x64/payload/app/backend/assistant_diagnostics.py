"""Local evidence reports for infrastructure issues across asset categories."""
import re
from backend.infrastructure_graph import InfrastructureGraph


def infrastructure_diagnostics(context, question):
    if not re.search(r'\b(troubleshoot\w*|diagnos\w*|issues?|problems?|slow|latency|errors?|faults?|packet loss|unreachable|unavailable|offline|not working|cannot connect|can\'t connect|no network|no internet)\b', question, re.I):
        return None
    # Explanations do not authorize inventory edits or intercept explicit outage simulations.
    if re.search(r'\b(add|create|update|configure|assign|delete|remove|turn off|switch off|power off|shut\s*down)\b', question, re.I):
        return None
    graph = InfrastructureGraph(context)
    selected = graph.select_assets(question)
    if not selected:
        return None
    lines = [f'Local infrastructure evidence for {len(selected)} selected asset(s); this is recorded inventory, not live monitoring:']
    shown = 0
    for aid in selected:
        asset = graph.assets[aid]
        block = [f"\n{asset['name']} ({asset['type']})"]
        specs = [f"{key}: {asset[key]}" for key in ('ip', 'cpu', 'ram', 'storage', 'os') if asset.get(key)]
        if specs:
            block.append('- Recorded properties: ' + '; '.join(specs))
        if asset.get('status'):
            block.append(f"- Recorded inventory status: {asset['status']} (does not verify current health)")
        for edge in graph.related_edges(aid):
            detail = ': ' + edge['detail'] if edge['detail'] else ''
            block.append(f"- {edge['kind']}: {graph.name(edge['source'])} → {graph.name(edge['target'])}{detail}")
        path = graph.upstream_path(aid)
        host = asset.get('hypervisor_id')
        if not path and host in graph.assets:
            host_path = graph.upstream_path(host)
            if host_path:
                block.append('- Physical host upstream path: ' + ' → '.join(graph.assets[key]['name'] for key in host_path)
                             + '; this does not establish the VM virtual NIC/VLAN configuration')
        if path:
            block.append('- Recorded upstream path: ' + ' → '.join(graph.assets[key]['name'] for key in path))
        elif not host:
            block.append('- No router/firewall path is recorded; missing inventory does not prove a live outage')
        if len(block) == 1:
            block.append('- No relationships are recorded in the available sections')
        text = '\n'.join(block)
        if sum(len(line) + 1 for line in lines) + len(text) > 4500:
            break
        lines.append(text)
        shown += 1
    if shown < len(selected):
        lines.append(f'\nShowing {shown} of {len(selected)} selected assets to fit the reply. Name a device or smaller group for its full evidence report.')
    denied = context.get('assistant_access', {}).get('read_disabled', [])
    if denied:
        lines.append('Restricted sections are excluded: ' + ', '.join(denied))
    lines.append('\nCheck actual link and interface state, addressing, gateway and VLAN configuration on both cable ends; inspect LAG/stack state and alternate uplinks. For VMs also check the physical host, virtual NIC and virtual switch. For power issues check mains and UPS state. Storage connectivity does not establish a mounted volume or service dependency. Shared racks, VLANs and clusters do not prove dependency or failover.\nWhat symptom or error do you observe, and when did it start? No configuration changes were made.')
    return '\n'.join(lines)


def asset_impact_answer(context, question):
    """Use the shared graph for network, host and recorded backup-power impact."""
    if not re.search(r'\b(turn off|switch off|power off|shut\s*down|fails?|failure|outage)\b', question, re.I):
        return None
    graph = InfrastructureGraph(context)
    selected = graph.select_assets(question)
    if len(selected) != 1:
        return None
    aid = selected[0]
    asset = graph.assets[aid]
    if asset.get('type') == 'Switch':
        return None  # The existing switch renderer uses this same graph and preserves its port detail.
    from backend import assistant_config
    if any(not assistant_config.section_allowed(section) for section in assistant_config.TOPOLOGY_READ_SECTIONS):
        return 'Infrastructure section access is restricted; a complete impact analysis is unavailable. No changes made.'
    network_lost = graph.reachable() - graph.reachable(aid) - {aid}
    dependency_nodes = {('assets', aid)}
    pending = list(dependency_nodes)
    while pending:
        current = pending.pop()
        for edge in graph.edges:
            if edge['target'] == current and edge['kind'] in ('hosted on', 'backup power') and edge['source'] not in dependency_nodes:
                dependency_nodes.add(edge['source'])
                pending.append(edge['source'])
    dependents = {node[1] for node in dependency_nodes if node[0] == 'assets'} - {aid}
    hosted = {key for key, row in graph.assets.items() if row.get('hypervisor_id') in network_lost}
    lines = [f"Recorded impact of losing {asset['name']} ({asset['type']}):"]
    if network_lost:
        lines.append('- Lose all recorded router/firewall paths: ' + ', '.join(graph.assets[key]['name'] for key in sorted(network_lost)))
    if hosted:
        lines.append('- VMs hosted on affected network hosts: ' + ', '.join(graph.assets[key]['name'] for key in sorted(hosted)))
    if dependents:
        lines.append('- Recorded hosting/power dependents: ' + ', '.join(graph.assets[key]['name'] for key in sorted(dependents)))
    if asset.get('type') == 'UPS':
        lines.append('These devices lose their recorded backup power source. This does not prove they shut down: mains power, alternate feeds and battery state are not recorded.')
    elif asset.get('type') == 'Physical server':
        lines.append('Directly hosted VMs depend on this physical host. Cluster membership alone does not prove automatic failover or the current VM placement.')
    elif asset.get('type') == 'Storage':
        lines.append('Network cables do not identify mounted volumes, datastores or application storage dependencies; those service relationships are not recorded, so dependent servers cannot be determined reliably.')
    if not network_lost and not dependents and not hosted:
        lines.append('No downstream network or hosting/power dependency is established by the available records. This does not prove there is no real-world impact.')
    lines.append('Physical reachability is separate from VLAN forwarding and live health. Inventory status is not monitoring. No changes made.')
    answer = '\n'.join(lines)
    if len(answer) > 5800:
        return f"The complete impact report for {asset['name']} exceeds the reply limit. Specify a device group; no partial outage list is presented. No changes made."
    return answer
