"""Versioned, canonical Ed25519 license envelopes; shared with the online issuer."""
import base64
import json
from datetime import datetime, timezone
from typing import Literal
from uuid import UUID

from cryptography import x509
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, Field, model_validator

DOMAIN = b'NETORY-LICENSE-V1\x00'
MAX_FILE_SIZE = 16384


class Claims(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    version: Literal[1, 2] = 1
    kind: Literal['license', 'clock_recovery'] = 'license'
    license_id: str
    installation_id: str | None = None
    customer: str = Field(min_length=1, max_length=240)
    issued_at: int = Field(ge=0, le=253402300799)
    not_before: int = Field(ge=0, le=253402300799)
    expires_at: int = Field(gt=0, le=253402300799)
    recovery_nonce: str | None = Field(default=None, min_length=32, max_length=128)

    @model_validator(mode='after')
    def validate_claims(self):
        UUID(self.license_id)
        if self.version == 1:
            if not self.installation_id:raise ValueError('Legacy licenses require their original installation ID')
            UUID(self.installation_id)
        elif self.installation_id is not None or self.kind != 'license' or self.recovery_nonce is not None:
            raise ValueError('Version 2 licenses do not contain installation or recovery fields')
        if not self.customer.strip() or self.expires_at <= self.not_before or self.issued_at > self.expires_at:
            raise ValueError('Invalid customer or validity period')
        if (self.kind == 'clock_recovery') != (self.recovery_nonce is not None):
            raise ValueError('Recovery files require a challenge; licenses cannot contain one')
        return self


def canonical(claims):
    return DOMAIN + json.dumps(claims, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()


def claim_payload(claims):
    payload = claims.model_dump()
    if claims.version == 2:
        payload.pop('installation_id')
        payload.pop('recovery_nonce')
    return payload


def sign(claims, private_key):
    payload = claim_payload(Claims.model_validate(claims))
    signature = private_key.sign(canonical(payload))
    return json.dumps({'payload': payload, 'signature': base64.b64encode(signature).decode()}, indent=2).encode()


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key')
        result[key] = value
    return result


def verify(raw, certificate):
    if len(raw) > MAX_FILE_SIZE:
        raise ValueError('License file is too large')
    envelope = json.loads(raw, object_pairs_hook=_unique)
    if not isinstance(envelope, dict) or set(envelope) != {'payload', 'signature'}:
        raise ValueError('Invalid license envelope')
    cert = x509.load_pem_x509_certificate(certificate)
    key = cert.public_key()
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError('Unsupported signing certificate')
    claims = Claims.model_validate(envelope['payload'])
    if claims.version == 2 and any(field in envelope['payload'] for field in ('installation_id', 'recovery_nonce')):
        raise ValueError('Unexpected legacy fields in version 2 license')
    signature = base64.b64decode(envelope['signature'], validate=True)
    # Verify exactly the normalized schema, including defaults; no unsigned fields.
    key.verify(signature, canonical(claim_payload(claims)))
    stamp = datetime.fromtimestamp(claims.issued_at, timezone.utc)
    if not cert.not_valid_before_utc <= stamp <= cert.not_valid_after_utc:
        raise ValueError('Signing certificate was not valid at issue time')
    return claims
