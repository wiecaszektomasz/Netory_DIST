"""Prevent a provider from silently choosing a day/month convention."""
import re

from backend.import_normalization import DATE_FIELDS


def date_clarification(attachment, messages, changes):
    if not any(DATE_FIELDS & change['fields'].keys() for change in changes):
        return None
    user_text = '\n'.join(message.content for message in messages if message.role == 'user')
    # Only user instructions establish a convention, not model claims or file text.
    convention = r'\b(?:dd\s*[/.-]\s*mm\s*[/.-]\s*yyyy|mm\s*[/.-]\s*dd\s*[/.-]\s*yyyy|day[ -]first|month[ -]first|day/month/year|month/day/year)\b'
    # A negated or questioned convention is not permission to assume one.
    conventions = list(re.finditer(convention, user_text, re.I))
    if len(conventions) == 1:
        found = conventions[0]
        prefix = user_text[max(0, found.start() - 40):found.start()]
        if not re.search(r'\b(?:not|unsure|unknown|either)\b', prefix, re.I) and '?' not in user_text[found.end():found.end() + 2]:
            return None
    source = attachment.content if attachment else messages[-1].content
    for match in re.finditer(r'(?<!\d)(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})(?!\d)', source):
        first, second = map(int, match.groups()[:2])
        if 1 <= first <= 12 and 1 <= second <= 12 and first != second:
            return (f'The source date {match.group()} is ambiguous. Please specify DD/MM/YYYY '
                    'or MM/DD/YYYY, or upload dates as YYYY-MM-DD. No changes have been saved.')
    return None
