"""Fresh signed validation requests and decisions, independent of client wall time."""
import base64
import hashlib
import json
from uuid import UUID
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from pydantic import BaseModel, ConfigDict, Field, model_validator

REQUEST_DOMAIN = b'NETORY-ONLINE-REQUEST-V1\x00'
DECISION_DOMAIN = b'NETORY-ONLINE-DECISION-V1\x00'


def encoded(value):
    return base64.b64encode(value).decode()


def decoded(value):
    return base64.b64decode(value, validate=True)


def canonical(domain, value):
    return domain + json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()


class ValidationRequest(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    activate: bool = False
    content: str = Field(min_length=1,max_length=16384)
    installation_id: str = Field(min_length=36,max_length=36)
    public_key: str = Field(min_length=44,max_length=44)
    machine_hash: str = Field(pattern=r'^[a-f0-9]{64}$')
    nonce: str = Field(pattern=r'^[a-f0-9]{64}$')
    signature: str = Field(min_length=88,max_length=88)

    @model_validator(mode='after')
    def check_id(self):
        UUID(self.installation_id)
        return self


def request_message(payload):
    return canonical(REQUEST_DOMAIN, {**({'activate': True} if payload.get('activate',False) else {}), 'license_hash':hashlib.sha256(payload['content'].encode()).hexdigest(),
        **{key:payload[key] for key in ('installation_id','public_key','machine_hash','nonce')}})


def make_request(raw,identity,key,machine_hash,nonce,activate=False):
    payload={'content':raw.decode(),'installation_id':identity['installation_id'],
        'public_key':encoded(key.public_key().public_bytes_raw()),'machine_hash':machine_hash,'nonce':nonce}
    if activate:payload['activate']=True
    payload['signature']=encoded(key.sign(request_message(payload)))
    return ValidationRequest.model_validate(payload).model_dump()


def verify_request(payload):
    payload=ValidationRequest.model_validate(payload).model_dump()
    Ed25519PublicKey.from_public_bytes(decoded(payload['public_key'])).verify(decoded(payload['signature']),request_message(payload))
    return payload


class Decision(BaseModel):
    model_config = ConfigDict(extra='forbid',strict=True)
    valid: bool
    code: str = Field(min_length=1,max_length=80)
    reason: str = Field(min_length=1,max_length=500)
    license_id: str
    installation_id: str
    public_key: str
    machine_hash: str
    nonce: str
    server_time: int
    expires_at: int | None = None
    customer: str | None = None


def sign_decision(payload,key):
    payload=Decision.model_validate(payload).model_dump()
    return {'payload':payload,'signature':encoded(key.sign(canonical(DECISION_DOMAIN,payload)))}


def verify_decision(envelope,certificate,request,license_id):
    if not isinstance(envelope,dict) or set(envelope)!={'payload','signature'}:
        raise ValueError('Malformed license-server decision')
    payload=Decision.model_validate(envelope['payload']).model_dump()
    key=x509.load_pem_x509_certificate(certificate).public_key()
    if not isinstance(key,Ed25519PublicKey):raise ValueError('Unexpected authority key')
    key.verify(decoded(envelope['signature']),canonical(DECISION_DOMAIN,payload))
    if payload['license_id']!=license_id or any(payload[field]!=request[field] for field in ('installation_id','public_key','machine_hash','nonce')):
        raise ValueError('License-server decision is for another request')
    return payload
