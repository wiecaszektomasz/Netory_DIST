"""Discover installed translation catalogs without a manually maintained language list."""
import json
import re
from pathlib import Path

LANGUAGE_DIRECTORY = Path(__file__).resolve().parent.parent / 'frontend' / 'Language'
LANGUAGE_CODE = re.compile(r'[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*')


def available_languages():
    catalogs = {}
    for path in sorted(LANGUAGE_DIRECTORY.glob('*.json')):
        if len(path.stem) > 35 or not LANGUAGE_CODE.fullmatch(path.stem):
            continue
        try:
            catalog = json.loads(path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            continue
        if not isinstance(catalog, dict) or not all(isinstance(value, str) for value in catalog.values()):
            continue
        catalogs[path.stem] = catalog
    return catalogs
