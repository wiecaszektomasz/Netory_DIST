"""Authenticated encryption for WLAN passwords; the key lives outside the database."""
from cryptography.fernet import Fernet, InvalidToken
from fastapi import HTTPException

from backend.config import settings


def cipher():
    try:
        return Fernet(settings.wlan_encryption_key.encode("ascii"))
    except (ValueError, UnicodeError):
        raise HTTPException(status_code=503, detail="WLAN password encryption key is not configured correctly") from None


def encrypt_password(value):
    if value is None or value == "":
        return None
    if not isinstance(value, str) or len(value) > 1024:
        raise HTTPException(status_code=422, detail="Wi-Fi password must be text of at most 1024 characters")
    return cipher().encrypt(value.encode("utf-8")).decode("ascii")


def decrypt_password(value):
    if not value:
        return ""
    try:
        return cipher().decrypt(value.encode("ascii")).decode("utf-8")
    except (InvalidToken, UnicodeError):
        raise HTTPException(status_code=503, detail="Stored WLAN password could not be decrypted") from None
