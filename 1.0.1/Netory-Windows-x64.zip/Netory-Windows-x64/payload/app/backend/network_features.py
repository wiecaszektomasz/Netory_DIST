"""VLAN network synchronization and advisory address-range overlap checks."""
from ipaddress import ip_network
from uuid import uuid4

from fastapi import HTTPException
from sqlalchemy import select

from backend.models import Environment, Membership, NetworkDefinition


def cidr(value):
    try:
        return ip_network(str(value).strip(), strict=False) if value else None
    except ValueError:
        return None


def synchronize_vlan_networks(data, previous_vlans, previous_networks):
    previous_vlan_by_id = {row.id: row for row in previous_vlans}
    networks = data['lans']
    for vlan in data['vlans']:
        vlan_id = str(vlan['id'])
        old = previous_vlan_by_id.get(vlan_id)
        linked = [row for row in networks if row.get('parentInterface') == {'type': 'vlan', 'vlanId': vlan_id}]
        previous_linked = [row for row in previous_networks if row.parent_interface == {'type': 'vlan', 'vlanId': vlan_id}]
        network = str(vlan.get('network') or '').strip()
        gateway = str(vlan.get('gateway') or '').strip()
        changed = old is None or cidr(network) != cidr(old.network) or gateway != (old.gateway or '')
        if (network and (changed or (not linked and not previous_linked))) or (old is not None and changed and linked):
            # Update the network represented by the VLAN form, leaving other subnets intact.
            target = next((row for row in linked if cidr(row.get('network')) == cidr(old.network if old else network)), None)
            if target is None and len(linked) == 1:
                target = linked[0]
            if target is None:
                target = {'id': str(uuid4()), 'name': f"{vlan['name']}_NETWORK", 'parentInterface': {'type': 'vlan', 'vlanId': vlan_id},
                          'location': vlan.get('location', ''), 'purpose': vlan.get('purpose', '')}
                networks.append(target)
            target['network'] = network
            target['gateway'] = gateway
        if not linked and previous_linked and not changed:
            # Removing/reparenting the last linked network must not recreate it later.
            vlan['network'], vlan['gateway'] = '', ''
        if old and vlan.get('name') != old.name:
            for row in linked:
                if row.get('name') == f'{old.name}_NETWORK':
                    row['name'] = f"{vlan['name']}_NETWORK"


def mirror_networks_to_vlans(vlans, networks):
    for vlan in vlans:
        linked = [row for row in networks if row.network_type == 'LAN' and row.parent_interface == {'type': 'vlan', 'vlanId': vlan.id}]
        if linked:
            primary = next((row for row in linked if cidr(row.network) == cidr(vlan.network)), linked[0])
            vlan.network, vlan.gateway = primary.network, primary.gateway


def visible_environment_ids(db, user):
    if user.is_admin:
        return set(db.scalars(select(Environment.id)))
    return set(db.scalars(select(Membership.environment_id).where(Membership.user_id == user.id)))


def overlap_records(db, environment_id=None, incoming=None):
    # A full inventory save replaces this environment, so compare its incoming
    # records with one another rather than with stale stored rows.
    rows = list(incoming) if incoming is not None else list(db.scalars(select(NetworkDefinition)))
    environments = dict(db.execute(select(Environment.id, Environment.name)).all())
    return [(row, cidr(row.network), environments.get(row.environment_id, '')) for row in rows if cidr(row.network)]


def shared_vlan_address(row, other, network, other_network):
    if network != other_network or 'WLAN' not in (row.network_type, other.network_type):
        return False
    def vlan_id(record):
        if record.network_type == 'WLAN':
            return record.vlan_interface_id
        parent = record.parent_interface or {}
        return parent.get('vlanId') if parent.get('type') == 'vlan' else None
    return bool(vlan_id(row) and vlan_id(row) == vlan_id(other))


def warnings_for(row, records, visible):
    network = cidr(row.network)
    if network is None:
        return []
    warnings = []
    for other, other_network, environment_name in records:
        if other.environment_id != row.environment_id or other.id == row.id:
            continue
        if network.version != other_network.version or not network.overlaps(other_network):
            continue
        if shared_vlan_address(row, other, network, other_network):
            continue
        accessible = other.environment_id in visible
        relation = 'same range as' if network == other_network else 'covered by' if network.subnet_of(other_network) else 'covers'
        warnings.append({'name': other.name if accessible else 'Network in a restricted environment',
                         'environment': environment_name if accessible else 'Restricted environment',
                         'network': str(other_network) if accessible else '', 'relation': relation})
    return warnings


def check_new_overlaps(db, environment_id, incoming, previous, user, accepted):
    if accepted:
        return
    old = {row.id: cidr(row.network) for row in previous}
    records = overlap_records(db, environment_id, incoming)
    visible = visible_environment_ids(db, user)
    conflicts = []
    for row in incoming:
        if cidr(row.network) is None or (row.id in old and cidr(row.network) == old[row.id]):
            continue
        warnings = warnings_for(row, records, visible)
        if warnings:
            conflicts.append({'name': row.name, 'network': row.network, 'overlaps': warnings})
    if conflicts:
        raise HTTPException(status_code=409, detail={'code': 'network_overlap', 'message': 'Network address ranges overlap. Save anyway?', 'networks': conflicts})


def network_warnings(db, user):
    records = overlap_records(db)
    visible = visible_environment_ids(db, user)
    result = {}
    for row, _, _ in records:
        if row.environment_id in visible:
            result.setdefault(row.environment_id, {})[row.id] = warnings_for(row, records, visible)
    return result
