"""Optional model-understanding samples using invented import files only."""
import json

from backend.assistant_eval import synthetic_context, parse_json


def evaluation_cases():
    rows = [{'Name': f'NAS-{i:02}', 'Address': f'10.2.1.{i}',
             'Model': f'QNAP TS-{240 + i}', 'VLAN MGMT': 40} for i in range(1, 6)]
    tsv = 'Name\tAddress\tModel\tVLAN MGMT\n' + '\n'.join(
        '\t'.join(str(value) for value in row.values()) for row in rows)
    return [
        {'id': 'nas_tsv', 'write': True, 'message': 'Add all storage from the file, include all supplied information.',
         'attachment': {'name': 'storage.tsv', 'content': tsv}, 'kind': 'storage'},
        {'id': 'nas_nested_json', 'write': True, 'message': 'Import all storage rows and all supplied details.',
         'attachment': {'name': 'storage.json', 'content': json.dumps({'export': {'devices': rows}})}, 'kind': 'storage'},
        {'id': 'translated_device_headers', 'write': True,
         'message': 'Import this device. Include every supplied value; preserve the purchase reference.',
         'attachment': {'name': 'urzadzenia.csv', 'content': 'Nazwa;Typ;Adres IP;Model;Numer seryjny;Referencja zakupu\nLAB-PC-01;Laptop;10.4.0.10;Example Book;00123;PO-001'}, 'kind': 'computer'},
        {'id': 'license_column_variants', 'write': True,
         'message': 'Import this license and all its details. Assigned devices are named devices; other assigned seats exclude them.',
         'attachment': {'name': 'licenses.csv', 'content': 'Software;Publisher;License Count;Other Assigned Seats;Assigned Devices;Expiry Date;Owner / Team;Contract reference\nSynthetic Office;Example;12;0;LAB-SERVER-1;2027/1/2;IT;REF-001'}, 'kind': 'license'},
        {'id': 'ambiguous_expiry', 'write': True,
         'message': 'Import this license. I have not specified the date convention.',
         'attachment': {'name': 'licenses.csv', 'content': 'Software,License Count,Expiry Date\nSynthetic Office,12,01/02/2027'}, 'kind': 'clarification'},
    ]


def evaluate_answer(case, answer):
    from backend.assistant import validate_changes
    from backend.import_references import resolve_import_references
    result = parse_json(answer)
    if not isinstance(result.get('answer'), str):
        return False
    changes = validate_changes(result['changes'])
    resolve_import_references(synthetic_context(), changes)
    if case['kind'] == 'clarification':
        return changes == [] and bool(result['answer'].strip())
    if any(change['operation'] != 'create' for change in changes):
        return False
    if case['kind'] == 'storage':
        expected = {f'NAS-{i:02}': {'name': f'NAS-{i:02}', 'type': 'Storage', 'ip': f'10.2.1.{i}',
                    'manufacturer': f'QNAP TS-{240 + i}', 'vlan': '40'} for i in range(1, 6)}
        if len(changes) != 5 or any(change.get('section', 'assets') != 'assets' for change in changes):
            return False
        actual = {change['fields'].get('name'): change['fields'] for change in changes}
        return actual == expected
    if len(changes) != 1:
        return False
    fields = changes[0]['fields']
    if case['kind'] == 'computer':
        expected = {'name': 'LAB-PC-01', 'type': 'Computer', 'ip': '10.4.0.10',
                    'manufacturer': 'Example Book', 'serial': '00123'}
        return (changes[0].get('section', 'assets') == 'assets'
                and set(fields) == set(expected) | {'notes'}
                and all(fields.get(key) == value for key, value in expected.items())
                and 'PO-001' in fields['notes'])
    expected = {'product': 'Synthetic Office', 'vendor': 'Example', 'seats': 12,
                'assigned': 0, 'assignedAssetIds': ['alpha-server1'], 'expiry': '2027-01-02', 'owner': 'IT'}
    return (changes[0].get('section') == 'licenses'
            and set(fields) == set(expected) | {'notes'}
            and all(fields.get(key) == value for key, value in expected.items())
            and 'REF-001' in fields['notes'])
