"""Conservative normalization of model proposals, never a replacement for validation.

Only known aliases and lossless scalar conversions are accepted. Unknown columns
remain visible to the caller's allowlist; protected fields are never dropped.
"""
import re
from datetime import date


def header_key(value):
    return re.sub(r'[\s_\-/]+', '', value.strip().casefold())


COMMON_ALIASES = {
    'site': 'location', 'description': 'notes', 'comments': 'notes',
}
SECTION_ALIASES = {
    'assets': {
        'asset name': 'name', 'device name': 'name', 'device type': 'type',
        'asset type': 'type', 'address': 'ip', 'ip address': 'ip', 'management ip': 'ip',
        'model': 'manufacturer', 'manufacturer model': 'manufacturer',
        'serial number': 'serial', 's/n': 'serial', 'host name': 'hostname',
        'vlan mgmt': 'vlan', 'management vlan': 'vlan', 'vlan id': 'vlan',
        'ports': 'portCount', 'number of ports': 'portCount',
        'memory': 'ram', 'disk capacity': 'storage', 'operating system': 'os',
        'warranty expiration': 'warrantyExpiry', 'warranty expiry date': 'warrantyExpiry',
    },
    'licenses': {
        'name': 'product', 'product name': 'product', 'software': 'product',
        'publisher': 'vendor', 'license type': 'type', 'license count': 'seats',
        'seat count': 'seats', 'quantity': 'seats', 'total seats': 'seats',
        'other assigned seats': 'assigned', 'assigned devices': 'assignedAssetIds',
        'expiration': 'expiry', 'expiration date': 'expiry', 'expiry date': 'expiry',
        'expires': 'expiry', 'owner team': 'owner', 'team': 'owner',
    },
    'hypervisors': {'management address': 'managementIp', 'ip address': 'managementIp',
                    'address': 'managementIp', 'hypervisor name': 'name'},
    'vlans': {'vlan name': 'name', 'vlan number': 'idValue', 'vlan id': 'idValue',
              'subnet': 'network', 'cidr': 'network', 'default gateway': 'gateway'},
    'lans': {'subnet': 'network', 'cidr': 'network', 'default gateway': 'gateway',
             'dns': 'dnsServers', 'vlan number': 'vlanId'},
    'wlans': {'subnet': 'network', 'cidr': 'network', 'default gateway': 'gateway',
              'dns': 'dnsServers', 'wifi name': 'name', 'vlan number': 'vlanId'},
    'rooms': {'room name': 'name'},
    'racks': {'rack name': 'name', 'rack height': 'capacityU', 'capacity u': 'capacityU'},
    'stacks': {'stack name': 'name', 'members': 'memberAssetIds'},
    'clusters': {'cluster name': 'name', 'members': 'memberAssetIds'},
    'lags': {'lag name': 'name', 'aggregation mode': 'aggregationType'},
    'accounts': {'account name': 'name', 'service name': 'name',
                 'account type': 'accountType', 'last rotation': 'rotation'},
    'connections': {},
}
INTEGER_FIELDS = {'portCount', 'rackUnits', 'rackStartU', 'upsRatedVA', 'upsRatedW',
                  'upsRuntimeMinutes', 'upsBatteryCount', 'capacityU', 'displayOrder',
                  'seats', 'assigned', 'idValue', 'vlanId', 'portA', 'portB'}
BOOLEAN_FIELDS = {'showOnMap', 'rackEnabled', 'backupPowerEnabled'}
DATE_FIELDS = {'expiry', 'rotation', 'warrantyExpiry', 'upsBatteryReplacementDate', 'osEol'}
CHOICES = {
    'licenses': {'type': ('Subscription', 'Perpetual', 'OEM', 'Open source', 'Other')},
    'hypervisors': {'platform': ('VMware vSphere', 'Microsoft Hyper-V', 'Proxmox VE', 'Nutanix AHV', 'KVM', 'Other')},
    'accounts': {'accountType': ('Administrator', 'Service account', 'Break-glass', 'API / integration', 'Other')},
    'stacks': {'deviceType': ('Switch', 'Router', 'Firewall / UTM')},
    'lags': {'aggregationType': ('Static', 'Dynamic')},
    'wlans': {'security': ('Open', 'WPA2-Personal', 'WPA2-Enterprise', 'WPA3-Personal',
                           'WPA3-Enterprise', 'WPA2/WPA3-Personal', 'WPA2/WPA3-Enterprise', 'Other')},
}
CHOICE_ALIASES = {
    ('licenses', 'type'): {'perpetuallicense': 'Perpetual', 'subscriptionlicense': 'Subscription'},
    ('hypervisors', 'platform'): {'vmware': 'VMware vSphere', 'esxi': 'VMware vSphere',
                                 'hyperv': 'Microsoft Hyper-V', 'proxmox': 'Proxmox VE', 'nutanix': 'Nutanix AHV'},
    ('accounts', 'accountType'): {'admin': 'Administrator', 'service': 'Service account'},
    ('stacks', 'deviceType'): {'firewall': 'Firewall / UTM', 'utm': 'Firewall / UTM'},
    ('lags', 'aggregationType'): {'lacp': 'Dynamic'},
}


def normalize_choice(section, field, value):
    if not isinstance(value, str):
        raise ValueError(f'{section}.{field} must be text')
    if not value and (section, field) in (('licenses', 'type'), ('accounts', 'accountType')):
        return value
    key = header_key(value)
    choices = {header_key(choice): choice for choice in CHOICES[section][field]}
    canonical = choices.get(key) or CHOICE_ALIASES.get((section, field), {}).get(key)
    if canonical is None:
        raise ValueError(f'Unsupported {section}.{field}; choose one of: ' + ', '.join(CHOICES[section][field]))
    return canonical


def normalize_scalar(field, value):
    if field in INTEGER_FIELDS and isinstance(value, str) and re.fullmatch(r'\d{1,10}', value.strip()):
        return int(value.strip())
    if field in BOOLEAN_FIELDS and isinstance(value, str):
        boolean = {'true': True, 'yes': True, 'false': False, 'no': False}
        return boolean.get(value.strip().casefold(), value)
    if field == 'vlan' and type(value) is int and 1 <= value <= 4094:
        return str(value)
    if field in DATE_FIELDS and isinstance(value, str):
        # Year-first dates are unambiguous. Do not guess day/month order.
        match = re.fullmatch(r'(\d{4})[-/](\d{1,2})[-/](\d{1,2})', value.strip())
        if match:
            return date(*map(int, match.groups())).isoformat()
    return value


def normalize_fields(section, fields, allowed):
    canonical = {header_key(field): field for field in allowed}
    aliases = {header_key(key): target for key, target in {
        **COMMON_ALIASES, **SECTION_ALIASES[section],
    }.items() if target in allowed}
    normalized = {}
    for key, value in fields.items():
        if not isinstance(key, str):
            raise ValueError('Inventory field names must be text')
        target = canonical.get(header_key(key)) or aliases.get(header_key(key)) or key
        value = normalize_scalar(target, value) if target in allowed else value
        if target in CHOICES.get(section, {}):
            value = normalize_choice(section, target, value)
        if target in normalized and normalized[target] != value:
            raise ValueError(f'Conflicting columns for {target}; clarify which value to import')
        normalized[target] = value
    fields.clear()
    fields.update(normalized)
