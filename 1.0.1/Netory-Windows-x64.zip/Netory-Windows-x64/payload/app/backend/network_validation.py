"""Validate conventional on-link gateways and explicitly entered DHCP ranges."""
from ipaddress import ip_address, ip_network
from fastapi import HTTPException


def validate_network_parameters(network, gateway=None, dhcp=None):
    subnet = ip_network(network, strict=True) if network else None
    next_hop = ip_address(gateway) if gateway else None
    if next_hop is not None:
        if next_hop.is_multicast or next_hop.is_unspecified or str(next_hop) == '255.255.255.255':
            raise HTTPException(status_code=422, detail='Gateway must be a unicast host address')
        if subnet:
            if next_hop.version != subnet.version:
                raise HTTPException(status_code=422, detail='Gateway and network must use the same IP version')
            # IPv6 link-local next hops and IPv4 /32 routed host records are valid exceptions.
            off_link_allowed = (subnet.version == 6 and next_hop.is_link_local) or (subnet.version == 4 and subnet.prefixlen == 32)
            if next_hop not in subnet and not off_link_allowed:
                raise HTTPException(status_code=422, detail='Gateway must belong to the network subnet')
            if subnet.version == 4 and subnet.prefixlen < 31 and next_hop in (subnet.network_address, subnet.broadcast_address):
                raise HTTPException(status_code=422, detail='Gateway cannot be the network or broadcast address')
    if not dhcp:
        return
    text = dhcp.strip()
    if '-' not in text:
        try:
            server = ip_address(text)
        except ValueError as error:
            raise HTTPException(status_code=422, detail='DHCP must be a server IP address or a start-end address range') from error
        if server.is_multicast or server.is_unspecified or str(server) == '255.255.255.255':
            raise HTTPException(status_code=422, detail='DHCP server must be a unicast host address')
        if subnet and server.version != subnet.version:
            raise HTTPException(status_code=422, detail='DHCP server and network must use the same IP version')
        return  # A DHCP server may be reached through a relay in another subnet.
    parts = text.split('-')
    try:
        if len(parts) != 2:
            raise ValueError()
        start, end = (ip_address(part.strip()) for part in parts)
    except ValueError as error:
        raise HTTPException(status_code=422, detail='DHCP range must contain valid start and end IP addresses') from error
    if subnet is None:
        raise HTTPException(status_code=422, detail='A network/CIDR is required for a DHCP range')
    if start.version != subnet.version or end.version != subnet.version or start not in subnet or end not in subnet:
        raise HTTPException(status_code=422, detail='DHCP range must belong to the network subnet')
    if int(start) > int(end):
        raise HTTPException(status_code=422, detail='DHCP range start must not exceed its end')
    multicast = ip_network('224.0.0.0/4' if start.version == 4 else 'ff00::/8')
    if (int(start) == 0 or
            (int(start) <= int(multicast.broadcast_address) and int(end) >= int(multicast.network_address)) or
            (start.version == 4 and int(end) == 4294967295)):
        raise HTTPException(status_code=422, detail='DHCP range must contain only unicast host addresses')
    if subnet.version == 4 and subnet.prefixlen < 31 and (start == subnet.network_address or end == subnet.broadcast_address):
        raise HTTPException(status_code=422, detail='DHCP range cannot include network or broadcast addresses')
    if next_hop and next_hop.version == start.version and int(start) <= int(next_hop) <= int(end):
        raise HTTPException(status_code=422, detail='DHCP range cannot include the gateway address')
