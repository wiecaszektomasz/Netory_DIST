"""Browser defenses shared by direct and reverse-proxy deployments."""
from fastapi.responses import JSONResponse

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: blob:; font-src 'self'; worker-src 'self' blob:; "
       "connect-src 'self'; object-src 'none'; base-uri 'none'; "
       "form-action 'self'; frame-ancestors 'none'")


async def security_headers(request, call_next):
    if request.url.path.startswith('/api/') and request.method not in {'GET', 'HEAD', 'OPTIONS'}:
        origin = request.headers.get('origin')
        if (request.headers.get('sec-fetch-site') == 'cross-site'
                or (origin and origin.rstrip('/') != str(request.base_url).rstrip('/'))):
            response = JSONResponse({'detail': 'Same-origin request required'}, status_code=403)
        else:
            response = await call_next(request)
    else:
        response = await call_next(request)
    response.headers['Content-Security-Policy'] = CSP
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=(), payment=(), usb=()'
    if request.url.scheme == 'https':
        response.headers['Strict-Transport-Security'] = 'max-age=31536000'
    if request.url.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store'
    return response
