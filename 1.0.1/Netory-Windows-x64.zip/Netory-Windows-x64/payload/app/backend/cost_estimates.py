"""Cost planning uses decimal net amounts; tax is applied once to the subtotal."""
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Literal
from uuid import uuid4

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy import delete, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from backend.audit import AuditedRoute, record_activity
from backend.config import settings
from backend.db import get_db
from backend.models import Asset, CostEstimate, CostPricing, License
from backend.security import current_user

router = APIRouter(prefix='/api/environments/{environment_id}/cost-estimates', route_class=AuditedRoute)
CENT = Decimal('0.01')
MAX_PRICE = Decimal('999999999.99')


def decimal_value(value, label, scale=2, maximum=MAX_PRICE):
    if isinstance(value, bool):
        raise ValueError(f'{label} must be a non-negative decimal')
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ValueError(f'{label} must be a non-negative decimal') from None
    if not amount.is_finite() or amount < 0 or amount > maximum or amount != amount.quantize(Decimal(10) ** -scale):
        raise ValueError(f'{label} must be between 0 and {maximum}, with at most {scale} decimal places')
    return amount


def money(value):
    return format(value.quantize(CENT, rounding=ROUND_HALF_UP), '.2f')


class CustomItem(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=240)
    quantity: str = '1'
    unit_price: str = '0.00'

    @field_validator('name')
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError('Item name cannot be blank')
        return value.strip()

    @field_validator('quantity', mode='before')
    @classmethod
    def quantity_value(cls, value):
        quantity = decimal_value(value, 'Quantity', 3, Decimal('1000000'))
        if quantity <= 0:
            raise ValueError('Quantity must be greater than zero')
        return str(quantity)

    @field_validator('unit_price', mode='before')
    @classmethod
    def price_value(cls, value):
        return money(decimal_value(value, 'Unit net price'))


    @model_validator(mode='after')
    def line_total_limit(self):
        if Decimal(self.quantity) * Decimal(self.unit_price) > MAX_PRICE:
            raise ValueError('Custom item net total cannot exceed 999999999.99')
        return self


class EstimateInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=240)
    project_number: str = Field(default='', max_length=120)
    valid_until: date
    currency: Literal['PLN', 'EUR', 'USD', 'GBP'] = Field(default_factory=lambda: settings.cost_estimate_default_currency)
    tax_rate: str = '23.00'
    custom_items: list[CustomItem] = Field(default_factory=list, max_length=500)

    @field_validator('name')
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError('Estimate name cannot be blank')
        return value.strip()

    @field_validator('tax_rate', mode='before')
    @classmethod
    def tax_value(cls, value):
        return money(decimal_value(value, 'Tax rate', 2, Decimal('100')))


def access(db, user, environment_id, write=False):
    from backend.main import environment_access
    return environment_access(db, user, environment_id, write=write)


def pricing_fields(db, environment_id):
    return {(row.section, row.record_id): {'costEstimateId': row.estimate_id or '', 'netPrice': row.net_price or ''}
            for row in db.scalars(select(CostPricing).where(CostPricing.environment_id == environment_id))}


def save_pricing(db, environment_id, section, record_id, fields):
    """Participates in the inventory transaction; omitted fields preserve old pricing."""
    if not {'costEstimateId', 'netPrice'}.intersection(fields):
        return
    row = db.get(CostPricing, (environment_id, section, record_id))
    estimate_id = fields.get('costEstimateId', row.estimate_id if row else None)
    if estimate_id not in (None, '') and (not isinstance(estimate_id, str) or len(estimate_id) > 36):
        raise HTTPException(422, 'Cost estimate ID must be a string of at most 36 characters.')
    estimate_id = estimate_id or None
    raw_price = fields.get('netPrice', row.net_price if row else None)
    if raw_price in (None, ''):
        price = None
    else:
        try:
            price = money(decimal_value(raw_price, 'Net price'))
        except ValueError as error:
            raise HTTPException(422, str(error)) from None
    if estimate_id:
        estimate = db.scalar(select(CostEstimate).where(CostEstimate.id == estimate_id, CostEstimate.environment_id == environment_id).with_for_update())
        if not estimate:
            raise HTTPException(422, 'Cost estimate must belong to the selected client.')
        if price is None:
            raise HTTPException(422, 'Assigned estimate items require a net price; enter 0 for a free item.')
        if section == 'assets':
            asset = db.get(Asset, (record_id, environment_id))
            if asset.status != 'Planned' and (not row or row.estimate_id != estimate_id):
                raise HTTPException(422, 'Only Planned devices can be assigned to a cost estimate.')
    if estimate_id is None and price is None:
        if row is not None:
            db.delete(row)
        return
    if row is None:
        row = CostPricing(environment_id=environment_id, section=section, record_id=record_id)
        db.add(row)
    row.estimate_id, row.net_price = estimate_id, price


def estimate_inventory(db, environment_id):
    assets = {row.id: row for row in db.scalars(select(Asset).where(Asset.environment_id == environment_id))}
    licenses = {row.id: row for row in db.scalars(select(License).where(License.environment_id == environment_id))}
    pricing = {}
    for row in db.scalars(select(CostPricing).where(CostPricing.environment_id == environment_id)):
        pricing.setdefault(row.estimate_id, []).append(row)
    return assets, licenses, pricing


def estimate_data(db, estimate, inventory=None):
    assets, licenses, pricing_by_estimate = inventory if inventory is not None else estimate_inventory(db, estimate.environment_id)
    lines, excluded = [], []
    for pricing in pricing_by_estimate.get(estimate.id, []):
        record = (assets if pricing.section == 'assets' else licenses).get(pricing.record_id)
        if record is None:
            continue
        if pricing.section == 'assets' and record.status != 'Planned':
            excluded.append({'id': record.id, 'name': record.name, 'status': record.status})
            continue
        lines.append({'kind': 'device' if pricing.section == 'assets' else 'license', 'id': record.id,
                      'name': record.name if pricing.section == 'assets' else record.product,
                      'manufacturer_model': (record.manufacturer if pricing.section == 'assets' else record.vendor) or '',
                      'quantity': '1', 'unit_price': pricing.net_price, 'net_total': pricing.net_price})
    for index, item in enumerate(estimate.custom_items or []):
        lines.append({'kind': 'custom', 'id': str(index), **item,
                      'net_total': money(Decimal(item['quantity']) * Decimal(item['unit_price']))})
    totals = {kind: sum((Decimal(line['net_total']) for line in lines if line['kind'] == kind), Decimal(0))
              for kind in ('device', 'license', 'custom')}
    net = sum(totals.values(), Decimal(0))
    tax = (net * Decimal(estimate.tax_basis_points) / Decimal(10000)).quantize(CENT, rounding=ROUND_HALF_UP)
    return {'id': estimate.id, 'name': estimate.name, 'project_number': estimate.project_number,
            'valid_until': estimate.valid_until.isoformat(), 'currency': estimate.currency,
            'tax_rate': money(Decimal(estimate.tax_basis_points) / 100), 'version': estimate.version,
            'custom_items': estimate.custom_items or [], 'lines': lines, 'excluded_devices': excluded,
            'net_subtotal': money(net), 'tax_total': money(tax), 'gross_total': money(net + tax),
            'category_totals': {kind: money(amount) for kind, amount in totals.items()}}


@router.get('')
def list_estimates(environment_id: str, catalog: bool = False, user=Depends(current_user), db: Session = Depends(get_db)):
    access(db, user, environment_id)
    rows = list(db.scalars(select(CostEstimate).where(
        CostEstimate.environment_id == environment_id).order_by(CostEstimate.name)))
    if catalog:
        return [{'id': row.id, 'name': row.name, 'currency': row.currency} for row in rows]
    inventory = estimate_inventory(db, environment_id) if rows else None
    return [estimate_data(db, row, inventory) for row in rows]


def values(payload):
    return {'name': payload.name, 'project_number': payload.project_number.strip(), 'valid_until': payload.valid_until,
            'currency': payload.currency, 'tax_basis_points': int(Decimal(payload.tax_rate) * 100),
            'custom_items': [item.model_dump() for item in payload.custom_items]}


def commit(db):
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, 'A cost estimate with this name already exists in this client.') from None


@router.post('', status_code=201)
def create_estimate(environment_id: str, payload: EstimateInput, user=Depends(current_user), db: Session = Depends(get_db)):
    environment = access(db, user, environment_id, True)
    row = CostEstimate(id=str(uuid4()), environment_id=environment_id, version=1, **values(payload))
    db.add(row)
    record_activity(db, {"user_id": user.id, "username": user.username, "is_admin": user.is_admin}, 'added', f'{user.username} added cost estimate “{row.name}” in “{environment.name}”', 'cost_estimates')
    commit(db)
    return estimate_data(db, row)


@router.put('/{estimate_id}')
def update_estimate(environment_id: str, estimate_id: str, payload: EstimateInput,
                    if_match: int = Header(), user=Depends(current_user), db: Session = Depends(get_db)):
    environment = access(db, user, environment_id, True)
    row = db.scalar(select(CostEstimate).where(CostEstimate.id == estimate_id, CostEstimate.environment_id == environment_id).with_for_update())
    if not row:
        raise HTTPException(404, 'Cost estimate not found.')
    if payload.currency != row.currency and db.scalar(select(CostPricing.record_id).where(CostPricing.estimate_id == estimate_id).limit(1)):
        raise HTTPException(422, 'Unassign inventory items before changing currency; existing prices are not converted.')
    try:
        result = db.execute(update(CostEstimate).where(CostEstimate.id == estimate_id, CostEstimate.environment_id == environment_id,
                                                     CostEstimate.version == if_match).values(**values(payload), version=CostEstimate.version + 1))
        if result.rowcount != 1:
            raise HTTPException(409, 'Cost estimate changed elsewhere. Reload before saving.')
        record_activity(db, {"user_id": user.id, "username": user.username, "is_admin": user.is_admin}, 'changed', f'{user.username} changed cost estimate “{payload.name}” in “{environment.name}”', 'cost_estimates')
        commit(db)
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, 'A cost estimate with this name already exists in this client.') from None
    db.refresh(row)
    return estimate_data(db, row)


def prune_pricing(db, environment_id, section, record_ids):
    query = delete(CostPricing).where(CostPricing.environment_id == environment_id, CostPricing.section == section)
    if record_ids:
        query = query.where(CostPricing.record_id.not_in(record_ids))
    db.execute(query)


def assistant_cost_answer(db, environment_id, question):
    """Answer cost questions locally; financial records never enter provider context."""
    import re
    from backend import assistant_config
    if not re.search(r'\b(cost|costs|estimates?|budgets?|prices?|pricing|tax|vat|gross|subtotal)\b', question, re.I):
        return None
    if not assistant_config.section_allowed('cost_estimates'):
        return 'Cost estimate access is disabled by the global assistant configuration.'
    if re.search(r'^\s*(?:(?:please|can you|could you|would you|I want to|I want you to)\s+)*(?:create|add|edit|update|change|set|apply|remove|delete)\b', question, re.I):
        return 'I can read cost estimates and their totals. To change financial data, use Cost estimates → Estimate settings or the Planned device/license pricing controls. No financial changes were proposed.'
    rows = list(db.scalars(select(CostEstimate).where(CostEstimate.environment_id == environment_id).order_by(CostEstimate.name)))
    named = [row for row in rows if re.search(r'(?<![\w-])' + re.escape(row.name) + r'(?![\w-])', question, re.I)]
    if not rows:
        return 'No cost estimates are recorded in the selected client environment.'
    if not named:
        requested = re.search(r'\bcost\s+estimate\s+(?:(?:named|called)\s+)?(.+?)\s*[?.!]*$', question, re.I)
        if requested:
            name = requested[1].strip().strip('\"\'').rstrip('?.!').strip()
            return f'No cost estimate named “{name}” is recorded in the selected client. Check the name or ask to list cost estimates.'
    chosen = named or rows
    inventory = estimate_inventory(db, environment_id)
    lines = [assistant_config.LOCAL_COST_ANSWER_MARKER]
    for row in chosen:
        estimate = estimate_data(db, row, inventory)
        lines.append(f"{row.name} · Project {row.project_number or '—'} · Valid until {row.valid_until.isoformat()}")
        totals = estimate['category_totals']
        lines.append(f"Planned devices: {totals['device']} {row.currency}; licenses: {totals['license']} {row.currency}; custom items: {totals['custom']} {row.currency}.")
        lines.append(f"Net subtotal: {estimate['net_subtotal']} {row.currency}; tax ({estimate['tax_rate']}%): {estimate['tax_total']} {row.currency}; total including tax: {estimate['gross_total']} {row.currency}.")
        if named or len(rows) == 1:
            for item in estimate['lines']:
                lines.append(f"- {item['name']}: quantity {item['quantity']}, unit net price {item['unit_price']} {row.currency}, line net total {item['net_total']} {row.currency}.")
            for item in estimate['excluded_devices']:
                lines.append(f"Excluded: {item['name']} ({item['status']}); only Planned devices contribute.")
    lines.append('Stored prices exclude tax; tax is calculated once on the net subtotal. License prices are total record costs, not per-seat prices. These are estimates, not live purchase prices.')
    answer = '\n'.join(lines)
    if len(answer) > 5800:
        return 'The cost estimate details exceed the reply limit. Specify an estimate name and view its full line-item summary under Cost estimates.'
    return answer


@router.get('/defaults')
def estimate_defaults(environment_id: str, user=Depends(current_user), db: Session = Depends(get_db)):
    access(db, user, environment_id)
    return {'currency': settings.cost_estimate_default_currency, 'tax_rate': '23.00'}


@router.delete('/{estimate_id}')
def delete_estimate(environment_id: str, estimate_id: str, if_match: int = Header(),
                    user=Depends(current_user), db: Session = Depends(get_db)):
    from backend.main import advance_environment_revision, read_inventory
    environment = access(db, user, environment_id, True)
    row = db.scalar(select(CostEstimate).where(CostEstimate.id == estimate_id,
        CostEstimate.environment_id == environment_id).with_for_update())
    if not row:
        raise HTTPException(404, 'Cost estimate not found.')
    if row.version != if_match:
        raise HTTPException(409, 'Cost estimate changed elsewhere. Reload before deleting.')
    name = row.name
    db.execute(update(CostPricing).where(CostPricing.environment_id == environment_id,
        CostPricing.estimate_id == estimate_id).values(estimate_id=None))
    revision = advance_environment_revision(db, environment, None)
    db.delete(row)
    record_activity(db, {"user_id": user.id, "username": user.username, "is_admin": user.is_admin},
        'deleted', f'{user.username} deleted cost estimate “{name}” in “{environment.name}”', 'cost_estimates')
    db.commit()
    return {'revision': revision, 'data': read_inventory(db, environment_id)}
