"""Private saved report settings, scoped to a user and client."""
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from backend.audit import AuditedRoute
from backend.db import get_db
from backend.models import ReportConfigurations
from backend.security import current_user

router = APIRouter(prefix='/api/environments/{environment_id}/report-configurations', route_class=AuditedRoute)


class ReportOptions(BaseModel):
    model_config = ConfigDict(extra='forbid')
    type: Literal['overview', 'assets', 'licenses', 'warranty', 'quality'] = 'overview'
    groupBy: Literal['type', 'status', 'manufacturer', 'location'] = 'type'
    horizon: Literal[30, 60, 90, 180, 365] = 90
    search: str = Field(default='', max_length=150)
    assetType: str = Field(default='', max_length=240)
    status: str = Field(default='', max_length=240)
    location: str = Field(default='', max_length=240)
    expiryOnly: bool = False
    columns: list[str] = Field(default_factory=list, max_length=20)

    @field_validator('columns')
    @classmethod
    def valid_columns(cls, values):
        allowed = {'name', 'type', 'status', 'manufacturer', 'location', 'hostname', 'ip', 'serial',
                   'warrantyExpiry', 'product', 'vendor', 'seats', 'assigned', 'available', 'expiry',
                   'owner', 'daysRemaining', 'missing', 'group', 'count', 'share'}
        if any(value not in allowed for value in values):
            raise ValueError('Unknown report column')
        return list(dict.fromkeys(values))


class ReportPreset(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=80)
    options: ReportOptions

    @field_validator('name')
    @classmethod
    def not_blank(cls, value):
        if not value.strip():
            raise ValueError('Enter a configuration name')
        return value.strip()


class ReportSave(BaseModel):
    model_config = ConfigDict(extra='forbid')
    version: int = Field(strict=True, ge=0)
    items: list[ReportPreset] = Field(max_length=20)

    @field_validator('items')
    @classmethod
    def unique_names(cls, items):
        if len({item.name for item in items}) != len(items):
            raise ValueError('Report configuration names must be unique')
        return items


def authorize(db, user, environment_id):
    from backend.main import environment_access
    # Viewers can save their own settings without changing inventory.
    environment_access(db, user, environment_id)


@router.get('')
def get_configurations(environment_id: str, user=Depends(current_user), db: Session = Depends(get_db)):
    authorize(db, user, environment_id)
    row = db.get(ReportConfigurations, (user.id, environment_id))
    return {'items': row.items if row else [], 'version': row.version if row else 0}


@router.put('')
def save_configurations(environment_id: str, payload: ReportSave,
                        user=Depends(current_user), db: Session = Depends(get_db)):
    authorize(db, user, environment_id)
    items = [item.model_dump() for item in payload.items]
    conflict = 'Saved reports changed on another device. Reopen Reports before saving again.'
    if payload.version == 0:
        db.add(ReportConfigurations(user_id=user.id, environment_id=environment_id, items=items, version=1))
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            raise HTTPException(409, conflict)
    else:
        changed = db.execute(update(ReportConfigurations).where(
            ReportConfigurations.user_id == user.id,
            ReportConfigurations.environment_id == environment_id,
            ReportConfigurations.version == payload.version,
        ).values(items=items, version=payload.version + 1))
        if changed.rowcount != 1:
            db.rollback()
            raise HTTPException(409, conflict)
        db.commit()
    return {'items': items, 'version': payload.version + 1}
