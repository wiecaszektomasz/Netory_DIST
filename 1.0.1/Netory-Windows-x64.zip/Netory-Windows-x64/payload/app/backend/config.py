import os
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    license_state_dir: str = os.path.join(os.environ.get('PROGRAMDATA', 'C:/ProgramData'), 'Netory', 'licensing') if os.name == 'nt' else '/var/lib/netory/licensing'
    database_url: str = "sqlite:///./stackroom.db"
    cost_estimate_default_currency: Literal["PLN", "EUR", "USD", "GBP"] = "PLN"
    cookie_secure: bool = True
    session_days: int = 7
    wlan_encryption_key: str = ""
    zabbix_encryption_key: str = ""
    ai_encryption_key: str = ""
    ai_allow_insecure_http: bool = False
    ai_allowed_hosts: str = "api.openai.com,api.anthropic.com,generativelanguage.googleapis.com,openrouter.ai,api.groq.com,api.deepseek.com,api.mistral.ai"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


settings = Settings()
