"""Global admin-maintained OS catalog; per-asset Other values remain environment scoped."""
from datetime import date
from typing import Literal
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from backend.db import get_db
from backend.models import OperatingSystem
from backend.security import current_user, require_admin

router = APIRouter(prefix='/api/operating-systems')


def default_catalog():
    result = []
    def add(id, name, family, eol, notes, source):
        result.append(dict(id=id, name=name, family=family, eol=eol, supportNotes=notes, sourceUrl=source))
    add('windows-10', 'Windows 10', 'Windows', '2025-10-14',
        'End of support for standard editions (22H2); optional Extended Security Updates excluded. LTSC editions have separate lifecycles.',
        'https://learn.microsoft.com/en-us/lifecycle/products/windows-10-home-and-pro')
    add('windows-11', 'Windows 11', 'Windows', None,
        'Support deadlines depend on the installed feature version and edition. No single end-of-support date applies to Windows 11.',
        'https://learn.microsoft.com/en-us/lifecycle/products/windows-11-home-and-pro')
    for version, end in [('2019', '2029-01-09'), ('2022', '2031-10-14'), ('2025', '2034-11-14')]:
        add('windows-server-' + version, 'Windows Server ' + version, 'Windows', end,
            'End of extended support (vendor calendar date); optional paid extensions excluded.',
            'https://learn.microsoft.com/en-us/lifecycle/products/windows-server-' + version)
        for edition in ['Standard', 'Datacenter']:
            add('windows-server-' + version + '-' + edition.lower(),
                'Windows Server ' + version + ' ' + edition, 'Windows', end,
                'End of extended support (vendor calendar date); optional paid extensions excluded.',
                'https://learn.microsoft.com/en-us/lifecycle/products/windows-server-' + version)
    for version, month in [('22.04', 'May 2027'), ('24.04', 'May 2029'), ('26.04', 'May 2031')]:
        add('ubuntu-' + version, 'Ubuntu ' + version + ' LTS', 'Linux', None,
            'Standard security maintenance ends ' + month + '. Vendor publishes a month, not an exact day. Ubuntu Pro extends coverage.',
            'https://ubuntu.com/about/release-cycle')
    for version, end in [('12', '2028-06-30'), ('13', '2030-06-30')]:
        add('debian-' + version, 'Debian ' + version, 'Linux', end, 'End of Debian LTS; package and architecture coverage varies.', 'https://www.debian.org/releases/')
    for version, end in [('8', '2029-05-31'), ('9', '2032-05-31'), ('10', '2035-05-31')]:
        add('rocky-' + version, 'Rocky Linux ' + version, 'Linux', end, 'End of security support.', 'https://docs.rockylinux.org/releases/')
        add('alma-' + version, 'AlmaLinux ' + version, 'Linux', end, 'End of security support for the major release; keep minor releases current.', 'https://wiki.almalinux.org/release-notes/')
    for version in ['8', '9', '10']:
        add('rhel-' + version, 'Red Hat Enterprise Linux ' + version, 'Linux', None,
            'Ten-year major-release lifecycle; minor-release coverage and extensions depend on subscription. Verify the applicable vendor lifecycle date.',
            'https://access.redhat.com/support/policy/updates/errata')
    for version in ['Sonoma 14', 'Sequoia 15', 'Tahoe 26']:
        add('macos-' + version.split()[-1], 'macOS ' + version, 'macOS', None, 'No fixed end-of-support date published. Review Apple security releases.', 'https://support.apple.com/en-us/100100')
    for version, end, notes in [
        ('7', '2025-10-02', 'End of general support; technical guidance is a separate phase.'),
        ('8', None, 'Verify the exact general-support deadline in the vendor product lifecycle matrix; technical guidance is a separate phase.'),
        ('9', None, 'Lifecycle varies by 9.x release. Verify the installed minor version in the vendor product lifecycle matrix.'),
    ]:
        add('vmware-esxi-' + version, 'VMware ESXi ' + version + '.x', 'Other', end, notes,
            'https://knowledge.broadcom.com/external/article/326984' if version == '7' else 'https://support.broadcom.com/group/ecx/productlifecycle')
    for version, notes in [
        ('7', 'Support ended July 2024; vendor publishes a month, not an exact day.'),
        ('8', 'Support ended August 2026; vendor publishes a month, not an exact day.'),
        ('9', 'End of support not yet announced. Keep the installed minor version current.'),
    ]:
        add('proxmox-ve-' + version, 'Proxmox VE ' + version + '.x', 'Linux', None, notes,
            'https://pve.proxmox.com/pve-docs/chapter-pve-faq.html#faq-support-table')
    return result


class OSInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=240)
    family: Literal['Windows', 'Linux', 'macOS', 'Other']
    eol: date | None = None
    supportNotes: str = Field(default='', max_length=1000)
    sourceUrl: str = Field(default='', max_length=1000)

    @field_validator('name')
    @classmethod
    def trim_name(cls, value):
        value = value.strip()
        if not value:
            raise ValueError('Operating system name is required')
        return value

    @field_validator('sourceUrl')
    @classmethod
    def safe_link(cls, value):
        if value and not value.startswith('https://'):
            raise ValueError('Source URL must use HTTPS')
        return value


def catalog(db):
    rows = {row['id']: row for row in default_catalog()}
    for row in db.scalars(select(OperatingSystem)):
        rows[row.id] = dict(id=row.id, name=row.name, family=row.family,
                            eol=row.eol.isoformat() if row.eol else None,
                            supportNotes=row.support_notes or '', sourceUrl=row.source_url or '')
    return sorted(rows.values(), key=lambda row: (row['family'], row['name'].casefold()))


@router.get('')
def list_os(user=Depends(current_user), db: Session = Depends(get_db)):
    return catalog(db)


def write_os(db, id, payload):
    if any(row['id'] != id and row['name'].casefold() == payload.name.casefold() for row in catalog(db)):
        raise HTTPException(409, 'An operating system with this name already exists')
    row = db.get(OperatingSystem, id)
    if row is None:
        row = OperatingSystem(id=id)
        db.add(row)
    row.name, row.family, row.eol = payload.name, payload.family, payload.eol
    row.support_notes, row.source_url = payload.supportNotes, payload.sourceUrl
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, 'An operating system with this name already exists') from None
    return next(item for item in catalog(db) if item['id'] == id)


@router.post('')
def create_os(payload: OSInput, user=Depends(require_admin), db: Session = Depends(get_db)):
    return write_os(db, str(uuid4()), payload)


@router.put('/{id}')
def update_os(id: str, payload: OSInput, user=Depends(require_admin), db: Session = Depends(get_db)):
    if not any(item['id'] == id for item in catalog(db)):
        raise HTTPException(404, 'Operating system not found')
    return write_os(db, id, payload)
