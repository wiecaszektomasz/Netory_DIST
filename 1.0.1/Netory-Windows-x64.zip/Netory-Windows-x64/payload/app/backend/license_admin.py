"""OS-administrator provisioning CLI; never regenerate an existing installation."""
import argparse
import json
from pathlib import Path
from backend.licensing import manager


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['init','status','install'])
    parser.add_argument('file', nargs='?', type=Path)
    args=parser.parse_args()
    if args.command=='init':
        print('Installation ID: '+manager.provision())
    elif args.command=='status':
        print(json.dumps(manager.status(details=True),indent=2))
    else:
        if not args.file: parser.error('A signed file is required')
        raw=args.file.read_bytes()
        if len(raw)>16384: parser.error('File exceeds 16 KB')
        print(json.dumps(manager.install(raw),indent=2))


if __name__=='__main__': main()
