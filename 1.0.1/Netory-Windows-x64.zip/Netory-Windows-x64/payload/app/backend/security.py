import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from backend.config import settings
from backend.db import get_db
from backend.models import SessionSettings, User, UserSession


password_hasher = PasswordHasher()
SESSION_COOKIE = "stackroom_session"


def hash_password(password: str) -> str:
    return password_hasher.hash(password)


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        return password_hasher.verify(stored_hash, password)
    except VerifyMismatchError:
        return False


def digest_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_session(db: Session, user: User) -> str:
    token = secrets.token_urlsafe(48)
    expires_at = datetime.now(timezone.utc) + timedelta(days=settings.session_days)
    db.add(UserSession(token_hash=digest_token(token), user_id=user.id, expires_at=expires_at))
    db.commit()
    return token


def idle_timeout_minutes(db: Session) -> int:
    policy = db.get(SessionSettings, 1)
    return policy.idle_timeout_minutes if policy else 30


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sign in required")
    session = db.get(UserSession, digest_token(token))
    now = datetime.now(timezone.utc)
    if not session:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired")
    expires_at = session.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    last_activity = session.last_activity_at
    if last_activity.tzinfo is None:
        last_activity = last_activity.replace(tzinfo=timezone.utc)
    if expires_at <= now or last_activity + timedelta(minutes=idle_timeout_minutes(db)) <= now:
        db.delete(session)
        db.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired")
    user = db.get(User, session.user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Account unavailable")
    if request.url.path != "/api/session/status":
        session.last_activity_at = now
        db.commit()
    request.state.audit_actor = {"user_id": user.id, "username": user.username, "is_admin": user.is_admin}
    return user


def require_admin(user: User = Depends(current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Administrator access required")
    return user


def require_assistant_write(user: User = Depends(current_user)) -> User:
    if not (user.is_admin or user.assistant_write_enabled):
        raise HTTPException(status_code=403, detail="Writable AI chat permission required")
    return user
