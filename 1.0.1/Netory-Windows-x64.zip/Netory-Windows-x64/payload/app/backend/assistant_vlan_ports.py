"""Exact read-only VLAN port listings from the complete authorized snapshot."""
import re

KINDS = {'switch': 'Switch', 'switches': 'Switch', 'router': 'Router', 'routers': 'Router',
         'physical server': 'Physical server', 'physical servers': 'Physical server'}
KIND = r'(switches|switch|routers|router|physical servers|physical server)'
LISTING = re.compile(
    r'\s*(?:please\s+)?(?:give\s+me|show\s+(?:me\s+)?|list|which\s+are|what\s+are)\s*'
    r'(?:all\s+|the\s+)?(?:(switch|router|physical server)\s+)?ports\s+'
    r'(?:in|on|for|assigned\s+to)\s+vlan\s*(?:id\s*)?(\d+)'
    r'(?:\s+(?:on|in|for)\s+(?:all\s+|the\s+)?' + KIND + r')?\s*[?.!]?\s*', re.I)
FOLLOWUP = re.compile(r'\s*(?:what\s+about|how\s+about|and|only|just)\s+(?:the\s+)?' + KIND + r'\s*[?.!]?\s*', re.I)


def ranges(ports):
    groups = []
    for port in sorted(set(ports)):
        if groups and port == groups[-1][1] + 1:
            groups[-1][1] = port
        else:
            groups.append([port, port])
    return ', '.join(str(start) if start == end else f'{start}–{end}' for start, end in groups)


def vlan_ports_answer(context, messages):
    if not messages or context.get('context_scope', {}).get('partial'):
        return None
    denied = context.get('assistant_access', {}).get('read_disabled', [])
    if {'assets', 'vlans'}.intersection(denied):
        return None
    question = messages[-1].content
    match = LISTING.fullmatch(question)
    category = None
    if not match:
        followup = FOLLOWUP.fullmatch(question)
        if not followup:
            return None
        category = KINDS[followup[1].lower()]
        # Carry the reference only through port-listing turns, never unrelated topics
        # or an invented VLAN number in an earlier assistant response.
        for message in reversed(messages[:-1]):
            if message.role != 'user':
                continue
            match = LISTING.fullmatch(message.content)
            if match:
                break
            if not FOLLOWUP.fullmatch(message.content):
                return None
    if not match:
        return None
    number = int(match[2])
    if not 1 <= number <= 4094:
        return 'Choose a VLAN ID between 1 and 4094.'
    category = category or KINDS.get((match[3] or match[1] or '').lower())
    lines, count, devices = [], 0, 0
    for asset in sorted(context.get('assets', []), key=lambda row: (row.get('name', ''), row['id'])):
        if category and asset.get('type') != category:
            continue
        tagged, untagged = [], []
        for port in range(1, (asset.get('port_count') or 0) + 1):
            config = (asset.get('port_vlans') or {}).get(str(port), {'untaggedVlan': 1})
            if number in (config.get('taggedVlans') or []):
                tagged.append(port)
            if config.get('untaggedVlan') == number:
                untagged.append(port)
        if not tagged and not untagged:
            continue
        count += len(set(tagged + untagged))
        devices += 1
        parts = ([f'tagged ports {ranges(tagged)}'] if tagged else []) + ([f'untagged ports {ranges(untagged)}'] if untagged else [])
        lines.append(f'- {asset["name"]} ({asset["type"]}): ' + '; '.join(parts))
    scope = f' on {category.lower()} devices' if category else ''
    if not count:
        return f'No recorded physical port assignments for VLAN {number}{scope} in the selected environment. A management VLAN or VLAN definition does not assign physical ports.'
    header = f'Recorded ports in VLAN {number}{scope}: {count} {'port' if count == 1 else 'ports'} across {devices} {'device' if devices == 1 else 'devices'}.\n'
    body = '\n'.join(lines)
    if len(body) > 5100:
        kept = []
        for line in lines:
            if len('\n'.join(kept + [line])) > 5100:
                break
            kept.append(line)
        body = '\n'.join(kept) + f'\nShowing {len(kept)} of {devices} devices. Narrow the request by device type to list more.'
    return header + body + '\nThese are inventory assignments, not live forwarding checks. No inventory changes were proposed or saved.'
