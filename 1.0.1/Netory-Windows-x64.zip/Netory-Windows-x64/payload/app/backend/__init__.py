"""Netory application backend."""
