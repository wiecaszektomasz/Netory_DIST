"""Optional physical-server out-of-band management inventory."""
from ipaddress import ip_address
from fastapi import HTTPException

FIELDS = {'enabled': 'managementControllerEnabled', 'type': 'managementControllerType',
          'ip': 'managementControllerIp', 'model': 'managementControllerModel', 'vlan': 'managementControllerVlan'}
TYPES = ('IPMI', 'iDRAC', 'KVM', 'iLO', 'Other')


def public_controller(value):
    value = value or {}
    return {field: value.get(key, False if key == 'enabled' else '') for key, field in FIELDS.items()}


def normalize_controller(asset, previous, vlans):
    value = {key: asset.get(field, (previous or {}).get(key, False if key == 'enabled' else ''))
             for key, field in FIELDS.items()}
    if type(value['enabled']) is not bool:
        raise HTTPException(422, 'Management controller enabled must be a boolean')
    if asset.get('type') != 'Physical server':
        if asset.get('managementControllerEnabled') is True:
            raise HTTPException(422, 'Management controllers are available only for physical servers')
        return {}
    if not value['enabled']:
        return {}
    if value['type'] not in TYPES:
        raise HTTPException(422, 'Choose IPMI, iDRAC, KVM, iLO or Other for the management controller')
    for key in ('ip', 'model'):
        if not isinstance(value[key], str):
            raise HTTPException(422, f'Management controller {key} must be text')
        value[key] = value[key].strip()
    if len(value['model']) > 240:
        raise HTTPException(422, 'Management controller model must be at most 240 characters')
    if value['ip']:
        try:
            parsed = ip_address(value['ip'])
            if '%' in value['ip']:
                raise ValueError()
            value['ip'] = str(parsed)
        except ValueError:
            raise HTTPException(422, 'Management controller IP must be an IPv4 or IPv6 address') from None
    number = value['vlan']
    if number not in ('', None):
        try:
            if isinstance(number, bool) or str(int(number)) != str(number):
                raise ValueError()
            number = int(number)
            if not 1 <= number <= 4094 or number not in {int(str(row.get('idValue'))) for row in vlans if str(row.get('idValue')).isdigit()}:
                raise ValueError()
        except (ValueError, TypeError, OverflowError):
            raise HTTPException(422, 'Choose a defined management controller VLAN from this client') from None
        value['vlan'] = number
    else:
        value['vlan'] = ''
    return value
