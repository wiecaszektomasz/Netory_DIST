"""Online activation with signed offline entitlement and persistent clock monitoring."""
import asyncio
import base64
import hashlib
import json
import os
import platform
import secrets
import threading
import time
import hmac
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from uuid import uuid4

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

from backend.db import get_db
from backend.config import settings
from backend.license_format import verify, MAX_FILE_SIZE
from backend.license_online_protocol import make_request, verify_decision, encoded, decoded
from backend.security import current_user, require_admin
from backend.audit import AuditedRoute

TRUST = Path(__file__).parent / 'trust' / 'license-authority.pem'
SERVER = 'https://lic.netory.app/api/validate'
_request_decision = ContextVar('netory_online_license_decision', default=None)


def atomic_write(path, content):
    path = Path(path)
    temporary = path.with_name(path.name + '.' + secrets.token_hex(8) + '.tmp')
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as target:
            target.write(content)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, path)
        if os.name != 'nt':
            fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
    finally:
        temporary.unlink(missing_ok=True)



def machine_fingerprint():
    # Send only a digest. Hostname/IP are not identities: they can change or be shared.
    if os.name == 'nt':
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Cryptography',0,
                             winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            machine = str(winreg.QueryValueEx(key,'MachineGuid')[0])
    else:
        machine = next((path.read_text().strip() for path in (Path('/etc/machine-id'),Path('/var/lib/dbus/machine-id')) if path.is_file()), '')
        if not machine:
            machine = f'{platform.node()}:{uuid.getnode()}'
    return hashlib.sha256((f'netory-instance-v1:{machine}:{uuid.getnode()}').encode()).hexdigest()


class LicenseManager:
    def __init__(self,directory,certificate=TRUST,transport=None,machine_hash=None):
        self.directory,self.certificate=Path(directory),Path(certificate)
        self.thread_lock=threading.RLock()
        self.transport=transport
        self.machine_hash=machine_hash
        self.clock_anchor=None

    @contextmanager
    def locked(self):
        with self.thread_lock:
            with (self.directory / 'lock').open('a+b') as handle:
                if os.name == 'nt':
                    import msvcrt
                    handle.seek(0)
                    if not handle.read(1):
                        handle.write(b'0'); handle.flush()
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle, fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    if os.name == 'nt':
                        handle.seek(0)
                        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        fcntl.flock(handle, fcntl.LOCK_UN)

    def provision(self):
        self.directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        with self.locked():
            if any((self.directory/name).exists() for name in ('installation.json','license.netory')):
                raise ValueError('Already provisioned or incomplete state: refusing to replace installation identity')
            key=Ed25519PrivateKey.generate()
            identity={'installation_id':str(uuid4()),'instance_private_key':encoded(key.private_bytes_raw())}
            atomic_write(self.directory/'installation.json',json.dumps(identity).encode())
            return identity['installation_id']

    def identity(self):
        identity=json.loads((self.directory/'installation.json').read_bytes())
        uuid.UUID(identity['installation_id'])
        if 'instance_private_key' not in identity:
            # Upgrade existing offline identity without changing its installation ID.
            identity={'installation_id':identity['installation_id'],
                      'instance_private_key':encoded(Ed25519PrivateKey.generate().private_bytes_raw())}
            atomic_write(self.directory/'installation.json',json.dumps(identity).encode())
        return identity

    def exchange(self,payload):
        if self.transport is not None:
            return self.transport(payload)
        # Only activation and background checks contact the authority.
        with httpx.Client(timeout=httpx.Timeout(4.0,connect=3.0),follow_redirects=False,trust_env=False) as client:
            with client.stream('POST',SERVER,json=payload) as response:
                response.raise_for_status()
                raw=bytearray()
                for chunk in response.iter_bytes():
                    raw.extend(chunk)
                    if len(raw)>16384:raise ValueError('License-server response is too large')
                return json.loads(raw)

    def evaluate(self,raw,identity,activate=False):
        # Obtain a fresh signed approval bound to this activation request.
        claims=verify(raw,self.certificate.read_bytes())
        if claims.kind!='license':raise ValueError('Only application license files are supported')
        key=Ed25519PrivateKey.from_private_bytes(decoded(identity['instance_private_key']))
        request=make_request(raw,identity,key,self.machine_hash or machine_fingerprint(),secrets.token_hex(32),activate=activate)
        envelope=self.exchange(request)
        decision=verify_decision(envelope,self.certificate.read_bytes(),request,claims.license_id)
        return decision, request, envelope

    def state_write(self, payload, identity):
        key=decoded(identity['instance_private_key'])
        body=json.dumps(payload,sort_keys=True,separators=(',',':')).encode()
        atomic_write(self.directory/'activation.json',json.dumps({
            'payload':payload,'mac':hmac.new(key,body,'sha256').hexdigest()}).encode())

    def state_read(self, identity):
        state=json.loads((self.directory/'activation.json').read_bytes())
        body=json.dumps(state['payload'],sort_keys=True,separators=(',',':')).encode()
        expected=hmac.new(decoded(identity['instance_private_key']),body,'sha256').hexdigest()
        if not hmac.compare_digest(expected,state['mac']):
            raise ValueError('Invalid activation state')
        return state['payload']

    def status(self,details=False):
        checked = _request_decision.get()
        if checked is not None and not details:
            return dict(checked)
        result={'valid':False,'read_only':True,'online_required':False}
        try:
            with self.locked():
                identity=self.identity()
                if details:result.update(installation_id=identity['installation_id'],validation_server=SERVER)
                raw=(self.directory/'license.netory').read_bytes()
                claims=verify(raw,self.certificate.read_bytes())
                state=self.state_read(identity)
                request=state['request']
                key=Ed25519PrivateKey.from_private_bytes(decoded(identity['instance_private_key']))
                if (claims.kind!='license' or request['content']!=raw.decode() or
                    request['installation_id']!=identity['installation_id'] or
                    request['public_key']!=encoded(key.public_key().public_bytes_raw()) or
                    request['machine_hash']!=(self.machine_hash or machine_fingerprint()) or not request['activate']):
                    result.update(code='instance_conflict',reason='Activation belongs to another license or instance.')
                    return result
                decision=verify_decision(state['envelope'],self.certificate.read_bytes(),request,claims.license_id)
                if not decision['valid'] or decision['expires_at']!=claims.expires_at:
                    raise ValueError('Invalid activation approval')
                now=time.time()
                monotonic=time.monotonic()
                # Compare wall time both with persisted high-water and elapsed process time.
                rollback=now < state['last_time']-2
                if self.clock_anchor is not None:
                    wall,steady=self.clock_anchor
                    rollback=rollback or now < wall+(monotonic-steady)-2
                state['blocked']=state['blocked'] or rollback
                state['last_time']=max(now,state['last_time'])
                self.state_write(state,identity)
                if self.clock_anchor is None or now>=self.clock_anchor[0]+(monotonic-self.clock_anchor[1]):
                    self.clock_anchor=(now,monotonic)
                result.update(**{field:decision[field] for field in ('customer','expires_at','license_id','server_time')})
                remote=state.get('remote')
                remote_decision=None
                if remote is not None:
                    remote_request=remote['request']
                    if any(remote_request[field]!=request[field] for field in ('content','installation_id','public_key','machine_hash')):
                        raise ValueError('Remote decision belongs to another activation')
                    remote_decision=verify_decision(remote['envelope'],self.certificate.read_bytes(),remote_request,claims.license_id)
                if state['blocked']:
                    result.update(code='clock_rollback',reason='Server clock rollback detected. Correct the clock and reactivate the license online.')
                elif remote_decision is not None and not remote_decision['valid']:
                    result.update(code=remote_decision['code'],reason=remote_decision['reason'])
                elif now>=claims.expires_at:
                    result.update(code='expired',reason='License has expired.')
                elif now<max(claims.not_before,claims.issued_at):
                    result.update(code='not_yet_valid',reason='License is not yet valid.')
                else:
                    result.update(valid=True,read_only=False,code='valid',reason='License is active. Offline use is enabled until expiry.')
        except FileNotFoundError:
            result.update(code='activation_required',online_required=True,reason='Online activation is required. Import the signed license file.')
        except Exception:
            result.update(code='validation_failed',reason='License, activation state or instance identity is invalid. Netory is read-only.')
        return result

    def refresh_online(self):
        """Best-effort heartbeat; only a verified authority decision changes entitlement."""
        status=self.status()
        if status.get('code') in {'activation_required','validation_failed','instance_conflict'}:
            return status
        try:
            with self.locked():
                identity=self.identity()
                raw=(self.directory/'license.netory').read_bytes()
                activation=self.state_read(identity)['request']
            # Keep network latency out of the local write gate and state lock.
            decision,request,envelope=self.evaluate(raw,identity)
            with self.locked():
                current_identity=self.identity()
                state=self.state_read(current_identity)
                if (current_identity==identity and state['request']==activation and
                    (self.directory/'license.netory').read_bytes()==raw):
                    state['remote']={'request':request,'envelope':envelope}
                    self.state_write(state,current_identity)
        except (httpx.HTTPError, InvalidSignature, ValueError, OSError, KeyError, TypeError):
            # Outages, invalid responses and concurrent removal cannot grant or revoke access.
            pass
        return self.status()

    def remove(self):
        with self.locked():
            (self.directory/'license.netory').unlink(missing_ok=True)
            (self.directory/'activation.json').unlink(missing_ok=True)
            self.clock_anchor=None
        return self.status(details=True)

    def install(self,raw):
        if len(raw)>MAX_FILE_SIZE:raise ValueError('License file exceeds 16 KB')
        with self.locked():
            identity=self.identity()
            decision,request,envelope=self.evaluate(raw,identity,activate=True)
            if not decision['valid']:raise ValueError(decision['reason'])
            claims=verify(raw,self.certificate.read_bytes())
            now=time.time()
            if abs(now-decision['server_time'])>120:
                raise ValueError('Correct the server clock before activating (must match authority time within two minutes).')
            if decision['expires_at']!=claims.expires_at or not max(claims.issued_at,claims.not_before)<=now<claims.expires_at:
                raise ValueError('License is outside its validity period')
            atomic_write(self.directory/'license.netory',raw)
            self.state_write({'request':request,'envelope':envelope,'last_time':max(now,decision['server_time']),
                              'blocked':False},identity)
            self.clock_anchor=(now,time.monotonic())
        return self.status(details=True)


manager=LicenseManager(settings.license_state_dir)


def require_writable_license():
    status=manager.status()
    if not status['valid']:raise HTTPException(423,'Netory is read-only: '+status['reason'])


async def license_heartbeat():
    while True:
        await asyncio.to_thread(manager.refresh_online)
        await asyncio.sleep(30)


# Authentication/session bookkeeping is permitted while business data is read-only.
EXEMPT = {'/api/login', '/api/logout', '/api/session/status', '/api/session/activity',
          '/api/license/install', '/api/license/remove'}


async def license_gate(request: Request, db=Depends(get_db)):
    """Route dependency: authenticate before checking the local entitlement, once per write."""
    token = None
    if request.url.path.startswith('/api/') and request.method not in {'GET', 'HEAD', 'OPTIONS'} and request.url.path not in EXEMPT:
        # Use the same request-scoped DB override as route dependencies (including tests).
        await asyncio.to_thread(current_user, request, db)
        allowed = False
        if request.url.path == '/api/assistant/chat':
            try:
                body = await request.json()
                allowed = isinstance(body, dict) and body.get('write_mode', False) is False and not body.get('attachment')
            except Exception:
                pass
        if not allowed:
            status = await asyncio.to_thread(manager.status)
            if not status['valid']:
                raise HTTPException(423, 'Netory is read-only: ' + status['reason'])
            token = _request_decision.set(status)
    try:
        yield
    finally:
        if token is not None:
            _request_decision.reset(token)


router = APIRouter(prefix='/api/license', tags=['Application license'], route_class=AuditedRoute)


class LicenseFile(BaseModel):
    model_config = ConfigDict(extra='forbid')
    content: str = Field(min_length=1, max_length=MAX_FILE_SIZE)


@router.get('/status')
def status(user=Depends(current_user)):
    return manager.status(details=user.is_admin)


def require_same_origin(request):
    origin = request.headers.get('origin')
    if request.headers.get('sec-fetch-site') == 'cross-site' or (origin and origin.rstrip('/') != str(request.base_url).rstrip('/')):
        raise HTTPException(403, 'Same-origin request required')


def import_file(payload, request):
    require_same_origin(request)
    try:
        return manager.install(payload.content.encode())
    except Exception as error:
        raise HTTPException(422, 'License could not be installed: ' + (str(error) or 'invalid file or online validation failed')) from None


@router.post('/install')
def install(payload: LicenseFile, request: Request, user=Depends(require_admin)):
    return import_file(payload, request)


@router.post('/remove')
def remove(request: Request, user=Depends(require_admin)):
    require_same_origin(request)
    return manager.remove()
