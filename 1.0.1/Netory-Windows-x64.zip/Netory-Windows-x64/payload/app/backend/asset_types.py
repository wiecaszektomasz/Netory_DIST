"""Canonical inventory types shared by import and save paths."""
import re


ASSET_TYPES = (
    'Physical server', 'Virtual server', 'Network device', 'Router',
    'Firewall / UTM', 'Switch', 'Access point', 'Wi-Fi controller', 'Storage',
    'Computer', 'Printer', 'Monitor', 'UPS', 'Patch panel', 'Other',
)


def type_key(value):
    return re.sub(r'[^a-z0-9]', '', value.casefold())


TYPE_ALIASES = {
    **{type_key(value): value for value in ASSET_TYPES},
    'virtualmachine': 'Virtual server', 'vm': 'Virtual server',
    'server': 'Physical server', 'physicalmachine': 'Physical server',
    'baremetalserver': 'Physical server', 'nas': 'Storage', 'san': 'Storage',
    'storagearray': 'Storage', 'storagedevice': 'Storage',
    'laptop': 'Computer', 'desktop': 'Computer', 'workstation': 'Computer',
    'pc': 'Computer', 'firewall': 'Firewall / UTM', 'utm': 'Firewall / UTM',
    'wirelessaccesspoint': 'Access point', 'ap': 'Access point',
    'wirelesscontroller': 'Wi-Fi controller', 'wlc': 'Wi-Fi controller',
    'uninterruptiblepowersupply': 'UPS',
}


def normalize_asset_type(value):
    if not isinstance(value, str) or type_key(value) not in TYPE_ALIASES:
        raise ValueError('Unsupported asset type. Choose a supported type; use Other with deviceKind for an unlisted device.')
    return TYPE_ALIASES[type_key(value)]
