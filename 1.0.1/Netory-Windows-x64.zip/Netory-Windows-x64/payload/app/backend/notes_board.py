"""Client-scoped short notes with immutable authorship and conflict protection."""
from datetime import timezone
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import delete, func, select, update
from sqlalchemy.orm import Session
from backend.audit import AuditedRoute
from backend.db import get_db
from backend.models import BoardNote, utc_now
from backend.security import current_user

router = APIRouter(prefix='/api/environments/{environment_id}/notes', route_class=AuditedRoute)


class NoteInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    content: str = Field(min_length=1, max_length=500)

    @field_validator('content')
    @classmethod
    def not_blank(cls, value):
        if not value.strip():
            raise ValueError('Write a note before posting')
        return value.strip()


class NoteUpdate(NoteInput):
    version: int = Field(strict=True, ge=1)


def access(db, user, environment_id, write=False):
    from backend.main import environment_access
    return environment_access(db, user, environment_id, write=write)


def public(note, user):
    def stamp(value):
        return value.replace(tzinfo=timezone.utc).isoformat() if value.tzinfo is None else value.isoformat()
    return {'id': note.id, 'content': note.content, 'author_id': note.author_id,
            'author_name': note.author_name, 'created_at': stamp(note.created_at),
            'updated_at': stamp(note.updated_at), 'version': note.version,
            'can_manage': user.is_admin or user.id == note.author_id}


def owned_note(db, environment_id, note_id, user):
    note = db.scalar(select(BoardNote).where(BoardNote.id == note_id, BoardNote.environment_id == environment_id))
    if not note:
        raise HTTPException(404, 'Note not found in this client')
    if not user.is_admin and note.author_id != user.id:
        raise HTTPException(403, 'You can edit or delete only your own notes')
    return note


@router.get('')
def list_notes(environment_id: str, offset: int = Query(default=0, ge=0), limit: int = Query(default=50, ge=1, le=100),
               user=Depends(current_user), db: Session = Depends(get_db)):
    access(db, user, environment_id)
    query = select(BoardNote).where(BoardNote.environment_id == environment_id)
    total = db.scalar(select(func.count()).select_from(query.subquery()))
    notes = db.scalars(query.order_by(BoardNote.created_at.desc(), BoardNote.id.desc()).offset(offset).limit(limit))
    return {'items': [public(note, user) for note in notes], 'total': total}


@router.post('', status_code=201)
def create_note(environment_id: str, payload: NoteInput, user=Depends(current_user), db: Session = Depends(get_db)):
    access(db, user, environment_id, write=True)
    now = utc_now()
    note = BoardNote(id=str(uuid4()), environment_id=environment_id, author_id=user.id,
                     author_name=user.username, content=payload.content, created_at=now, updated_at=now, version=1)
    db.add(note)
    db.commit()
    return public(note, user)


@router.patch('/{note_id}')
def update_note(environment_id: str, note_id: str, payload: NoteUpdate,
                user=Depends(current_user), db: Session = Depends(get_db)):
    access(db, user, environment_id, write=True)
    note = owned_note(db, environment_id, note_id, user)
    changed = db.execute(update(BoardNote).where(BoardNote.id == note.id, BoardNote.version == payload.version)
                         .values(content=payload.content, updated_at=utc_now(), version=BoardNote.version + 1))
    if changed.rowcount != 1:
        raise HTTPException(409, 'This note changed. Refresh the board before editing it again.')
    db.commit()
    db.refresh(note)
    return public(note, user)


@router.delete('/{note_id}', status_code=204)
def delete_note(environment_id: str, note_id: str, version: int = Query(ge=1),
                user=Depends(current_user), db: Session = Depends(get_db)):
    access(db, user, environment_id, write=True)
    note = owned_note(db, environment_id, note_id, user)
    changed = db.execute(delete(BoardNote).where(BoardNote.id == note.id, BoardNote.version == version))
    if changed.rowcount != 1:
        raise HTTPException(409, 'This note changed. Refresh the board before deleting it.')
    db.commit()
    return Response(status_code=204)
