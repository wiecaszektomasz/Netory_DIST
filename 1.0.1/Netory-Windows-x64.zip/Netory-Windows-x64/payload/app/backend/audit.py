"""Record API activity without storing request bodies, credentials, or tokens."""
from datetime import datetime, timedelta, timezone
from uuid import uuid4
import json

from fastapi import Depends, HTTPException, Request
from fastapi.routing import APIRoute
from fastapi.exceptions import RequestValidationError
from sqlalchemy import delete
from sqlalchemy.orm import Session

from backend.db import get_db
from backend.models import AuditLog, AuditSettings, Environment, User, License


def audit_context(request: Request, db: Session = Depends(get_db)):
    request.state.audit_bind = db.get_bind()
    request.state.audit_db = db
    ids = request.path_params
    target = None
    if ids.get('license_id'):
        target = db.get(License, (ids['license_id'], ids['environment_id']))
    elif ids.get('user_id'):
        target = db.get(User, ids['user_id'])
    elif ids.get('environment_id'):
        target = db.get(Environment, ids['environment_id'])
    request.state.audit_target_name = (
        getattr(target, 'name', None) or getattr(target, 'username', None) or getattr(target, 'product', None)
    )


def retention_days(db):
    policy = db.get(AuditSettings, 1)
    return policy.retention_days if policy else 90


def purge_expired(db):
    db.execute(delete(AuditLog).where(
        AuditLog.created_at < datetime.now(timezone.utc) - timedelta(days=retention_days(db))
    ))


def actor_snapshot(request, user):
    request.state.audit_actor = {"user_id": user.id, "username": user.username, "is_admin": user.is_admin}


def record_activity(db, actor, action, message, resource, target_ids=None, status=200):
    purge_expired(db)
    db.add(AuditLog(
        id=str(uuid4()), user_id=actor.get('user_id'), username=actor.get('username', 'Anonymous'),
        is_admin=actor.get('is_admin', False), action=action, message=message,
        method='', resource=resource, target_ids=target_ids or {}, status_code=status,
    ))


def inventory_changes(db, user, environment, before, after):
    actor = {"user_id": user.id, "username": user.username, "is_admin": user.is_admin}
    labels = {'rooms': 'room', 'racks': 'rack cabinet', 'vlans': 'VLAN', 'lans': 'network', 'wlans': 'WLAN', 'stacks': 'device stack', 'clusters': 'server cluster', 'lags': 'LAG',
              'licenses': 'license', 'hypervisors': 'hypervisor', 'accounts': 'special account', 'connections': 'connection'}
    for section in before:
        old = {str(row['id']): row for row in before[section]}
        new = {str(row['id']): row for row in after[section]}
        for record_id in sorted(old.keys() | new.keys()):
            previous, current = old.get(record_id), new.get(record_id)
            if previous == current:
                continue
            verb = 'added' if previous is None else 'deleted' if current is None else 'changed'
            row = current or previous
            label = (row.get('deviceKind') or row.get('type', 'asset')) if section == 'assets' else labels.get(section, section)
            name = row.get('name') or row.get('product') or row.get('username') or record_id
            # Only names enter the log; changed passwords and other field values remain private.
            message = f'{user.username} {verb} {label} “{name}” in “{environment.name}”'
            record_activity(db, actor, verb, message, section,
                            {'record_id': record_id, 'environment_id': environment.id})


ACTION_MESSAGES = {
    'save_zabbix_connection': 'saved Zabbix connection for',
    'disconnect_zabbix': 'disconnected Zabbix source for',
    'update_assistant_permission': 'changed writable AI chat permission for',
    'create_ai_provider': 'added AI connection', 'update_ai_provider': 'changed AI connection',
    'delete_ai_provider': 'deleted AI connection', 'update_ai_default': 'changed default AI provider',
    'test_ai_provider': 'tested AI connection',
    'create_environment': 'added client environment', 'rename_environment': 'renamed client environment',
    'copy_environment': 'copied client environment', 'copy_all_environments': 'copied all client environments',
    'delete_environment': 'deleted client environment', 'create_user': 'added user',
    'update_user_status': 'changed account status for', 'delete_user': 'deleted user',
    'reset_user_password': 'reset password for', 'change_own_password': 'changed their password',
    'update_user_preferences': 'changed their preferences',
    'add_member': 'granted client access to', 'update_member': 'changed client access for',
    'remove_member': 'removed client access for', 'save_license': 'saved license', 'delete_license': 'deleted license',
    'update_map_settings': 'changed network map layout',
    'update_session_timeout': 'changed session inactivity timeout',
    'update_login_protection': 'changed login protection settings',
    'update_audit_retention': 'changed activity log retention',
}


class AuditedRoute(APIRoute):
    def get_route_handler(self):
        handler = super().get_route_handler()

        async def audited(request: Request):
            status = 500
            response = None
            try:
                response = await handler(request)
                status = response.status_code
                return response
            except RequestValidationError:
                status = 422
                raise
            except HTTPException as error:
                status = error.status_code
                raise
            finally:
                if hasattr(request.state, 'audit_db') and status >= 400:
                    request.state.audit_db.rollback()
                should_log = self.name in ('login', 'logout') or (status < 400 and self.name in ACTION_MESSAGES)
                if should_log and hasattr(request.state, 'audit_bind'):
                    actor = getattr(request.state, 'audit_actor', {})
                    username = actor.get('username', 'Anonymous')
                    target = getattr(request.state, 'audit_target_name', None)
                    if response is not None and self.name in ('create_user', 'create_environment', 'rename_environment'):
                        data = json.loads(response.body)
                        target = data.get('username') or data.get('name')
                    if self.name == 'login':
                        message = f'{username} signed in' if status < 400 else f'Sign-in attempt for {username} failed' + (' (temporarily blocked)' if status == 429 else '')
                    elif self.name == 'logout':
                        message = f'{username} signed out'
                    else:
                        message = f'{username} {ACTION_MESSAGES[self.name]}' + (f' “{target}”' if target else '')
                    with Session(bind=request.state.audit_bind) as db:
                        record_activity(db, actor, self.name, message, 'account' if self.name in ('login', 'logout') else 'administration',
                                        {key: str(value)[:80] for key, value in request.path_params.items()}, status)
                        db.commit()
        return audited
