"""Answer connection questions locally from full recorded topology."""
import re
from backend.infrastructure_graph import InfrastructureGraph


def connectivity_answer(context, question):
    if not re.search(r'\b(connect(?:ed|ion|ions|ivity)?|link(?:ed|s)?|reach(?:able)?|uplinks?)\b', question, re.I):
        return None
    # An explicit edit must retain the reviewed change workflow.
    if re.search(r'\b(create|add|update|configure|assign|remove|delete|disconnect|rename|change|set|pass|tagged|untagged|vlan)\b', question, re.I):
        return None
    if re.search(r'^\s*(?:please\s+)?(?:connect|link)\b|\b(?:can|could|would|will)\s+you\s+(?:please\s+)?(?:connect|link)\b', question, re.I):
        return None
    from backend import assistant as ai
    if any(not ai.assistant_config.section_allowed(section) for section in ai.assistant_config.TOPOLOGY_READ_SECTIONS):
        return 'Topology section access is restricted; unavailable connection records do not mean the devices are unconnected.'
    graph = InfrastructureGraph(context)
    selected = graph.select_assets(question)
    if not selected:
        return None  # General networking explanations remain available without inventing inventory endpoints.
    enumerate_peers = re.search(r'\b(?:what|which)\b.*\bconnected\b|\b(?:list|show)\b.*\b(?:connections?|links?|uplinks?)\b|\bconnections?\s+(?:for|of)\b', question, re.I)
    if enumerate_peers and len(selected) == 1:
        aid = selected[0]
        node = ('assets', aid)
        edges = [edge for edge in graph.edges if node in (edge['source'], edge['target']) and edge['kind'] in ('cable', 'LAG member')]
        lines = [f"Recorded connections for {graph.assets[aid]['name']}:"]
        for edge in edges:
            lines.append(f"- {edge['kind']}: {graph.name(edge['source'])} ↔ {graph.name(edge['target'])}, {edge['detail']}")
        if not edges:
            lines.append('- No direct cable or LAG member is recorded for this physical asset.')
        path = graph.upstream_path(aid)
        if len(path) > 1:
            lines.append('Recorded upstream path: ' + ' → '.join(graph.assets[key]['name'] for key in path))
        lines.append('Direct cables and upstream paths are different. This inventory does not verify live connectivity.')
        answer = '\n'.join(lines)
    else:
        trace = ai.topology_trace(context, 'trace ' + question)
        if trace['status'] != 'recorded_path':
            return ai.recorded_path_answer(trace)
        source, target = trace['source_id'], trace['target_id']
        direct = any(
            any(port['device_id'] == source for port in hop['from_ports']) and
            any(port['device_id'] == target for port in hop['to_ports'])
            for hop in trace['hops'])
        if direct:
            header = f"Yes. {trace['source_name']} has a recorded direct cable/LAG connection to {trace['target_name']}."
        else:
            header = f"Yes. {trace['source_name']} has a recorded network path to {trace['target_name']} through intermediate switches or a logical stack."
            if re.search(r'\bdirect(?:ly)?\b', question, re.I):
                header = f"No direct cable/LAG between {trace['source_name']} and {trace['target_name']} is recorded, but an indirect network path exists."
        lines = [header, 'Recorded path:']
        for hop in trace['hops']:
            left = '; '.join(f"{port['device_name']} port {port['port']}" for port in hop['from_ports'])
            right = '; '.join(f"{port['device_name']} port {port['port']}" for port in hop['to_ports'])
            lines.append(f'- {left} → {right}')
        for device in trace['devices_on_path']:
            if device['kind'] == 'stack':
                lines.append('Logical stack ' + device['name'] + ': ' + ', '.join(member['device_name'] for member in device['members']) + '. Different physical members can provide ingress and egress.')
        lines.append('Checked against the full authorized inventory, including LAG members and stack membership. A recorded path does not verify live link state or VLAN forwarding.')
        answer = '\n'.join(lines)
    if len(answer) > 5800:
        return 'The complete connectivity report exceeds the reply limit. Specify a shorter segment or device pair; no partial path is presented.'
    return answer
