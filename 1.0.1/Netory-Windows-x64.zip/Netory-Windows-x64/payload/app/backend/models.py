from datetime import date, datetime, timezone

from sqlalchemy import JSON, Boolean, Date, DateTime, ForeignKey, ForeignKeyConstraint, Integer, PrimaryKeyConstraint, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from backend.db import Base


def utc_now():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    username: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(512))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    assistant_write_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    dashboard: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    language: Mapped[str] = mapped_column(String(35), default="en", server_default="en")
    theme: Mapped[str] = mapped_column(String(16), default="default")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class UserSession(Base):
    __tablename__ = "user_sessions"

    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    last_activity_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class Environment(Base):
    __tablename__ = "environments"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    revision: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, onupdate=utc_now)


class Membership(Base):
    __tablename__ = "environment_memberships"
    __table_args__ = (UniqueConstraint("user_id", "environment_id"),)

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(16), default="editor")


class Room(Base):
    __tablename__ = "rooms"
    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))


class RackCabinet(Base):
    __tablename__ = "rack_cabinets"
    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    capacity_u: Mapped[int] = mapped_column(Integer)
    display_order: Mapped[int] = mapped_column(Integer, default=1, server_default='1')
    room_id: Mapped[str | None] = mapped_column(String(80))
    location: Mapped[str | None] = mapped_column(String(240))


class Asset(Base):
    __tablename__ = "assets"

    backup_power_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default='0')
    backup_ups_id: Mapped[str | None] = mapped_column(String(80))
    ups_parameters: Mapped[dict | None] = mapped_column(JSON, default=dict)
    management_controller: Mapped[dict | None] = mapped_column(JSON, default=dict)
    device_kind: Mapped[str | None] = mapped_column(String(120))
    warranty_expiry: Mapped[date | None] = mapped_column(Date)
    __table_args__ = (UniqueConstraint("environment_id", "name"),)

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    type: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(40), default="In service")
    hostname: Mapped[str | None] = mapped_column(String(240))
    manufacturer: Mapped[str | None] = mapped_column(String(240))
    serial: Mapped[str | None] = mapped_column(String(160))
    location: Mapped[str | None] = mapped_column(String(240))
    ip: Mapped[str | None] = mapped_column(String(64))
    port_count: Mapped[int] = mapped_column(Integer, default=0)
    internet_ports: Mapped[list[int] | None] = mapped_column(JSON, default=list)
    port_types: Mapped[dict[str, str | dict[str, str]] | None] = mapped_column(JSON, default=dict)
    port_vlans: Mapped[dict[str, dict[str, int | list[int] | None]] | None] = mapped_column(JSON, default=dict)
    show_on_map: Mapped[bool] = mapped_column(Boolean, default=False)
    cpu: Mapped[str | None] = mapped_column(String(240))
    ram: Mapped[str | None] = mapped_column(String(160))
    storage: Mapped[str | None] = mapped_column(String(240))
    os: Mapped[str | None] = mapped_column(String(240))
    os_catalog_id: Mapped[str | None] = mapped_column(String(80))
    os_family: Mapped[str | None] = mapped_column(String(16))
    os_eol: Mapped[date | None] = mapped_column(Date)
    rack_enabled: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", nullable=False)
    rack_units: Mapped[int | None] = mapped_column(Integer)
    room_id: Mapped[str | None] = mapped_column(String(80))
    rack_id: Mapped[str | None] = mapped_column(String(80))
    rack_start_u: Mapped[int | None] = mapped_column(Integer)
    hypervisor: Mapped[str | None] = mapped_column(String(240))
    hypervisor_id: Mapped[str | None] = mapped_column(String(80))
    hypervisor_cluster_id: Mapped[str | None] = mapped_column(String(80))
    vlan: Mapped[str | None] = mapped_column(String(120))
    notes: Mapped[str | None] = mapped_column(Text)


class Vlan(Base):
    __tablename__ = "vlans"
    __table_args__ = (
        UniqueConstraint(
            "environment_id", "vlan_number", "master_device_id",
            name="uq_vlans_environment_number_master",
        ),
    )

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    vlan_number: Mapped[int] = mapped_column(Integer)
    network: Mapped[str | None] = mapped_column(String(120))
    gateway: Mapped[str | None] = mapped_column(String(64))
    master_device_id: Mapped[str | None] = mapped_column(String(80))
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    location: Mapped[str | None] = mapped_column(String(240))
    purpose: Mapped[str | None] = mapped_column(String(240))
    notes: Mapped[str | None] = mapped_column(Text)


class NetworkDefinition(Base):
    __tablename__ = "network_definitions"
    __table_args__ = (UniqueConstraint("environment_id", "network_type", "name"),)

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    network_type: Mapped[str] = mapped_column(String(8))
    parent_interface: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    parent_device_id: Mapped[str | None] = mapped_column(String(80))
    vlan_interface_id: Mapped[str | None] = mapped_column(String(80))
    name: Mapped[str] = mapped_column(String(240))
    ssid: Mapped[str | None] = mapped_column(String(240))
    security: Mapped[str | None] = mapped_column(String(80))
    auth_server: Mapped[str | None] = mapped_column(String(240))
    wifi_password_encrypted: Mapped[str | None] = mapped_column(Text)
    network: Mapped[str | None] = mapped_column(String(120))
    gateway: Mapped[str | None] = mapped_column(String(64))
    dns_servers: Mapped[str | None] = mapped_column(Text)
    dhcp: Mapped[str | None] = mapped_column(Text)
    vlan_number: Mapped[int | None] = mapped_column(Integer)
    location: Mapped[str | None] = mapped_column(String(240))
    purpose: Mapped[str | None] = mapped_column(String(240))
    notes: Mapped[str | None] = mapped_column(Text)


class DeviceStack(Base):
    __tablename__ = "device_stacks"
    __table_args__ = (UniqueConstraint("environment_id", "name"),)

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    device_type: Mapped[str] = mapped_column(String(80))


class DeviceStackMember(Base):
    __tablename__ = "device_stack_members"
    __table_args__ = (
        PrimaryKeyConstraint("stack_id", "asset_id", "environment_id"),
        ForeignKeyConstraint(["stack_id", "environment_id"], ["device_stacks.id", "device_stacks.environment_id"], ondelete="CASCADE"),
        ForeignKeyConstraint(["asset_id", "environment_id"], ["assets.id", "assets.environment_id"], ondelete="CASCADE"),
        UniqueConstraint("environment_id", "asset_id"),
        UniqueConstraint("environment_id", "stack_id", "member_order"),
    )

    stack_id: Mapped[str] = mapped_column(String(80))
    asset_id: Mapped[str] = mapped_column(String(80))
    environment_id: Mapped[str] = mapped_column(String(36), index=True)
    member_order: Mapped[int] = mapped_column(Integer)


class ServerCluster(Base):
    __tablename__ = "server_clusters"
    __table_args__ = (UniqueConstraint("environment_id", "name"),)

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    show_on_map: Mapped[bool] = mapped_column(Boolean, default=True)
    location: Mapped[str | None] = mapped_column(String(240))
    notes: Mapped[str | None] = mapped_column(Text)


class ServerClusterMember(Base):
    __tablename__ = "server_cluster_members"
    __table_args__ = (
        PrimaryKeyConstraint("cluster_id", "asset_id", "environment_id"),
        ForeignKeyConstraint(["cluster_id", "environment_id"], ["server_clusters.id", "server_clusters.environment_id"], ondelete="CASCADE"),
        ForeignKeyConstraint(["asset_id", "environment_id"], ["assets.id", "assets.environment_id"], ondelete="CASCADE"),
        UniqueConstraint("environment_id", "asset_id"),
        UniqueConstraint("environment_id", "cluster_id", "member_order"),
    )

    cluster_id: Mapped[str] = mapped_column(String(80))
    asset_id: Mapped[str] = mapped_column(String(80))
    environment_id: Mapped[str] = mapped_column(String(36), index=True)
    member_order: Mapped[int] = mapped_column(Integer)


class License(Base):
    __tablename__ = "licenses"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    product: Mapped[str] = mapped_column(String(240))
    vendor: Mapped[str | None] = mapped_column(String(240))
    license_key: Mapped[str | None] = mapped_column(String(512))
    type: Mapped[str | None] = mapped_column(String(80))
    seats: Mapped[int | None] = mapped_column(Integer)
    assigned: Mapped[int | None] = mapped_column(Integer)
    assigned_asset_ids: Mapped[list[str] | None] = mapped_column(JSON, default=list)
    expiry: Mapped[datetime | None] = mapped_column(Date)
    owner: Mapped[str | None] = mapped_column(String(240))
    notes: Mapped[str | None] = mapped_column(Text)


class Hypervisor(Base):
    __tablename__ = "hypervisors"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    platform: Mapped[str] = mapped_column(String(120))
    version: Mapped[str | None] = mapped_column(String(120))
    management_ip: Mapped[str | None] = mapped_column(String(64))
    cluster: Mapped[str | None] = mapped_column(String(240))
    location: Mapped[str | None] = mapped_column(String(240))
    capacity: Mapped[str | None] = mapped_column(String(240))
    notes: Mapped[str | None] = mapped_column(Text)


class SpecialAccount(Base):
    __tablename__ = "special_accounts"

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(240))
    system: Mapped[str] = mapped_column(String(240))
    username: Mapped[str | None] = mapped_column(String(240))
    account_type: Mapped[str | None] = mapped_column(String(80))
    owner: Mapped[str | None] = mapped_column(String(240))
    vault: Mapped[str | None] = mapped_column(String(240))
    rotation: Mapped[datetime | None] = mapped_column(Date)
    notes: Mapped[str | None] = mapped_column(Text)


class OperatingSystem(Base):
    __tablename__ = "operating_systems"
    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(240), unique=True)
    family: Mapped[str] = mapped_column(String(16))
    eol: Mapped[date | None] = mapped_column(Date)
    support_notes: Mapped[str | None] = mapped_column(String(1000))
    source_url: Mapped[str | None] = mapped_column(String(1000))


class NetworkConnection(Base):
    __tablename__ = "network_connections"
    __table_args__ = (
        UniqueConstraint("environment_id", "device_a_id", "port_a"),
        UniqueConstraint("environment_id", "device_b_id", "port_b"),
    )

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    device_a_id: Mapped[str] = mapped_column(String(80))
    port_a: Mapped[int] = mapped_column(Integer)
    device_b_id: Mapped[str] = mapped_column(String(80))
    port_b: Mapped[int] = mapped_column(Integer)


class LinkAggregationGroup(Base):
    __tablename__ = "link_aggregation_groups"
    __table_args__ = (
        UniqueConstraint("environment_id", "name"),
        ForeignKeyConstraint(
            ["device_a_id", "environment_id"],
            ["assets.id", "assets.environment_id"],
            ondelete="CASCADE",
        ),
        ForeignKeyConstraint(
            ["device_b_id", "environment_id"],
            ["assets.id", "assets.environment_id"],
            ondelete="CASCADE",
        ),
        ForeignKeyConstraint(
            ["stack_a_id", "environment_id"],
            ["device_stacks.id", "device_stacks.environment_id"],
            ondelete="CASCADE",
        ),
        ForeignKeyConstraint(
            ["stack_b_id", "environment_id"],
            ["device_stacks.id", "device_stacks.environment_id"],
            ondelete="CASCADE",
        ),
    )

    id: Mapped[str] = mapped_column(String(80), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    aggregation_type: Mapped[str] = mapped_column(String(16), default="Static")
    device_a_id: Mapped[str] = mapped_column(String(80))
    ports_a: Mapped[list[dict]] = mapped_column(JSON)
    device_b_id: Mapped[str] = mapped_column(String(80))
    ports_b: Mapped[list[dict]] = mapped_column(JSON)
    stack_a_id: Mapped[str | None] = mapped_column(String(80))
    stack_b_id: Mapped[str | None] = mapped_column(String(80))


class LoginProtectionSettings(Base):
    __tablename__ = "login_protection_settings"

    enabled: Mapped[bool] = mapped_column(Boolean, default=True)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    max_failed_attempts: Mapped[int] = mapped_column(Integer, default=5)
    block_minutes: Mapped[int] = mapped_column(Integer, default=15)


class LoginAttempt(Base):
    __tablename__ = "login_attempts"

    username_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    reset_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    blocked_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AuditSettings(Base):
    __tablename__ = "audit_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    retention_days: Mapped[int] = mapped_column(Integer, default=90)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    message: Mapped[str | None] = mapped_column(Text)

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, index=True)
    user_id: Mapped[str | None] = mapped_column(String(36))
    username: Mapped[str] = mapped_column(String(120))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    action: Mapped[str] = mapped_column(String(120))
    method: Mapped[str] = mapped_column(String(8))
    resource: Mapped[str] = mapped_column(String(240))
    target_ids: Mapped[dict] = mapped_column(JSON, default=dict)
    status_code: Mapped[int] = mapped_column(Integer)


class SessionSettings(Base):
    __tablename__ = "session_settings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    idle_timeout_minutes: Mapped[int] = mapped_column(Integer, default=30)


class AIProvider(Base):
    __tablename__ = "ai_providers"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    vendor: Mapped[str] = mapped_column(String(24))
    base_url: Mapped[str] = mapped_column(String(500))
    api_key_encrypted: Mapped[str | None] = mapped_column(Text)
    model: Mapped[str] = mapped_column(String(200), default="")
    enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    environment_ids: Mapped[list] = mapped_column(JSON, default=list)
    request_limit: Mapped[int] = mapped_column(Integer, default=100)
    models: Mapped[list] = mapped_column(JSON, default=list)
    test_status: Mapped[str] = mapped_column(String(24), default="untested")
    tested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    usage_date: Mapped[date | None] = mapped_column(Date)
    requests_today: Mapped[int] = mapped_column(Integer, default=0)
    total_requests: Mapped[int] = mapped_column(Integer, default=0)


class AISettings(Base):
    __tablename__ = "ai_settings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    default_provider_id: Mapped[str | None] = mapped_column(ForeignKey("ai_providers.id", ondelete="SET NULL"))


class TrashedAsset(Base):
    __tablename__ = 'trashed_assets'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    asset_id: Mapped[str] = mapped_column(String(80))
    environment_id: Mapped[str] = mapped_column(String(36), index=True)
    environment_name: Mapped[str] = mapped_column(String(120))
    name: Mapped[str] = mapped_column(String(240))
    type: Mapped[str] = mapped_column(String(80))
    deleted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now, index=True)
    deleted_by_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    deleted_by_username: Mapped[str] = mapped_column(String(120))
    deleted_by_admin: Mapped[bool] = mapped_column(Boolean)
    snapshot: Mapped[dict] = mapped_column(JSON)


class CostEstimate(Base):
    __tablename__ = 'cost_estimates'
    __table_args__ = (UniqueConstraint('environment_id', 'name'),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey('environments.id', ondelete='CASCADE'), index=True)
    name: Mapped[str] = mapped_column(String(240))
    project_number: Mapped[str] = mapped_column(String(120), default='')
    valid_until: Mapped[date] = mapped_column(Date)
    currency: Mapped[str] = mapped_column(String(3), default='PLN')
    tax_basis_points: Mapped[int] = mapped_column(Integer, default=2300)
    custom_items: Mapped[list] = mapped_column(JSON, default=list)
    version: Mapped[int] = mapped_column(Integer, default=1)


class CostPricing(Base):
    __tablename__ = 'cost_pricing'
    environment_id: Mapped[str] = mapped_column(ForeignKey('environments.id', ondelete='CASCADE'), primary_key=True)
    section: Mapped[str] = mapped_column(String(16), primary_key=True)
    record_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    estimate_id: Mapped[str | None] = mapped_column(ForeignKey('cost_estimates.id', ondelete='SET NULL'), index=True)
    net_price: Mapped[str | None] = mapped_column(String(24))


class MapSettings(Base):
    __tablename__ = "map_settings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    layout: Mapped[str] = mapped_column(String(16), default="elk", server_default="elk")


class ZabbixIntegration(Base):
    __tablename__ = "zabbix_integrations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey("environments.id", ondelete="CASCADE"), unique=True)
    url: Mapped[str] = mapped_column(String(500))
    token_encrypted: Mapped[str] = mapped_column(Text)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    interval_minutes: Mapped[int] = mapped_column(Integer, default=15)
    mappings: Mapped[dict] = mapped_column(JSON, default=dict)
    last_sync: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str | None] = mapped_column(String(240))


class BoardNote(Base):
    __tablename__ = 'board_notes'

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey('environments.id', ondelete='CASCADE'), index=True)
    author_id: Mapped[str | None] = mapped_column(ForeignKey('users.id', ondelete='SET NULL'))
    author_name: Mapped[str] = mapped_column(String(120))
    content: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    version: Mapped[int] = mapped_column(Integer, default=1)


class ReportConfigurations(Base):
    __tablename__ = 'report_configurations'
    user_id: Mapped[str] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    environment_id: Mapped[str] = mapped_column(ForeignKey('environments.id', ondelete='CASCADE'), primary_key=True, index=True)
    items: Mapped[list] = mapped_column(JSON, default=list)
    version: Mapped[int] = mapped_column(Integer, default=1)
