"""Build complete tagged-path proposals locally from the fresh inventory."""
import re


FOLLOW_UP = re.compile(
    r'\s*(?:please\s+)?(?:'
    r'confirm|yes(?:[, ]+confirm)?|proceed|go ahead|do it|'
    r'(?:yes[, ]+)?(?:update|configure|apply|propose|set|tag)'
    r'(?:\s+(?:the|these|those|all|all these|all those))?'
    r'\s+(?:ports?|changes?|them|it|this|that|the changes)'
    r')(?:\s+please)?[.!\s]*', re.I)


def tagged_path_plan(context, messages, write_mode, _single=False):
    from backend import assistant as ai
    if not _single:
        bulk = bulk_server_plan(context, messages, write_mode)
        if bulk is not None:
            return bulk
    question = messages[-1].content
    confirm = bool(FOLLOW_UP.fullmatch(question))
    mode_reply = re.compile(r'\s*(?:as\s+)?(tagged|untagged)(?:\s+(?:at|on)\s+(?:the\s+)?destination)?[.!\s]*', re.I)
    request = question
    chosen_mode = None
    if confirm or mode_reply.fullmatch(question):
        request = None
        for message in reversed(messages):
            if message.role != 'user':
                continue
            if FOLLOW_UP.fullmatch(message.content):
                continue
            match = mode_reply.fullmatch(message.content)
            if match:
                if chosen_mode is None:
                    chosen_mode = match[1].lower()
                continue
            request = message.content
            break
        if request is None:
            return None
    if not re.search(r'\bvlan\b', request, re.I) or not re.search(r'\bfrom\b.*\bto\b', request, re.I | re.S):
        return None
    if re.search(r'\b(remove|delete|translate)\b', request, re.I):
        return None
    vlans = re.findall(r'\bvlan(?:\s+id)?\s*[:#]?\s*(\d+)\b', request, re.I)
    if not vlans and not confirm and chosen_mode is None:
        return None  # General path advice can still show the complete recorded trace.
    if len(vlans) != 1:
        return {'answer': 'Specify one VLAN ID for this path. No changes proposed.', 'changes': []}
    modes = set(re.findall(r'\b(tagged|untagged)\b', request, re.I))
    modes = {mode.lower() for mode in modes}
    mode = chosen_mode or (next(iter(modes)) if len(modes) == 1 else None)
    if mode is None:
        return {'answer': f"For your latest request — {request} — should VLAN {vlans[0]} be tagged at the destination, or untagged at the destination with tagged uplinks? Reply tagged or untagged. Confirm alone cannot select a mode. No changes proposed.", 'changes': []}
    number = int(vlans[0])
    if not 1 <= number <= 4094:
        return {'answer': 'Choose a VLAN number from 1 to 4094. Nothing was changed.', 'changes': []}
    if not any(vlan.get('vlan_number') == number for vlan in context.get('vlans', [])):
        return {'answer': f'VLAN {number} is not defined in the available VLAN inventory. Define it first, then request this tagged path again. No changes proposed.', 'changes': []}
    trace = ai.topology_trace(context, request)
    if trace['status'] != 'recorded_path':
        return {'answer': ai.recorded_path_answer(trace), 'changes': []}
    assets = {asset['id']: asset for asset in context['assets']}
    patches, missing, conflicts = {}, [], []
    # For an access destination, both ends of the final cable must be untagged.
    final_ports = set()
    if mode == 'untagged' and trace['hops']:
        final_ports = {(port['device_id'], str(port['port']))
                       for port in trace['hops'][-1]['from_ports'] + trace['hops'][-1]['to_ports']}
    seen = set()
    for device in trace['devices_on_path']:
        for port in device['ingress_ports'] + device['egress_ports']:
            key = (port['device_id'], str(port['port']))
            if key in seen:
                continue
            seen.add(key)
            if assets[key[0]]['type'] == 'Patch panel':
                continue
            config = port['vlan_config']
            label = f"{port['device_name']} port {port['port']}"
            if config is None:
                conflicts.append(label + ': VLAN settings unavailable')
                continue
            if key in final_ports:
                updated = {'untaggedVlan': number,
                           'taggedVlans': [vlan for vlan in config['taggedVlans'] if vlan != number]}
                if updated != config:
                    patches.setdefault(key[0], {})[key[1]] = updated
                    missing.append(label + f' → untagged VLAN {number} (was {config["untaggedVlan"]})')
                continue
            if config['untaggedVlan'] == number:
                conflicts.append(label + f': VLAN {number} is currently untagged; specify a replacement native VLAN before tagging it')
                continue
            if number not in config['taggedVlans']:
                patches.setdefault(key[0], {})[key[1]] = {
                    'untaggedVlan': config['untaggedVlan'],
                    'taggedVlans': sorted(set(config['taggedVlans']) | {number}),
                }
                missing.append(label + f' → tagged VLAN {number}')
    if conflicts:
        return {'answer': 'Cannot safely complete the tagged path:\n- ' + '\n- '.join(conflicts) + '\nNo changes proposed.', 'changes': []}
    if not missing:
        return {'answer': f'VLAN {number} already has the requested {mode} destination and tagged uplink settings on the recorded path, including all LAG members. No inventory changes are needed. Live forwarding is not verified.', 'changes': []}
    explicit = bool(re.search(r'\b(update|configure|apply|set|propose)\b', request, re.I))
    proposing = write_mode and (confirm or explicit)
    answer = (f"VLAN {number}: {trace['source_name']} → {trace['target_name']}, destination {mode}. Required port updates (including every LAG member):\n- "
              + '\n- '.join(missing) + '\nUnrelated tagged VLANs and uplink native VLANs are preserved; destination changes are listed above. Already-correct ports need no update. ')
    if proposing:
        answer += 'Review and Apply the proposed Netory inventory changes. This does not configure live devices.'
    elif write_mode:
        answer += 'Reply confirm to generate the complete reviewed inventory proposal.'
    else:
        answer += 'Enable Propose inventory changes and confirm to generate a reviewed proposal. This does not configure live devices.'
    return {'answer': answer, 'changes': [
        {'operation': 'update', 'asset_id': aid, 'fields': {'portVlans': ports}}
        for aid, ports in patches.items()] if proposing else []}


ALL_SERVERS = re.compile(r'\b(?:all|every)(?:\s+connected)?\s+servers?\b', re.I)
SCOPE_REPLY = re.compile(r'\s*(?:from\s+.+?\s+to\s+)?(?:all|every)(?:\s+connected)?\s+servers?[.!\s]*', re.I)


def bulk_server_plan(context, messages, write_mode):
    from backend import assistant as ai
    request, scope, chosen_mode = None, None, None
    latest = messages[-1].content
    confirm = bool(FOLLOW_UP.fullmatch(latest))
    for message in reversed(messages):
        if message.role != 'user':
            continue
        text = message.content
        if FOLLOW_UP.fullmatch(text):
            continue
        if re.fullmatch(r'\s*(tagged|untagged)[.!\s]*', text, re.I):
            chosen_mode = chosen_mode or text.strip(' .!').lower()
            continue
        if SCOPE_REPLY.fullmatch(text):
            scope = scope or text
            continue
        request = text
        break
    if request is None or not (ALL_SERVERS.search(request) or scope):
        return None
    if not re.search(r'\bvlan\b', request, re.I) or re.search(r'\b(remove|delete|translate)\b', request, re.I):
        return None
    numbers = re.findall(r'\bvlan(?:\s+id)?\s*[:#]?\s*(\d+)\b', request, re.I)
    if len(numbers) != 1:
        return {'answer': 'Specify one VLAN ID to pass to all connected servers. No changes proposed.', 'changes': []}
    modes = {mode.lower() for mode in re.findall(r'\b(tagged|untagged)\b', request, re.I)}
    mode = chosen_mode or (next(iter(modes)) if len(modes) == 1 else None)
    if mode is None:
        return {'answer': f'For VLAN {numbers[0]} to all connected servers, should destinations be tagged or untagged? Reply tagged or untagged. No changes proposed.', 'changes': []}
    source_text = scope if scope and re.search(r'\bfrom\b', scope, re.I) else request
    origin = re.search(r'\bfrom\s+(.+?)(?=\s+to\b|\s+as\b|[.!?]|$)', source_text, re.I)
    source = origin[1].strip() if origin else 'Router'
    routers = [asset for asset in context.get('assets', []) if asset.get('name', '').casefold() == source.casefold()
               or (source.casefold() == 'router' and asset.get('type') == 'Router')]
    if len(routers) != 1:
        return {'answer': 'Specify one recorded source router name; Router is ambiguous or unavailable. No changes proposed.', 'changes': []}
    source = routers[0]['name']
    from backend.infrastructure_graph import InfrastructureGraph
    infrastructure = InfrastructureGraph(context)
    merged, connected, skipped, conflicts = {}, [], [], []
    for server_id in infrastructure.select_assets('all servers'):
        server = infrastructure.assets[server_id]
        canonical = f"propose VLAN {numbers[0]} from {source} to {server['name']} as {mode}"
        trace = ai.topology_trace(context, canonical)
        if trace['status'] == 'no_recorded_path':
            skipped.append(server['name'])
            continue
        if trace['status'] != 'recorded_path':
            return {'answer': ai.recorded_path_answer(trace), 'changes': []}
        plan = tagged_path_plan(context, [ai.Message(role='user', content=canonical)], True, _single=True)
        if not plan['changes'] and 'already has the requested' not in plan['answer']:
            return {'answer': f"Cannot complete the bulk plan for {server['name']}: " + plan['answer'], 'changes': []}
        connected.append(server['name'])
        for change in plan['changes']:
            ports = merged.setdefault(change['asset_id'], {})
            for port, config in change['fields']['portVlans'].items():
                if port in ports and ports[port] != config:
                    conflicts.append(port)
                ports[port] = config
    if conflicts:
        return {'answer': 'The requested paths require conflicting settings on shared ports. Specify separate destination groups. No changes proposed.', 'changes': []}
    if not connected:
        return {'answer': f'No physical or virtual servers have recorded paths from {source}. Hosting alone does not identify a VM network port. No changes proposed.', 'changes': []}
    changes = [{'operation': 'update', 'asset_id': aid, 'fields': {'portVlans': ports}} for aid, ports in merged.items()]
    if len(changes) > 500:
        return {'answer': 'This complete plan exceeds 500 asset updates. Specify a smaller server group. No changes proposed.', 'changes': []}
    count = sum(len(ports) for ports in merged.values())
    answer = (f"VLAN {numbers[0]} from {source} to all {len(connected)} connected servers, destinations {mode}: "
              f"{count} ports need updates across {len(changes)} devices. Shared uplinks are updated once; every recorded LAG member is included. "
              'Existing unrelated VLAN settings are preserved.\nServers: ' + ', '.join(connected[:10])
              + (f' (and {len(connected) - 10} more; all are included in the plan)' if len(connected) > 10 else ''))
    if skipped:
        answer += f"\nExcluded {len(skipped)} servers without recorded network paths: " + ', '.join(skipped[:8])
    proposing = write_mode and (confirm or bool(re.search(r'\b(update|configure|apply|set|propose)\b', request, re.I)))
    if not changes:
        answer += '\nAll connected paths already have the requested settings. No changes needed.'
    elif proposing:
        answer += '\nReview and Apply the complete Netory inventory proposal. Live devices are not configured.'
    else:
        answer += '\nReply confirm' + ('' if write_mode else ' with Propose inventory changes enabled') + ' to generate the complete reviewed proposal.'
    return {'answer': answer, 'changes': changes if proposing else []}
