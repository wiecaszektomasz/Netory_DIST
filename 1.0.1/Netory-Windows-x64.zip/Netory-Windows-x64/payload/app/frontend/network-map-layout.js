// Reorder sibling branches using their actual connected port positions.
// Crossings take priority over shorter links; equal layouts retain their order.
export function minimizeMapCrossings({ positions, widths, depths, links, endpointPoint,
  siblingGroups, children = new Map(), blockWidths = widths, blockLefts, canSwap = () => true, maxComparisons = 250000 }) {
  const rows = new Map();
  for (const [id, position] of positions) {
    const depth = depths.get(id);
    if (!rows.has(depth)) rows.set(depth, []);
    rows.get(depth).push(id);
  }
  for (const row of rows.values()) row.sort((a, b) => positions.get(a).x - positions.get(b).x);
  const orientation = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
  let remainingComparisons = maxComparisons;
  const score = () => {
    const segments = links.map(link => ({
      a: endpointPoint(link.deviceAId, link.portA),
      b: endpointPoint(link.deviceBId, link.portB)
    }));
    let crossings = 0;
    let length = 0;
    for (let index = 0; index < segments.length; index += 1) {
      const {a,b} = segments[index];
      length += Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
      for (let other = index + 1; other < segments.length; other += 1) {
        if (--remainingComparisons < 0) return null;
        const { a: c, b: d } = segments[other];
        // Shared endpoints and collinear links are not proper crossings.
        if (orientation(a, b, c) * orientation(a, b, d) < 0 &&
            orientation(c, d, a) * orientation(c, d, b) < 0) crossings += 1;
      }
    }
    return { crossings, length };
  };
  const initial = score();
  if (!initial) return {before:null, after:null};
  let best = initial;
  // Alternate downward and upward sweeps so changes can propagate between levels.
  const leftOf = id => blockLefts ? blockLefts.get(id) : positions.get(id).x;
  const moveBranch = (id, delta) => {
    positions.get(id).x += delta;
    if (blockLefts) blockLefts.set(id, blockLefts.get(id) + delta);
    for (const childId of children.get(id) || []) moveBranch(childId, delta);
  };
  // Keep siblings together and move descendants with their parent. Flat row swaps
  // otherwise leave storage and server clusters underneath unrelated switches.
  const orderedRows = siblingGroups
    ? siblingGroups.map(group => group.slice().sort((a, b) => leftOf(a) - leftOf(b)))
    : [...rows.entries()].sort(([a], [b]) => a - b).map(([, row]) => row);
  for (let pass = 0; pass < 8; pass += 1) {
    let changed = false;
    const sweep = pass % 2 ? orderedRows.slice().reverse() : orderedRows;
    for (const row of sweep) {
      for (let index = 0; index < row.length - 1; index += 1) {
        const leftId = row[index];
        const rightId = row[index + 1];
        if (!canSwap(leftId, rightId)) continue;
        const oldLeft = leftOf(leftId);
        const oldRight = leftOf(rightId);
        const gap = oldRight - oldLeft - blockWidths.get(leftId);
        const leftDelta = blockWidths.get(rightId) + gap;
        const rightDelta = oldLeft - oldRight;
        moveBranch(rightId, rightDelta);
        moveBranch(leftId, leftDelta);
        const candidate = score();
        if (!candidate) {
          moveBranch(leftId, -leftDelta);
          moveBranch(rightId, -rightDelta);
          return {before:initial.crossings, after:best.crossings};
        }
        if (candidate.crossings < best.crossings ||
            (candidate.crossings === best.crossings && candidate.length < best.length - 0.01)) {
          [row[index], row[index + 1]] = [rightId, leftId];
          best = candidate;
          changed = true;
        } else {
          moveBranch(leftId, -leftDelta);
          moveBranch(rightId, -rightDelta);
        }
      }
    }
    if (!changed) break;
  }
  return { before: initial.crossings, after: best.crossings };
}
