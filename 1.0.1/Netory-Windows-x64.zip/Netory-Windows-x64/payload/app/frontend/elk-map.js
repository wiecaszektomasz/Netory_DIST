import { html, t } from './i18n.js?v=20261015-map-admin2';
import { esc } from './utils.js?v=20261015-map-admin2';

export function buildELKGraph(data, links, direction = 'RIGHT') {
  const assets = new Map((data.assets || []).map(asset => [asset.id, asset]));
  const connections = links.filter(link => assets.has(link.deviceAId) && assets.has(link.deviceBId));
  const connected = new Set(connections.flatMap(link => [link.deviceAId, link.deviceBId]));
  const nodes = [...assets.values()].filter(asset => connected.has(asset.id) || asset.showOnMap);
  const ids = new Map(nodes.map((asset, index) => [asset.id, `n${index}`]));
  const ports = new Map(nodes.map(asset => [asset.id, new Set()]));
  for (const link of connections) {ports.get(link.deviceAId).add(Number(link.portA)); ports.get(link.deviceBId).add(Number(link.portB));}
  return {
    id: 'root', layoutOptions: {'elk.algorithm': 'layered', 'elk.direction': direction, 'elk.edgeRouting': 'ORTHOGONAL', 'elk.spacing.nodeNode': '55', 'elk.layered.spacing.nodeNodeBetweenLayers': '100', 'elk.padding': '[top=40,left=40,bottom=40,right=40]', 'elk.randomSeed': '1'},
    children: nodes.map(asset => {
      const numbers = [...ports.get(asset.id)].sort((a,b) => a-b);
      return {id: ids.get(asset.id), assetId: asset.id, name: asset.name, type: asset.type, width: 230, height: Math.max(80, numbers.length * 20 + 35), ports: numbers.map(port => ({id: `${ids.get(asset.id)}p${port}`, number: port, width: 8, height: 8}))};
    }),
    edges: connections.map((link,index) => ({id: `e${index}`, sources: [`${ids.get(link.deviceAId)}p${Number(link.portA)}`], targets: [`${ids.get(link.deviceBId)}p${Number(link.portB)}`], description: `${assets.get(link.deviceAId).name} port ${link.portA} ↔ ${assets.get(link.deviceBId).name} port ${link.portB}${link.lagId ? ' · LAG member' : ''}`, lag: Boolean(link.lagId)})),
  };
}
export function renderELKSVG(graph) {
  const lines = (graph.edges || []).map(edge => (edge.sections || []).map(section => {
    const points = [section.startPoint, ...(section.bendPoints || []), section.endPoint];
    return html`<path class="elk-cable ${edge.lag ? 'elk-lag' : ''}" d="${points.map((point,index) => `${index ? 'L' : 'M'}${point.x} ${point.y}`).join(' ')}"><title>${esc(edge.description)}</title></path>`;
  }).join('')).join('');
  const nodes = (graph.children || []).map(node => html`<g transform="translate(${node.x},${node.y})"><title>${esc(node.name)} · ${esc(node.type)}</title><rect class="elk-device" width="${node.width}" height="${node.height}" rx="8"/><text class="elk-name" x="12" y="24">${esc((node.name || '').slice(0,28))}</text><text class="elk-type" x="12" y="44">${esc(node.type || '')}</text>${(node.ports || []).map(port => {const east = port.x >= node.width / 2; return html`<g><rect class="elk-port" x="${port.x}" y="${port.y}" width="${port.width}" height="${port.height}"><title>${esc(node.name)} port ${port.number}</title></rect><text class="elk-port-label" x="${port.x + (east ? -5 : 13)}" y="${port.y + 8}" text-anchor="${east ? 'end' : 'start'}">${port.number}</text></g>`;}).join('')}</g>`).join('');
  return html`<svg class="elk-map-svg" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="[[experimental_elk_network_topology]]" width="${graph.width || 400}" height="${graph.height || 200}" viewBox="0 0 ${graph.width || 400} ${graph.height || 200}">${lines}${nodes}</svg>`;
}
export function renderELKView(buttons) {
  return html`<div class="network-map-workspace"><div class="list-toolbar network-map-toolbar">${buttons}<div class="map-tools"><label>[[direction]] <select data-elk-direction><option value="RIGHT">[[left_to_right]]</option><option value="DOWN">[[top_to_bottom]]</option></select></label><button class="button" data-elk-fit>[[fit_to_screen]]</button><button class="button" data-elk-zoom="-20" aria-label="[[zoom_out]]">−</button><span data-elk-scale>100%</span><button class="button" data-elk-zoom="20" aria-label="[[zoom_in]]">+</button><button class="button" data-elk-retry>[[rebuild_layout]]</button></div></div><p class="panel-sub">[[experimental_elk_layout_individual_devices_and_physical_cables_including_lag_members_hover]]</p><section class="panel"><div class="network-map-scroll elk-map-scroll"><div data-elk-canvas aria-busy="true"><div class="empty-state">[[building_elk_layout]]</div></div></div></section></div>`;
}
export function bindELKView(view, data, links) {
  const canvas = view.querySelector('[data-elk-canvas]'), scroll = view.querySelector('.elk-map-scroll');
  let worker, timeout, graph, zoom = 100, observer, generation = 0;
  const dispose = () => { generation += 1; worker?.terminate(); clearTimeout(timeout); observer?.disconnect(); };
  observer = new MutationObserver(() => {if (!canvas.isConnected) dispose();});
  observer.observe(view, {childList: true});
  const applyZoom = value => {zoom = Math.max(10, Math.min(250, value)); const svg = canvas.querySelector('svg'); if (svg && graph) {svg.style.width = `${graph.width * zoom / 100}px`; svg.style.height = `${graph.height * zoom / 100}px`;} view.querySelector('[data-elk-scale]').textContent = `${Math.round(zoom)}%`;};
  const fail = message => {worker?.terminate(); clearTimeout(timeout); if (!canvas.isConnected) return; canvas.setAttribute('aria-busy','false'); canvas.innerHTML = html`<div class="empty-state" role="alert">${esc(message)} Use Rebuild layout to retry.</div>`;};
  const rebuild = () => {
    const request = ++generation;
    worker?.terminate(); clearTimeout(timeout);
    const input = buildELKGraph(data,links,view.querySelector('[data-elk-direction]').value);
    if (!input.children.length) {canvas.setAttribute('aria-busy','false'); canvas.innerHTML = html(["<div class=\"empty-state\">[[no_connected_devices_or_devices_marked_add_to_map]]</div>"]);return;}
    canvas.setAttribute('aria-busy','true'); canvas.innerHTML = html(["<div class=\"empty-state\">[[building_elk_layout]]</div>"]);
    try {
      worker = new Worker(new URL('./elk-layout-worker.js?v=20261014-startup1', import.meta.url));
      timeout = setTimeout(() => fail('Layout exceeded 30 seconds.'), 30000);
      worker.onmessage = event => { if (request !== generation) return; if (event.data.id === 0) { if (event.data.error) { fail(event.data.error.message || 'Could not initialize ELK.'); return; } worker.postMessage({id: 1, cmd: 'layout', graph: input, layoutOptions: {}, options: {}}); return; } clearTimeout(timeout); worker.terminate(); if (!canvas.isConnected) return; if (event.data.error) {fail(event.data.error.message || 'ELK layout failed.');return;} graph = event.data.data; canvas.innerHTML = renderELKSVG(graph); canvas.setAttribute('aria-busy','false'); applyZoom(zoom); };
      worker.onerror = () => {if (request === generation) fail('Could not load the ELK layout engine.');};
      worker.postMessage({id: 0, cmd: 'register', algorithms: ['layered']});
    } catch (error) {fail(error.message);}
  };
  view.querySelector('[data-elk-direction]').addEventListener('change',rebuild);
  view.querySelector('[data-elk-retry]').addEventListener('click',rebuild);
  view.querySelector('[data-elk-fit]').addEventListener('click', () => {if (graph) applyZoom(Math.min((scroll.clientWidth - 24) / graph.width, (scroll.clientHeight - 24) / graph.height) * 100);});
  view.querySelectorAll('[data-elk-zoom]').forEach(button => button.addEventListener('click', () => applyZoom(zoom + Number(button.dataset.elkZoom))));
  rebuild();
}
