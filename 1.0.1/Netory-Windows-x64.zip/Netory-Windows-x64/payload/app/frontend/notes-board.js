import {esc} from './utils.js';
import {t, getLocale} from './i18n.js?v=20261015-map-admin2';

export function formatNoteTime(value, locale = getLocale()) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? t('Unknown time') : new Intl.DateTimeFormat(locale, {
    year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
  }).format(date);
}

export function noteCard(note, {canEdit, editing = false, draft = ''}) {
  const manage = canEdit && note.can_manage;
  const stamp = (value, label = '') => `${label}<time datetime="${esc(value)}">${esc(formatNoteTime(value))}</time>`;
  return `<article class="board-note" data-note-card="${esc(note.id)}" aria-label="${esc(t('Note by'))} ${esc(note.author_name)}">
    ${editing ? `<form data-note-edit="${esc(note.id)}"><label class="sr-only" for="edit-note-${esc(note.id)}">${esc(t('Edit note'))}</label><textarea id="edit-note-${esc(note.id)}" name="content" maxlength="500" required rows="4">${esc(draft)}</textarea><div class="notes-edit-actions"><button class="button" type="submit">${esc(t('Save'))}</button><button class="button" type="button" data-note-cancel>${esc(t('Cancel'))}</button></div></form>` : `<p class="board-note-content">${esc(note.content)}</p>`}
    <footer class="board-note-footer"><strong>${esc(note.author_name)}</strong><span>${stamp(note.created_at)}</span>${note.version > 1 ? `<span>${stamp(note.updated_at, esc(t('Edited')) + ' ')}</span>` : ''}</footer>
    ${manage && !editing ? `<div class="board-note-actions"><button class="button" type="button" data-note-edit-open="${esc(note.id)}">${esc(t('Edit'))}</button><button class="button" type="button" data-note-delete="${esc(note.id)}">${esc(t('Delete'))}</button></div>` : ''}</article>`;
}

export async function renderNotesBoard({root, environmentId, canEdit, apiRequest, isCurrent}) {
  const base = `/api/environments/${encodeURIComponent(environmentId)}/notes`;
  let notes = [], total = 0, nextOffset = 0, hasMore = false, composerOpen = false, draft = '', editing = null, editVersion = null, editDraft = '', message = '', failed = false, busy = false;
  const request = (suffix = '', method = 'GET', body) => apiRequest(base + suffix, {method, ...(body ? {body: JSON.stringify(body)} : {})});
  const load = async (more = false) => {
    const offset = more ? nextOffset : 0;
    const result = await request(`?limit=50&offset=${offset}`);
    notes = more ? [...notes, ...result.items.filter(note => !notes.some(current => current.id === note.id))] : result.items;
    total = result.total;
    nextOffset = offset + result.items.length;
    hasMore = result.items.length > 0 && nextOffset < total;
  };
  const run = async action => {
    if (busy || !isCurrent()) return;
    busy = true;
    root.querySelectorAll('button, textarea').forEach(element => {element.disabled = true;});
    root.setAttribute('aria-busy', 'true');
    try {await action(); failed = false;} catch (error) {message = error.message; failed = true;}
    finally {busy = false; if (isCurrent()) {root.removeAttribute('aria-busy'); draw();}}
  };
  const draw = () => {
    if (!isCurrent()) return;
    root.innerHTML = `<div class="notes-board"><header class="notes-board-header"><div><h2>${esc(t('Notes board'))}</h2><p>${esc(t('Short notes shared with everyone who has access to this client.'))}</p></div><div class="notes-header-actions">${canEdit ? `<button class="button primary" type="button" data-note-toggle aria-expanded="${composerOpen}" aria-haspopup="dialog" aria-controls="new-board-note-dialog">${esc(t('Add note'))}</button>` : ''}<button class="button" type="button" data-notes-refresh>${esc(t('Refresh'))}</button></div></header>
      ${message ? `<p class="notes-board-feedback" role="${failed ? 'alert' : 'status'}">${esc(message)}</p>` : ''}
      ${canEdit ? (composerOpen ? `<dialog id="new-board-note-dialog" class="notes-composer-dialog" data-note-dialog aria-labelledby="new-board-note-title"><div class="modal-head"><h2 id="new-board-note-title">${esc(t('Add note'))}</h2><button class="button" type="button" data-note-close aria-label="${esc(t('Close'))}">×</button></div>${failed && message ? `<p class="notes-board-feedback" role="alert">${esc(message)}</p>` : ''}<form id="new-board-note-form" class="notes-composer" data-note-create><label for="new-board-note">${esc(t('Leave a note'))}</label><textarea id="new-board-note" name="content" maxlength="500" required rows="3" placeholder="${esc(t('Write a short update, reminder or handover note…'))}">${esc(draft)}</textarea><div><span class="secondary-cell" data-note-length>${draft.length}/500</span><button class="button" type="button" data-note-dismiss>${esc(t('Cancel'))}</button><button class="button primary" type="submit">${esc(t('Post note'))}</button></div></form></dialog>` : '') : `<p class="secondary-cell">${esc(t('Read-only access. Users with edit access can post notes.'))}</p>`}
      <div class="notes-board-count" role="status">${esc(t('Notes'))}: ${total}</div><div class="notes-board-grid">${notes.map(note => noteCard(note, {canEdit, editing: editing === note.id, draft: editDraft})).join('')}</div>
      ${!notes.length ? `<div class="notes-board-empty">${esc(t('No notes yet.'))}</div>` : ''}
      ${hasMore ? `<button class="button" type="button" data-notes-more>${esc(t('Load older notes'))}</button>` : ''}</div>`;
    const closeComposer = () => {
      if (busy) return;
      composerOpen = false;
      draw();
      root.querySelector('[data-note-toggle]')?.focus();
    };
    const dialog = root.querySelector('[data-note-dialog]');
    if (composerOpen) {
      dialog?.showModal?.();
      root.querySelector('[data-note-create] textarea')?.focus();
    }
    dialog?.addEventListener('cancel', event => {event.preventDefault(); closeComposer();});
    dialog?.addEventListener('click', event => {if (event.target === dialog) closeComposer();});
    root.querySelector('[data-note-close]')?.addEventListener('click', closeComposer);
    root.querySelector('[data-note-dismiss]')?.addEventListener('click', closeComposer);
    root.querySelector('[data-note-toggle]')?.addEventListener('click', () => {
      composerOpen = !composerOpen;
      draw();
      root.querySelector(composerOpen ? '[data-note-create] textarea' : '[data-note-toggle]')?.focus();
    });
    root.querySelector('[data-notes-refresh]')?.addEventListener('click', () => run(async () => {await load(); message = t('Board refreshed.');}));
    root.querySelector('[data-notes-more]')?.addEventListener('click', () => run(() => load(true)));
    root.querySelector('[data-note-create] textarea')?.addEventListener('input', event => {
      draft = event.target.value;
      root.querySelector('[data-note-length]').textContent = `${draft.length}/500`;
    });
    root.querySelector('[data-note-create]')?.addEventListener('submit', event => {
      event.preventDefault();
      const content = draft.trim();
      if (!content) {message = t('Write a note before posting.'); failed = true; draw(); return;}
      run(async () => {await request('', 'POST', {content}); draft = ''; composerOpen = false; root.querySelector('[data-note-toggle]')?.focus(); await load(); message = t('Note posted.');});
    });
    root.querySelectorAll('[data-note-edit-open]').forEach(button => button.addEventListener('click', () => {
      editing = button.dataset.noteEditOpen;
      const note = notes.find(note => note.id === editing);
      editDraft = note.content; editVersion = note.version;
      message = ''; draw(); root.querySelector('[data-note-edit] textarea')?.focus();
    }));
    root.querySelector('[data-note-cancel]')?.addEventListener('click', () => {editing = null; editDraft = ''; draw();});
    root.querySelector('[data-note-edit] textarea')?.addEventListener('input', event => {editDraft = event.target.value;});
    root.querySelector('[data-note-edit]')?.addEventListener('submit', event => {
      event.preventDefault();
      const note = notes.find(note => note.id === editing);
      if (!editDraft.trim()) {message = t('Write a note before posting.'); failed = true; draw(); return;}
      run(async () => {
        const updated = await request(`/${encodeURIComponent(note.id)}`, 'PATCH', {content: editDraft.trim(), version: editVersion});
        notes = notes.map(current => current.id === updated.id ? updated : current);
        editing = null; editDraft = ''; message = t('Note updated.');
      });
    });
    root.querySelectorAll('[data-note-delete]').forEach(button => button.addEventListener('click', () => {
      const note = notes.find(note => note.id === button.dataset.noteDelete);
      if (!confirm(t('Delete this note?'))) return;
      run(async () => {
        await request(`/${encodeURIComponent(note.id)}?version=${note.version}`, 'DELETE');
        notes = notes.filter(current => current.id !== note.id); total--; nextOffset = Math.max(0, nextOffset - 1); hasMore = nextOffset < total; message = t('Note deleted.');
      });
    }));
  };
  root.innerHTML = `<p>${esc(t('Loading notes…'))}</p>`;
  await run(() => load());
}
