// Pure cable geometry. Detailed visibility searches run in map-routing-worker.js.
export function previewMapRoute(start, end) {
  return [start, {x:start.x, y:end.y}, end];
}

function routeAroundDevices(geometry, start, end, endpointPortKeys = [], allowInternetNode = false, routedRoutes = [], exhaustive = false) {
  const clearance = 6;
  const endpointPorts = new Set(endpointPortKeys);
  const obstacleCandidates = geometry.obstacleCandidates;
  const portObstacles = geometry.portObstacles.filter(obstacle => !endpointPorts.has(obstacle.key));
  const contains = (obstacle, point) =>
    point.x >= obstacle.left && point.x <= obstacle.right &&
    point.y >= obstacle.top && point.y <= obstacle.bottom;
  const startBounds = obstacleCandidates.find(obstacle => contains(obstacle, start));
  const endBounds = obstacleCandidates.find(obstacle => contains(obstacle, end));
  const deviceObstacles = obstacleCandidates.filter(obstacle =>
    !contains(obstacle, start) && !contains(obstacle, end)
  ).map(obstacle => ({
    left: obstacle.left - clearance,
    right: obstacle.right + clearance,
    top: obstacle.top - clearance,
    bottom: obstacle.bottom + clearance
  }));
  // Device bounds already protect their ports. Merge overlapping port
  // clearances on endpoint devices without changing the blocked area.
  const exposedPorts = portObstacles.filter(port => !deviceObstacles.some(bounds =>
    port.left >= bounds.left && port.right <= bounds.right &&
    port.top >= bounds.top && port.bottom <= bounds.bottom
  )).sort((a, b) => a.top - b.top || a.bottom - b.bottom || a.left - b.left);
  const portBands = [];
  for (const port of exposedPorts) {
    const previous = portBands[portBands.length - 1];
    if (previous && previous.top === port.top && previous.bottom === port.bottom &&
        port.left < previous.right) {
      previous.right = Math.max(previous.right, port.right);
    } else {
      portBands.push({ ...port });
    }
  }
  const endpointHeaders = obstacleCandidates.filter(bounds =>
    contains(bounds, start) || contains(bounds, end)
  ).map(bounds => ({ left: bounds.left, right: bounds.right,
    top: bounds.top, bottom: bounds.top + 20 }));
  const obstacles = deviceObstacles.concat(portBands, endpointHeaders);
  if (geometry.internetObstacle && !allowInternetNode) obstacles.push(geometry.internetObstacle);
  const routedSegments = routedRoutes.flatMap(route => route.points.slice(1).map((point, index) => ({
    start: route.points[index],
    end: point,
    routeStart: route.points[0],
    routeEnd: route.points[route.points.length - 1]
  })));
  const pointBlocked = point => obstacles.some(obstacle =>
    point.x > obstacle.left && point.x < obstacle.right &&
    point.y > obstacle.top && point.y < obstacle.bottom
  );
  const segmentClear = (first, second) => {
    if (first.x === second.x) {
      return !obstacles.some(obstacle =>
        first.x > obstacle.left && first.x < obstacle.right &&
        Math.max(Math.min(first.y, second.y), obstacle.top) <
          Math.min(Math.max(first.y, second.y), obstacle.bottom)
      );
    }
    if (first.y === second.y) {
      return !obstacles.some(obstacle =>
        first.y > obstacle.top && first.y < obstacle.bottom &&
        Math.max(Math.min(first.x, second.x), obstacle.left) <
          Math.min(Math.max(first.x, second.x), obstacle.right)
      );
    }
    return false;
  };
  const points = [];
  const indexes = new Map();
  const addPoint = point => {
    if (pointBlocked(point)) return undefined;
    const key = `${point.x},${point.y}`;
    if (indexes.has(key)) return indexes.get(key);
    indexes.set(key, points.length);
    points.push(point);
    return points.length - 1;
  };
  // Keep a right-angle connection visible even when overlapping clearance
  // regions leave an endpoint enclosed. Prefer the less obstructed elbow.
  const fallbackRoute = () => {
    const candidates = [
      [start, {x:start.x, y:end.y}, end],
      [start, {x:end.x, y:start.y}, end]
    ];
    const score = route => route.slice(1).reduce((total, point, index) => {
      const first = route[index];
      return total + obstacles.reduce((blocked, obstacle) => {
        const overlap = first.x === point.x
          ? (first.x > obstacle.left && first.x < obstacle.right
            ? Math.max(0, Math.min(Math.max(first.y, point.y), obstacle.bottom) - Math.max(Math.min(first.y, point.y), obstacle.top)) : 0)
          : (first.y > obstacle.top && first.y < obstacle.bottom
            ? Math.max(0, Math.min(Math.max(first.x, point.x), obstacle.right) - Math.max(Math.min(first.x, point.x), obstacle.left)) : 0);
        return blocked + overlap;
      }, 0);
    }, 0);
    return candidates.sort((a, b) => score(a) - score(b))[0];
  };
  addPoint(start);
  addPoint(end);
  addPoint({ x: start.x, y: end.y });
  addPoint({ x: end.x, y: start.y });
  const addEndpointExits = (point, bounds) => {
    if (!bounds) return;
    [
    { x: point.x, y: bounds.top - clearance },
    { x: point.x, y: bounds.bottom + clearance },
    { x: bounds.left - clearance, y: point.y },
    { x: bounds.right + clearance, y: point.y }
    ].forEach(addPoint);
  };
  addEndpointExits(start, startBounds);
  addEndpointExits(end, endBounds);
  obstacles.forEach(obstacle => {
    addPoint({ x: obstacle.left, y: obstacle.top });
    addPoint({ x: obstacle.left, y: obstacle.bottom });
    addPoint({ x: obstacle.right, y: obstacle.top });
    addPoint({ x: obstacle.right, y: obstacle.bottom });
  });
  // Existing routes affect scoring, but their bend candidates must not grow
  // without limit as each additional connection is routed.
  const bendSegments = routedSegments.length > 16 ? routedSegments.slice(-16) : routedSegments;
  bendSegments.forEach(({ start: first, end: second }) => {
    if (first.y === second.y) {
      [-5, 5].forEach(offset => {
        addPoint({ x: first.x, y: first.y + offset });
        addPoint({ x: second.x, y: second.y + offset });
      });
    } else {
      [-5, 5].forEach(offset => {
        addPoint({ x: first.x + offset, y: first.y });
        addPoint({ x: second.x + offset, y: second.y });
      });
    }
  });
  const startIndex = indexes.get(`${start.x},${start.y}`);
  const endIndex = indexes.get(`${end.x},${end.y}`);
  if (startIndex === undefined || endIndex === undefined) return fallbackRoute();
  // Avoid a quadratic visibility graph on exceptionally large topologies.
  if (points.length > 1200) return fallbackRoute();
  const edges = points.map(() => []);
  // Candidate elbows repeatedly reuse the same segments. Their overlap
  // and crossing costs stay fixed throughout this connection's search.
  const segmentCosts = new Map();
  const segmentCost = (first, second) => {
    const forward = first.x < second.x || (first.x === second.x && first.y <= second.y);
    const a = forward ? first : second, b = forward ? second : first;
    const key = `${a.x},${a.y}:${b.x},${b.y}`;
    if (segmentCosts.has(key)) return segmentCosts.get(key);
    const routePoints = [first, second];
    const overlap = routePoints.slice(1).reduce((total, point, index) => {
      const previous = routePoints[index];
      return total + routedSegments.reduce((shared, segment) => {
        const existing = segment.start;
        const existingEnd = segment.end;
        if (previous.y === point.y && existing.y === existingEnd.y && previous.y === existing.y) {
          return shared + Math.max(0,
            Math.min(Math.max(previous.x, point.x), Math.max(existing.x, existingEnd.x)) -
            Math.max(Math.min(previous.x, point.x), Math.min(existing.x, existingEnd.x))
          );
        }
        if (previous.x === point.x && existing.x === existingEnd.x && previous.x === existing.x) {
          return shared + Math.max(0,
            Math.min(Math.max(previous.y, point.y), Math.max(existing.y, existingEnd.y)) -
            Math.max(Math.min(previous.y, point.y), Math.min(existing.y, existingEnd.y))
          );
        }
        return shared;
      }, 0);
    }, 0);
    const crossings = routePoints.slice(1).reduce((total, point, index) => {
      const previous = routePoints[index];
      return total + routedSegments.filter(({ start: existing, end: existingEnd, routeStart, routeEnd }) => {
        const horizontal = previous.y === point.y;
        const existingHorizontal = existing.y === existingEnd.y;
        if (horizontal === existingHorizontal) return false;
        const hStart = horizontal ? previous : existing;
        const hEnd = horizontal ? point : existingEnd;
        const vStart = horizontal ? existing : previous;
        const vEnd = horizontal ? existingEnd : point;
        const x = vStart.x;
        const y = hStart.y;
        const sharedEndpoint = [start, end].some(endpoint => endpoint.x === x && endpoint.y === y) &&
          [routeStart, routeEnd].some(endpoint => endpoint.x === x && endpoint.y === y);
        // Include bends, so a path cannot evade the penalty by turning at a crossing.
        return !sharedEndpoint && x >= Math.min(hStart.x, hEnd.x) && x <= Math.max(hStart.x, hEnd.x) &&
          y >= Math.min(vStart.y, vEnd.y) && y <= Math.max(vStart.y, vEnd.y);
      }).length;
    }, 0);
    const cost = overlap * 1000 + crossings * 1000;
    segmentCosts.set(key, cost);
    return cost;
  };
  const connect = (firstIndex, secondIndex, routePoints) => {
    const distance = routePoints.slice(1).reduce((total, point, index) => {
      const previous = routePoints[index];
      return total + Math.abs(point.x - previous.x) + Math.abs(point.y - previous.y)
        + segmentCost(previous, point);
    }, 0) + (routePoints.length - 2) * 0.1;
    const routeDistance = distance;
    edges[firstIndex].push({ index: secondIndex, routePoints, distance: routeDistance });
    edges[secondIndex].push({
      index: firstIndex,
      routePoints: routePoints.slice().reverse(),
      distance: routeDistance
    });
  };
  const candidatePairs = new Set();
  const addPair = (a, b) => {
    if (a !== b) candidatePairs.add(`${Math.min(a, b)}:${Math.max(a, b)}`);
  };
  if (exhaustive || points.length <= 80) {
    for (let a = 0; a < points.length; a += 1) {
      for (let b = a + 1; b < points.length; b += 1) addPair(a, b);
    }
  } else {
    // A sparse visibility graph avoids scoring every possible elbow against
    // every obstacle and existing link on large, high-port-count maps.
    for (const axis of ['x', 'y']) {
      const groups = new Map();
      points.forEach((point, index) => {
        if (!groups.has(point[axis])) groups.set(point[axis], []);
        groups.get(point[axis]).push(index);
      });
      const otherAxis = axis === 'x' ? 'y' : 'x';
      for (const group of groups.values()) {
        group.sort((a, b) => points[a][otherAxis] - points[b][otherAxis]);
        for (let i = 1; i < group.length; i += 1) addPair(group[i - 1], group[i]);
      }
    }
    points.forEach((point, index) => {
      points.map((other, otherIndex) => ({ index: otherIndex,
        distance: Math.abs(point.x - other.x) + Math.abs(point.y - other.y) }))
        .filter(other => other.index !== index)
        .sort((a, b) => a.distance - b.distance)
        .slice(0, 12).forEach(other => addPair(index, other.index));
    });
    addPair(startIndex, endIndex);
  }
  for (const pair of candidatePairs) {
      const [firstIndex, secondIndex] = pair.split(':').map(Number);
      const first = points[firstIndex];
      const second = points[secondIndex];
      if (first.x === second.x || first.y === second.y) {
        if (segmentClear(first, second)) connect(firstIndex, secondIndex, [first, second]);
        continue;
      }
      const bends = [
        { x: first.x, y: second.y },
        { x: second.x, y: first.y }
      ];
      bends.forEach(bend => {
        if (!pointBlocked(bend) && segmentClear(first, bend) && segmentClear(bend, second)) {
          connect(firstIndex, secondIndex, [first, bend, second]);
        }
      });
  }
  const distances = Array(points.length).fill(Infinity);
  const previous = Array(points.length).fill(null);
  const visited = new Set();
  distances[startIndex] = 0;
  while (visited.size < points.length) {
    let current = -1;
    for (let index = 0; index < points.length; index += 1) {
      if (!visited.has(index) && (current === -1 || distances[index] < distances[current])) current = index;
    }
    if (current === -1 || !Number.isFinite(distances[current])) break;
    if (current === endIndex) break;
    visited.add(current);
    edges[current].forEach(edge => {
      const distance = distances[current] + edge.distance;
      if (distance >= distances[edge.index]) return;
      distances[edge.index] = distance;
      previous[edge.index] = { index: current, routePoints: edge.routePoints };
    });
  }
  if (!Number.isFinite(distances[endIndex])) {
    // Retry small graphs only; exhaustive large graphs grow quadratically.
    if (!exhaustive && points.length > 80 && points.length <= 240) {
      return routeAroundDevices(geometry, start, end, endpointPortKeys, allowInternetNode, routedRoutes, true);
    }
    return fallbackRoute();
  }
  const route = [points[endIndex]];
  let current = endIndex;
  while (current !== startIndex) {
    const segment = previous[current];
    route.push(...segment.routePoints.slice(0, -1).reverse());
    current = segment.index;
  }
  route.reverse();
  return route.filter((point, index) => {
    if (index === 0 || index === route.length - 1) return true;
    const before = route[index - 1];
    const after = route[index + 1];
    return (before.x === point.x) !== (point.x === after.x);
  });
}

export function routeMapConnections(input) {
  const routes = [];
  for (const request of input.routes) {
    const points = request.fixedPoints || routeAroundDevices(input.geometry, request.start, request.end,
      request.endpointPortKeys, request.allowInternetNode, routes);
    routes.push({points});
  }
  return routes.map(route => route.points);
}

export function runMapRouting(input) {
  let worker, timer, rejectPending, settled = false;
  const finish = (callback, value) => {
    if (settled) return;
    settled = true; clearTimeout(timer); worker?.terminate(); callback(value);
  };
  const promise = new Promise((resolve, reject) => {
    rejectPending = reject;
    try {
      worker = new Worker(new URL('./map-routing-worker.js?v=20261025-map1', import.meta.url), {type:'module'});
      timer = setTimeout(() => finish(reject, new Error('Cable routing took too long; keeping the preview.')), 30000);
      timer.unref?.();
      worker.onmessage = ({data}) => data.error
        ? finish(reject, new Error(data.error)) : finish(resolve, data.routes);
      worker.onerror = () => finish(reject, new Error('Cable routing is unavailable; keeping the preview.'));
      worker.postMessage(input);
    } catch (error) { finish(reject, error); }
  });
  return {promise, cancel: () => finish(rejectPending, new Error('Routing cancelled.'))};
}
