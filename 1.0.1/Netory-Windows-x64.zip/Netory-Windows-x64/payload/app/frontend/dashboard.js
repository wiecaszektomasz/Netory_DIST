import { html, t } from './i18n.js?v=20261015-map-admin2';
import { esc } from './utils.js?v=20261015-map-admin2';

export const metricLabels = {assets: 'Assets', vlans: 'VLANs', licenses: 'Licenses', servers: 'Servers', networks: 'LANs & WLANs', accounts: 'Accounts', rooms: 'Rooms & cabinets', maintenance: 'Maintenance'};
export const widgetLabels = {recent: 'Recently added assets', licenses: 'License expiry reminders', warranties: 'Warranty expiry reminders', status: 'Device status', types: 'Asset types', locations: 'Locations', os: 'OS support reminders', licenseUsage: 'License seat usage', completeness: 'Missing inventory details'};
export const defaultDashboard = {metrics: ['assets', 'vlans', 'licenses', 'servers'], widgets: ['recent', 'licenses', 'warranties', 'status', 'os', 'licenseUsage'], reminderDays: 90, rowLimit: 6};
export function dashboardPreferences(saved) {
  return {metrics: [...new Set((saved?.metrics || defaultDashboard.metrics).filter(key => key in metricLabels))], widgets: [...new Set((saved?.widgets || defaultDashboard.widgets).filter(key => key in widgetLabels))], reminderDays: saved?.reminderDays || 90, rowLimit: saved?.rowLimit || 6};
}
export function environmentDashboard(saved, environmentId) {
  return saved?.environments ? saved.environments[environmentId] || saved.default : saved;
}
export function daysUntil(date, now = new Date()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) return Infinity;
  const [year, month, day] = date.split('-').map(Number);
  return Math.round((Date.UTC(year, month - 1, day) - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
}
export function dashboardSummaries(data, preferences) {
  const assets = data.assets || [], licenses = data.licenses || [];
  const group = key => [...assets.reduce((counts, row) => { const value = (key === 'status' || key === 'type' ? t(row[key]) : row[key]) || t('Not recorded'); counts.set(value, (counts.get(value) || 0) + 1); return counts; }, new Map())].sort((a,b) => b[1] - a[1]).map(([name,value]) => ({name, detail: `${t('{count} devices', {count: value})}`}));
  const reminders = (rows, field, name) => rows.filter(row => Number.isFinite(daysUntil(row[field])) && daysUntil(row[field]) <= preferences.reminderDays).sort((a,b) => a[field].localeCompare(b[field])).map(row => ({name: row[name], detail: `${field === 'osEol' ? (row.os || 'OS') + ' · ' : ''}${row[field]} · ${daysUntil(row[field]) < 0 ? t('Expired') : daysUntil(row[field]) === 0 ? t('Due today') : t('In {count} days', {count: daysUntil(row[field])})}`, warn: true}));
  return {
    recent: assets.slice().reverse().map(row => ({name: row.name, detail: [row.type, row.location, row.status].filter(Boolean).join(' · ')})),
    licenses: reminders(licenses, 'expiry', 'product'), warranties: reminders(assets, 'warrantyExpiry', 'name'),
    os: reminders(assets, 'osEol', 'name'),
    status: group('status'), types: group('type'), locations: group('location'),
    licenseUsage: licenses.map(row => {const total = Number(row.seats) || 0; const used = Math.max(Number(row.assigned) || 0, (row.assignedAssetIds || []).length); return {name: row.product, detail: `${t('{used} / {total} seats used · {available} available', {used, total, available: Math.max(0, total - used)})}`, warn: used > total};}),
    completeness: ['serial', 'location', 'hostname', 'warrantyExpiry'].map(key => ({name: t({serial: 'Missing serial number', location: 'Missing location', hostname: 'Missing hostname', warrantyExpiry: 'Missing warranty date'}[key]), detail: `${t('{count} of {total} assets', {count: assets.filter(row => !row[key]).length, total: assets.length})}`})),
  };
}
export function renderDashboard(data, saved) {
  const prefs = dashboardPreferences(saved), assets = data.assets || [];
  const values = {assets: [assets.length, `${t('{count} in service', {count: assets.filter(row => row.status === 'In service').length})}`], vlans: [(data.vlans || []).length, 'Networks documented'], licenses: [(data.licenses || []).length, 'Entitlements tracked'], servers: [assets.filter(row => ['Physical server', 'Virtual server'].includes(row.type)).length, 'Physical and virtual'], networks: [(data.lans || []).length + (data.wlans || []).length, 'Wired and wireless networks'], accounts: [(data.accounts || []).length, 'Registered accounts'], rooms: [`${(data.rooms || []).length} / ${(data.racks || []).length}`, 'Rooms / rack cabinets'], maintenance: [assets.filter(row => row.status === 'Maintenance').length, 'Devices in maintenance']};
  const summaries = dashboardSummaries(data, prefs);
  const pages = {licenses: 'licenses', licenseUsage: 'licenses', recent: 'assets', warranties: 'assets', status: 'assets', types: 'assets', locations: 'assets', os: 'assets', completeness: 'assets'};
  const panels = prefs.widgets.map((key, index) => {const rows = summaries[key]; return html`<section class="panel" style="order:${index}"><div class="panel-head"><div><div class="panel-title">${esc(t(widgetLabels[key]))}</div><div class="panel-sub">${t('{count} items', {count: rows.length})}${rows.length > prefs.rowLimit ? ' · ' + t('Scroll to see all {count} records', {count: rows.length}) : ''}</div></div><button class="text-button" data-page="${pages[key]}">[[view_all]]</button></div>${rows.length ? html`<div class="dashboard-summary-scroll" style="--summary-rows:${prefs.rowLimit}"${rows.length > prefs.rowLimit ? ` tabindex="0" role="region" aria-label="${esc(t(widgetLabels[key]))} — ${esc(t('Scroll to see all {count} records', {count: rows.length}))}"` : ''}>${rows.map(row => html`<div class="license-row"><div><div class="primary-cell">${esc(row.name || t('Unnamed'))}</div><div class="secondary-cell ${row.warn ? 'dashboard-warning' : ''}">${esc(row.detail)}</div></div></div>`).join('')}</div>` : html(["<div class=\"empty-state\">[[no_matching_records]]</div>"])}</section>`;});
  return html`<div class="overview-intro"><div><div class="eyebrow">[[your_environment_at_a_glance]]</div><p>${t('Reminders within {count} days, including expired dates.', {count: prefs.reminderDays})}</p></div><button class="button" data-dashboard-config>[[configure_dashboard]]</button></div>
    <section class="metrics">${prefs.metrics.map(key => html`<div class="metric"><div class="metric-top">${esc(t(metricLabels[key]))}</div><div class="metric-value">${esc(String(values[key][0]))}</div><div class="metric-foot">${esc(t(values[key][1]))}</div></div>`).join('')}</section>
    <div class="dashboard-grid">${[0, 1].map(column => html`<div class="dashboard-column">${panels.filter((_, index) => index % 2 === column).join('')}</div>`).join('')}</div>
    ${!prefs.widgets.length && !prefs.metrics.length ? html(["<div class=\"empty-state\">[[your_dashboard_is_empty_choose_cards_and_summaries_in_configure_dashboard]]</div>"]) : ''}`;
}

export function openDashboardConfiguration({saved, environmentId, apiRequest, onSaved, closeModal}) {
  const prefs = dashboardPreferences(saved), root = document.getElementById('modal-root');
  const choices = (labels, selected, kind) => [...selected, ...Object.keys(labels).filter(key => !selected.includes(key))].map(key => html`<div class="dashboard-choice" data-choice="${key}"><label><input type="checkbox" name="${kind}" value="${key}" ${selected.includes(key) ? 'checked' : ''}> ${esc(t(labels[key]))}</label><div><button type="button" class="text-button" data-move="-1" aria-label="${esc(t('Move {label} up', {label: t(labels[key])}))}">↑</button><button type="button" class="text-button" data-move="1" aria-label="${esc(t('Move {label} down', {label: t(labels[key])}))}">↓</button></div></div>`).join('');
  root.innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="dashboard-config-form"><div class="modal-head"><h2>[[configure_dashboard]]</h2><button type="button" class="button" data-close>[[close]]</button></div><div class="modal-body"><p class="panel-sub">[[these_preferences_belong_to_your_account_for_the_currently_selected_client_viewers_can_per]]</p><p class="form-error" role="alert" hidden></p><fieldset><legend>[[summary_cards]]</legend>${choices(metricLabels,prefs.metrics,'metrics')}</fieldset><fieldset><legend>[[information_and_summaries]]</legend>${choices(widgetLabels,prefs.widgets,'widgets')}</fieldset><div class="form-grid"><div class="field"><label>[[reminder_period_days]]<input type="number" name="reminderDays" min="1" max="365" value="${prefs.reminderDays}" required></label></div><div class="field"><label>[[visible_rows_per_summary]]<input type="number" name="rowLimit" min="3" max="20" value="${prefs.rowLimit}" required></label></div></div></div><div class="modal-foot"><button type="button" class="button" data-dashboard-reset>[[restore_defaults]]</button><button type="button" class="button" data-close>[[cancel]]</button><button type="submit" class="button primary">[[save_dashboard]]</button></div></form></div>`;
  const form = root.querySelector('form');
  form.addEventListener('click', event => {
    const move = event.target.closest('[data-move]');
    if (move) { const row = move.closest('[data-choice]'); const sibling = Number(move.dataset.move) < 0 ? row.previousElementSibling : row.nextElementSibling; if (sibling?.matches('[data-choice]')) { if (Number(move.dataset.move) < 0) sibling.before(row); else sibling.after(row); } }
    if (event.target.closest('[data-dashboard-reset]')) openDashboardConfiguration({saved: defaultDashboard, environmentId, apiRequest, onSaved, closeModal});
  });
  form.addEventListener('submit', async event => {
    event.preventDefault(); const button = form.querySelector('[type="submit"]'); button.disabled = true;
    const values = new FormData(form), dashboard = {metrics: values.getAll('metrics'), widgets: values.getAll('widgets'), reminderDays: Number(values.get('reminderDays')), rowLimit: Number(values.get('rowLimit'))};
    try {const result = await apiRequest('/api/users/me/preferences', {method:'PATCH', body: JSON.stringify({dashboard, environmentId})}); onSaved(result.dashboard); closeModal();}
    catch (error) {const message = form.querySelector('[role="alert"]'); message.textContent = error.message; message.hidden = false; button.disabled = false;}
  });
}
