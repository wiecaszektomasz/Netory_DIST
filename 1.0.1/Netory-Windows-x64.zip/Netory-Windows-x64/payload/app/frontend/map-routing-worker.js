import {routeMapConnections} from './map-routing.js?v=20261025-map1';

self.onmessage = ({data}) => {
  try { self.postMessage({routes:routeMapConnections(data)}); }
  catch (error) { self.postMessage({error:error.message || 'Cable routing failed.'}); }
};
