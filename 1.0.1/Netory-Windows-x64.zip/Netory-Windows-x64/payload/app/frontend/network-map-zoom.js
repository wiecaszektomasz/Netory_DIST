// Keep the same point of the map beneath the viewport center while resizing.
export function preserveMapViewport(scroll, svg, resize) {
  const viewport = scroll.getBoundingClientRect();
  const centerX = viewport.left + (scroll.clientLeft || 0) + scroll.clientWidth / 2;
  const centerY = viewport.top + (scroll.clientTop || 0) + scroll.clientHeight / 2;
  const before = svg.getBoundingClientRect();
  const mapX = before.width ? (centerX - before.left) / before.width : 0.5;
  const mapY = before.height ? (centerY - before.top) / before.height : 0.5;
  resize();
  const after = svg.getBoundingClientRect();
  scroll.scrollLeft += after.left + mapX * after.width - centerX;
  scroll.scrollTop += after.top + mapY * after.height - centerY;
}
