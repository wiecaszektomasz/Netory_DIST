// Resolve room membership without changing inventory or following cyclic host references.
export function assetRoomId(asset, data, visited = new Set()) {
  if (!asset || visited.has(asset.id)) return '';
  visited.add(asset.id);
  const rack = (data.racks || []).find(item => item.id === asset.rackId);
  if (rack) return rack.roomId || '';
  if (asset.roomId) return asset.roomId;
  if (asset.type === 'Virtual server') {
    if (asset.hypervisorClusterId) {
      const cluster = (data.clusters || []).find(item => item.id === asset.hypervisorClusterId);
      const rooms = new Set((cluster?.memberAssetIds || []).map(id => assetRoomId(data.assets.find(item => item.id === id), data, new Set(visited))));
      return rooms.size === 1 ? [...rooms][0] : '';
    }
    return assetRoomId(data.assets.find(item => item.id === asset.hypervisorId), data, visited);
  }
  return '';
}

export function buildRoomMap(data, roomId, connections = data.connections || []) {
  const assets = data.assets.filter(asset => assetRoomId(asset, data) === roomId);
  const ids = new Set(assets.map(asset => asset.id));
  const external = connections.filter(link => ids.has(link.deviceAId) !== ids.has(link.deviceBId));
  const externalIds = new Set(external.flatMap(link => [link.deviceAId, link.deviceBId]));
  // Keep group identities and names, with only members from this room.
  // Single-member groups still show membership when the other members are elsewhere.
  const roomGroups = groups => (groups || []).map(group => ({
    ...group, memberAssetIds: (group.memberAssetIds || []).filter(id => ids.has(id))
  })).filter(group => group.memberAssetIds.length);
  return {
    data: {...data, assets: assets.map(asset => externalIds.has(asset.id) ? {...asset, showOnMap: true} : asset), stacks: roomGroups(data.stacks), clusters: roomGroups(data.clusters),
      connections: connections.filter(link => ids.has(link.deviceAId) && ids.has(link.deviceBId))},
    external
  };
}


// A cabinet placement controls the room, including an unassigned cabinet room.
export function bindAssetRoomField(form, racks = []) {
  const room = form.querySelector('[name="roomId"]');
  if (!room) return;
  const cabinet = form.querySelector('[name="rackId"]');
  const enabled = form.querySelector('[name="rackEnabled"]');
  const type = form.querySelector('[name="type"]');
  let manualRoom = room.value;
  const sync = () => {
    const rack = enabled?.checked && type?.value !== 'Virtual server' && racks.find(item => item.id === cabinet?.value);
    room.disabled = Boolean(rack);
    room.value = rack ? rack.roomId || '' : manualRoom;
  };
  room.addEventListener('change', () => { if (!room.disabled) manualRoom = room.value; });
  cabinet?.addEventListener('change', sync);
  enabled?.addEventListener('change', sync);
  type?.addEventListener('change', sync);
  sync();
}
