import { html, t } from './i18n.js?v=20261015-map-admin2';
import { esc } from './utils.js?v=20261015-map-admin2';

export function osPicker(asset, catalog) {
  const selected = asset.osCatalogId || (asset.os ? 'other' : '');
  return html`<select name="osCatalogId" aria-label="[[operating_system]]"><option value="">[[not_assigned]]</option>${catalog.map(item => html`<option value="${esc(item.id)}" ${selected === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}<option value="other" ${selected === 'other' ? 'selected' : ''}>[[other_custom_operating_system]]</option></select><div data-os-info class="secondary-cell"></div><div data-os-custom><label>[[custom_os_name]]<input name="os" maxlength="240" value="${esc(asset.os || '')}"></label><label>[[os_family]]<select name="osFamily">${['Other', 'Windows', 'Linux', 'macOS'].map(family => html`<option ${asset.osFamily === family ? 'selected' : ''}>${family}</option>`).join('')}</select></label><label>[[end_of_life_date]]<input name="osEol" type="date" value="${esc(asset.osEol || '')}"></label><span class="secondary-cell">[[leave_the_date_blank_when_unknown_or_not_published]]</span></div>`;
}

export function bindOSPicker(form, catalog) {
  const select = form.querySelector('[name="osCatalogId"]');
  if (!select) return;
  const update = () => {
    const custom = select.value === 'other';
    const group = form.querySelector('[data-os-custom]');
    group.hidden = !custom;
    group.querySelectorAll('input, select').forEach(input => { input.disabled = !custom; });
    group.querySelector('[name="os"]').required = custom;
    const entry = catalog.find(item => item.id === select.value);
    form.querySelector('[data-os-info]').textContent = entry ? `End of life: ${entry.eol || 'Not published / unknown'}. ${entry.supportNotes || ''}` : '';
  };
  select.addEventListener('change', update);
  update();
}

export function collectOS(values, catalog) {
  const entry = catalog.find(item => item.id === values.osCatalogId);
  if (entry) return { osCatalogId: entry.id, os: entry.name, osFamily: entry.family, osEol: entry.eol || '' };
  if (values.osCatalogId === 'other') return { osCatalogId: '', os: (values.os || '').trim(), osFamily: values.osFamily || 'Other', osEol: values.osEol || '' };
  return { osCatalogId: '', os: '', osFamily: '', osEol: '' };
}

export function osIcon(asset, x, y, size = 8) {
  if (!['Physical server', 'Virtual server'].includes(asset.type)) return '';
  let family = asset.osFamily;
  if (/^proxmox-ve-/.test(asset.osCatalogId || '') || /\bproxmox\b/i.test(asset.os || '')) family = 'Proxmox';
  else if (/^vmware-esxi-/.test(asset.osCatalogId || '') || /\b(?:vmware|esxi)\b/i.test(asset.os || '')) family = 'VMware';
  if (!family) {
    if (/windows/i.test(asset.os || '')) family = 'Windows';
    else if (/mac\s?os|os x/i.test(asset.os || '')) family = 'macOS';
    else if (/linux|ubuntu|debian|rocky|red hat|rhel|centos|alma|suse|fedora/i.test(asset.os || '')) family = 'Linux';
  }
  const shapes = {
    Proxmox: html(["<path d=\"m1.5 1.5 8 8m0-8-8 8\" stroke=\"#e57000\" stroke-width=\"3\" stroke-linecap=\"round\"/><path d=\"m2.5 2.5 6 6m0-6-6 6\" stroke=\"#fff\" stroke-width=\".7\"/>"]),
    VMware: html(["<rect x=\".6\" y=\".6\" width=\"6.8\" height=\"6.8\" rx=\"1.3\" fill=\"none\" stroke=\"#1684b0\" stroke-width=\"1.2\"/><rect x=\"3.6\" y=\"3.6\" width=\"6.8\" height=\"6.8\" rx=\"1.3\" fill=\"none\" stroke=\"#536a78\" stroke-width=\"1.2\"/>"]),
    Windows: html(["<path fill=\"#1684d5\" d=\"M0 1h4v4H0zm5-1h5v5H5zM0 6h4v4H0zm5 0h5v5H5z\"/>"]),
    Linux: html(["<ellipse cx=\"5\" cy=\"6\" rx=\"3.7\" ry=\"4.7\" fill=\"#26332c\"/><ellipse cx=\"5\" cy=\"7\" rx=\"2.5\" ry=\"3\" fill=\"#fff\"/><circle cx=\"4\" cy=\"3.5\" r=\".65\" fill=\"#fff\"/><circle cx=\"6\" cy=\"3.5\" r=\".65\" fill=\"#fff\"/><path d=\"m3.5 4.5 1.5 1 1.5-1zM1 10h3M6 10h3\" stroke=\"#e5a92b\" fill=\"#e5a92b\"/>"]),
    macOS: html(["<path fill=\"#718078\" d=\"M5 2C5 0 7 0 8 0 8 1.5 6.5 2.5 5 2M5 3C3 1.5 0 3 1 6.5 1.7 9 3 11 4.5 10c.5-.4 1-.4 1.5 0 1.5 1 3-1.5 3.5-3C7 6 7 4.5 9 3.5 8 2 6 2 5 3\"/>"]),
  };
  if (!shapes[family]) return '';
  return html`<g class="map-os-icon" role="img" aria-label="${esc(family)}" transform="translate(${x} ${y}) scale(${size / 11})"><title>${esc(asset.os || family)}${asset.osEol ? ` · End of life: ${esc(asset.osEol)}` : ''}</title><rect x="-1" y="-1" width="13" height="13" rx="2" fill="#fff" stroke="#c4cfc8" stroke-width=".7"/>${shapes[family]}</g>`;
}

export async function openOSManager({ apiRequest, onChanged }) {
  const root = document.getElementById('modal-root');
  let catalog = await apiRequest('/api/operating-systems');
  const list = () => {
    root.innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><section class="modal"><div class="modal-head"><h2>[[operating_systems]]</h2><button type="button" class="button" data-close>[[close]]</button></div><div class="modal-body"><p>[[shared_catalog_for_all_clients_editing_a_record_updates_linked_servers_blank_dates_mean_un]]</p>${catalog.map(item => html`<div class="license-row"><div><strong>${esc(item.name)}</strong><div class="secondary-cell">${esc(item.family)} · End of life: ${esc(item.eol || 'Not published / unknown')}</div><div class="secondary-cell">${esc(item.supportNotes)}</div>${item.sourceUrl ? html`<a href="${esc(item.sourceUrl)}" target="_blank" rel="noopener noreferrer">[[lifecycle_source]]</a>` : ''}</div><button type="button" class="button" data-os-edit="${esc(item.id)}">[[edit]]</button></div>`).join('')}</div><div class="modal-foot"><button type="button" class="button primary" data-os-add>[[add_operating_system]]</button></div></section></div>`;
    root.querySelector('[data-os-add]').onclick = () => edit();
    root.querySelectorAll('[data-os-edit]').forEach(button => { button.onclick = () => edit(catalog.find(item => item.id === button.dataset.osEdit)); });
  };
  const edit = (item = {}) => {
    root.innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="os-catalog-form"><div class="modal-head"><h2>${item.id ? t("edit") : t("add")} operating system</h2><button type="button" class="button" data-close>[[close]]</button></div><div class="modal-body"><p class="form-error" role="alert" hidden></p><div class="field"><label>[[name]]<input name="name" value="${esc(item.name || '')}" maxlength="240" required></label></div><div class="field"><label>[[family]]<select name="family">${['Windows', 'Linux', 'macOS', 'Other'].map(family => html`<option ${item.family === family ? 'selected' : ''}>${family}</option>`).join('')}</select></label></div><div class="field"><label>[[end_of_life_date]]<input type="date" name="eol" value="${esc(item.eol || '')}"></label></div><div class="field"><label>[[support_notes]]<textarea name="supportNotes" maxlength="1000">${esc(item.supportNotes || '')}</textarea></label></div><div class="field"><label>[[lifecycle_source_https]]<input type="url" name="sourceUrl" maxlength="1000" value="${esc(item.sourceUrl || '')}"></label></div></div><div class="modal-foot"><button type="button" class="button" data-os-back>[[back]]</button><button type="submit" class="button primary">[[save]]</button></div></form></div>`;
    root.querySelector('[data-os-back]').onclick = list;
    root.querySelector('form').onsubmit = async event => {
      event.preventDefault();
      const form = event.currentTarget;
      const button = form.querySelector('[type="submit"]');
      button.disabled = true;
      try {
        const values = Object.fromEntries(new FormData(form));
        values.eol ||= null;
        await apiRequest('/api/operating-systems' + (item.id ? '/' + encodeURIComponent(item.id) : ''), { method: item.id ? 'PUT' : 'POST', body: JSON.stringify(values) });
        catalog = await apiRequest('/api/operating-systems');
        await onChanged(catalog);
        list();
      } catch (error) {
        const message = form.querySelector('.form-error');
        message.textContent = error.message;
        message.hidden = false;
      } finally { button.disabled = false; }
    };
  };
  list();
}
