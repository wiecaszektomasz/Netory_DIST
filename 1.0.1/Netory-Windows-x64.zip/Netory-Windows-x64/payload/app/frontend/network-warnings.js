export async function saveWithOverlapConfirmation(apiRequest, path, options, ask) {
  try {
    return await apiRequest(path, options);
  } catch (error) {
    if (error.detail?.code !== 'network_overlap') throw error;
    const lines = error.detail.networks.flatMap(network => network.overlaps.map(other =>
      `${network.name} (${network.network}) ${other.relation} ${other.name}${other.network ? ` (${other.network})` : ''}`));
    if (!ask(`Warning: overlapping network ranges:\n\n${lines.join('\n')}\n\nSave anyway?`)) {
      throw new Error('Network save cancelled.');
    }
    return apiRequest(path, {...options, headers: {...options.headers, 'X-Accept-Network-Overlap': 'true'}});
  }
}
