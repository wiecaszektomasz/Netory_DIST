import { html, t } from './i18n.js?v=20261015-map-admin2';
import { bindMapDeviceSearch } from './map-device-search.js?v=20261015-map-admin2';
import { preserveMapViewport } from './network-map-zoom.js?v=20261015-map-admin2';
import { bindConnectionHighlights } from './map-highlights.js?v=20261025-map2';
import { buildSharedELKGraph, elkRoutePoints, runSharedELKLayout } from './elk-shared-layout.js?v=20261015-map-admin2';
import { renderPowerFilter, bindPowerMap, powerDeviceAttributes } from './power-map.js?v=20261015-map-admin2';
import { renderRackView, renderRackRoomFilter, bindRackMapControls } from './racks.js?v=20261025-rooms1';
import { osIcon } from './operating-systems.js?v=20261015-map-admin2';
import { previewMapRoute, runMapRouting } from './map-routing.js?v=20261025-map1';
import { minimizeMapCrossings } from './network-map-layout.js?v=20261025-map1';

import { assetRoomId, buildRoomMap } from './room-map.js?v=20261026-room-visibility1';

export function createNetworkMapRenderer({ getData, allPortConnections, empty, esc, lagEndpointName, view, getPortSpeed, getPortType, renderAfterPaint = task => Promise.resolve().then(task), onRenderError = error => console.error(error), canEdit = () => false, getLayoutMode = () => 'elk' }) {
  let selectedSearchDeviceId = null;
  let renderGeneration = 0;
  let networkMapZoom = 100;
  let mapExpanded = false;
  let rackSize = 100;
  const selectedRoomIds = new Set();
  let mapViewMode = 'physical';
  let selectedMapRoomId = null;
  let renderedData = null;
  let physicalLayoutMode = 'elk';
  const usesELK = () => mapViewMode !== 'rack' && physicalLayoutMode === 'elk';
  let elkInput = null, elkKey = '', elkResult = null, elkTask = null, elkError = '';
  let elkObserver = null;
  let routingInput = null, routingKey = '', routingGeometryKey = '', routingResult = null;
  let routingTask = null, routingError = '', routingObserver = null, routingMounted = null;
  const selectedVlanIds = new Set();
  const selectedUpsIds = new Set();
  const portVlanIds = (device, port) => {
    const config = device?.portVlans?.[port] || device?.portVlans?.[String(port)];
    if (!config) return new Set(['1']);
    const ids = new Set((config.taggedVlans || []).map(Number).filter(Number.isInteger).map(String));
    if (config.untaggedVlan !== null && config.untaggedVlan !== undefined) ids.add(String(config.untaggedVlan));
    return ids;
  };
  const connectionHasSelectedVlan = (deviceA, portA, deviceB, portB) => {
    if (mapViewMode !== 'vlan' || !selectedVlanIds.size) return false;
    const vlansA = portVlanIds(deviceA, portA);
    const vlansB = portVlanIds(deviceB, portB);
    return [...selectedVlanIds].some(id => vlansA.has(id) && vlansB.has(id));
  };
  const selectedManagementVlan = device => {
    const vlanId = Number(String(device?.vlan ?? '').trim());
    return mapViewMode === 'vlan' && Number.isInteger(vlanId) &&
      vlanId > 0 && selectedVlanIds.has(String(vlanId));
  };
  const parseSpeedGbps = speed => {
    const match = String(speed || '').trim().toLowerCase().replace(/\s+/g, '')
      .match(/^(\d+(?:[.,]\d+)?)(tbps|tbit\/s|tb\/s|gbps|gbit\/s|gb\/s|mbps|mbit\/s|mb\/s|kbps|kbit\/s|kb\/s|bps|bit\/s|b\/s)$/);
    if (!match) return null;
    const value = Number(match[1].replace(',', '.'));
    const multiplier = match[2].startsWith('t') ? 1000
      : match[2].startsWith('g') ? 1
        : match[2].startsWith('m') ? 0.001
          : match[2].startsWith('k') ? 0.000001 : 0.000000001;
    return value * multiplier;
  };
  const speedLegend = [
    { gbps: 0.1, label: t("100_mb"), className: 'map-link-speed-100m' },
    { gbps: 1, label: t("1_gb"), className: 'map-link-speed-1g' },
    { gbps: 2.5, label: t("2_5_gb"), className: 'map-link-speed-2-5g' },
    { gbps: 5, label: t("5_gb"), className: 'map-link-speed-5g' },
    { gbps: 10, label: t("10_gb"), className: 'map-link-speed-10g' },
    { gbps: 25, label: t("25_gb"), className: 'map-link-speed-25g' },
    { gbps: 40, label: t("40_gb"), className: 'map-link-speed-40g' },
    { gbps: 50, label: t("50_gb"), className: 'map-link-speed-50g' },
    { gbps: 100, label: t("100_gb"), className: 'map-link-speed-100g' },
    { gbps: 200, label: t("200_gb"), className: 'map-link-speed-200g' },
    { gbps: 400, label: t("400_gb"), className: 'map-link-speed-400g' },
  ];
  const speedClass = speedGbps => speedLegend.find(item => item.gbps === speedGbps)?.className || 'map-link-speed-unknown';
  function deviceGlyph(type, x, y) {
    if (type === 'Switch') return html`<g class="map-device-glyph" aria-hidden="true"><rect class="map-device-glyph-fill" x="${x}" y="${y + 2}" width="12" height="4" rx=".8"></rect><path d="M ${x + 2} ${y + 3}v2 M ${x + 4.5} ${y + 3}v2 M ${x + 7} ${y + 3}v2 M ${x + 9.5} ${y + 3}v2"></path></g>`;
    if (type === 'Router') return html`<g class="map-device-glyph" aria-hidden="true"><path d="M ${x + 4.5} ${y}L ${x + 9} ${y + 4.5}L ${x + 4.5} ${y + 9}L ${x} ${y + 4.5}Z"></path><circle class="map-device-glyph-fill" cx="${x + 4.5}" cy="${y + 4.5}" r="1.1"></circle></g>`;
    if (type === 'Firewall / UTM') return html`<g class="map-device-glyph" aria-hidden="true"><path class="map-device-glyph-fill" d="M ${x + 4.5} ${y}L ${x + 8.5} ${y + 1.5}V ${y + 5}Q ${x + 7} ${y + 8} ${x + 4.5} ${y + 9}Q ${x + 2} ${y + 8} ${x + .5} ${y + 5}V ${y + 1.5}Z"></path><path d="M ${x + 2.5} ${y + 4.5}l1.3 1.3l2.7 -3"></path></g>`;
    if (type === 'Access point' || type === 'Wi-Fi controller') return html`<g class="map-device-glyph" aria-hidden="true"><circle class="map-device-glyph-fill" cx="${x + 4.5}" cy="${y + 6}" r="1"></circle><path d="M ${x + 2.5} ${y + 4.5}Q ${x + 4.5} ${y + 2.5} ${x + 6.5} ${y + 4.5} M ${x + 1} ${y + 3}Q ${x + 4.5} ${y - .5} ${x + 8} ${y + 3}"></path></g>`;
    if (type === 'Physical server') return html`<g class="map-device-glyph" aria-hidden="true"><rect class="map-device-glyph-fill" x="${x}" y="${y - 2}" width="11" height="16" rx="1"></rect><path d="M ${x + .5} ${y + 3}h10 M ${x + .5} ${y + 8}h10 M ${x + .5} ${y + 13}h10"></path><circle cx="${x + 2}" cy="${y + 1}" r=".8"></circle><circle cx="${x + 2}" cy="${y + 6}" r=".8"></circle><circle cx="${x + 2}" cy="${y + 11}" r=".8"></circle><path d="M ${x + 4} ${y + 1}h5 M ${x + 4} ${y + 6}h5 M ${x + 4} ${y + 11}h5"></path></g>`;
    if (type === 'Virtual server') return html`<g class="map-device-glyph" aria-hidden="true"><rect x="${x + .5}" y="${y + 1.5}" width="6" height="6" rx=".8"></rect><rect class="map-device-glyph-fill" x="${x + 2.5}" y="${y + .5}" width="6" height="6" rx=".8"></rect></g>`;
    if (type === 'Storage') return html`<g class="map-device-glyph" aria-hidden="true"><path class="map-device-glyph-fill" d="M ${x + .5} ${y + 2}C ${x + .5} ${y} ${x + 8.5} ${y} ${x + 8.5} ${y + 2}V ${y + 7}C ${x + 8.5} ${y + 9} ${x + .5} ${y + 9} ${x + .5} ${y + 7}Z"></path><path d="M ${x + .5} ${y + 2}C ${x + .5} ${y + 4} ${x + 8.5} ${y + 4} ${x + 8.5} ${y + 2}M ${x + .5} ${y + 5}C ${x + .5} ${y + 7} ${x + 8.5} ${y + 7} ${x + 8.5} ${y + 5}"></path></g>`;
    return html`<g class="map-device-glyph" aria-hidden="true"><path class="map-device-glyph-fill" d="M ${x + 4.5} ${y}L ${x + 9} ${y + 4.5}L ${x + 4.5} ${y + 9}L ${x} ${y + 4.5}Z"></path></g>`;
  }
  function renderNetworkMap() {
    physicalLayoutMode = getLayoutMode() === 'physical' ? 'physical' : 'elk';
    const fullData = getData();
    if (selectedMapRoomId !== null && selectedMapRoomId !== '' && !(fullData.rooms || []).some(room => room.id === selectedMapRoomId)) selectedMapRoomId = null;
    const roomMap = mapViewMode === 'room' && selectedMapRoomId !== null ? buildRoomMap(fullData, selectedMapRoomId, allPortConnections()) : null;
    const data = roomMap?.data || fullData;
    renderedData = data;
    const deviceSearch = html`<div class="map-device-search"><label for="map-device-search-input">[[find_device]]</label><input id="map-device-search-input" type="search" data-map-search placeholder="[[device_name_type_or_ip]]" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="map-device-search-results"><div id="map-device-search-results" class="map-device-search-results" data-map-search-results role="listbox" aria-label="[[matching_devices]]" hidden></div><span class="map-search-status" data-map-search-status role="status"></span></div>`;
    const viewButtons = html`<div class="map-view-controls" role="group" aria-label="[[network_map_view]]">${[['physical','Physical View'],['vlan','VLAN view'],['room','Room View'],['rack','Rack View'],['power','Power Supply View']].map(([mode,label]) => html`<button class="button ${(mapViewMode === mode || mode === 'physical' && mapViewMode === 'elk') ? 'active' : ''}" type="button" data-map-view-mode="${mode}" aria-pressed="${mapViewMode === mode || mode === 'physical' && mapViewMode === 'elk'}">${t(label)}</button>`).join('')}</div>`;
    const roomFilter = mapViewMode === 'room' ? html`<label>[[room]] <select data-room-map-select><option value="__choose__" ${selectedMapRoomId === null ? 'selected' : ''}>[[choose_room]]</option><option value="" ${selectedMapRoomId === '' ? 'selected' : ''}>[[no_room_assigned]]</option>${(fullData.rooms || []).map(room => html`<option value="${esc(room.id)}" ${selectedMapRoomId === room.id ? 'selected' : ''}>${esc(room.name)}</option>`).join('')}</select></label>` : '';
    if (mapViewMode === 'room' && selectedMapRoomId === null) {
      elkInput = null; routingInput = null;
      return html`${viewButtons}${roomFilter}<div class="network-map-scroll"><section class="panel"><p>[[room_map_choose_hint]]</p></section></div>`;
    }
    const powerFilter = mapViewMode === 'power' ? renderPowerFilter(data, selectedUpsIds) : '';
    const powerAttributes = device => mapViewMode === 'power' ? powerDeviceAttributes(device, selectedUpsIds) : '';
    const availableRooms = new Set(['', ...(data.rooms || []).map(room => room.id)]);
    for (const id of selectedRoomIds) if (!availableRooms.has(id)) selectedRoomIds.delete(id);
    if (mapViewMode === 'rack') return html`<div class="network-map-workspace ${mapExpanded ? 'is-expanded' : ''}"><div class="list-toolbar network-map-toolbar">${viewButtons}${deviceSearch}<div class="map-tools"><div class="map-zoom-controls" role="group" aria-label="[[rack_size]]"><button class="button icon-only" type="button" data-rack-size-step="-10" aria-label="[[reduce_cabinet_size]]">−</button><input type="range" min="25" max="200" step="5" value="${rackSize}" data-rack-size aria-label="[[cabinet_size]]"><span class="map-zoom-value" data-rack-size-value>${rackSize}%</span><button class="button icon-only" type="button" data-rack-size-step="10" aria-label="[[increase_cabinet_size]]">+</button></div><button class="button" type="button" data-rack-fit>[[fit_to_screen]]</button><button class="button map-magnify-button" type="button" data-rack-magnifier aria-pressed="false">[[magnifier]]</button><button class="button" type="button" data-map-expand aria-expanded="${mapExpanded}">${mapExpanded ? t("close_large_map") : t("expand_map")}</button></div></div><section class="panel">${renderRackRoomFilter(data.rooms || [], [...selectedRoomIds])}<div class="network-map-scroll">${renderRackView(data, canEdit(), {compact: true, showRoomFilter: false, roomIds: [...selectedRoomIds], size: rackSize})}</div></section></div>`;
    const vlanNamesById = new Map();
    (data.vlans || []).forEach(vlan => {
      const value = Number(vlan.idValue);
      if (!Number.isInteger(value)) return;
      const id = String(value);
      const names = vlanNamesById.get(id) || new Set();
      if (vlan.name) names.add(vlan.name);
      vlanNamesById.set(id, names);
    });
    const vlanOptions = [...vlanNamesById.entries()]
      .map(([id, names]) => ({ id, label: `${id} — ${[...names].join(', ') || 'VLAN'}` }))
      .sort((first, second) => Number(first.id) - Number(second.id));
    for (const id of selectedVlanIds) {
      if (!vlanNamesById.has(id)) selectedVlanIds.delete(id);
    }
    const assetsById = new Map(data.assets.map(asset => [asset.id, asset]));
    const physicalHostsById = new Map(data.assets
      .filter(asset => asset.type === 'Physical server')
      .map(asset => [asset.id, asset]));
    const stacks = [
      ...(data.stacks || []),
      ...(data.clusters || []).map(cluster => ({ ...cluster, deviceType: 'Physical server', isCluster: true }))
    ];
    const stackIdByAsset = new Map();
    const stackPortInfo = new Map();
    const stackAssets = stacks.map(stack => {
      const members = (stack.memberAssetIds || []).map(id => assetsById.get(id)).filter(Boolean);
      const id = `${stack.isCluster ? 'cluster' : 'stack'}-${stack.id}`;
      let port = 0;
      members.forEach(member => {
        stackIdByAsset.set(member.id, id);
        for (let memberPort = 1; memberPort <= Number(member.portCount || 0); memberPort += 1) {
          port += 1;
          stackPortInfo.set(`${id}:${port}`, { member, memberPort });
        }
      });
      return {
        id, name: stack.name, type: stack.deviceType, portCount: port, isStack: true, stackMembers: members,
        stackId: stack.id, isCluster: Boolean(stack.isCluster), internetPorts: [],
        showOnMap: Boolean(stack.isCluster && stack.showOnMap !== false) || members.some(member => member.showOnMap)
      };
    });
    const mapAssetsById = new Map(assetsById);
    stackAssets.forEach(stack => {
      mapAssetsById.set(stack.id, stack);
      if (stack.isCluster) physicalHostsById.set(stack.id, stack);
    });
    const vmHostId = vm => vm.hypervisorClusterId
      ? `cluster-${vm.hypervisorClusterId}` : stackIdByAsset.get(vm.hypervisorId) || vm.hypervisorId;
    const mapEndpoint = (assetId, port) => {
      const stackId = stackIdByAsset.get(assetId);
      if (!stackId) return { deviceId: assetId, port: Number(port) };
      const stack = mapAssetsById.get(stackId);
      let firstPort = 0;
      for (const member of stack.stackMembers) {
        const count = Number(member.portCount || 0);
        if (member.id === assetId) return { deviceId: stackId, port: firstPort + Number(port) };
        firstPort += count;
      }
      return { deviceId: assetId, port: Number(port) };
    };
    const physicalConnections = allPortConnections().filter(link => {
      const first = assetsById.get(link.deviceAId);
      const second = assetsById.get(link.deviceBId);
      return first && second && Number.isInteger(Number(link.portA)) && Number.isInteger(Number(link.portB)) &&
        Number(link.portA) > 0 && Number(link.portA) <= Number(first.portCount) &&
        Number(link.portB) > 0 && Number(link.portB) <= Number(second.portCount);
    });
    const lagSpeedGroups = new Map();
    physicalConnections.filter(link => link.lagId).forEach(link => {
      const firstSpeed = getPortSpeed?.(assetsById.get(link.deviceAId), link.portA) || '1 Gbps';
      const secondSpeed = getPortSpeed?.(assetsById.get(link.deviceBId), link.portB) || '1 Gbps';
      const firstGbps = parseSpeedGbps(firstSpeed);
      const secondGbps = parseSpeedGbps(secondSpeed);
      const known = Number.isFinite(firstGbps) && Number.isFinite(secondGbps);
      const gbps = known ? Math.min(firstGbps, secondGbps) : null;
      const key = known ? String(gbps) : `unknown:${firstSpeed}/${secondSpeed}`;
      const groups = lagSpeedGroups.get(link.lagId) || new Map();
      const label = known
        ? gbps >= 1 ? `${gbps} Gb/s` : `${Number((gbps * 1000).toPrecision(12))} Mb/s`
        : `unknown (${firstSpeed} / ${secondSpeed})`;
      const group = groups.get(key) || { count: 0, label };
      group.count += 1;
      groups.set(key, group);
      lagSpeedGroups.set(link.lagId, groups);
    });
    const lagSpeedSummary = lagId => [...(lagSpeedGroups.get(lagId)?.values() || [])]
      .map(group => `${group.count} × ${group.label}`).join(' + ');
    const validConnections = physicalConnections.map(link => {
      const first = mapEndpoint(link.deviceAId, link.portA);
      const second = mapEndpoint(link.deviceBId, link.portB);
      return {
        ...link, deviceAId: first.deviceId, portA: first.port,
        deviceBId: second.deviceId, portB: second.port,
        physicalDeviceAId: link.deviceAId, physicalPortA: Number(link.portA),
        physicalDeviceBId: link.deviceBId, physicalPortB: Number(link.portB)
      };
    });
    // Stack members share a layout device, but retain distinct mapped ports.
    // Keep their physical links for routing and synchronized port highlighting.
    const internetEndpoints = data.assets.flatMap(device =>
      (Array.isArray(device.internetPorts) ? device.internetPorts : [])
        .map(Number)
        .filter(port => Number.isInteger(port) && port > 0 && port <= Number(device.portCount))
        .map(port => {
          const endpoint = mapEndpoint(device.id, port);
          return {
            ...endpoint, physicalDeviceId: device.id, physicalPort: port,
            linkId: `internet-${endpoint.deviceId}-${endpoint.port}`
          };
        })
    );
    const connectedIds = new Set(validConnections.flatMap(link => [link.deviceAId, link.deviceBId]));
    const connectedInternetIds = new Set(internetEndpoints.map(endpoint => endpoint.deviceId));
    const connectedVirtualHostIds = new Set(data.assets
      .filter(asset => asset.type === 'Virtual server' && connectedIds.has(asset.id))
      .map(vmHostId));
    const visibleHostIds = new Set([...physicalHostsById.values()]
      .filter(host => host.showOnMap || connectedIds.has(host.id) ||
        connectedInternetIds.has(host.id) || connectedVirtualHostIds.has(host.id))
      .map(host => host.id));
    const virtualMachinesByHost = new Map();
    const virtualMachineHostById = new Map();
    data.assets.filter(asset =>
      asset.type === 'Virtual server' &&
      physicalHostsById.has(vmHostId(asset)) && visibleHostIds.has(vmHostId(asset)) &&
      (asset.showOnMap !== false || connectedIds.has(asset.id))
    ).forEach(vm => {
      const hostId = vmHostId(vm);
      const virtualMachines = virtualMachinesByHost.get(hostId) || [];
      virtualMachines.push(vm);
      virtualMachinesByHost.set(hostId, virtualMachines);
      virtualMachineHostById.set(vm.id, hostId);
    });
    const stackedIds = new Set(stackIdByAsset.keys());
    const virtualMachineHostIds = new Set(virtualMachinesByHost.keys());
    const devices = [
      ...data.assets.filter(asset =>
        !stackedIds.has(asset.id) &&
        (asset.type !== 'Virtual server' || !physicalHostsById.has(vmHostId(asset)))
      ),
      ...stackAssets
    ].filter(asset => asset.showOnMap || connectedIds.has(asset.id) ||
      connectedInternetIds.has(asset.id) ||
      virtualMachineHostIds.has(asset.id));
    if (!devices.length) return html`${viewButtons}${deviceSearch}${roomFilter}${powerFilter}<div class="network-map-scroll"><section class="panel"><div class="empty-state"><strong>[[no_devices_are_added_to_the_network_map_yet]]</strong>[[connect_device_ports_or_enable_add_to_map_in_a_device_record_to_show_it_here]]</div></section></div>`;

    const portPitch = 5.5;
    const portWidth = 4.5;
    const portHeight = 4.5;
    const cardHeight = 44;
    const stackContentTop = 12;
    const stackMemberGap = 6;
    const stackPadding = 8;
    const portRows = device => Number(device.portCount) > 8 ? 2 : 1;
    const stackMemberColumns = member => Number(member.portCount) <= 8
      ? Number(member.portCount)
      : Math.ceil(Number(member.portCount || 0) / portRows(member));
    const stackMemberLayouts = new Map();
    const stackHeights = new Map();
    const deviceContentWidths = new Map();
    const deviceHeights = new Map();
    const virtualMachineLayouts = new Map();
    const portsPerRow = new Map(devices.map(device => {
      const count = Number(device.portCount) || 0;
      const singleRowDevice = count <= 8;
      const columns = singleRowDevice ? count : Math.ceil(count / portRows(device));
      return [device.id, Math.max(1, columns)];
    }));
    const portGridPosition = (device, index) => {
      if (device.isStack) {
        const portInfo = stackPortInfo.get(`${device.id}:${index + 1}`);
        const member = portInfo?.member;
        const memberPort = Number(portInfo?.memberPort || index + 1);
        const columns = member ? stackMemberColumns(member) : portsPerRow.get(device.id);
        if (member && Number(member.portCount) > 8) {
          return { row: (memberPort - 1) % portRows(member), column: Math.floor((memberPort - 1) / portRows(member)) };
        }
        return { row: Math.floor((memberPort - 1) / columns), column: (memberPort - 1) % columns };
      }
      if (Number(device.portCount) > 8) return { row: index % portRows(device), column: Math.floor(index / portRows(device)) };
      const columns = portsPerRow.get(device.id);
      return { row: Math.floor(index / columns), column: index % columns };
    };
    const mapTypeColors = { 'Patch panel': '#59636e', Switch: '#3f8198', Router: '#3f7f68', 'Firewall / UTM': '#c36a44', 'Wi-Fi controller': '#746da2', 'Access point': '#5588ad', 'Physical server': '#5e7187', 'Virtual server': '#498b8c', Storage: '#b1883f', 'Network device': '#7c8667', Other: '#8b7658' };
    const mapManufacturer = device => device.manufacturer || '—';
    const deviceWidths = new Map(devices.map(device => {
      if (device.isStack) {
        let offset = 0;
        let maxMemberWidth = 64;
        const layouts = device.stackMembers.map(member => {
          const columns = Math.max(1, stackMemberColumns(member));
          const typeLine = mapManufacturer(member);
          const nameWidth = Math.min(member.name.length, 24) * 3.9 + 20;
          const metadataWidth = typeLine.length * 3 + 20;
          const width = Math.ceil(Math.max(64, 20 + columns * portPitch, nameWidth, metadataWidth));
          const layout = { member, offset, width };
          maxMemberWidth = Math.max(maxMemberWidth, width);
          offset += cardHeight + stackMemberGap;
          return layout;
        });
        if (layouts.length) offset -= stackMemberGap;
        stackMemberLayouts.set(device.id, layouts);
        stackHeights.set(device.id, Math.max(
          60,
          stackContentTop + offset + stackPadding
        ));
        return [device.id, Math.max(stackPadding * 2 + maxMemberWidth, Math.min(device.name.length, 24) * 3.9 + 20)];
      }
      const count = Number(device.portCount) || 0;
      const typeLine = mapManufacturer(device);
      const nameWidth = Math.min(device.name.length, 24) * 3.9 + 20;
      const metadataWidth = typeLine.length * 3 + 20;
      const contentWidth = Math.ceil(Math.max(64, 20 + portsPerRow.get(device.id) * portPitch, nameWidth, metadataWidth));
      deviceContentWidths.set(device.id, contentWidth);
      const virtualMachines = virtualMachinesByHost.get(device.id) || [];
      if (!virtualMachines.length) return [device.id, contentWidth];
      const columns = Math.ceil(virtualMachines.length / 10);
      const rows = Math.min(10, virtualMachines.length);
      const panelWidth = columns * 50 + (columns - 1) * 4 + 8;
      const panelHeight = 11 + rows * 14 + (rows - 1) * 3 + 4;
      virtualMachineLayouts.set(device.id, { virtualMachines, columns, rows, panelWidth, panelHeight });
      deviceHeights.set(device.id, Math.max(cardHeight, panelHeight));
      return [device.id, contentWidth + 6 + panelWidth];
    }));
    // Cluster members retain their physical ports; VMs share a panel inside the group.
    devices.filter(device => device.isCluster).forEach(device => {
      const contentWidth = deviceWidths.get(device.id);
      deviceContentWidths.set(device.id, contentWidth);
      const virtualMachines = virtualMachinesByHost.get(device.id) || [];
      if (!virtualMachines.length) return;
      const columns = Math.ceil(virtualMachines.length / 10);
      const rows = Math.min(10, virtualMachines.length);
      const panelWidth = columns * 50 + (columns - 1) * 4 + 8;
      const panelHeight = 11 + rows * 14 + (rows - 1) * 3 + 4;
      virtualMachineLayouts.set(device.id, { virtualMachines, columns, rows, panelWidth, panelHeight });
      const height = Math.max(stackHeights.get(device.id), panelHeight + stackContentTop + stackPadding);
      stackHeights.set(device.id, height);
      deviceHeights.set(device.id, height);
      deviceWidths.set(device.id, contentWidth + 6 + panelWidth + stackPadding);
    });
    const connectedPorts = new Map(devices.map(device => [device.id, []]));
    const adjacency = new Map(devices.map(device => [device.id, new Set()]));
    const layoutDeviceId = deviceId => virtualMachineHostById.get(deviceId) || deviceId;
    validConnections.forEach(link => {
      const deviceAId = layoutDeviceId(link.deviceAId);
      const deviceBId = layoutDeviceId(link.deviceBId);
      connectedPorts.get(deviceAId)?.push(Number(link.portA));
      connectedPorts.get(deviceBId)?.push(Number(link.portB));
      if (deviceAId !== deviceBId) {
        adjacency.get(deviceAId)?.add(deviceBId);
        adjacency.get(deviceBId)?.add(deviceAId);
      }
    });
    const typePriority = { Router: 100, 'Firewall / UTM': 100, 'Network device': 90, Switch: 80, 'Wi-Fi controller': 70, 'Access point': 60, 'Physical server': 50, Storage: 40, 'Virtual server': 30, Other: 20 };
    const deviceScore = deviceId => (typePriority[mapAssetsById.get(deviceId)?.type] || 10) * 100 + (adjacency.get(deviceId)?.size || 0);
    const unseen = new Set(devices.map(device => device.id));
    const components = [];
    while (unseen.size) {
      const seed = unseen.values().next().value;
      const members = new Set([seed]);
      const pending = [seed];
      while (pending.length) {
        const current = pending.pop();
        for (const neighbor of adjacency.get(current) || []) {
          if (!members.has(neighbor)) { members.add(neighbor); pending.push(neighbor); }
        }
      }
      members.forEach(id => unseen.delete(id));
      const root = [...members].sort((left, right) => deviceScore(right) - deviceScore(left) || mapAssetsById.get(left).name.localeCompare(mapAssetsById.get(right).name))[0];
      components.push({ root, members, score: deviceScore(root) });
    }
    components.sort((left, right) => right.score - left.score || mapAssetsById.get(left.root).name.localeCompare(mapAssetsById.get(right.root).name));

    const depthByDevice = new Map();
    const childrenByDevice = new Map(devices.map(device => [device.id, []]));
    const visited = new Set();
    components.forEach(component => {
      const queue = [component.root];
      visited.add(component.root);
      depthByDevice.set(component.root, 0);
      while (queue.length) {
        const current = queue.shift();
        const neighbors = [...(adjacency.get(current) || [])].filter(id => component.members.has(id) && !visited.has(id));
        neighbors.sort((left, right) => deviceScore(right) - deviceScore(left) || mapAssetsById.get(left).name.localeCompare(mapAssetsById.get(right).name));
        neighbors.forEach(neighbor => {
          visited.add(neighbor);
          depthByDevice.set(neighbor, depthByDevice.get(current) + 1);
          childrenByDevice.get(current).push(neighbor);
          queue.push(neighbor);
        });
      }
    });
    const additionalGatewayIds = components.flatMap(component =>
      [...component.members].filter(deviceId => {
        if (deviceId === component.root) return false;
        const type = mapAssetsById.get(deviceId)?.type;
        return type === 'Router' || type === 'Firewall / UTM';
      })
    );
    devices.filter(device =>
      device.isStack && (device.type === 'Router' || device.type === 'Firewall / UTM')
    ).forEach(device => {
      const component = components.find(item => item.members.has(device.id));
      if (component?.root !== device.id && !additionalGatewayIds.includes(device.id)) {
        additionalGatewayIds.push(device.id);
      }
    });
    additionalGatewayIds.forEach(deviceId => depthByDevice.set(deviceId, 0));

    const treeGap = 14;
    const subtreeWidths = new Map();
    const childrenInLayout = new Map();
    const upstreamPortOrder = (parentId, childId) => {
      const ports = validConnections.flatMap(link => {
        const first = layoutDeviceId(link.deviceAId);
        const second = layoutDeviceId(link.deviceBId);
        if (first === parentId && second === childId) return [Number(link.portA)];
        if (second === parentId && first === childId) return [Number(link.portB)];
        return [];
      });
      const parent = mapAssetsById.get(parentId);
      const columns = ports.map(port => portGridPosition(parent, port - 1).column);
      return columns.length ? columns.reduce((sum, column) => sum + column, 0) / columns.length : Infinity;
    };
    function measureSubtree(deviceId) {
      const children = childrenByDevice.get(deviceId).map(id => ({ id, width: measureSubtree(id) }));
      children.sort((left, right) => upstreamPortOrder(deviceId, left.id) - upstreamPortOrder(deviceId, right.id) ||
        right.width - left.width || mapAssetsById.get(left.id).name.localeCompare(mapAssetsById.get(right.id).name));
      childrenInLayout.set(deviceId, children.map(child => child.id));
      const childrenWidth = children.reduce((sum, child) => sum + child.width, 0) + Math.max(0, children.length - 1) * treeGap;
      const width = Math.max(deviceWidths.get(deviceId), childrenWidth);
      subtreeWidths.set(deviceId, width);
      return width;
    }
    components.forEach(component => measureSubtree(component.root));
    const relativeX = new Map();
    const subtreeLefts = new Map();
    function placeSubtree(deviceId, left) {
      const width = subtreeWidths.get(deviceId);
      subtreeLefts.set(deviceId, left + 30);
      relativeX.set(deviceId, left + (width - deviceWidths.get(deviceId)) / 2);
      const children = childrenInLayout.get(deviceId);
      const childrenWidth = children.reduce((sum, id) => sum + subtreeWidths.get(id), 0) + Math.max(0, children.length - 1) * treeGap;
      let childLeft = left + (width - childrenWidth) / 2;
      children.forEach(childId => {
        placeSubtree(childId, childLeft);
        childLeft += subtreeWidths.get(childId) + treeGap;
      });
    }
    let forestWidth = 0;
    components.forEach((component, index) => {
      if (index) forestWidth += 72;
      component.left = forestWidth;
      placeSubtree(component.root, component.left);
      forestWidth += subtreeWidths.get(component.root);
    });
    additionalGatewayIds.forEach(deviceId => {
      relativeX.set(deviceId, forestWidth);
      forestWidth += deviceWidths.get(deviceId) + treeGap;
    });

    const rowHeights = [];
    const rowGutters = [];
    const rowCount = Math.max(...depthByDevice.values()) + 1;
    devices.forEach((device, index) => {
      const row = depthByDevice.get(device.id);
      rowHeights[row] = Math.max(
        rowHeights[row] || 0,
        stackHeights.get(device.id) || deviceHeights.get(device.id) || cardHeight
      );
      const internetCount = internetEndpoints.filter(endpoint => endpoint.deviceId === device.id).length;
      const connectionCount = connectedPorts.get(device.id).length || 0;
      rowGutters[row] = Math.max(rowGutters[row] || 22, 22 + (connectionCount + internetCount) * 6);
    });
    const rowOffsets = [30];
    if (internetEndpoints.length) rowOffsets[0] = 66 + internetEndpoints.length * 6;
    for (let row = 1; row < rowHeights.length; row += 1) rowOffsets[row] = rowOffsets[row - 1] + rowHeights[row - 1] + rowGutters[row - 1];
    const positions = new Map(devices.map((device, index) => [device.id, {
      x: 30 + relativeX.get(device.id),
      y: rowOffsets[depthByDevice.get(device.id)]
    }]));
    let svgWidth = 30 + forestWidth + 30;
    const gridBottom = rowOffsets[rowOffsets.length - 1] + rowHeights[rowHeights.length - 1];
    let svgHeight = gridBottom + 30;
    const portX = (deviceId, row, column, portNumber) => {
      const device = mapAssetsById.get(deviceId);
      const point = positions.get(deviceId);
      if (device.isStack) {
        const portInfo = stackPortInfo.get(`${deviceId}:${portNumber}`);
        const member = portInfo?.member;
        const twoPortRows = member && Number(member.portCount) > 8;
        return point.x + stackPadding + 6 + column * portPitch +
          (row && !twoPortRows ? portPitch / 2 : 0);
      }
      if (device.type === 'Access point') {
        const count = Number(device.portCount) || 0;
        const rowPorts = Math.ceil(count / 2);
        const portsInRow = row === 0 ? rowPorts : count - rowPorts;
        return point.x + deviceWidths.get(deviceId) / 2 -
          ((portsInRow - 1) * portPitch + portWidth) / 2 + column * portPitch;
      }
      return point.x + 6 + column * portPitch;
    };
    const portPoint = (deviceId, portNumber) => {
      const point = positions.get(deviceId);
      const index = Number(portNumber) - 1;
      const device = mapAssetsById.get(deviceId);
      const { row, column } = portGridPosition(device, index);
      const memberId = stackPortInfo.get(`${deviceId}:${Number(portNumber)}`)?.member?.id;
      const memberOffset = stackMemberLayouts.get(deviceId)?.find(item => item.member.id === memberId)?.offset || 0;
      return {
        x: portX(deviceId, row, column, Number(portNumber)) + portWidth / 2,
        y: point.y + (device.isStack ? stackContentTop + memberOffset : 0) + 23 + row * 7 + portHeight
      };
    };
    const connectionPoint = (deviceId, portNumber) => {
      const hostId = virtualMachineHostById.get(deviceId);
      if (!hostId) return portPoint(deviceId, portNumber);
      const hostPosition = positions.get(hostId);
      const layout = virtualMachineLayouts.get(hostId);
      const index = layout.virtualMachines.findIndex(vm => vm.id === deviceId);
      const column = Math.floor(index / 10);
      const row = index % 10;
      const panelX = hostPosition.x + deviceContentWidths.get(hostId) + 6;
      const panelY = hostPosition.y + (deviceHeights.get(hostId) - layout.panelHeight) / 2;
      const cardX = panelX + 4 + column * 54;
      const cardY = panelY + 11 + row * 17;
      return { x: cardX + 50, y: cardY + 7 };
    };
    const movableChildren = new Map([...childrenInLayout].map(([id, children]) => [id,
      children.filter(childId => depthByDevice.get(childId) > depthByDevice.get(id))
    ]));
    const parentByDevice = new Map([...movableChildren].flatMap(([parentId, children]) =>
      children.map(childId => [childId, parentId])
    ));
    minimizeMapCrossings({
      positions, widths: deviceWidths, depths: depthByDevice,
      siblingGroups: [...movableChildren.values()], children: movableChildren,
      blockWidths: subtreeWidths, blockLefts: subtreeLefts,
      // Keep an unambiguous upstream port order; geometric scoring alone can
      // mistake lines through a tall cluster for a reason to reverse its siblings.
      canSwap: (leftId, rightId) => upstreamPortOrder(parentByDevice.get(leftId), leftId) >=
        upstreamPortOrder(parentByDevice.get(rightId), rightId),
      links: validConnections.filter(link =>
        positions.has(layoutDeviceId(link.deviceAId)) && positions.has(layoutDeviceId(link.deviceBId))
      ),
      endpointPoint: connectionPoint
    });
    // Keep redundant sibling cores together above their shared downstream links.
    for (const [parentId, children] of movableChildren) {
      if (children.length !== 2 || !children.every(id => mapAssetsById.get(id)?.type === 'Switch')) continue;
      const [leftId, rightId] = children;
      const shared = [...adjacency.get(leftId)].filter(id => id !== parentId && adjacency.get(rightId).has(id));
      if (shared.length < 2) continue;
      const center = positions.get(parentId).x + deviceWidths.get(parentId) / 2;
      const gap = 28;
      const total = deviceWidths.get(leftId) + deviceWidths.get(rightId) + gap;
      positions.get(leftId).x = center - total / 2;
      positions.get(rightId).x = center - total / 2 + deviceWidths.get(leftId) + gap;
    }
    if (usesELK()) {
      elkInput = buildSharedELKGraph(devices, deviceWidths, new Map(devices.map(device => [device.id, deviceHeights.get(device.id) || stackHeights.get(device.id) || cardHeight])), positions, validConnections, layoutDeviceId, connectionPoint, depthByDevice);
      const key = JSON.stringify(elkInput);
      if (key !== elkKey) {
        elkTask?.cancel(); elkTask = null; elkKey = key; elkResult = null; elkError = '';
      }
      if (elkResult) {
        for (const node of elkResult.children) positions.set(node.deviceId, {x:node.x,y:node.y});
        svgWidth = elkResult.width; svgHeight = elkResult.height;
      }
    }
    const connectionKey = link => link.lagId || link.id || `${link.deviceAId}:${link.portA}-${link.deviceBId}:${link.portB}`;
    const internetNodeWidth = Math.max(60, internetEndpoints.length * 6 + 12);
    const internetNodeHeight = 28;
    const internetNodeX = svgWidth / 2;
    const internetNodeY = 12;
    const portClearance = 2.5;
    const obstacleCandidates = devices.flatMap(device => {
      const position = positions.get(device.id);
      if (device.isStack) {
        const bounds = (stackMemberLayouts.get(device.id) || []).map(({ offset, width }) => ({
          left: position.x + stackPadding,
          right: position.x + stackPadding + width,
          top: position.y + stackContentTop + offset - 1,
          bottom: position.y + stackContentTop + offset - 1 + cardHeight
        }));
        const vmLayout = virtualMachineLayouts.get(device.id);
        if (vmLayout) {
          const panelX = position.x + deviceContentWidths.get(device.id) + 6;
          const panelY = position.y + (deviceHeights.get(device.id) - vmLayout.panelHeight) / 2;
          bounds.push({ left: panelX, right: panelX + vmLayout.panelWidth,
            top: panelY, bottom: panelY + vmLayout.panelHeight });
        }
        return bounds;
      }
      const contentWidth = deviceContentWidths.get(device.id) || deviceWidths.get(device.id);
      const height = deviceHeights.get(device.id) || cardHeight;
      const vmLayout = virtualMachineLayouts.get(device.id);
      const bounds = [{
        left: position.x,
        right: position.x + (vmLayout ? contentWidth : deviceWidths.get(device.id)),
        top: position.y,
        bottom: position.y + height
      }];
      if (vmLayout) {
        const panelX = position.x + contentWidth + 6;
        const panelY = position.y + (height - vmLayout.panelHeight) / 2;
        bounds.push({
          left: panelX,
          right: panelX + vmLayout.panelWidth,
          top: panelY,
          bottom: panelY + vmLayout.panelHeight
        });
      }
      return bounds;
    });
    const portObstacles = devices.flatMap(device => {
      const position = positions.get(device.id);
      const count = Number(device.portCount) || 0;
      return Array.from({ length: count }, (_, index) => {
        const portNumber = index + 1;
        const { row, column } = portGridPosition(device, index);
        const portInfo = stackPortInfo.get(`${device.id}:${portNumber}`);
        const memberLayout = device.isStack
          ? stackMemberLayouts.get(device.id)?.find(item => item.member.id === portInfo?.member?.id)
          : null;
        const x = portX(device.id, row, column, portNumber);
        const y = position.y + (device.isStack ? stackContentTop + (memberLayout?.offset || 0) : 0) + 23 + row * 7;
        return {
          left: x - portClearance,
          right: x + portWidth + portClearance,
          top: y - portClearance,
          bottom: y + portHeight + portClearance,
          key: `${device.id}:${portNumber}`
        };
      });
    });
    const routingGeometry = {obstacleCandidates, portObstacles,
      internetObstacle: internetEndpoints.length ? {
        left:internetNodeX-internetNodeWidth/2-6, right:internetNodeX+internetNodeWidth/2+6,
        top:internetNodeY-6, bottom:internetNodeY+internetNodeHeight+6
      } : null};
    const geometryKey = JSON.stringify(routingGeometry);
    const requests = [];
    const cachedRoutes = routingGeometryKey === geometryKey ? routingResult : null;
    const routeAroundDevices = (start, end, endpointPortKeys = [], allowInternetNode = false, _routes = [], fixedPoints = null) => {
      const request = {start,end,endpointPortKeys,allowInternetNode,fixedPoints};
      const key = JSON.stringify(request);
      requests.push(request);
      return fixedPoints || cachedRoutes?.get(key) || previewMapRoute(start,end);
    };
    const orderedInternetEndpoints = internetEndpoints
      .slice()
      .sort((left, right) => positions.get(left.deviceId).x - positions.get(right.deviceId).x || left.port - right.port);
    const internetRoutes = [];
    orderedInternetEndpoints.forEach((endpoint, rank) => {
        const port = portPoint(endpoint.deviceId, endpoint.port);
        const physicalDevice = assetsById.get(endpoint.physicalDeviceId);
        const anchorX = internetNodeX + (rank - (internetEndpoints.length - 1) / 2) * Math.min(5, (internetNodeWidth - 20) / Math.max(1, internetEndpoints.length - 1));
        const cloudEntry = { x: anchorX, y: internetNodeY + internetNodeHeight };
        const link = { id: endpoint.linkId };
        internetRoutes.push({
          link, isInternet: true,
          description: `${physicalDevice.name} port ${endpoint.physicalPort} connects directly to the Internet`,
          physicalDevice,
          points: routeAroundDevices(port, cloudEntry, [`${endpoint.deviceId}:${endpoint.port}`], true, internetRoutes)
        });
      });
    const backupPowerBadge = (device, x, y) => {
      if (!device.backupPowerEnabled) return '';
      const ups = assetsById.get(device.backupUpsId);
      const label = `Backup power${ups ? ` · UPS: ${ups.name}` : ''}`;
      return html`<g class="map-backup-power" role="img" aria-label="${esc(t(label))}"><title>${esc(t(label))}</title><path transform="translate(${x} ${y})" d="M 4 0 L 0 5 H 2 L 1 9 L 6 3 H 3 Z"></path></g>`;
    };
    function renderVirtualMachinePanel(device, point, contentWidth) {
      const virtualMachineLayout = virtualMachineLayouts.get(device.id);
      if (!virtualMachineLayout) return '';
      const panelX = point.x + contentWidth + 6;
      const panelY = point.y + (deviceHeights.get(device.id) - virtualMachineLayout.panelHeight) / 2;
      const virtualMachineCards = virtualMachineLayout.virtualMachines.map((vm, index) => {
        const column = Math.floor(index / 10);
        const row = index % 10;
        const x = panelX + 4 + column * 54;
        const y = panelY + 11 + row * 17;
        const nameLimit = osIcon(vm, 0, 0) ? 6 : 9;
        const hostName = vm.hypervisorClusterId ? device.name : assetsById.get(vm.hypervisorId)?.name || device.name;
        const vmName = vm.name.length > nameLimit ? `${vm.name.slice(0, nameLimit - 1)}…` : vm.name;
        const hasConnections = physicalConnections.some(link =>
          link.deviceAId === vm.id || link.deviceBId === vm.id
        );
        const connectedPort = hasConnections
          ? html`<rect class="map-port connected" x="${x + 47}" y="${y + 5}" width="3" height="4" rx="1"></rect>`
          : '';
        return html`<g data-map-device-id="${esc(vm.id)}" ${powerAttributes(vm)} class="map-vm-card" role="img" aria-label="${esc(`${vm.name}, virtual machine on ${hostName}${hasConnections ? ', connected to network' : ''}`)}"><title>${esc(`${vm.name} · Virtual machine on ${hostName}${hasConnections ? ' · Connected to network' : ''}`)}</title><rect class="map-vm-node" x="${x}" y="${y}" width="50" height="14" rx="2"></rect><g class="map-vm-glyph" aria-hidden="true"><rect x="${x + 2}" y="${y + 4}" width="6" height="6" rx="1"></rect><rect x="${x + 4}" y="${y + 2}" width="6" height="6" rx="1"></rect></g><text class="map-vm-name" x="${x + 12}" y="${y + 9.5}">${esc(vmName)}</text>${osIcon(vm, x + 38, y + 3, 8)}${backupPowerBadge(vm, x + 51, y + 2)}${connectedPort}</g>`;
      }).join('');
      const hostLinkY = device.isCluster ? point.y + deviceHeights.get(device.id) / 2 : point.y + cardHeight / 2;
      return html`<g class="map-vm-panel" role="group" aria-label="${virtualMachineLayout.virtualMachines.length} virtual machines hosted on ${esc(device.name)}"><path class="map-vm-host-link" d="M ${point.x + contentWidth} ${hostLinkY} H ${panelX}"></path><rect class="map-vm-panel-frame" x="${panelX}" y="${panelY}" width="${virtualMachineLayout.panelWidth}" height="${virtualMachineLayout.panelHeight}" rx="3"></rect><text class="map-vm-panel-title" x="${panelX + 4}" y="${panelY + 7.5}">[[vms]] ${virtualMachineLayout.virtualMachines.length}</text>${virtualMachineCards}</g>`;
    }
    const framesForDevice = device => {
      const point = positions.get(device.id);
      const width = deviceWidths.get(device.id);
      const contentWidth = deviceContentWidths.get(device.id) || width;
      const height = stackHeights.get(device.id) || cardHeight;
      const color = mapTypeColors[device.type] || '#7c8667';
      if (device.isStack) {
        const members = stackMemberLayouts.get(device.id) || [];
        const memberFrames = members.map(({ member, offset, width: memberWidth }) => {
          const memberY = point.y + stackContentTop + offset - 1;
          const osBadge = osIcon(member, point.x + stackPadding + 18, memberY + 3, 12);
          const textOffset = osBadge ? 34 : 16;
          const hasManagementVlan = selectedManagementVlan(member);
          const nameLimit = Math.max(8, Math.floor((memberWidth - textOffset - 4) / 3.9) - (hasManagementVlan ? 4 : 0));
          const memberName = member.name.length > nameLimit ? `${member.name.slice(0, nameLimit - 1)}…` : member.name;
          const memberMeta = mapManufacturer(member);
          const memberMetaLimit = Math.max(4, Math.floor((memberWidth - textOffset - 19) / 3));
          const shortMemberMeta = hasManagementVlan && memberMeta.length > memberMetaLimit
            ? `${memberMeta.slice(0, memberMetaLimit - 1)}…`
            : memberMeta;
          const managementBadge = hasManagementVlan
            ? html`<text class="map-management-badge" x="${point.x + stackPadding + memberWidth - 3}" y="${memberY + 7}" text-anchor="end"><title>[[management_vlan]] ${esc(member.vlan)}</title>[[mgmt]]</text>`
            : '';
          return html`<g data-map-device-id="${esc(member.id)}" ${powerAttributes(member)} class="map-stack-member" style="color:${mapTypeColors[member.type] || color}"><title>${esc(member.name)}, ${esc(memberMeta)}</title><rect class="map-node map-stack-member-node" x="${point.x + stackPadding}" y="${memberY}" width="${memberWidth}" height="${cardHeight}" rx="3"></rect><rect class="map-node-accent" x="${point.x + stackPadding}" y="${memberY}" width="2" height="${cardHeight}" rx="1"></rect>${deviceGlyph(member.type, point.x + stackPadding + 4, memberY + 3)}<text class="map-node-meta" x="${point.x + stackPadding + textOffset}" y="${memberY + 8}">${esc(shortMemberMeta)}</text><text class="map-node-name" x="${point.x + stackPadding + textOffset}" y="${memberY + 15}">${esc(memberName)}</text>${osBadge}${managementBadge}${backupPowerBadge(member, point.x + stackPadding - 8, memberY + 2)}</g>`;
        }).join('');
        const stackJoins = members.slice(1).map((member, index) => {
          const previous = members[index];
          const joinX = point.x + stackPadding + previous.width / 2;
          const joinStartY = point.y + stackContentTop + previous.offset + cardHeight - 1;
          const joinEndY = point.y + stackContentTop + member.offset - 1;
          return html`<path class="map-stack-join" d="M ${joinX} ${joinStartY} V ${joinEndY}"></path>`;
        }).join('');
        return html`<g class="map-stack${device.isCluster ? ' map-cluster' : ''}" role="group" aria-label="${esc(device.name)}, ${device.isCluster ? 'server cluster' : 'stack'} with ${esc(device.stackMembers.map(member => member.name).join(', '))}"><title>${esc(device.name)} ${device.isCluster ? 'server cluster' : 'stack'}</title><rect class="map-stack-frame" x="${point.x}" y="${point.y}" width="${width}" height="${height}" rx="5"></rect><text class="map-stack-title" x="${point.x + width / 2}" y="${point.y + 8}">${esc(device.name)}</text>${stackJoins}${memberFrames}${renderVirtualMachinePanel(device, point, contentWidth)}</g>`;
      }
      if (device.type === 'Access point') {
        const managementBadge = selectedManagementVlan(device)
          ? html`<text class="map-management-badge map-management-badge-access-point" x="${point.x + width / 2}" y="${point.y + cardHeight - 7}"><title>[[management_vlan]] ${esc(device.vlan)}</title>[[mgmt]]</text>`
          : '';
        return html`<g style="color:${color}"><circle class="map-node map-node-access-point" cx="${point.x + width / 2}" cy="${point.y + cardHeight / 2}" r="${cardHeight / 2}"></circle>${managementBadge}${backupPowerBadge(device, point.x - 8, point.y + 2)}</g>`;
      }
      const virtualMachinePanel = renderVirtualMachinePanel(device, point, contentWidth);
      const managementBadge = selectedManagementVlan(device)
        ? html`<text class="map-management-badge" x="${point.x + contentWidth - 3}" y="${point.y + 7}" text-anchor="end"><title>[[management_vlan]] ${esc(device.vlan)}</title>[[mgmt]]</text>`
        : '';
      return html`<g class="${device.type === 'Patch panel' ? 'map-patch-panel' : ''}" style="color:${color}"><rect class="map-node" x="${point.x}" y="${point.y}" width="${contentWidth}" height="${height}" rx="${device.type === 'Switch' ? '3' : '5'}"></rect><rect class="map-node-accent" x="${point.x}" y="${point.y}" width="3" height="${height}" rx="2"></rect>${deviceGlyph(device.type, point.x + 4, point.y + 3)}${managementBadge}${backupPowerBadge(device, point.x - 8, point.y + 2)}${virtualMachinePanel}</g>`;
    };
    const frames = devices.map(device => html`<g data-map-device-id="${esc(device.id)}" ${powerAttributes(device)}>${framesForDevice(device)}</g>`).join('');
    const internetNode = internetEndpoints.length
      ? html`<g class="map-internet-node" role="img" aria-label="[[internet_31deec]]"><path class="map-internet-cloud" d="M ${internetNodeX - internetNodeWidth / 2 + 12} ${internetNodeY + internetNodeHeight - 3} C ${internetNodeX - internetNodeWidth / 2 + 4} ${internetNodeY + internetNodeHeight - 3}, ${internetNodeX - internetNodeWidth / 2 + 3} ${internetNodeY + 14}, ${internetNodeX - internetNodeWidth / 2 + 12} ${internetNodeY + 13} C ${internetNodeX - internetNodeWidth / 2 + 14} ${internetNodeY + 3}, ${internetNodeX - 2} ${internetNodeY + 2}, ${internetNodeX + 2} ${internetNodeY + 11} C ${internetNodeX + 13} ${internetNodeY + 5}, ${internetNodeX + internetNodeWidth / 2 - 4} ${internetNodeY + 10}, ${internetNodeX + internetNodeWidth / 2 - 8} ${internetNodeY + 17} C ${internetNodeX + internetNodeWidth / 2 - 1} ${internetNodeY + 18}, ${internetNodeX + internetNodeWidth / 2 - 4} ${internetNodeY + internetNodeHeight - 3}, ${internetNodeX + internetNodeWidth / 2 - 13} ${internetNodeY + internetNodeHeight - 3} Z"></path><text class="map-internet-label" x="${internetNodeX}" y="${internetNodeY + 21}">[[internet]]</text></g>`
      : '';
    const connectionRoutes = [];
    validConnections.filter(link =>
      positions.has(layoutDeviceId(link.deviceAId)) && positions.has(layoutDeviceId(link.deviceBId))
    ).forEach(link => {
      const first = connectionPoint(link.deviceAId, link.portA);
      const second = connectionPoint(link.deviceBId, link.portB);
      const elkPoints = usesELK() && elkResult ? elkRoutePoints(elkResult.edges.find(edge => edge.id === `e${validConnections.indexOf(link)}`), first, second) : null;
      const firstDevice = assetsById.get(link.physicalDeviceAId);
      const secondDevice = assetsById.get(link.physicalDeviceBId);
      const firstSpeed = getPortSpeed?.(firstDevice, link.physicalPortA) || '1 Gbps';
      const secondSpeed = getPortSpeed?.(secondDevice, link.physicalPortB) || '1 Gbps';
      const firstSpeedGbps = parseSpeedGbps(firstSpeed);
      const secondSpeedGbps = parseSpeedGbps(secondSpeed);
      const bothSpeedsKnown = Number.isFinite(firstSpeedGbps) && Number.isFinite(secondSpeedGbps);
      const effectiveSpeed = bothSpeedsKnown ? Math.min(firstSpeedGbps, secondSpeedGbps) : null;
      const effectiveSpeedText = link.lagId
        ? `LAG speed ${lagSpeedSummary(link.lagId)}`
        : bothSpeedsKnown
        ? `link speed ${firstSpeedGbps <= secondSpeedGbps ? firstSpeed : secondSpeed}`
        : `speed unknown (${firstSpeed} / ${secondSpeed})`;
      const description = `${firstDevice.name} port ${link.physicalPortA} connects to ${secondDevice.name} port ${link.physicalPortB} · ${effectiveSpeedText}`;
      const vlanMatch = connectionHasSelectedVlan(
        firstDevice, link.physicalPortA, secondDevice, link.physicalPortB
      );
      connectionRoutes.push({
        link: {
          ...link,
          speedClass: speedClass(effectiveSpeed),
          vlanClass: mapViewMode === 'vlan'
            ? vlanMatch ? 'map-vlan-active' : 'map-vlan-muted'
            : ''
        }, description,
        points: routeAroundDevices(first, second, [
          `${link.deviceAId}:${link.portA}`,
          `${link.deviceBId}:${link.portB}`
        ], false, [], elkPoints)
      });
    });
    routingInput = {geometry:routingGeometry, routes:requests};
    const nextRoutingKey = JSON.stringify(routingInput);
    if (nextRoutingKey !== routingKey) {
      routingTask?.cancel(); routingTask = null; routingError = ''; routingResult = null;
      routingKey = nextRoutingKey; routingGeometryKey = geometryKey;
    }
    const routePath = points => `M ${points[0].x} ${points[0].y} ${points.slice(1).map(point => `L ${point.x} ${point.y}`).join(' ')}`;
    const allConnectionRoutes = [...connectionRoutes, ...internetRoutes];
    const lines = allConnectionRoutes.map(route =>
      html`<path class="map-link ${route.link.speedClass || ''} ${route.link.lagId ? 'map-link-lag' : route.isInternet ? 'map-link-internet' : ''} ${route.link.vlanClass || (mapViewMode === 'vlan' ? 'map-vlan-muted' : '')}" data-connection-id="${esc(connectionKey(route.link))}" d="${routePath(route.points)}"><title>${esc(route.link.lagName ? `${route.link.lagName} LAG: ${route.description}` : route.description)}</title></path>`
    ).join('');
    const lagLabelRoutes = new Map();
    connectionRoutes.filter(route => route.link.lagId).forEach(route => {
      const existing = lagLabelRoutes.get(route.link.lagId);
      if (!existing || (
        existing.link.vlanClass === 'map-vlan-muted' &&
        route.link.vlanClass === 'map-vlan-active'
      )) {
        lagLabelRoutes.set(route.link.lagId, route);
      }
    });
    const lagLabels = [...lagLabelRoutes.values()].map(route => {
      const labelSegment = route.points.slice(1).map((point, index) => {
        const previous = route.points[index];
        return previous.y === point.y ? { start: previous, end: point, length: Math.abs(point.x - previous.x) } : null;
      }).filter(segment => segment && segment.length > 0)
        .sort((left, right) => right.length - left.length)[0];
      const start = route.points[0];
      const end = route.points[route.points.length - 1];
      const labelX = labelSegment ? (labelSegment.start.x + labelSegment.end.x) / 2 : (start.x + end.x) / 2;
      const labelY = labelSegment ? labelSegment.start.y - 3.5 : (start.y + end.y) / 2 - 3;
      return html`<text class="map-lag-label ${route.link.vlanClass || (mapViewMode === 'vlan' ? 'map-vlan-muted' : '')}" data-connection-id="${esc(route.link.lagId)}" x="${labelX}" y="${labelY}">${esc(route.link.lagName)}</text>`;
    }).join('');
    const bridgeRadius = 1.25;
    const minimumBridgeRadius = .5;
    const bridgeCrossings = [];
    const bridgeCrossingKeys = new Set();
    allConnectionRoutes.forEach((underRoute, underIndex) => {
      allConnectionRoutes.slice(underIndex + 1).forEach((overRoute, routeOffset) => {
        const overIndex = underIndex + routeOffset + 1;
        underRoute.points.slice(1).forEach((underEnd, underSegmentIndex) => {
          const underStart = underRoute.points[underSegmentIndex];
          if (underStart.x === underEnd.x && underStart.y === underEnd.y) return;
          const underHorizontal = underStart.y === underEnd.y;
          overRoute.points.slice(1).forEach((overEnd, overSegmentIndex) => {
            const overStart = overRoute.points[overSegmentIndex];
            if (overStart.x === overEnd.x && overStart.y === overEnd.y) return;
            const overHorizontal = overStart.y === overEnd.y;
            if (underHorizontal === overHorizontal) return;
            const horizontalStart = underHorizontal ? underStart : overStart;
            const horizontalEnd = underHorizontal ? underEnd : overEnd;
            const verticalStart = underHorizontal ? overStart : underStart;
            const verticalEnd = underHorizontal ? overEnd : underEnd;
            const x = verticalStart.x;
            const y = horizontalStart.y;
            const crossingKey = `${underIndex}:${overIndex}:${x}:${y}`;
            if (bridgeCrossingKeys.has(crossingKey)) return;
            const horizontalMin = Math.min(horizontalStart.x, horizontalEnd.x);
            const horizontalMax = Math.max(horizontalStart.x, horizontalEnd.x);
            const verticalMin = Math.min(verticalStart.y, verticalEnd.y);
            const verticalMax = Math.max(verticalStart.y, verticalEnd.y);
            if (x <= horizontalMin || x >= horizontalMax || y <= verticalMin || y >= verticalMax) return;
            const crossingRadius = Math.min(
              bridgeRadius,
              (x - horizontalMin) / 2,
              (horizontalMax - x) / 2,
              (y - verticalMin) / 2,
              (verticalMax - y) / 2
            );
            if (crossingRadius < minimumBridgeRadius) return;
            bridgeCrossingKeys.add(crossingKey);
            bridgeCrossings.push({ route: overRoute, x, y, horizontal: overHorizontal, radius: crossingRadius });
          });
        });
      });
    });
    allConnectionRoutes.forEach((bendRoute, bendRouteIndex) => {
      bendRoute.points.slice(1, -1).forEach((bend, pointOffset) => {
        const previous = bendRoute.points[pointOffset];
        const next = bendRoute.points[pointOffset + 2];
        const previousHorizontal = previous.y === bend.y;
        const nextHorizontal = next.y === bend.y;
        if (previousHorizontal === nextHorizontal) return;
        allConnectionRoutes.forEach((straightRoute, straightRouteIndex) => {
          if (bendRouteIndex === straightRouteIndex) return;
          straightRoute.points.slice(1).forEach((end, segmentIndex) => {
            const start = straightRoute.points[segmentIndex];
            if (start.x === end.x && start.y === end.y) return;
            const horizontal = start.y === end.y;
            const crossesBend = horizontal
              ? bend.y === start.y && bend.x > Math.min(start.x, end.x) && bend.x < Math.max(start.x, end.x)
              : bend.x === start.x && bend.y > Math.min(start.y, end.y) && bend.y < Math.max(start.y, end.y);
            if (!crossesBend) return;
            const crossingKey = `${Math.min(bendRouteIndex, straightRouteIndex)}:${Math.max(bendRouteIndex, straightRouteIndex)}:${bend.x}:${bend.y}`;
            if (bridgeCrossingKeys.has(crossingKey)) return;
            const radius = Math.min(
              bridgeRadius,
              horizontal ? (bend.x - Math.min(start.x, end.x)) / 2 : (bend.y - Math.min(start.y, end.y)) / 2,
              horizontal ? (Math.max(start.x, end.x) - bend.x) / 2 : (Math.max(start.y, end.y) - bend.y) / 2
            );
            if (radius < minimumBridgeRadius) return;
            bridgeCrossingKeys.add(crossingKey);
            bridgeCrossings.push({ route: straightRoute, x: bend.x, y: bend.y, horizontal, radius });
          });
        });
      });
    });
    allConnectionRoutes.forEach((underRoute, underIndex) => {
      underRoute.points.slice(1, -1).forEach((underBend, underPointOffset) => {
        const underPrevious = underRoute.points[underPointOffset];
        const underNext = underRoute.points[underPointOffset + 2];
        if ((underPrevious.y === underBend.y) === (underNext.y === underBend.y)) return;
        allConnectionRoutes.slice(underIndex + 1).forEach((overRoute, routeOffset) => {
          overRoute.points.slice(1, -1).forEach((overBend, overPointOffset) => {
            if (underBend.x !== overBend.x || underBend.y !== overBend.y) return;
            const overPrevious = overRoute.points[overPointOffset];
            const overNext = overRoute.points[overPointOffset + 2];
            const horizontal = overNext.y === overBend.y;
            if ((overPrevious.y === overBend.y) === horizontal) return;
            const direction = horizontal
              ? Math.sign(overNext.x - overBend.x)
              : Math.sign(overNext.y - overBend.y);
            const segmentLength = horizontal
              ? Math.abs(overNext.x - overBend.x)
              : Math.abs(overNext.y - overBend.y);
            const radius = Math.min(bridgeRadius, segmentLength / 2);
            if (radius < minimumBridgeRadius) return;
            const x = overBend.x + (horizontal ? direction * radius : 0);
            const y = overBend.y + (horizontal ? 0 : direction * radius);
            const overIndex = underIndex + routeOffset + 1;
            const crossingKey = `${underIndex}:${overIndex}:${underBend.x}:${underBend.y}`;
            if (bridgeCrossingKeys.has(crossingKey)) return;
            bridgeCrossingKeys.add(crossingKey);
            bridgeCrossings.push({ route: overRoute, x, y, horizontal, radius });
          });
        });
      });
    });
    const bridges = bridgeCrossings.map(({ route, x, y, horizontal, radius }) => {
      const connectionId = esc(connectionKey(route.link));
      const gapWidth = Math.min(2, Math.max(1.4, radius * 1.4));
      const gap = horizontal
        ? `M ${x - radius} ${y} H ${x + radius}`
        : `M ${x} ${y - radius} V ${y + radius}`;
      const arc = horizontal
        ? `M ${x - radius} ${y} Q ${x} ${y - radius * 2} ${x + radius} ${y}`
        : `M ${x} ${y - radius} Q ${x + radius * 2} ${y} ${x} ${y + radius}`;
      return html`<g class="map-bridge ${route.link.vlanClass || (mapViewMode === 'vlan' ? 'map-vlan-muted' : '')}" data-connection-id="${connectionId}"><path class="map-bridge-gap" style="stroke-width:${gapWidth}" d="${gap}"></path><path class="map-bridge-arc ${route.link.speedClass || ''}" d="${arc}"></path></g>`;
    }).join('');
    const nodesForDevice = device => {
      const point = positions.get(device.id);
      const osBadge = osIcon(device, point.x + 18, point.y + 3, 12);
      const textOffset = osBadge ? 34 : 16;
      const hasManagementVlan = selectedManagementVlan(device);
      const maxNameLength = Math.max(8, Math.floor(((deviceContentWidths.get(device.id) || deviceWidths.get(device.id)) - textOffset - 4) / 3.9) - (hasManagementVlan ? 4 : 0));
      const shortName = device.name.length > maxNameLength ? `${device.name.slice(0, maxNameLength - 1)}…` : device.name;
      const manufacturer = mapManufacturer(device);
      const manufacturerLimit = Math.max(4, Math.floor(((deviceContentWidths.get(device.id) || deviceWidths.get(device.id)) - textOffset - 19) / 3));
      const shortManufacturer = hasManagementVlan && manufacturer.length > manufacturerLimit
        ? `${manufacturer.slice(0, manufacturerLimit - 1)}…`
        : manufacturer;
      const count = Number(device.portCount) || 0;
      const ports = Array.from({ length: count }, (_, index) => {
        const number = index + 1;
        const { row, column } = portGridPosition(device, index);
        const portInfo = stackPortInfo.get(`${device.id}:${number}`);
        const physicalDevice = portInfo?.member || device;
        const physicalPort = portInfo?.memberPort || number;
        const displayPortNumber = device.isStack ? physicalPort : number;
        const connection = validConnections.find(link =>
          link.deviceAId === device.id && Number(link.portA) === number ||
          link.deviceBId === device.id && Number(link.portB) === number);
        const physicalConnection = physicalConnections.find(link =>
          (link.deviceAId === physicalDevice.id && Number(link.portA) === physicalPort) ||
          (link.deviceBId === physicalDevice.id && Number(link.portB) === physicalPort));
        const internetConnected = (device.internetPorts || []).some(port => Number(port) === number);
        const internetEndpoint = internetEndpoints.find(endpoint => endpoint.deviceId === device.id && endpoint.port === number);
        const externalConnection = roomMap?.external.find(link =>
          link.deviceAId === physicalDevice.id && Number(link.portA) === physicalPort ||
          link.deviceBId === physicalDevice.id && Number(link.portB) === physicalPort);
        const connected = Boolean(connection || physicalConnection || externalConnection) || internetConnected || Boolean(internetEndpoint);
        const x = portX(device.id, row, column, number);
        const memberLayout = device.isStack
          ? stackMemberLayouts.get(device.id)?.find(item => item.member.id === physicalDevice.id)
          : null;
        const y = point.y + (device.isStack ? stackContentTop + (memberLayout?.offset || 0) : 0) + 23 + row * 7;
        const portTypeFn = getPortType || ((a, p) => a?.portTypes?.[p] ?? a?.portTypes?.[String(p)] ?? 'ETH 1 Gb/s');
        const portType = portTypeFn(physicalDevice, physicalPort);
        const assignedVlans = portVlanIds(physicalDevice, physicalPort);
        const matchesSelectedVlan = mapViewMode === 'vlan' &&
          [...assignedVlans].some(id => selectedVlanIds.has(id));
        const vlanClass = mapViewMode === 'vlan'
          ? matchesSelectedVlan ? 'map-vlan-active' : 'map-vlan-muted'
          : '';
        const vlanLabel = assignedVlans.size ? `VLANs ${[...assignedVlans].join(', ')}` : 'no VLAN assigned';
        let label = `${physicalDevice.name} port ${physicalPort} (${portType}), not connected`;
        if (connection) {
          const peerId = connection.physicalDeviceAId === physicalDevice.id && connection.physicalPortA === physicalPort
            ? connection.physicalDeviceBId : connection.physicalDeviceAId;
          const peerPort = connection.physicalDeviceAId === physicalDevice.id && connection.physicalPortA === physicalPort
            ? connection.physicalPortB : connection.physicalPortA;
          const peerDevice = assetsById.get(peerId);
          const peerPortType = peerDevice ? portTypeFn(peerDevice, peerPort) : 'ETH 1 Gb/s';
          label = `${physicalDevice.name} port ${physicalPort} (${portType}), connected to ${peerDevice?.name || 'peer'} port ${peerPort} (${peerPortType})`;
        } else if (physicalConnection && stackIdByAsset.get(physicalConnection.deviceAId) === device.id &&
            stackIdByAsset.get(physicalConnection.deviceBId) === device.id) {
          const peerId = physicalConnection.deviceAId === physicalDevice.id ? physicalConnection.deviceBId : physicalConnection.deviceAId;
          const peerPort = physicalConnection.deviceAId === physicalDevice.id ? physicalConnection.portB : physicalConnection.portA;
          const peerDevice = assetsById.get(peerId);
          const peerPortType = peerDevice ? portTypeFn(peerDevice, peerPort) : 'ETH 1 Gb/s';
          label = `${physicalDevice.name} port ${physicalPort} (${portType}), internally connected to ${peerDevice?.name || 'peer'} port ${peerPort} (${peerPortType})`;
        } else if (internetEndpoint) {
          label = `${physicalDevice.name} port ${physicalPort} (${portType}), connected directly to the Internet`;
        }
        const lagId = connection?.lagId || physicalConnection?.lagId;
        if (physicalDevice.type === 'Patch panel') {
          label = `${physicalDevice.name} port ${physicalPort}`;
          if (physicalConnection) {
            const first = physicalConnection.deviceAId === physicalDevice.id && Number(physicalConnection.portA) === physicalPort;
            const peer = assetsById.get(first ? physicalConnection.deviceBId : physicalConnection.deviceAId);
            const peerPort = first ? physicalConnection.portB : physicalConnection.portA;
            label += `, connected to ${peer?.name || 'peer'} port ${peerPort}`;
          } else label += internetEndpoint ? ', connected directly to the Internet' : ', not connected';
          if (lagId) label += ` · LAG ${physicalConnection?.lagName || lagId}`;
        } else {
          if (lagId) label += ` · LAG speed ${lagSpeedSummary(lagId)}`;
          label += ` · ${vlanLabel}`;
        }
        let roomNavigation = '';
        if (externalConnection) {
          const first = externalConnection.deviceAId === physicalDevice.id;
          const peer = fullData.assets.find(asset => asset.id === (first ? externalConnection.deviceBId : externalConnection.deviceAId));
          const peerRoom = (fullData.rooms || []).find(room => room.id === assetRoomId(peer, fullData));
          roomNavigation = `role="button" tabindex="0" data-room-map-target="${esc(peerRoom?.id || '')}"`;
          label = `${physicalDevice.name} port ${physicalPort} (${portType}), ${t('room_external_connections')}: ${peer?.name || ''} port ${first ? externalConnection.portB : externalConnection.portA} — ${peerRoom?.name || t('no_room_assigned')}`;
        }
        const connectionId = connection
          ? `data-connection-id="${esc(connectionKey(connection))}"`
          : internetEndpoint ? `data-connection-id="${esc(internetEndpoint.linkId)}"` : '';
        return html`<g${device.isStack && mapViewMode === 'power' ? ` ${powerAttributes(physicalDevice)}` : ''} class="${vlanClass} ${externalConnection ? 'map-room-uplink' : ''}" ${connectionId} ${roomNavigation} aria-label="${esc(t(label))}"><title>${esc(t(label))}</title><rect class="map-port ${connected ? 'connected' : ''}" x="${x}" y="${y}" width="${portWidth}" height="${portHeight}" rx="1"></rect><text class="map-port-label ${connected ? 'connected' : ''}" x="${x + portWidth / 2}" y="${y + 3.5}">${externalConnection ? '↗' : displayPortNumber}</text></g>`;
      }).join('');
      const hostedVms = virtualMachinesByHost.get(device.id) || [];
      const mapLabel = `${device.name}, ${device.type}${hostedVms.length ? `, hosting ${hostedVms.length} virtual machine${hostedVms.length === 1 ? '' : 's'}` : ''}`;
      if (device.isStack) {
        return html`<g role="group" aria-label="${esc(mapLabel)}, ${count} ports"><title>${esc(device.name)} ${device.isCluster ? 'server cluster' : 'stack'}</title>${ports}</g>`;
      }
      if (device.type === 'Access point') {
        const centerX = point.x + deviceWidths.get(device.id) / 2;
        return html`<g role="group" aria-label="${esc(mapLabel)}, ${count} ports">${deviceGlyph(device.type, centerX - 4.5, point.y + 1)}<text class="map-node-meta map-node-access-point-meta" x="${centerX}" y="${point.y + 16}">${esc(manufacturer)}</text><text class="map-node-name map-node-access-point-name" x="${centerX}" y="${point.y + 22}">${esc(shortName)}</text>${ports}</g>`;
      }
      return html`<g role="group" aria-label="${esc(mapLabel)}, ${count} ports"><title>${esc(mapLabel)}</title><text class="map-node-meta" x="${point.x + textOffset}" y="${point.y + 9}">${esc(shortManufacturer)}</text><text class="map-node-name" x="${point.x + textOffset}" y="${point.y + 17}">${esc(shortName)}</text>${ports}${osBadge}</g>`;
    };
    const nodes = devices.map(device => html`<g ${powerAttributes(device)}>${nodesForDevice(device)}</g>`).join('');
    const internetRows = internetEndpoints.map(endpoint => {
      const device = assetsById.get(endpoint.physicalDeviceId);
      return html`<tr class="connection-row" data-connection-id="${esc(endpoint.linkId)}" tabindex="0"><td>${esc(device.name)}</td><td>[[port]] ${endpoint.physicalPort}</td><td>[[internet_31deec]]</td><td>—</td></tr>`;
    }).join('');
    const logicalConnectionsCount = physicalConnections.filter(link => !link.lagId).length +
      new Set(physicalConnections.filter(link => link.lagId).map(link => link.lagId)).size;
    const connectionsCount = logicalConnectionsCount + internetEndpoints.length;
    const virtualMachineCount = [...virtualMachinesByHost.values()].reduce((total, machines) => total + machines.length, 0) +
      devices.filter(device => device.type === 'Virtual server').length;
    const lagConnectionGroups = new Map();
    physicalConnections.filter(link => link.lagId).forEach(link => {
      const group = lagConnectionGroups.get(link.lagId) || [];
      group.push(link);
      lagConnectionGroups.set(link.lagId, group);
    });
    const connectionRowsList = [
      ...physicalConnections.filter(link => !link.lagId).map(link => {
        const firstDevice = assetsById.get(link.deviceAId);
        const secondDevice = assetsById.get(link.deviceBId);
        return html`<tr class="connection-row" data-connection-id="${esc(connectionKey(link))}" tabindex="0"><td>${esc(firstDevice.name)}</td><td>[[port]] ${esc(link.portA)}</td><td>${esc(secondDevice.name)}</td><td>[[port]] ${esc(link.portB)}</td></tr>`;
      }),
      ...[...lagConnectionGroups.entries()].map(([lagId, links]) => {
        const firstDevice = lagEndpointName(data.lags.find(lag => lag.id === lagId), 'A');
        const secondDevice = lagEndpointName(data.lags.find(lag => lag.id === lagId), 'B');
        const pairs = links.map(link => `${Number(link.portA)}↔${Number(link.portB)}`).join(', ');
        return html`<tr class="connection-row" data-connection-id="${esc(lagId)}" tabindex="0"><td>${esc(firstDevice)} <span class="tag blue">${esc(links[0].lagName)}</span></td><td>${esc(pairs)}</td><td>${esc(secondDevice)}</td><td>${links.length} port pairs · ${esc(lagSpeedSummary(lagId))}</td></tr>`;
      })
    ];
    const connectionRows = connectionsCount
      ? `${connectionRowsList.join('')}${internetRows}`
      : html`<tr><td colspan="4"><div class="empty-state"><strong>[[no_links_yet]]</strong>[[connect_device_ports_from_a_device_s_edit_form]]</div></td></tr>`;
    const usedSpeeds = new Set(physicalConnections.map(link => {
      const first = parseSpeedGbps(getPortSpeed?.(assetsById.get(link.deviceAId), link.portA) || '1 Gbps');
      const second = parseSpeedGbps(getPortSpeed?.(assetsById.get(link.deviceBId), link.portB) || '1 Gbps');
      return first === null || second === null ? null : Math.min(first, second);
    }));
    const speedLegendHtml = speedLegend.filter(item => usedSpeeds.has(item.gbps)).map(item =>
      html`<span class="map-legend-item"><span class="map-legend-line ${item.className.replace('map-link-', 'map-legend-line-')}" aria-hidden="true"></span>${item.label}</span>`
    ).join('');
    const connectionLegend = mapViewMode !== 'vlan'
      ? html`<div class="map-legend" aria-label="[[connection_speed_and_type]]"><span class="map-legend-item"><strong>[[slower_port_speed]]</strong></span>${speedLegendHtml}<span class="map-legend-item"><span class="map-legend-line map-legend-line-speed-unknown" aria-hidden="true"></span>[[unknown_custom]]</span><span class="map-legend-item"><span class="map-legend-line map-legend-line-lag" aria-hidden="true"></span>[[lag_dashed]]</span><span class="map-legend-item"><span class="map-legend-line map-legend-line-internet" aria-hidden="true"></span>[[internet_dotted]]</span></div>`
      : html(["<div class=\"map-legend\" aria-label=\"[[connection_types]]\"><span class=\"map-legend-item\"><span class=\"map-legend-line map-legend-line-lag\" aria-hidden=\"true\"></span>[[lag_dashed]]</span><span class=\"map-legend-item\"><span class=\"map-legend-line map-legend-line-internet\" aria-hidden=\"true\"></span>[[internet_dotted]]</span></div>"]);
    const routingNotice = (!usesELK() || elkResult || elkError) && requests.some(route => !route.fixedPoints) && !routingResult
      ? `<div class="panel-sub" role="status">${routingError || typeof Worker === 'undefined' ? 'Showing simplified cable routes.' : 'Arranging connections…'}</div>` : '';
    const viewControls = routingNotice + viewButtons + (usesELK() && (!elkResult || elkError) ? html`<div class="panel-sub" role="status">${elkError ? `ELK failed; showing original routes: ${esc(elkError)}` : t("building_elk_routes")}</div>` : '');
    const vlanFilter = html`<div class="map-vlan-filter" ${mapViewMode === 'vlan' ? '' : 'hidden'}><strong>[[show_vlans]]</strong>${vlanOptions.length ? vlanOptions.map(vlan => html`<label><input type="checkbox" data-map-vlan="${esc(vlan.id)}" ${selectedVlanIds.has(vlan.id) ? 'checked' : ''}>${esc(vlan.label)}</label>`).join('') : html(["<span class=\"secondary-cell\">[[no_vlans_configured]]</span>"])}<span class="map-vlan-hint">${selectedVlanIds.size ? t("links_are_highlighted_when_both_ports_share_a_selected_vlan") : t("select_one_or_more_vlans_to_highlight_matching_ports_and_links")} Unassigned and non-matching ports remain visible but faded.</span></div>`;
    const modeLegend = mapViewMode === 'vlan'
      ? html(["<div class=\"map-legend map-vlan-legend\"><span class=\"map-legend-item\"><span class=\"map-vlan-swatch\"></span>[[selected_vlan_shared_link]]</span><span class=\"map-legend-item\"><span class=\"map-vlan-swatch map-vlan-swatch-muted\"></span>[[other_or_unassigned]]</span><span class=\"map-legend-item\"><span class=\"map-management-legend\">[[mgmt]]</span>[[device_management_vlan]]</span></div>"])
      : '';
    return html`<div class="network-map-workspace ${mapExpanded ? 'is-expanded' : ''}"><div class="list-toolbar network-map-toolbar"><div class="map-topology-summary"><div class="eyebrow">[[topology]]</div><div class="map-summary">${devices.length} device${devices.length === 1 ? '' : 's'} · ${virtualMachineCount} virtual machine${virtualMachineCount === 1 ? '' : 's'} · ${connectionsCount} logical connection${connectionsCount === 1 ? '' : 's'} · Green ports are connected</div>${connectionLegend}${modeLegend}</div><div class="map-tools">${viewControls}${deviceSearch}${vlanFilter}${roomFilter}${powerFilter}<div class="map-zoom-controls" role="group" aria-label="[[network_map_zoom_controls]]"><button class="button icon-only" type="button" data-map-zoom="-10" aria-label="[[zoom_out]]" title="[[zoom_out]]">−</button><input id="map-zoom-slider" type="range" min="1" max="200" step="1" value="${networkMapZoom}" aria-label="[[network_map_zoom]]"><span id="map-zoom-value" class="map-zoom-value">${networkMapZoom}%</span><button class="button icon-only" type="button" data-map-zoom="10" aria-label="[[zoom_in]]" title="[[zoom_in]]">+</button><button class="button" type="button" data-map-fit>[[fit_to_screen]]</button><button class="button" type="button" data-map-expand aria-expanded="${mapExpanded}">${mapExpanded ? t("close_large_map") : t("expand_map")}</button></div></div></div><section class="panel"><div class="network-map-scroll"><div class="network-map-stage"><svg class="network-map ${mapViewMode === 'vlan' ? 'vlan-view' : mapViewMode === 'power' ? 'power-view' : ''}" role="img" aria-label="${mapViewMode === 'vlan' ? 'VLAN filtered network topology' : 'Network topology'}" width="${svgWidth}" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}" xmlns="http://www.w3.org/2000/svg" style="width:${networkMapZoom}%;max-width:none"><title>[[network_topology_with_numbered_ports]]</title>${frames}${internetNode}${lines}${bridges}${nodes}${lagLabels}</svg></div></div></section></div><section class="panel" style="margin-top:14px"><div class="panel-head"><div><div class="panel-title">[[port_connections]]</div><div class="panel-sub">[[logical_lag_bundles_and_physical_port_members_including_direct_internet_access]]</div></div></div><div class="table-wrap"><table><thead><tr><th>[[device]]</th><th>[[port]]</th><th>[[connected_device]]</th><th>[[port]]</th></tr></thead><tbody>${connectionRows}</tbody></table></div></section>`;
  }
  function bindNetworkMapInteractions({ preserveViewport = false } = {}) {
    bindMapDeviceSearch(view, renderedData || getData(), selectedSearchDeviceId, id => { selectedSearchDeviceId = id; });
    const rerender = (focusSelector, { preserveViewport = true } = {}) => {
      const generation = ++renderGeneration;
      const currentScroll = view.querySelector('.network-map-scroll');
      const roomFilterOpen = view.querySelector('.rack-room-filter')?.open;
      const scrollLeft = currentScroll?.scrollLeft || 0;
      const scrollTop = currentScroll?.scrollTop || 0;
      view.setAttribute('aria-busy', 'true');
      renderAfterPaint(() => {
        if (generation !== renderGeneration || !currentScroll?.isConnected || view.querySelector('.network-map-scroll') !== currentScroll) return;
        try {
          view.innerHTML = renderNetworkMap();
          bindNetworkMapInteractions({ preserveViewport });
          const roomFilter = view.querySelector('.rack-room-filter');
          if (roomFilter && roomFilterOpen) roomFilter.open = true;
          const updatedScroll = view.querySelector('.network-map-scroll');
          if (updatedScroll && (preserveViewport || !usesELK())) {
            updatedScroll.scrollLeft = scrollLeft;
            updatedScroll.scrollTop = scrollTop;
          }
          if (focusSelector) view.querySelector(focusSelector)?.focus({ preventScroll: true });
        } finally { view.removeAttribute('aria-busy'); }
      }).catch(error => {
        if (generation !== renderGeneration) return;
        view.removeAttribute('aria-busy');
        onRenderError(error);
      });
    };
    view.querySelectorAll('[data-map-view-mode]').forEach(button => {
      button.addEventListener('click', () => {
        mapViewMode = button.dataset.mapViewMode;
        rerender(`[data-map-view-mode="${mapViewMode === 'elk' ? 'physical' : mapViewMode}"]`);
      });
    });
    elkObserver?.disconnect();
    if (!usesELK()) {elkTask?.cancel(); elkTask = null;}
    if (usesELK()) {
      const mounted = view.querySelector('.network-map-scroll');
      elkObserver = new MutationObserver(() => {
        if (!mounted?.isConnected) {elkTask?.cancel(); elkTask = null; elkObserver.disconnect();}
      });
      elkObserver.observe(view, {childList:true});
      if (!elkResult && !elkTask && !elkError && elkInput) {
        const key = elkKey;
        const task = runSharedELKLayout(elkInput); elkTask = task;
        task.promise.then(result => {
          if (elkTask !== task || !usesELK() || key !== elkKey || !mounted?.isConnected) return;
          elkTask = null; elkResult = result; rerender(undefined, { preserveViewport: false });
        }).catch(error => {
          if (elkTask !== task || !mounted?.isConnected) return;
          elkTask = null; elkError = error.message; rerender();
        });
      }
    }
    routingObserver?.disconnect();
    const routingMount = view.querySelector('.network-map-scroll');
    if (routingMounted !== routingMount) {routingTask?.cancel(); routingTask = null;}
    routingMounted = routingMount;
    if (mapViewMode === 'rack' || !routingMount) { routingTask?.cancel(); routingTask = null; }
    else if (typeof Worker !== 'undefined' && typeof MutationObserver !== 'undefined') {
      routingObserver = new MutationObserver(() => {
        if (!routingMount.isConnected) {routingTask?.cancel(); routingTask = null; routingObserver.disconnect();}
      });
      routingObserver.observe(view, {childList:true});
      // ELK changes node positions. Route remaining cables only after it settles.
      if ((!usesELK() || elkResult || elkError) && routingInput?.routes.some(route => !route.fixedPoints) &&
          !routingTask && !routingResult && !routingError) {
        const key = routingKey, input = routingInput;
        const task = runMapRouting(input); routingTask = task;
        task.promise.then(routes => {
          if (routingTask !== task || key !== routingKey || !routingMount.isConnected) return;
          routingTask = null;
          routingResult = new Map(input.routes.map((request,index) => [JSON.stringify(request),routes[index]]));
          rerender();
        }).catch(error => {
          if (routingTask !== task || !routingMount.isConnected) return;
          routingTask = null; routingError = error.message; rerender();
        });
      }
    }
    if (mapViewMode === 'room') view.querySelectorAll('[data-room-map-target]').forEach(button => {
      const navigate = () => {
        const roomId = button.dataset.roomMapTarget;
        if (roomId !== '' && !(getData().rooms || []).some(room => room.id === roomId)) return;
        selectedMapRoomId = roomId;
        selectedSearchDeviceId = null;
        rerender('[data-room-map-select]');
      };
      button.addEventListener('click', navigate);
      button.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); event.stopPropagation(); navigate(); }
      });
    });
    view.querySelector('[data-room-map-select]')?.addEventListener('change', event => { selectedMapRoomId = event.target.value === '__choose__' ? null : event.target.value; rerender(); });
    if (mapViewMode === 'power') bindPowerMap(view, selectedUpsIds);
    if (mapViewMode === 'rack') {
      view.querySelectorAll('[data-map-room]').forEach(input => input.addEventListener('change', () => {
        if (input.checked) selectedRoomIds.add(input.dataset.mapRoom); else selectedRoomIds.delete(input.dataset.mapRoom);
        rerender();
      }));
      view.querySelector('[data-map-all-rooms]')?.addEventListener('click', () => { selectedRoomIds.clear(); rerender(); });
      view.onkeydown = view.onpointerover = view.onpointerout = view.onfocusin = view.onfocusout = null;
      bindRackMapControls(view, {size: rackSize, onSize: value => { rackSize = value; }, expanded: mapExpanded, onExpanded: value => { mapExpanded = value; }});
      return;
    }
    const scroll = view.querySelector('.network-map-scroll');
    const svg = view.querySelector('.network-map');
    if (!scroll || !svg) return;
    let enlargedMap = null;
    let magnifying = false;
    let lastPointer = null;
    let lens = null;
    bindConnectionHighlights(view, svg, () => enlargedMap, () => { if (magnifying && lastPointer && lens) lens.hidden = false; });
    const slider = view.querySelector('#map-zoom-slider');
    const workspace = view.querySelector('.network-map-workspace');
    const expandButton = view.querySelector('[data-map-expand]');
    const applyZoom = zoom => {
      networkMapZoom = Math.round(Math.max(1, Math.min(200, zoom)));
      preserveMapViewport(scroll, svg, () => {
        svg.style.width = `${Number(svg.getAttribute('width')) * 2 * networkMapZoom / 100}px`;
        const stage = svg.closest('.network-map-stage');
        if (stage) {
          const scaledWidth = Number(svg.getAttribute('width')) * 2 * networkMapZoom / 100;
          const scaledHeight = Number(svg.getAttribute('height')) * 2 * networkMapZoom / 100;
          stage.style.width = `${Math.max(scroll.clientWidth, scaledWidth)}px`;
          stage.style.minHeight = `${Math.max(scroll.clientHeight, scaledHeight)}px`;
        }
      });
      slider.value = String(networkMapZoom);
      view.querySelector('#map-zoom-value').textContent = `${networkMapZoom}%`;
    };
    const magnifyButton = document.createElement('button');
    magnifyButton.type = 'button';
    magnifyButton.className = 'button map-magnify-button';
    magnifyButton.textContent = t("magnifier");
    magnifyButton.title = t("toggle_magnifying_glass");
    magnifyButton.setAttribute('aria-pressed', 'false');
    expandButton.before(magnifyButton);
    lens = document.createElement('div');
    lens.className = 'map-magnifying-lens';
    lens.setAttribute('aria-hidden', 'true');
    lens.hidden = true;
    workspace.append(lens);
    let lensFrame = 0, lastLensSize = 0, lastLensWidth = 0, lastLensHeight = 0;
    const moveLens = event => {
      if (!magnifying) return;
      lastPointer = { clientX: event.clientX, clientY: event.clientY };
      const bounds = svg.getBoundingClientRect();
      const viewport = scroll.getBoundingClientRect();
      if (event.clientX < viewport.left || event.clientX > viewport.right ||
          event.clientY < viewport.top || event.clientY > viewport.bottom) {
        lens.hidden = true;
        return;
      }
      const container = workspace.getBoundingClientRect();
      const size = Math.min(200, viewport.width - 16);
      const left = Math.max(viewport.left + 4, Math.min(event.clientX - size / 2, viewport.right - size - 4));
      const top = Math.max(viewport.top + 4, Math.min(event.clientY - size / 2, viewport.bottom - size - 4));
      if (size !== lastLensSize) {lens.style.width = lens.style.height = `${size}px`; lastLensSize = size;}
      lens.style.left = `${left - container.left}px`;
      lens.style.top = `${top - container.top}px`;
      if (bounds.width !== lastLensWidth || bounds.height !== lastLensHeight) {
        enlargedMap.style.width = `${bounds.width * 3}px`;
        enlargedMap.style.height = `${bounds.height * 3}px`;
        lastLensWidth = bounds.width; lastLensHeight = bounds.height;
      }
      enlargedMap.style.transform = `translate(${size / 2 - (event.clientX - bounds.left) * 3}px, ${size / 2 - (event.clientY - bounds.top) * 3}px)`;
      lens.hidden = false;
    };
    magnifyButton.addEventListener('click', () => {
      magnifying = !magnifying;
      magnifyButton.setAttribute('aria-pressed', String(magnifying));
      magnifyButton.classList.toggle('active', magnifying);
      scroll.classList.toggle('is-magnifying', magnifying);
      lens.hidden = true;
      if (magnifying) {
        enlargedMap = svg.cloneNode(true);
        lastLensWidth = lastLensHeight = 0;
        enlargedMap.setAttribute('class', `map-magnified-copy${svg.classList.contains('power-view') ? ' power-view' : ''}${svg.classList.contains('has-link-focus') ? ' has-link-focus' : ''}`);
        enlargedMap.removeAttribute('role');
        enlargedMap.setAttribute('aria-hidden', 'true');
        lens.replaceChildren(enlargedMap);
        const bounds = scroll.getBoundingClientRect();
        moveLens({ clientX: bounds.left + bounds.width / 2, clientY: bounds.top + bounds.height / 2 });
      } else {
        lens.replaceChildren();
        enlargedMap = null;
      }
    });
    const scheduleLens = event => {
      if (!magnifying) return;
      lastPointer = {clientX:event.clientX,clientY:event.clientY};
      if (lensFrame) return;
      lensFrame = requestAnimationFrame(() => {
        lensFrame = 0;
        if (scroll.isConnected && magnifying && lastPointer) moveLens(lastPointer);
      });
    };
    scroll.addEventListener('pointermove', scheduleLens, {passive:true});
    scroll.addEventListener('pointerdown', scheduleLens, {passive:true});
    scroll.addEventListener('scroll', () => {
      if (magnifying && lastPointer && !lens.hidden) scheduleLens(lastPointer);
    }, {passive:true});
    workspace.addEventListener('keydown', event => {
      if (event.key === 'Escape' && magnifying) {
        event.stopImmediatePropagation();
        magnifyButton.click();
        magnifyButton.focus();
      }
    });
    view.onkeydown = event => {
      if (event.key === 'Escape' && magnifying && !workspace.contains(event.target)) {
        magnifyButton.click();
        magnifyButton.focus();
      }
    };
    view.querySelectorAll('[data-map-vlan]').forEach(input => {
      input.addEventListener('change', () => {
        if (input.checked) selectedVlanIds.add(input.dataset.mapVlan);
        else selectedVlanIds.delete(input.dataset.mapVlan);
        rerender(`[data-map-vlan="${input.dataset.mapVlan}"]`);
      });
    });
    slider.addEventListener('input', () => applyZoom(Number(slider.value)));
    view.querySelectorAll('[data-map-zoom]').forEach(button => {
      button.addEventListener('click', () => applyZoom(networkMapZoom + Number(button.dataset.mapZoom)));
    });
    const fitMap = () => {
      const availableWidth = Math.max(1, scroll.clientWidth - 24);
      const availableHeight = Math.max(1, scroll.clientHeight - 24);
      const fit = Math.min(availableWidth / Number(svg.getAttribute('width')), availableHeight / Number(svg.getAttribute('height'))) * 100;
      applyZoom(fit / 2);
      scroll.scrollLeft = Math.max(0, (scroll.scrollWidth - scroll.clientWidth) / 2);
      scroll.scrollTop = 0;
    };
    view.querySelector('[data-map-fit]').addEventListener('click', fitMap);
    const setExpanded = expanded => {
      mapExpanded = expanded;
      workspace.classList.toggle('is-expanded', expanded);
      expandButton.textContent = expanded ? 'Close large map' : 'Expand map';
      expandButton.setAttribute('aria-expanded', String(expanded));
      fitMap();
      expandButton.focus();
    };
    expandButton.addEventListener('click', () => setExpanded(!mapExpanded));
    workspace.addEventListener('keydown', event => {
      if (event.key === 'Escape' && mapExpanded) {
        event.preventDefault();
        setExpanded(false);
      }
      if (event.key === 'Tab' && mapExpanded) {
        const controls = [...workspace.querySelectorAll('button, input')].filter(control => !control.closest('[hidden]'));
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    });
    let viewportWidth = scroll.clientWidth, viewportHeight = scroll.clientHeight, resizeFrame = 0;
    const resizeObserver = new ResizeObserver(() => {
      const width = scroll.clientWidth, height = scroll.clientHeight;
      if (width === viewportWidth && height === viewportHeight) return;
      viewportWidth = width; viewportHeight = height;
      if (resizeFrame) return;
      resizeFrame = requestAnimationFrame(() => {
        resizeFrame = 0;
        if (scroll.isConnected) applyZoom(networkMapZoom);
      });
    });
    resizeObserver.observe(scroll);
    // Release the observer when the map is replaced or navigation removes it.
    const removalObserver = new MutationObserver(() => {
      if (!scroll.isConnected) {
        resizeObserver.disconnect();
        if (lensFrame) cancelAnimationFrame(lensFrame);
        if (resizeFrame) cancelAnimationFrame(resizeFrame);
        removalObserver.disconnect();
      }
    });
    removalObserver.observe(view, { childList: true, subtree: true });
    if (usesELK() && elkResult && !preserveViewport) fitMap(); else applyZoom(networkMapZoom);

  }
  return { renderNetworkMap, bindNetworkMapInteractions };
}
