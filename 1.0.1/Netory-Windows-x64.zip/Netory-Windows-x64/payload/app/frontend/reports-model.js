export const reportColumns = {
  assets: ['name','type','status','manufacturer','location','hostname','ip','serial','warrantyExpiry'],
  licenses: ['product','vendor','type','seats','assigned','available','expiry','owner'],
  warranty: ['name','type','location','warrantyExpiry','daysRemaining'],
  quality: ['name','type','location','missing'],
};
export function daysUntil(value, now = new Date()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return null;
  const date = new Date(`${value}T00:00:00Z`);
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0,10) !== value) return null;
  return Math.round((date - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
}
export function buildReport(data, options = {}, now = new Date()) {
  const type = Object.hasOwn(reportColumns, options.type) ? options.type : 'overview';
  const term = String(options.search || '').trim().toLowerCase();
  const assets = (data.assets || []).filter(row => (!options.status || row.status === options.status) && (!options.assetType || row.type === options.assetType) && (!options.location || row.location === options.location) && (!term || reportColumns.assets.some(key => String(row[key] || '').toLowerCase().includes(term))));
  const licenses = (data.licenses || []).filter(row => !term || ['product','vendor','owner','type'].some(key => String(row[key] || '').toLowerCase().includes(term))).map(row => ({...row, available: Number(row.seats || 0) - Number(row.assigned || 0)}));
  const horizon = [30,60,90,180,365].includes(Number(options.horizon)) ? Number(options.horizon) : 90;
  const expiry = row => daysUntil(row.expiry,now);
  const due = value => value !== null && value <= horizon;
  const warranty = assets.map(row => ({...row,daysRemaining:daysUntil(row.warrantyExpiry,now)})).filter(row => due(row.daysRemaining)).sort((a,b)=>a.daysRemaining-b.daysRemaining);
  const quality = assets.map(row=>({...row,missing:['name','type','status','manufacturer','serial','location'].filter(key=>!String(row[key] || '').trim()).join(', ')})).filter(row=>row.missing);
  const licenseRows = options.expiryOnly ? licenses.filter(row=>due(expiry(row))) : licenses;
  const groupBy = ['type','status','manufacturer','location'].includes(options.groupBy) ? options.groupBy : 'type';
  const counts = new Map();
  for (const row of assets) {const label = row[groupBy] || 'Not specified';counts.set(label,(counts.get(label)||0)+1);}
  const groups = [...counts].map(([group,count])=>({group,count,share:assets.length ? `${(100*count/assets.length).toFixed(1)}%` : '0%'})).sort((a,b)=>b.count-a.count || a.group.localeCompare(b.group));
  const metrics = [['Assets',assets.length],['Licenses',licenses.length],['Assigned seats',licenses.reduce((sum,row)=>sum+Number(row.assigned||0),0)],['Licenses expired / due',licenses.filter(row=>due(expiry(row))).length],['Warranties expired / due',warranty.length],['Assets missing details',quality.length]];
  const rows = type==='licenses' ? licenseRows : type==='warranty' ? warranty : type==='quality' ? quality : type==='assets' ? assets : groups;
  const allowed = reportColumns[type] || ['group','count','share'];
  const selected = (Array.isArray(options.columns) ? options.columns : []).filter(key=>allowed.includes(key));
  return {type,metrics,groups,rows,columns:selected.length ? selected : allowed,horizon};
}
export function csvReport(columns, rows, headings = columns) {
  const cell = value => {let text=String(value ?? '');if (/^[\s]*[=+@-]/.test(text)) text=`'${text}`;return `"${text.replaceAll('"','""')}"`;};
  return '\uFEFF'+[headings,...rows.map(row=>columns.map(key=>row[key]))].map(row=>row.map(cell).join(',')).join('\r\n');
}
