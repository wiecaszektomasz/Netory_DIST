import { html, t } from './i18n.js?v=20261015-map-admin2';
export function createAssistant({ apiRequest, getEnvironment, getUser, onApplied }) {
  const root = document.createElement('div');
  root.id = 'assistant-root';
  root.hidden = true;
  document.body.append(root);
  const icon = name => html`<img src="/frontend/icons/${name}.svg" alt="" width="18" height="18">`;
  root.innerHTML = html`<button class="assistant-launcher" type="button" aria-label="[[open_netory_assistant]]" title="[[netory_assistant]]" aria-expanded="false">${icon('sparkles')}</button><section class="assistant-panel" aria-label="[[netory_assistant]]" hidden><header class="assistant-header"><span class="assistant-avatar">${icon('sparkles')}</span><div><strong>[[netory_assistant]]</strong><div class="assistant-scope"></div></div><button class="assistant-icon-button" type="button" data-assistant-clear title="[[new_chat]]" aria-label="[[new_chat]]">${icon('square-pen')}</button><button class="assistant-icon-button" type="button" data-assistant-close title="[[close_assistant]]" aria-label="[[close_assistant]]">${icon('x')}</button></header><div class="assistant-meta"></div><div class="assistant-messages" role="log" aria-live="polite"></div><div class="assistant-error" role="alert" hidden></div><div class="assistant-write-controls" hidden><label><input type="checkbox" data-write-mode> [[propose_inventory_changes]]</label><label data-attachment-label hidden>[[attach_csv_tsv_json_xml_yaml_or_text_sent_to_ai_provider]]<input type="file" data-attachment accept=".csv,.tsv,.json,.jsonl,.ndjson,.txt,.md,.xml,.yaml,.yml" aria-label="[[attach_inventory_file]]"></label><span data-attachment-name></span></div><form class="assistant-compose"><textarea aria-label="[[message_netory_assistant]]" placeholder="[[ask_about_this_environment]]" rows="2" maxlength="6000"></textarea><button class="assistant-send" type="submit" aria-label="[[send_message]]" title="[[send_message]]">${icon('arrow-up')}</button></form><div class="assistant-footnote">[[read_only_ai_answers_may_be_inaccurate]]</div></section>`;
  const panel = root.querySelector('.assistant-panel');
  const launcher = root.querySelector('.assistant-launcher');
  const log = root.querySelector('.assistant-messages');
  const input = root.querySelector('textarea');
  const send = root.querySelector('.assistant-send');
  const error = root.querySelector('.assistant-error');
  const writeMode = root.querySelector('[data-write-mode]');
  const fileInput = root.querySelector('[data-attachment]');
  let attachment = null;
  let environmentId = null;
  let contextUserId = null;
  let modeContext = null;
  let writableAllowed = false;
  writeMode.addEventListener('change', () => {
    clear();
    updateMode();
  });
  fileInput.addEventListener('change', async () => {
    attachment = null;
    root.querySelector('[data-attachment-name]').textContent = '';
    const file = fileInput.files[0];
    if (!file) return;
    try {
      if (!/\.(csv|tsv|json|jsonl|ndjson|txt|md|xml|yaml|yml)$/i.test(file.name) || file.size > 40000) throw new Error(t("choose_a_csv_tsv_json_xml_yaml_markdown_or_text_file_up_to_40_kb_export_excel_files_as_csv"));
      const fileGeneration = generation;
      const content = await file.text();
      if (generation !== fileGeneration || fileInput.files[0] !== file) return;
      if (!content.trim() || content.includes('\0')) throw new Error(t("choose_a_non_empty_text_file"));
      attachment = { name: file.name.slice(0, 160), content };
      root.querySelector('[data-attachment-name]').textContent = file.name;
    } catch (failure) { fileInput.value = ''; error.textContent = failure.message; error.hidden = false; }
  });
  let messages = [];
  let busy = false;
  let available = false;
  let generation = 0;
  function append(role, content) {
    const article = document.createElement('article');
    article.className = `assistant-message assistant-message-${role}`;
    const label = document.createElement('strong');
    label.textContent = role === 'user' ? t('You') : 'Netory';
    const text = document.createElement('div');
    text.textContent = content;
    article.append(label, text);
    log.append(article);
    log.scrollTop = log.scrollHeight;
    return article;
  }
  function setWriteAccess(allowed) {
    if (writableAllowed !== allowed) {
      writeMode.checked = allowed;
      writableAllowed = allowed;
    }
    root.querySelector('.assistant-write-controls').hidden = !allowed;
    if (!allowed) {
      writeMode.checked = false;
      attachment = null;
      fileInput.value = '';
      root.querySelector('[data-attachment-name]').textContent = '';
    }
    root.querySelectorAll('[data-assistant-apply]').forEach(button => { button.disabled = busy || !allowed || button.dataset.applied === 'true'; });
    updateMode();
  }
  function updateMode() {
    root.querySelector('[data-attachment-label]').hidden = !writeMode.checked;
    root.querySelector('.assistant-footnote').textContent = t(writeMode.checked ? 'Review and apply proposals · Files and messages go to the AI provider' : 'Read-only · AI answers may be inaccurate');
    input.placeholder = t(writeMode.checked ? 'Ask a question or describe an inventory change...' : 'Ask about this environment...');
  }
  function clear() {
    generation += 1;
    messages = [];
    busy = false;
    log.replaceChildren();
    input.value = '';
    attachment = null;
    fileInput.value = '';
    root.querySelector('[data-attachment-name]').textContent = '';
    error.hidden = true;
    append('assistant', writeMode.checked ? 'I can answer questions and propose creating or editing devices, licenses, networks, and other inventory records. Describe a device or attach an inventory file, then review and apply the proposed changes.' : 'What would you like to know about this environment?');
    controls();
  }
  function controls() {
    input.disabled = busy || !available;
    writeMode.disabled = busy;
    fileInput.disabled = busy;
    send.disabled = busy || !available || !input.value.trim();
    root.querySelector('[data-assistant-clear]').disabled = busy;
  }
  async function refreshStatus() {
    const token = generation;
    const env = getEnvironment();
    if (!env) return;
    root.querySelector('.assistant-meta').textContent = t("checking_connection");
    try {
      const status = await apiRequest(`/api/assistant/status?environment_id=${encodeURIComponent(env.id)}`);
      if (generation !== token) return;
      available = status.available;
      setWriteAccess(Boolean(status.write_allowed));
      root.querySelector('.assistant-meta').textContent = status.available ? t('message_44', {0: (status.provider), 1: (status.model), 2: (status.remaining)}) : status.message;
    } catch (failure) {
      if (generation !== token) return;
      available = false;
      root.querySelector('.assistant-meta').textContent = failure.message;
    }
    controls();
  }
  function close() {
    panel.hidden = true;
    launcher.setAttribute('aria-expanded', 'false');
  }
  launcher.addEventListener('click', async () => {
    if (!panel.hidden) { close(); return; }
    panel.hidden = false;
    launcher.setAttribute('aria-expanded', 'true');
    await refreshStatus();
    if (available) input.focus();
  });
  root.querySelector('[data-assistant-close]').addEventListener('click', close);
  root.querySelector('[data-assistant-clear]').addEventListener('click', clear);
  input.addEventListener('input', controls);
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); if (!send.disabled) root.querySelector('form').requestSubmit(); }
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !panel.hidden) close(); });
  root.querySelector('form').addEventListener('submit', async event => {
    event.preventDefault();
    const content = input.value.trim();
    if (!content || busy || !available) return;
    const env = getEnvironment();
    const token = generation;
    const history = messages.slice(-18).map(message => ({ role: message.role, content: message.content.slice(0, 6000) }));
    history.push({ role: 'user', content });
    append('user', content);
    input.value = '';
    error.hidden = true;
    busy = true;
    controls();
    const pending = append('assistant', 'Thinking...');
    pending.classList.add('assistant-pending');
    try {
      const response = await apiRequest('/api/assistant/chat', { method: 'POST', body: JSON.stringify({ environment_id: env.id, messages: history, write_mode: writeMode.checked, attachment }) });
      if (token !== generation) return;
      pending.remove();
      messages = [...history, { role: 'assistant', content: response.answer }];
      append('assistant', response.answer);
      if (response.proposal_token) {
        const changeCount = response.changes.length;
        const deviceCount = new Set(response.changes.filter(change => change.operation === 'update' && !change.section).map(change => change.asset_id)).size;
        const review = append('assistant', t('message_45', {0: (changeCount), 1: (changeCount === 1 ? '' : 's'), 2: (deviceCount), 3: (deviceCount === 1 ? '' : 's')}) + JSON.stringify(response.changes, null, 2));
        const apply = document.createElement('button');
        apply.dataset.assistantApply = '';
        apply.type = 'button'; apply.className = 'button primary'; apply.textContent = t("apply_these_changes");
        review.append(apply);
        apply.addEventListener('click', async () => {
          if (busy || token !== generation || !writableAllowed) return;
          busy = true; controls(); apply.disabled = true; error.hidden = true;
          try {
            const result = await apiRequest('/api/assistant/apply', {method: 'POST', body: JSON.stringify({token: response.proposal_token})});
            if (token !== generation) return;
            onApplied?.(env.id, result);
            apply.textContent = t('{count} changes saved', {count: changeCount});
            apply.dataset.applied = 'true';
          } catch (failure) {
            if (token !== generation) return;
            error.textContent = failure.message; error.hidden = false; apply.disabled = false;
          } finally { if (token === generation) { busy = false; controls(); } }
        });
      }
    } catch (failure) {
      if (token !== generation) return;
      pending.remove();
      error.textContent = failure.message;
      error.hidden = false;
      input.value = content;
    } finally {
      if (token === generation) { busy = false; await refreshStatus(); controls(); }
    }
  });
  return {
    sync() {
      updateMode();
      const controls = [
        ['.assistant-launcher', 'Open Netory assistant'], ['[data-assistant-clear]', 'New chat'],
        ['[data-assistant-close]', 'Close assistant'], ['.assistant-send', 'Send message'],
        ['.assistant-panel', 'Netory assistant'], ['textarea', 'Message Netory assistant'],
        ['[data-attachment]', 'Attach inventory file'],
      ];
      for (const [selector, key] of controls) {
        const control = root.querySelector(selector);
        control?.setAttribute('aria-label', t(key));
        control?.setAttribute('title', t(key));
      }
      const heading = root.querySelector('.assistant-header strong');
      if (heading) heading.textContent = t('Netory assistant');

      const env = getEnvironment();
      const visible = Boolean(getUser() && env);
      root.hidden = !visible;
      const user = getUser();
      const userChanged = contextUserId !== (user?.id ?? null);
      contextUserId = user?.id ?? null;
      const nextModeContext = `${user?.id ?? ''}:${env?.id ?? ''}:${Boolean(user?.is_admin || user?.assistant_write_enabled)}:${env?.role ?? ''}`;
      if (modeContext !== nextModeContext) {
        modeContext = nextModeContext;
        setWriteAccess(Boolean(user?.is_admin || (user?.assistant_write_enabled && env?.role === 'editor')));
      }
      if (!visible) { close(); available = false; environmentId = null; clear(); return; }
      if (environmentId !== env.id || userChanged) {
        environmentId = env.id;
        available = false;
        clear();
        root.querySelector('.assistant-scope').textContent = env.name;
        if (!panel.hidden) refreshStatus();
      }
    }
  };
}
