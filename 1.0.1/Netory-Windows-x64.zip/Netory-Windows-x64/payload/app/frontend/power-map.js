import { html, t } from './i18n.js?v=20261015-map-admin2';
import {esc} from './utils.js?v=20261015-map-admin2';

export function renderPowerFilter(data, selectedUpsIds) {
  const devices = (data.assets || []).filter(asset=>asset.type === 'UPS');
  const available = new Set(devices.map(asset=>asset.id));
  for (const id of selectedUpsIds) if (!available.has(id)) selectedUpsIds.delete(id);
  return html`<div class="map-vlan-filter"><strong>[[backup_ups]]</strong>${devices.map(ups=>html`<label><input type="checkbox" data-map-ups="${esc(ups.id)}" ${selectedUpsIds.has(ups.id) ? 'checked' : ''}>${esc(ups.name)}</label>`).join('') || html(["<span class=\"secondary-cell\">[[no_ups_devices_configured]]</span>"])}<span class="map-vlan-hint">[[select_a_ups_to_highlight_devices_assigned_to_it_for_backup_power]]</span></div>`;
}

export function powerDeviceAttributes(device, selectedUpsIds) {
  if (device.isStack) return '';
  const upsId = device.backupPowerEnabled ? device.backupUpsId || '' : '';
  return `data-power-device="${esc(device.id)}" data-backup-ups-id="${esc(upsId)}" data-power-highlight="${Boolean(upsId && selectedUpsIds.has(upsId))}"`;
}

export function bindPowerMap(view, selectedUpsIds) {
  view.querySelectorAll('[data-map-ups]').forEach(input=>input.addEventListener('change',()=>{
    if(input.checked) selectedUpsIds.add(input.dataset.mapUps);
    else selectedUpsIds.delete(input.dataset.mapUps);
    // Includes the magnifier copy when it is open.
    view.querySelectorAll('[data-power-device]').forEach(device=>{
      device.setAttribute('data-power-highlight',String(Boolean(device.dataset.backupUpsId && selectedUpsIds.has(device.dataset.backupUpsId))));
    });
  }));
}
