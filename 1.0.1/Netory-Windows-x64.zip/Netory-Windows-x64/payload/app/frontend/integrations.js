import { esc } from './utils.js';

export function filterHostRows(root, value) {
  const terms = value.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  let visible = 0;
  const rows = [...root.querySelectorAll('[data-host-search]')];
  for (const row of rows) {
    row.hidden = !terms.every(term => row.dataset.hostSearch.includes(term));
    if (!row.hidden) visible++;
  }
  const count = root.querySelector('[data-host-count]');
  if (count) count.textContent = `${visible} of ${rows.length} hosts`;
  const empty = root.querySelector('[data-host-no-match]');
  if (empty) empty.hidden = visible !== 0;
  const all = root.querySelector('[data-select-all]');
  const available = rows.filter(row => !row.hidden).flatMap(row => [...row.querySelectorAll('[name="host_ids"]:not(:disabled)')]);
  if (all) {
    const checked = available.filter(input => input.checked).length;
    all.checked = available.length > 0 && checked === available.length;
    all.indeterminate = checked > 0 && checked < available.length;
  }
}

const assetTypes = ['Physical server', 'Virtual server', 'Switch', 'Router', 'Firewall / UTM', 'Network device', 'Access point', 'Wi-Fi controller', 'Storage', 'Computer', 'Printer', 'UPS', 'Other'];

export async function renderIntegrations({root, environmentId, canEdit, isAdmin, apiRequest, isCurrent, onChanged}) {
  const base = `/api/environments/${encodeURIComponent(environmentId)}/integrations/zabbix`;
  let config = null, groups = [], hosts = [], selectedGroup = '', message = '', busy = false;
  let showSettings = false, showHosts = false, query = '';
  const selected = new Set(), overrides = new Map();
  const request = (suffix, method = 'GET', body) => apiRequest(base + suffix, {method, ...(body ? {body: JSON.stringify(body)} : {})});
  const run = async action => {
    if (busy) return;
    busy = true;
    root.querySelectorAll('button, input, select').forEach(el => { el.disabled = true; });
    try { await action(); } catch (error) { message = error.message; }
    finally { busy = false; if (isCurrent()) draw(); }
  };
  const discover = async () => {
    groups = await request('/groups');
    hosts = await request(`/hosts?group_id=${encodeURIComponent(selectedGroup)}`);
  };
  const feedback = () => message ? `<p class="integration-feedback" role="status">${esc(message)}</p>` : '';
  const draw = () => {
    if (!isCurrent()) return;
    const insecure = config?.url.startsWith('http:');
    root.innerHTML = `<div class="integration-page"><header class="integration-page-header"><h2>Zabbix integration</h2><p>Connect Zabbix and review hosts before importing them into this client's infrastructure.</p></header>
      ${feedback()}
      <section class="panel integrations-panel integration-summary"><div class="integration-section-header"><h3>Zabbix data source</h3><p>${config ? esc(config.url) : 'No connection configured'}</p></div>
      ${config ? `<p>${config.enabled ? 'Automatic sync enabled' : 'Automatic sync paused'} · Every ${config.interval_minutes} minutes · ${config.imported_count} linked hosts</p><p class="secondary-cell">Last attempt: ${config.last_sync ? esc(new Date(/(?:Z|[+-]\d{2}:\d{2})$/.test(config.last_sync) ? config.last_sync : config.last_sync + 'Z').toLocaleString()) : 'Never'}</p>${config.last_error ? `<p role="alert">${esc(config.last_error)}</p>` : ''}` : '<p>Add the connection in settings, then review and select hosts to import.</p>'}
      ${insecure ? '<p class="integration-warning" role="alert">Warning: HTTP sends your API token and host data without encryption. Use HTTPS where possible.</p>' : ''}
      <div class="row-actions"><button class="button" data-settings>Connection settings</button>${config && canEdit ? '<button class="button" data-test>Test connection</button><button class="button primary" data-discover>Review discovered hosts</button><button class="button" data-sync>Sync linked assets now</button>' : ''}</div></section>
      <dialog class="integration-dialog integration-settings-dialog" data-settings-dialog aria-labelledby="integration-config-heading"><div class="integration-dialog-head"><div><h3 id="integration-config-heading">Connection settings</h3><p>API access and automatic synchronization.</p></div><button class="button" type="button" data-settings-close>Close</button></div><div class="integration-dialog-body integration-configuration">
      ${feedback()}
      ${isAdmin ? `<form data-connection class="form-grid"><label>Zabbix URL<input name="url" type="url" required maxlength="500" placeholder="https://zabbix.example.com/zabbix" value="${esc(config?.url || '')}" ${config ? 'readonly' : ''}></label><p data-http-warning class="integration-warning" role="alert" hidden>Warning: HTTP sends your API token and host data without encryption. Anyone able to intercept this connection can read them. Use HTTPS where possible.</p><label>API token<input name="api_key" type="password" autocomplete="new-password" ${config ? '' : 'required'} placeholder="${config ? 'Leave blank to keep saved token' : ''}"></label><label>Sync interval (minutes)<input name="interval_minutes" type="number" min="1" max="1440" required value="${config?.interval_minutes || 15}"></label><label><input name="enabled" type="checkbox" ${config?.enabled !== false ? 'checked' : ''}> Automatic synchronization</label><div><button class="button primary" type="submit">Save connection</button>${config ? ' <button class="button" type="button" data-disconnect>Disconnect</button>' : ''}</div></form><p class="secondary-cell">Use an API token with read access to host groups, hosts and items. HTTP is supported with a warning; HTTPS requires a trusted certificate. Tokens are encrypted on the server. Disconnecting retains imported assets.</p>` : '<p class="secondary-cell">An administrator manages this connection.</p>'}
      </div></dialog>
      <dialog class="integration-dialog integration-review-dialog" data-host-dialog aria-labelledby="integration-discovery-heading"><div class="integration-dialog-head"><div><h3 id="integration-discovery-heading">Discovered hosts (${hosts.length})</h3><p>Review each detected type, adjust the import type, then select hosts to add.</p></div><button class="button" type="button" data-review-close>Close</button></div><div class="integration-dialog-body">
      ${feedback()}
      <p class="secondary-cell">Types are suggested from Zabbix templates and inventory. Review the import type for every selected host. Linked assets keep their existing type. Unlinking stops Zabbix updates and keeps the imported asset.</p>
      <div class="integration-review-filters"><label>Host group<select data-group><option value="">All host groups</option>${groups.map(g => `<option value="${esc(g.groupid)}" ${selectedGroup === g.groupid ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></label><label>Search hosts<input type="search" data-host-filter value="${esc(query)}" placeholder="Name, hostname, IP, type or template…"></label><button class="button" type="button" data-refresh-hosts>Refresh hosts</button></div>
      <form data-import><div class="integration-host-toolbar"><label class="integration-select-all"><input type="checkbox" data-select-all> Select all matching hosts</label><span class="secondary-cell" data-host-count>${hosts.length} of ${hosts.length} hosts</span></div>
      <div class="integration-host-table-wrap"><table class="integration-host-table"><thead><tr><th scope="col">Select</th><th scope="col">Host / hostname</th><th scope="col">IP address</th><th scope="col">Detected type</th><th scope="col">Import as</th><th scope="col">Templates</th><th scope="col">Status</th></tr></thead><tbody>
      ${hosts.map(h => { const detected = h.detected_type || 'Other'; const type = overrides.get(h.id) || h.asset_type || detected; return `<tr data-host-search="${esc([h.name, h.hostname, h.ip || '', detected, h.id, ...h.templates].join(' ').toLocaleLowerCase())}"><td><input type="checkbox" name="host_ids" value="${esc(h.id)}" aria-label="Select ${esc(h.name)}" ${h.imported ? 'disabled' : ''} ${selected.has(h.id) ? 'checked' : ''}></td><td><span class="integration-host-name">${esc(h.name)}</span><div class="secondary-cell">${esc(h.hostname)}</div></td><td>${esc(h.ip || '—')}</td><td>${esc(detected)}</td><td><select data-host-type="${esc(h.id)}" aria-label="Import type for ${esc(h.name)}" ${h.imported ? 'disabled' : ''}>${assetTypes.map(t => `<option value="${esc(t)}" ${t === type ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></td><td class="integration-template-cell" title="${esc(h.templates.join(', '))}">${esc(h.templates.join(', ')) || '—'}</td><td>${h.imported ? `<span class="tag">Linked</span>${canEdit ? ` <button class="button" type="button" data-unlink-host="${esc(h.id)}" aria-label="Unlink ${esc(h.name)}">Unlink</button>` : ''}` : 'Available'}</td></tr>`; }).join('')}
      </tbody></table></div><p class="secondary-cell" data-host-no-match ${hosts.length ? 'hidden' : ''}>No hosts match your search.</p>
      <div class="integration-dialog-foot"><span class="secondary-cell" data-selected-count>${hosts.filter(h => !h.imported && selected.has(h.id)).length} selected</span><button class="button primary" type="submit">Import selected hosts</button></div></form></div></dialog></div>`;
    const settingsDialog = root.querySelector('[data-settings-dialog]');
    const hostDialog = root.querySelector('[data-host-dialog]');
    if (showSettings) settingsDialog?.showModal?.();
    if (showHosts) hostDialog?.showModal?.();
    settingsDialog?.addEventListener('cancel', () => { showSettings = false; });
    hostDialog?.addEventListener('cancel', () => { showHosts = false; });
    root.querySelector('[data-settings]')?.addEventListener('click', () => { showSettings = true; draw(); });
    root.querySelector('[data-settings-close]')?.addEventListener('click', () => { showSettings = false; settingsDialog?.close?.(); root.querySelector('[data-settings]')?.focus?.(); });
    root.querySelector('[data-review-close]')?.addEventListener('click', () => { showHosts = false; hostDialog?.close?.(); root.querySelector('[data-discover]')?.focus?.(); });
    const urlInput = root.querySelector('[name="url"]');
    const updateWarning = () => {
      const warning = root.querySelector('[data-http-warning]');
      if (warning) warning.hidden = !/^http:/i.test(urlInput?.value.trim() || '');
    };
    urlInput?.addEventListener('input', updateWarning);
    updateWarning();
    root.querySelector('[data-connection]')?.addEventListener('submit', event => {
      event.preventDefault();
      const values = new FormData(event.currentTarget);
      run(async () => {
        config = await request('', 'PUT', {url: values.get('url'), api_key: values.get('api_key') || null, interval_minutes: Number(values.get('interval_minutes')), enabled: values.has('enabled')});
        showSettings = false;
        message = 'Connection saved.';
        await discover(); showHosts = true;
        message = `Found ${hosts.length} hosts. Review types and select hosts to import.`;
      });
    });
    root.querySelector('[data-disconnect]')?.addEventListener('click', () => {
      if (!confirm('Disconnect Zabbix and stop automatic updates? Imported assets will remain.')) return;
      run(async () => { await request('', 'DELETE'); config = null; groups = []; hosts = []; selected.clear(); overrides.clear(); showSettings = false; showHosts = false; message = 'Disconnected.'; });
    });
    root.querySelector('[data-test]')?.addEventListener('click', () => run(async () => { const result = await request('/test', 'POST'); message = result.message; }));
    root.querySelector('[data-discover]')?.addEventListener('click', () => run(async () => { await discover(); showHosts = true; message = ''; }));
    root.querySelectorAll('[data-unlink-host]').forEach(button => button.addEventListener('click', () => run(async () => {
      const id = button.dataset.unlinkHost;
      await request(`/hosts/${encodeURIComponent(id)}`, 'DELETE');
      hosts = hosts.map(host => host.id === id ? {...host, imported: false} : host);
      selected.delete(id); overrides.delete(id);
      message = 'Host unlinked. The imported asset was kept and will no longer receive Zabbix updates.';
      config = await request('');
    })));
    root.querySelector('[data-refresh-hosts]')?.addEventListener('click', () => run(discover));
    root.querySelector('[data-sync]')?.addEventListener('click', () => run(async () => { const result = await request('/sync', 'POST'); await onChanged(); config = await request(''); message = `Updated ${result.updated} assets.${result.missing.length ? ` ${result.missing.length} hosts unavailable; existing assets retained.` : ''}`; }));
    root.querySelector('[data-group]')?.addEventListener('change', event => {
      selectedGroup = event.target.value;
      run(discover);
    });
    const applyFilter = () => {
      query = root.querySelector('[data-host-filter]')?.value || '';
      filterHostRows(root, query);
      const count = root.querySelector('[data-selected-count]');
      if (count) count.textContent = `${hosts.filter(h => !h.imported && selected.has(h.id)).length} selected`;
    };
    root.querySelector('[data-host-filter]')?.addEventListener('input', applyFilter);
    root.querySelectorAll('[name="host_ids"]').forEach(input => input.addEventListener('change', () => {
      if (input.checked) selected.add(input.value); else selected.delete(input.value);
      applyFilter();
    }));
    root.querySelectorAll('[data-host-type]').forEach(input => input.addEventListener('change', () => overrides.set(input.dataset.hostType, input.value)));
    root.querySelector('[data-select-all]')?.addEventListener('change', event => {
      root.querySelectorAll('[data-host-search]').forEach(row => {
        if (!row.hidden) row.querySelectorAll('[name="host_ids"]:not(:disabled)').forEach(input => {
          input.checked = event.target.checked;
          if (input.checked) selected.add(input.value); else selected.delete(input.value);
        });
      });
      applyFilter();
    });
    root.querySelector('[data-import]')?.addEventListener('submit', event => {
      event.preventDefault();
      const ids = hosts.filter(h => !h.imported && selected.has(h.id)).map(h => h.id);
      if (!ids.length) { message = 'Select at least one host.'; draw(); return; }
      const types = Object.fromEntries(ids.map(id => [id, overrides.get(id) || hosts.find(h => h.id === id).asset_type || hosts.find(h => h.id === id).detected_type || 'Other']));
      run(async () => {
        const result = await request('/import', 'POST', {host_ids: ids, asset_types: types});
        await onChanged(); config = await request(''); await discover();
        ids.forEach(id => selected.delete(id));
        message = `Imported / updated ${result.updated} assets.${result.missing.length ? ` ${result.missing.length} hosts unavailable.` : ''}`;
      });
    });
    if (showHosts) applyFilter();
  };
  root.innerHTML = '<section class="panel"><p>Loading integrations…</p></section>';
  await run(async () => { config = await request(''); });
}
