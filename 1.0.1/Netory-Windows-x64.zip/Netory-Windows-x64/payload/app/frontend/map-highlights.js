// Bind independently of zoom/magnifier setup so port hover always works.
export function bindConnectionHighlights(view, svg, getCopy = () => null, onHighlight = () => {}) {
  let pinned = '';
  const target = element => element?.closest?.('[data-connection-id]') || null;
  const index = root => {
    const groups = new Map();
    root?.querySelectorAll?.('[data-connection-id]').forEach(element => {
      const id = element.dataset.connectionId;
      if (!groups.has(id)) groups.set(id, []);
      groups.get(id).push(element);
    });
    return groups;
  };
  const groups = index(view);
  let active = '', copy = null, copyGroups = new Map();
  const highlight = id => {
    const nextCopy = getCopy();
    const copyChanged = nextCopy !== copy;
    if (id === active && !copyChanged) return;
    if (copyChanged) {copy = nextCopy; copyGroups = index(copy);}
    for (const group of [groups,copyGroups]) {
      for (const element of group.get(active) || []) element.classList.toggle('is-highlighted',false);
      for (const element of group.get(id) || []) element.classList.toggle('is-highlighted',Boolean(id));
    }
    if (Boolean(active) !== Boolean(id) || copyChanged) {
      svg.classList.toggle('has-link-focus', Boolean(id));
      copy?.classList.toggle('has-link-focus', Boolean(id));
    }
    active = id;
    onHighlight();
  };
  const pin = element => { const id = target(element)?.dataset.connectionId || ''; pinned = pinned === id ? '' : id; highlight(pinned); };
  svg.addEventListener('click', event => pin(event.target));
  view.querySelectorAll('.connection-row').forEach(row => {
    row.addEventListener('click', () => pin(row));
    row.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') {event.preventDefault(); pin(row);} });
  });
  view.onpointerover = event => {const entered = target(event.target), from = target(event.relatedTarget); if (entered && view.contains(entered) && entered.dataset.connectionId !== from?.dataset.connectionId) highlight(entered.dataset.connectionId);};
  view.onpointerout = event => {const exited = target(event.target), to = target(event.relatedTarget); if (exited && view.contains(exited) && exited.dataset.connectionId !== to?.dataset.connectionId) highlight(to?.dataset.connectionId || pinned);};
  view.onfocusin = event => {const focused = target(event.target); if (focused) highlight(focused.dataset.connectionId);};
  view.onfocusout = event => highlight(target(event.relatedTarget)?.dataset.connectionId || pinned);
}
