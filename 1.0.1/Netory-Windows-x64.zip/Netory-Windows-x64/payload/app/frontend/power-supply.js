import { html, t } from './i18n.js?v=20261015-map-admin2';
import {esc} from './utils.js?v=20261015-map-admin2';

export function powerSupplyFields(asset, assets) {
  const choices = assets.filter(item=>item.type === 'UPS' && item.id !== asset.id);
  return html`<div class="field full" data-power-settings role="group" aria-labelledby="power-supply-heading"><div class="rack-settings-heading"><strong id="power-supply-heading">[[power_supply]]</strong><label class="rack-enable-toggle"><input type="checkbox" name="backupPowerEnabled" aria-controls="backup-ups-fields" ${!choices.length && !asset.backupPowerEnabled ? 'disabled' : ''} ${asset.backupPowerEnabled ? 'checked' : ''}> [[backup_power_supply]]</label></div><p class="panel-sub">[[enable_if_this_device_is_powered_by_a_ups_choose_its_backup_power_source]]</p>${choices.length ? '' : html(["<p class=\"panel-sub\" role=\"status\">[[add_a_ups_under_other_devices_ups_to_assign_backup_power]]</p>"])}<div id="backup-ups-fields" class="power-supply-fields" data-backup-ups ${asset.backupPowerEnabled ? '' : 'hidden'}><label for="backup-ups-source">[[backup_ups]]</label><select id="backup-ups-source" name="backupUpsId"><option value="">[[select_ups]]</option>${choices.map(item=>html`<option value="${esc(item.id)}" ${asset.backupUpsId === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select></div></div>`;
}

export function bindPowerSupplyFields(form) {
  const enabled = form.querySelector('[name="backupPowerEnabled"]');
  const picker = form.querySelector('[name="backupUpsId"]');
  if (!enabled || !picker) return;
  const sync = ()=>{
    picker.closest('[data-backup-ups]').hidden = !enabled.checked;
    picker.disabled = !enabled.checked;
    picker.required = enabled.checked;
  };
  enabled.addEventListener('change',sync);
  sync();
}
