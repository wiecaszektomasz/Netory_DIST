export function mapSearchCandidates(data, targets) {
  const records = [...(data.assets || []),
    ...(data.stacks || []).map(item => ({ ...item, id: `stack-${item.id}`, type: 'Stack' })),
    ...(data.clusters || []).map(item => ({ ...item, id: `cluster-${item.id}`, type: 'Server cluster' }))];
  return records.filter(item => targets.has(item.id)).sort((a, b) => a.name.localeCompare(b.name));
}

export function bindMapDeviceSearch(view, data, selectedId, onSelect) {
  const input = view.querySelector('[data-map-search]');
  const list = view.querySelector('[data-map-search-results]');
  const status = view.querySelector('[data-map-search-status]');
  if (!input || !list) return;
  const targets = new Map();
  view.querySelectorAll('[data-map-device-id]').forEach(target => {
    if (!targets.has(target.dataset.mapDeviceId)) targets.set(target.dataset.mapDeviceId, target);
  });
  const candidates = mapSearchCandidates(data, targets);
  const hide = () => { list.hidden = true; input.setAttribute('aria-expanded', 'false'); };
  const feature = id => {
    const target = targets.get(id);
    const scroll = view.querySelector('.network-map-scroll');
    if (!target || !scroll) return;
    view.querySelectorAll('.map-search-highlight').forEach(node => node.classList.remove('map-search-highlight'));
    target.classList.add('map-search-highlight');
    const bounds = target.getBoundingClientRect();
    const viewport = scroll.getBoundingClientRect();
    scroll.scrollLeft += bounds.left + bounds.width / 2 - viewport.left - (scroll.clientLeft || 0) - scroll.clientWidth / 2;
    scroll.scrollTop += bounds.top + bounds.height / 2 - viewport.top - (scroll.clientTop || 0) - scroll.clientHeight / 2;
    status.textContent = `Highlighted: ${candidates.find(item => item.id === id)?.name || ''}`;
  };
  const select = item => {
    input.value = item.name;
    onSelect(item.id);
    hide();
    feature(item.id);
    input.focus();
  };
  const suggest = () => {
    const query = input.value.trim().toLocaleLowerCase();
    list.replaceChildren();
    if (!query) {
      view.querySelectorAll('.map-search-highlight').forEach(node => node.classList.remove('map-search-highlight'));
      onSelect(null);
      status.textContent = '';
      hide();
      return;
    }
    const matches = candidates.filter(item => [item.name, item.type, item.ip, item.hostname]
      .some(value => String(value || '').toLocaleLowerCase().includes(query))).slice(0, 20);
    for (const item of matches) {
      const button = document.createElement('button');
      button.type = 'button';
      button.setAttribute('role', 'option');
      button.textContent = `${item.name} · ${item.type}${item.ip ? ` · ${item.ip}` : ''}`;
      button.addEventListener('click', () => select(item));
      list.append(button);
    }
    if (!matches.length) {
      const message = document.createElement('p');
      message.textContent = 'No matching devices in this view.';
      list.append(message);
    }
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
  };
  input.addEventListener('input', suggest);
  input.addEventListener('focus', suggest);
  input.addEventListener('keydown', event => {
    if (event.key === 'Escape') { hide(); event.stopPropagation(); }
    if (event.key === 'ArrowDown' || event.key === 'Enter') {
      const first = list.querySelector('button');
      if (first && !list.hidden) {
        event.preventDefault();
        if (event.key === 'Enter') first.click(); else first.focus();
      }
    }
  });
  list.addEventListener('keydown', event => {
    const buttons = [...list.querySelectorAll('button')];
    const index = buttons.indexOf(event.target);
    if (event.key === 'Escape') { event.stopPropagation(); input.focus(); hide(); }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const next = index + (event.key === 'ArrowDown' ? 1 : -1);
      if (next < 0) input.focus(); else buttons[Math.min(next, buttons.length - 1)]?.focus();
    }
  });
  input.closest('.map-device-search').addEventListener('focusout', event => {
    if (!event.currentTarget.contains(event.relatedTarget)) hide();
  });
  if (targets.has(selectedId)) {
    input.value = candidates.find(item => item.id === selectedId)?.name || '';
    requestAnimationFrame(() => { if (input.isConnected) feature(selectedId); });
  }
}
