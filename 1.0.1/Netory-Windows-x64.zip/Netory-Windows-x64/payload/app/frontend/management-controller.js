import {esc} from './utils.js';

export const controllerFields = ['managementControllerType', 'managementControllerIp', 'managementControllerModel', 'managementControllerVlan'];
export function managementControllerFields(asset, vlans) {
  const choices = [...new Map(vlans.map(vlan => [Number(vlan.idValue), vlan])).values()].sort((a, b) => a.idValue - b.idValue);
  return `<div class="field full" data-management-controller><label class="rack-enable-toggle"><input type="checkbox" name="managementControllerEnabled" aria-controls="management-controller-fields" ${asset.managementControllerEnabled ? 'checked' : ''}><span>Has IPMI / iDRAC / KVM management</span></label><p class="secondary-cell">Dedicated out-of-band controller settings, separate from the server's network address and port VLANs.</p><div id="management-controller-fields" class="form-grid" data-controller-fields ${asset.managementControllerEnabled ? '' : 'hidden'}>
    <div class="field"><label for="controller-type">Controller type</label><select id="controller-type" name="managementControllerType">${['IPMI', 'iDRAC', 'KVM', 'iLO', 'Other'].map(type => `<option ${type === (asset.managementControllerType || 'IPMI') ? 'selected' : ''}>${type}</option>`).join('')}</select></div>
    <div class="field"><label for="controller-ip">Controller IP address</label><input id="controller-ip" name="managementControllerIp" value="${esc(asset.managementControllerIp || '')}" maxlength="64" placeholder="IPv4 or IPv6 address" autocomplete="off"></div>
    <div class="field"><label for="controller-model">Controller model</label><input id="controller-model" name="managementControllerModel" value="${esc(asset.managementControllerModel || '')}" maxlength="240" placeholder="e.g. iDRAC9"></div>
    <div class="field"><label for="controller-vlan">Controller management VLAN</label><select id="controller-vlan" name="managementControllerVlan"><option value="">Not assigned</option>${choices.map(vlan => `<option value="${Number(vlan.idValue)}" ${String(asset.managementControllerVlan) === String(vlan.idValue) ? 'selected' : ''}>${Number(vlan.idValue)} — ${esc(vlan.name)}</option>`).join('')}</select></div>
  </div></div>`;
}

export function collectManagementController(form, type) {
  const enabled = type === 'Physical server' && Boolean(form.querySelector('[name="managementControllerEnabled"]')?.checked);
  return {managementControllerEnabled: enabled, ...Object.fromEntries(controllerFields.map(key => {
    const value = enabled ? form.querySelector(`[name="${key}"]`)?.value?.trim() || '' : '';
    return [key, key === 'managementControllerVlan' && value !== '' ? Number(value) : value];
  }))};
}

export function bindManagementController(form) {
  const root = form.querySelector('[data-management-controller]');
  if (!root) return;
  const toggle = form.querySelector('[name="managementControllerEnabled"]');
  const type = form.querySelector('[name="type"]');
  const sync = () => {
    const physical = type.value === 'Physical server';
    const enabled = physical && toggle.checked;
    root.hidden = !physical;
    const group = root.closest('.device-settings-group');
    if (group) group.hidden = !physical;
    toggle.disabled = !physical;
    root.querySelector('[data-controller-fields]').hidden = !enabled;
    for (const key of controllerFields) {
      const input = form.querySelector(`[name="${key}"]`);
      input.disabled = !enabled;
      input.required = enabled && key === 'managementControllerType';
    }
  };
  toggle.addEventListener('change', sync);
  type.addEventListener('change', sync);
  sync();
}
