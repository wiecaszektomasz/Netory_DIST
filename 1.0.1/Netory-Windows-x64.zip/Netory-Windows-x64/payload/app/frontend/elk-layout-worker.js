// ELK's dedicated worker owns the register/layout message protocol.
importScripts('./vendor/elkjs/elk-worker.min.js');
