import {esc} from './utils.js';

export async function openApplicationLicense({apiRequest, root, closeModal, onChanged}) {
  try {
    const status = await apiRequest('/api/license/status');
    onChanged(status);
    root.innerHTML = `<div class="modal-backdrop" id="modal-backdrop"><section class="modal"><div class="modal-head"><h2>Application license</h2><button class="button" type="button" data-license-close>Close</button></div><div class="modal-body"><p role="status">${esc(status.reason)}</p><dl>${status.expires_at ? `<dt>Expires</dt><dd>${esc(new Date(status.expires_at * 1000).toLocaleString())}</dd>` : ''}${status.customer ? `<dt>Licensed to</dt><dd>${esc(status.customer)}</dd>` : ''}</dl><p>Activation requires a connection to lic.netory.app and binds the license to this instance. Once activated, Netory works offline until the license expires. When reachable, the license server is checked every 30 seconds; a disabled or revoked license makes Netory read-only. Server clock rollback blocks changes and requires correcting the clock and reactivating online.</p><form data-license-import><label>Signed license file<input type="file" accept=".netory,.json" name="file" required></label><button class="button primary" type="submit">Install license</button></form><p>Removing the license makes Netory read-only. It does not release the activation on the license server.</p><button class="button danger" type="button" data-license-remove>Remove license</button><p data-license-error role="alert" hidden></p></div></section></div>`;
    root.querySelector('[data-license-close]').addEventListener('click', closeModal);
    root.querySelector('[data-license-remove]').addEventListener('click', async event => {
      if (!window.confirm('Remove the installed license? Netory will become read-only. The license server activation will remain reserved for this instance.')) return;
      const button = event.currentTarget;
      button.disabled = true;
      try {
        const updated = await apiRequest('/api/license/remove', {method:'POST'});
        onChanged(updated); await openApplicationLicense({apiRequest, root, closeModal, onChanged});
      } catch(error) {
        const message = root.querySelector('[data-license-error]');
        message.textContent = error.message; message.hidden = false; button.disabled = false;
      }
    });
    for (const [selector, endpoint] of [['[data-license-import]', 'install']]) {
      root.querySelector(selector).addEventListener('submit', async event => {
        event.preventDefault(); const form = event.currentTarget, button = form.querySelector('button'); button.disabled = true;
        try {
          const file = new FormData(form).get('file'); if (file.size > 16384) throw new Error('License files must be at most 16 KB.');
          const updated = await apiRequest(`/api/license/${endpoint}`, {method:'POST', body:JSON.stringify({content:await file.text()})});
          onChanged(updated); await openApplicationLicense({apiRequest, root, closeModal, onChanged});
        } catch(error) {const message=root.querySelector('[data-license-error]');message.textContent=error.message;message.hidden=false;button.disabled=false;}
      });
    }
  } catch(error) {root.innerHTML=`<div class="modal-backdrop"><section class="modal"><div class="modal-body"><p role="alert">${esc(error.message)}</p><button class="button" data-license-close>Close</button></div></section></div>`;root.querySelector('[data-license-close]').addEventListener('click',closeModal);}
}
