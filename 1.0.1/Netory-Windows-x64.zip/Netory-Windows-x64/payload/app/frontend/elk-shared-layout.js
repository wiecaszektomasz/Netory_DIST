// Adapt the established map geometry; ELK never reconstructs inventory groups.
export function buildSharedELKGraph(devices, widths, heights, positions, links, groupId, endpointPoint, depths = new Map()) {
  const levelHeights = new Map();
  for (const device of devices) {
    const depth = depths.get(device.id) || 0;
    levelHeights.set(depth, Math.max(levelHeights.get(depth) || 0, heights.get(device.id) || 44));
  }
  const levelY = new Map();
  let nextY = 80;
  for (const depth of [...levelHeights.keys()].sort((a,b) => a-b)) {
    levelY.set(depth, nextY); nextY += levelHeights.get(depth) + 65;
  }
  const children = devices.map((device,index) => ({id: `n${index}`, deviceId: device.id, x: positions.get(device.id).x, y: levelY.get(depths.get(device.id) || 0), width: widths.get(device.id), height: levelHeights.get(depths.get(device.id) || 0), layoutOptions: {'elk.portConstraints': 'FIXED_POS', 'elk.partitioning.partition': String(depths.get(device.id) || 0)}, ports: []}));
  const nodes = new Map(children.map(node => [node.deviceId,node]));
  const ports = new Map();
  const port = (id,number,side) => {
    const group = groupId(id), node = nodes.get(group);
    if (!node) return null;
    const key = `${id}:${number}:${side}`;
    if (!ports.has(key)) {
      const point = endpointPoint(id,number), origin = positions.get(group);
      const pin = {layoutOptions: {'elk.port.side': side}, id: `${node.id}p${node.ports.length}`, width: 0, height: 0, portY: point.y-origin.y, x: point.x-origin.x, y: side === 'NORTH' ? 0 : node.height};
      node.ports.push(pin); ports.set(key,pin.id);
    }
    return ports.get(key);
  };
  const edges = links.flatMap((link,index) => {
    if (groupId(link.deviceAId) === groupId(link.deviceBId)) return [];
    // Peer cables must not promote one peer into another tree level.
    if (depths.size && depths.get(groupId(link.deviceAId)) === depths.get(groupId(link.deviceBId))) return [];
    const reverse = (depths.get(groupId(link.deviceAId)) || 0) > (depths.get(groupId(link.deviceBId)) || 0);
    const source = port(link.deviceAId,link.portA,reverse ? 'NORTH' : 'SOUTH');
    const target = port(link.deviceBId,link.portB,reverse ? 'SOUTH' : 'NORTH');
    return source && target ? [{id: `e${index}`, reverse, sources:[reverse ? target : source], targets:[reverse ? source : target]}] : [];
  });
  // Ports in two rows often share an x coordinate. Give each boundary
  // anchor its own lane, while staying within its physical port column.
  for (const node of children) {
    const columns = new Map();
    for (const pin of node.ports) {
      const key = `${pin.layoutOptions['elk.port.side']}:${pin.x}`;
      if (!columns.has(key)) columns.set(key, []);
      columns.get(key).push(pin);
    }
    for (const pins of columns.values()) {
      if (pins.length < 2) continue;
      pins.sort((a,b) => a.portY-b.portY || a.id.localeCompare(b.id));
      const spread = Math.min(2.2, (pins.length-1)*1.3);
      pins.forEach((pin,index) => {pin.x += -spread + index*spread*2/(pins.length-1);});
    }
  }
  return {id:'root', layoutOptions: {'elk.algorithm':'layered','elk.layered.layering.strategy':'INTERACTIVE','elk.layered.cycleBreaking.strategy':'INTERACTIVE','elk.separateConnectedComponents':'false','elk.layered.nodePlacement.bk.fixedAlignment':'BALANCED','elk.direction':'DOWN','elk.edgeRouting':'ORTHOGONAL','elk.padding':'[top=80,left=40,bottom=40,right=40]','elk.spacing.nodeNode':'35','elk.spacing.edgeEdge':'6','elk.layered.spacing.edgeEdgeBetweenLayers':'6','elk.layered.spacing.nodeNodeBetweenLayers':'65','elk.randomSeed':'1'}, children, edges};
}
export function elkRoutePoints(edge, actualStart, actualEnd) {
  const section = edge?.sections?.[0];
  if (!section) return null;
  const points = [section.startPoint, ...(section.bendPoints || []), section.endPoint];
  if (edge.reverse) points.reverse();
  // ELK attaches ports to layout box boundaries. The box may be
  // taller than the rendered device because peers share a row height.
  // Join the route to the renderer's exact member/VM port coordinates.
  if (actualStart) {
    const start = points[0];
    points.unshift({...actualStart}, {x: start.x, y: actualStart.y});
  }
  if (actualEnd) {
    const end = points[points.length - 1];
    points.push({x: end.x, y: actualEnd.y}, {...actualEnd});
  }
  return points.filter((point,index) => !index || point.x !== points[index-1].x || point.y !== points[index-1].y);
}
export function runSharedELKLayout(graph) {
  const worker = new Worker(new URL('./elk-layout-worker.js?v=20261014-startup1',import.meta.url));
  let timer, rejectPending;
  const promise = new Promise((resolve,reject) => {
    rejectPending = reject;
    timer = setTimeout(() => {worker.terminate();reject(new Error('ELK layout exceeded 30 seconds.'));},30000);
    worker.onerror = () => {clearTimeout(timer);worker.terminate();reject(new Error('Could not load the ELK layout engine.'));};
    worker.onmessage = ({data}) => {
      if (data.error) {clearTimeout(timer);worker.terminate();reject(new Error(data.error.message || 'ELK layout failed.'));return;}
      if (data.id === 0) worker.postMessage({id:1,cmd:'layout',graph,layoutOptions:{},options:{}});
      else {clearTimeout(timer);worker.terminate();resolve(data.data);}
    };
    worker.postMessage({id:0,cmd:'register',algorithms:['layered']});
  });
  return {promise, cancel: () => {clearTimeout(timer);worker.terminate();rejectPending(new Error('Layout cancelled.'));}};
}
