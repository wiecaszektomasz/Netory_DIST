let generatedIdCounter = 0;

export const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

export function createId(prefix) {
  const source = globalThis.crypto;
  if (typeof source?.randomUUID === 'function') return `${prefix}-${source.randomUUID()}`;
  if (typeof source?.getRandomValues === 'function') {
    const bytes = source.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    const uuid = `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    return `${prefix}-${uuid}`;
  }
  generatedIdCounter += 1;
  return `${prefix}-${Date.now().toString(36)}-${generatedIdCounter.toString(36)}-${Math.random().toString(36).slice(2)}`;
}

function isValidIPv4(value) {
  const parts = value.split('.');
  return parts.length === 4 && parts.every(part => /^(0|[1-9]\d{0,2})$/.test(part) && Number(part) <= 255);
}

function isValidIpAddress(value) {
  if (!value.includes(':')) return isValidIPv4(value);
  const address = value.toLowerCase();
  if (!/^[0-9a-f:.]+$/.test(address) || address.includes(':::') || address.split('::').length > 2) return false;
  if ((address.startsWith(':') && !address.startsWith('::')) || (address.endsWith(':') && !address.endsWith('::'))) return false;
  const compressed = address.includes('::');
  const parts = address.split(':');
  let groups = parts.filter(Boolean);
  if (groups.some(group => group.includes('.'))) {
    if (!groups[groups.length - 1].includes('.')) return false;
    if (!isValidIPv4(groups.pop())) return false;
    groups = [...groups, 'ipv4-a', 'ipv4-b'];
  }
  if (groups.some(group => group !== 'ipv4-a' && group !== 'ipv4-b' && !/^[0-9a-f]{1,4}$/.test(group))) return false;
  return compressed ? groups.length < 8 : groups.length === 8;
}

function networkAddressError(value) {
  const parts = value.split('/');
  const invalid = 'Network must be a valid IPv4 or IPv6 network address with a CIDR prefix.';
  if (parts.length !== 2 || !isValidIpAddress(parts[0]) || !/^\d+$/.test(parts[1])) return invalid;
  const ipv6 = parts[0].includes(':');
  const width = ipv6 ? 128 : 32;
  const prefix = Number(parts[1]);
  if (prefix > width) return invalid;
  let address;
  if (!ipv6) {
    address = parts[0].split('.').reduce((total, octet) => (total << 8n) | BigInt(octet), 0n);
  } else {
    const text = parts[0].replace(/\d+\.\d+\.\d+\.\d+$/, dotted => {
      const octets = dotted.split('.').map(Number);
      return `${((octets[0] << 8) | octets[1]).toString(16)}:${((octets[2] << 8) | octets[3]).toString(16)}`;
    });
    const halves = text.split('::');
    const left = halves[0].split(':').filter(Boolean);
    const right = (halves[1] || '').split(':').filter(Boolean);
    const groups = halves.length === 2 ? [...left, ...Array(8 - left.length - right.length).fill('0'), ...right] : left;
    address = groups.reduce((total, group) => (total << 16n) | BigInt(`0x${group}`), 0n);
  }
  const hostBits = BigInt(width - prefix);
  const network = (address >> hostBits) << hostBits;
  if (network === address) return '';
  const correct = ipv6
    ? Array.from({length: 8}, (_, index) => ((network >> BigInt((7 - index) * 16)) & 65535n).toString(16)).join(':')
    : Array.from({length: 4}, (_, index) => Number((network >> BigInt((3 - index) * 8)) & 255n)).join('.');
  return `Network address has host bits set. Use ${correct}/${prefix}.`;
}

export function validateFormValues(section, values) {
  if (section === 'vlans') {
    const vlanId = Number(values.id);
    if (!Number.isInteger(vlanId) || vlanId < 1 || vlanId > 4094) return 'VLAN ID must be a whole number between 1 and 4094.';
    if (values.network?.trim()) {
      const error = networkAddressError(values.network.trim());
      if (error) return error;
    }
    if (values.gateway?.trim() && !isValidIpAddress(values.gateway.trim())) return 'Gateway must be a valid IPv4 or IPv6 address.';
  }
  if (section === 'lans' || section === 'wlans') {
    if (values.network?.trim()) {
      const error = networkAddressError(values.network.trim());
      if (error) return error;
    }
    if (values.gateway?.trim() && !isValidIpAddress(values.gateway.trim())) return 'Gateway must be a valid IPv4 or IPv6 address.';
    if (values.dnsServers?.trim() && values.dnsServers.split(',').map(server => server.trim()).filter(Boolean).some(server => !isValidIpAddress(server))) return 'DNS servers must be valid IPv4 or IPv6 addresses separated by commas.';
    if (values.vlanId && (!/^\d+$/.test(values.vlanId) || Number(values.vlanId) < 1 || Number(values.vlanId) > 4094)) return 'VLAN ID must be a whole number between 1 and 4094.';
  }
  if (section === 'assets' && values.ip?.trim() && !isValidIpAddress(values.ip.trim())) return 'Management IP must be a valid IPv4 or IPv6 address.';
  if (section === 'assets' && values.managementControllerIp?.trim() && !isValidIpAddress(values.managementControllerIp.trim())) return 'Controller IP must be a valid IPv4 or IPv6 address.';
  if (section === 'hypervisors' && values.managementIp?.trim() && !isValidIpAddress(values.managementIp.trim())) return 'Management IP must be a valid IPv4 or IPv6 address.';
  return '';
}

export const predefinedPortTypes = [
  { type: 'Fast Ethernet', speed: '100 Mbps' },
  { type: 'Gigabit Ethernet', speed: '1 Gbps' },
  { type: 'Gigabit SFP', speed: '1 Gbps' },
  { type: '2.5G Ethernet', speed: '2.5 Gbps' },
  { type: '5G Ethernet', speed: '5 Gbps' },
  { type: '10G Ethernet', speed: '10 Gbps' },
  { type: '10G SFP+', speed: '10 Gbps' },
  { type: '25G SFP28', speed: '25 Gbps' },
  { type: '40G QSFP+', speed: '40 Gbps' },
  { type: '50G SFP56', speed: '50 Gbps' },
  { type: '100G QSFP28', speed: '100 Gbps' },
  { type: '200G QSFP56', speed: '200 Gbps' },
  { type: '400G QSFP-DD', speed: '400 Gbps' },
];

export const standardPortTypes = predefinedPortTypes.map(({ type }) => type);
export const defaultPortType = 'Gigabit Ethernet';
export const defaultPortSpeed = '1 Gbps';

const legacyPortTypeMap = {
  'ETH 1 Gb/s': { type: 'Gigabit Ethernet', speed: '1 Gbps' },
  'ETH 10 Gb/s': { type: '10G Ethernet', speed: '10 Gbps' },
  'SFP': { type: 'Gigabit SFP', speed: '1 Gbps' },
  'SFP+': { type: '10G SFP+', speed: '10 Gbps' },
  'QSFP28 100G': { type: '100G QSFP28', speed: '100 Gbps' },
};

export function getPortInfo(asset, port) {
  const val = asset?.portTypes?.[port] ?? asset?.portTypes?.[String(port)];
  if (!val) return { type: defaultPortType, speed: defaultPortSpeed };
  if (typeof val === 'string') {
    return legacyPortTypeMap[val] || { type: val.trim() || defaultPortType, speed: defaultPortSpeed };
  }
  return {
    type: val.type && String(val.type).trim() ? String(val.type).trim() : defaultPortType,
    speed: val.speed && String(val.speed).trim() ? String(val.speed).trim() : defaultPortSpeed,
  };
}

export function getPortType(asset, port) {
  return getPortInfo(asset, port).type;
}

export function getPortSpeed(asset, port) {
  return getPortInfo(asset, port).speed;
}
