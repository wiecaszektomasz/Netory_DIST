import {esc} from './utils.js?v=20261021-notes-board1';
import {t, getLocale} from './i18n.js?v=20261015-map-admin2';
import {buildReport, reportColumns, csvReport} from './reports-model.js?v=20261025-security1';

const titles = {overview:'Environment overview', assets:'Asset inventory', licenses:'License usage and expiry', warranty:'Warranty expiry', quality:'Data completeness'};
const descriptions = {overview:'See how assets are distributed across your environment.', assets:'Find devices and export an inventory list.', licenses:'Check seat usage and upcoming license renewals.', warranty:'Find assets with expired or soon expiring warranties.', quality:'Find incomplete records that need attention.'};
const labels = {assetType:'Device type', groupBy:'Group assets by', horizon:'Expiry window (days)', search:'Search', warrantyExpiry:'Warranty expiry', daysRemaining:'Days remaining', available:'Available seats', assigned:'Assigned seats', missing:'Missing fields'};
const label = key => t(labels[key] || key.replace(/([A-Z])/g,' $1').replace(/^./, s=>s.toUpperCase()));
const text = (key, values) => esc(t(key, values));
function normalize(options = {}) {
  return {type:Object.hasOwn(titles,options.type) ? options.type : 'overview',
    groupBy:['type','status','manufacturer','location'].includes(options.groupBy) ? options.groupBy : 'type',
    horizon:[30,60,90,180,365].includes(Number(options.horizon)) ? Number(options.horizon) : 90,
    ...Object.fromEntries(['search','assetType','status','location'].map(key=>[key,String(options[key] || '')])),
    expiryOnly:Boolean(options.expiryOnly),
    columns:Array.isArray(options.columns) ? options.columns.filter(key=>typeof key==='string') : []};
}

export async function renderReports({root, data, environment, userId, apiRequest, isCurrent = () => true}) {
  const storageKey = `netory.reports.v1:${userId}:${environment.id}`;
  let options = {type:'overview', groupBy:'type', horizon:90, columns:[]};
  const endpoint = `/api/environments/${encodeURIComponent(environment.id)}/report-configurations`;
  let presets = [], legacy = [], version = 0, ready = false, saving = false;
  let selectedPreset = '';
  let savedOpen = false;
  let report;
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
    if (Array.isArray(saved)) legacy = saved.filter(p=>p && typeof p.name==='string' && p.options && typeof p.options==='object')
      .slice(0,20).map(p=>({name:p.name.slice(0,80), options:normalize(p.options)}));
  } catch { /* Storage is optional; inventory is never persisted here. */ }

  const values = key => [...new Set((data.assets || []).map(row=>row[key]).filter(Boolean))].sort();
  function select(key, items, all = true) {
    return `<label>${esc(label(key))}<select name="${key}">${all ? `<option value="">${text('All')}</option>` : ''}${items.map(value=>`<option value="${esc(value)}" ${String(value)===String(options[key])?'selected':''}>${esc(key==='groupBy' ? label(value) : value)}</option>`).join('')}</select></label>`;
  }
  function draw() {
    if (!isCurrent()) return;
    const assetReport = options.type !== 'licenses';
    const expiryReport = ['licenses', 'warranty'].includes(options.type);
    root.innerHTML = `<section class="panel reports-panel">
      <div class="panel-head"><div><h2>${text('Reports')}</h2><p class="panel-sub">${esc(environment.name)} · ${text('Configure, analyze and export current environment data.')}</p></div></div>
      <form class="report-controls">
        <fieldset class="report-type-picker"><legend>${text('Choose a report')}</legend><div class="report-type-grid">${Object.entries(titles).map(([key,title])=>`<label class="report-type-card ${options.type===key?'is-selected':''}"><input type="radio" name="type" value="${key}" ${options.type===key?'checked':''}><span><strong>${text(title)}</strong><small>${text(descriptions[key])}</small></span></label>`).join('')}</div></fieldset>
        <div class="report-filter-heading"><h3>${text('Filter your results')}</h3><p class="panel-sub">${text('Choose filters, then generate your report.')}</p></div>
        <label>${text('Search')}<input name="search" type="search" value="${esc(options.search || '')}" maxlength="150" placeholder="${text(options.type==='licenses' ? 'Product, vendor, owner…' : 'Name, vendor, location…')}"></label>
        ${assetReport ? `${select('assetType',values('type'))}${select('status',values('status'))}${select('location',values('location'))}` : ''}
        ${options.type==='overview' ? select('groupBy',['type','status','manufacturer','location'],false) : ''}
        ${expiryReport ? select('horizon',[30,60,90,180,365],false) : ''}
        ${options.type==='licenses' ? `<label class="report-check"><input type="checkbox" name="expiryOnly" ${options.expiryOnly?'checked':''}>${text('Only expired / due licenses')}</label>` : ''}
        ${expiryReport ? `<p class="panel-sub report-filter-note">${text('Includes overdue dates. Records without an expiry date are excluded from expiry results.')}</p>` : ''}
        ${reportColumns[options.type] ? `<details class="report-advanced"><summary>${text('Report columns')}</summary><fieldset class="report-columns"><legend class="sr-only">${text('Report columns')}</legend>${reportColumns[options.type].map(key=>`<label><input type="checkbox" name="column" value="${key}" ${!options.columns.length || options.columns.includes(key)?'checked':''}>${esc(label(key))}</label>`).join('')}</fieldset></details>` : ''}
        <div class="report-actions"><button class="button primary" type="submit">${text('Generate report')}</button><button class="button" type="button" data-report-reset>${text('Reset filters')}</button><span class="panel-sub" data-report-pending role="status"></span></div>
      </form>
      <details class="report-saved" ${savedOpen?'open':''}><summary>${text('Saved reports')}</summary><div class="report-presets">

        <label>${text('Saved report')}<select data-report-preset ${!ready?'disabled':''}><option value="">${text('Choose a saved configuration')}</option>${presets.map((p,i)=>`<option value="${i}" ${String(i)===selectedPreset?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label>
        <label>${text('Report configuration name')}<input data-report-name placeholder="${text('Configuration name')}" maxlength="80"></label>
        <button class="button" data-report-save ${!ready?'disabled':''}>${text('Save configuration')}</button><button class="button" data-report-delete ${!ready || selectedPreset===''?'disabled':''}>${text('Delete selected')}</button>${legacy.length ? `<button class="button" data-report-import ${!ready?'disabled':''}>${text('Import browser configurations')}</button>` : ''}<span data-report-feedback role="status"></span>
      </div></details>
      <details class="report-about"><summary>${text('About this data')}</summary><p class="panel-sub report-help">${text('Configurations are saved to your account for this client and are available across devices. Report results use a snapshot of the current inventory; reopen Reports to refresh. Results are not saved as historical snapshots. Expiry results include overdue dates and exclude blank dates.')}</p>
      </details><div data-report-output role="region" aria-label="${text('Report results')}"></div></section>`;
    root.querySelector('form').addEventListener('submit',event=>{event.preventDefault(); read(); output();});
    root.querySelector('form').addEventListener('change', event=>{
      if (event.target.name==='type') {read(); options.columns=[]; selectedPreset=''; draw(); root.querySelector('[name=type]:checked')?.focus?.();}
      else root.querySelector('[data-report-pending]').textContent=t('Filters changed. Generate report to update results.');
    });
    root.querySelector('[name=search]').addEventListener('input',()=>{root.querySelector('[data-report-pending]').textContent=t('Filters changed. Generate report to update results.');});
    root.querySelector('[data-report-reset]').onclick=()=>{options={type:options.type,groupBy:'type',horizon:90,columns:[]}; draw();};
    root.querySelector('[data-report-preset]').onchange=event=>{
      const saved=presets[Number(event.target.value)];
      if (event.target.value!=='' && saved) {selectedPreset=event.target.value; options=normalize(saved.options); draw();}
    };
    root.querySelector('.report-saved').addEventListener('toggle',event=>{savedOpen=event.target.open;});
    const persist = async (next, selection, imported = false) => {
      if (!ready || saving || !isCurrent()) return;
      saving = true;
      root.querySelectorAll?.('.report-presets button, .report-presets input, .report-presets select').forEach(element=>{element.disabled=true;});
      feedback('Saving configuration…');
      try {
        const result = await apiRequest(endpoint, {method:'PUT',body:JSON.stringify({items:next,version})});
        if (!isCurrent()) return;
        presets=result.items.map(p=>({...p,options:normalize(p.options)})); version=result.version; selectedPreset=selection;
        if (imported) {
          legacy=[];
          try {localStorage.removeItem(storageKey);} catch { /* Imported settings are safely stored on the server. */ }
        }
        savedOpen=true; draw(); feedback('Configuration saved to your account.');
      } catch (error) {
        if (isCurrent()) {savedOpen=true; draw(); feedback(error.message);}
      } finally {saving=false;}
    };
    root.querySelector('[data-report-save]').onclick=()=>{
      const name=root.querySelector('[data-report-name]').value.trim();
      if (!name) {feedback('Enter a configuration name.'); return;}
      read();
      const next=presets.filter(p=>p.name!==name);
      if (next.length>=20) {feedback('You can save up to 20 configurations per client.'); return;}
      next.push({name,options:{...options}});
      return persist(next,String(next.length-1));
    };
    root.querySelector('[data-report-delete]').onclick=()=>{
      const value=root.querySelector('[data-report-preset]').value;
      if (value==='') return;
      return persist(presets.filter((_,index)=>index!==Number(value)),'');
    };
    root.querySelector('[data-report-import]')?.addEventListener('click',()=>{
      const next=presets.map(p=>({...p}));
      for (const preset of legacy) {
        if (next.some(p=>p.name===preset.name && JSON.stringify(p.options)===JSON.stringify(preset.options))) continue;
        let name=preset.name, suffix=1;
        while (next.some(p=>p.name===name)) name=`${preset.name.slice(0,65)} (${suffix++})`;
        next.push({...preset,name});
      }
      if (next.length>20) {feedback('You can save up to 20 configurations per client.'); return;}
      return persist(next,'',true);
    });
    output();
  }
  function feedback(message) {savedOpen=true; root.querySelector('.report-saved').open=true; root.querySelector('[data-report-feedback]').textContent=t(message);}
  function read() {
    const form=new FormData(root.querySelector('form'));
    options=normalize({...options,...Object.fromEntries(form),expiryOnly:form.has('expiryOnly'),columns:form.getAll('column')});
    delete options.column;
  }
  function display(key, value) {
    if (key==='missing') return String(value || '').split(', ').map(label).join(', ');
    if (key==='group' && value==='Not specified') return t('Not specified');
    return value ?? '—';
  }
  function table() {
    return `<div class="table-wrap"><table><thead><tr>${report.columns.map(key=>`<th>${esc(label(key))}</th>`).join('')}</tr></thead><tbody>${report.rows.map(row=>`<tr>${report.columns.map(key=>`<td>${esc(display(key,row[key]))}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${report.columns.length}">${text('No records match these filters.')}</td></tr>`}</tbody></table></div>`;
  }
  function filterDescription() {
    const parts = [];
    if (report.type!=='licenses') {
      if (options.assetType) parts.push(`${t('Device type')}: ${options.assetType}`);
      if (options.status) parts.push(`${t('Status')}: ${options.status}`);
      if (options.location) parts.push(`${t('Location')}: ${options.location}`);
    }
    if (options.search) parts.push(`${t('Search')}: ${options.search}`);
    if (report.type==='overview') parts.push(`${t('Group assets by')}: ${label(options.groupBy || 'type')}`);
    if (['licenses','warranty'].includes(report.type)) parts.push(`${t('Expiry window (days)')}: ${report.horizon}`);
    if (report.type==='licenses' && options.expiryOnly) parts.push(t('Only expired / due licenses'));
    return parts.join(' · ') || t('All records');
  }
  function output() {
    report=buildReport(data,options);
    root.querySelector('[data-report-pending]').textContent='';
    const timestamp=new Date().toLocaleString(getLocale());
    root.querySelector('[data-report-output]').innerHTML=`<div class="report-actions"><h3>${text(titles[report.type])}</h3><button class="button" data-report-csv>${text('Export CSV')}</button><button class="button" data-report-print>${text('Print / Save PDF')}</button></div>
      <p class="panel-sub">${esc(environment.name)} · ${text('Generated {time} · {count} rows',{time:timestamp,count:report.rows.length})}</p>
      <p class="panel-sub report-applied-filters">${esc(filterDescription())}</p>
      <div class="report-metrics">${report.metrics.filter(([name])=>report.type==='overview' || (report.type==='licenses' ? ['Licenses','Assigned seats','Licenses expired / due'].includes(name) : report.type==='warranty' ? name==='Warranties expired / due' : report.type==='quality' ? name==='Assets missing details' : name==='Assets')).map(([name,value])=>`<div><strong>${value}</strong><span>${text(name)}</span></div>`).join('')}</div>
      ${report.type==='overview' ? `<div class="report-bars">${report.groups.map(row=>`<div><span>${esc(display('group',row.group))}</span><meter min="0" max="${Math.max(1,...report.groups.map(r=>r.count))}" value="${row.count}">${row.count}</meter><strong>${row.count}</strong></div>`).join('')}</div>` : ''}${table()}`;
    root.querySelector('[data-report-csv]').onclick=()=>{
      const rows=report.rows.map(row=>Object.fromEntries(report.columns.map(key=>[key,display(key,row[key])])));
      const url=URL.createObjectURL(new Blob([csvReport(report.columns,rows,report.columns.map(label))],{type:'text/csv;charset=utf-8'}));
      const a=document.createElement('a'); a.href=url; a.download=`netory-${report.type}-${new Date().toISOString().slice(0,10)}.csv`; a.click();
      setTimeout(()=>URL.revokeObjectURL(url),1000);
    };
    root.querySelector('[data-report-print]').onclick=()=>{
      const popup=window.open('','_blank');
      if (!popup) {feedback('Allow popups to print this report.'); return;}
      popup.opener=null;
      popup.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${text(titles[report.type])}</title><style>body{font:12px system-ui;color:#182d22;padding:24px}table{border-collapse:collapse;width:100%}th,td{padding:7px;border:1px solid #bcc9c0;text-align:left}th{background:#edf2ee}tr{break-inside:avoid}h1{font-size:22px}@page{size:landscape;margin:12mm}</style></head><body><h1>${text(titles[report.type])}</h1><p>${esc(environment.name)} · ${esc(timestamp)}</p><p>${esc(filterDescription())}</p><p>${report.metrics.map(([name,value])=>`${text(name)}: ${value}`).join(' · ')}</p>${table()}</body></html>`);
      popup.document.close(); popup.focus(); popup.print();
    };
  }
  root.innerHTML=`<p role="status">${text('Loading reports…')}</p>`;
  try {
    const result=await apiRequest(endpoint);
    if (!isCurrent()) return;
    presets=result.items.map(p=>({...p,options:normalize(p.options)})); version=result.version; ready=true;
    draw();
  } catch (error) {
    if (isCurrent()) {draw(); feedback(error.message);}
  }
}
