import { html, t } from './i18n.js?v=20261015-map-admin2';
export async function openAssetTrash(apiRequest, esc, stillAllowed, onRestored = async () => {}) {
  const modal = document.getElementById('modal-root');
  modal.innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><section class="modal asset-trash-modal"><div class="modal-head"><h2>[[asset_trash]]</h2><button type="button" class="button" data-close>[[close]]</button></div><div class="modal-body"><p class="panel-sub">[[deleted_assets_are_retained_until_a_superadmin_permanently_deletes_them_restore_returns_as]]</p><form data-trash-search class="list-toolbar"><input name="q" type="search" maxlength="200" class="search" aria-label="[[search_deleted_assets]]" placeholder="[[name_type_environment_or_deleted_by]]"><button class="button" type="submit">[[search]]</button></form><p data-trash-error class="form-error" role="alert" hidden></p><div data-trash-content role="status">[[loading_deleted_assets]]</div></div><div class="modal-foot"><button class="button" type="button" data-administration-settings>[[back]]</button></div></section></div>`;
  const root = modal.querySelector('.asset-trash-modal');
  let query = '', offset = 0, generation = 0;
  const error = root.querySelector('[data-trash-error]');
  const content = root.querySelector('[data-trash-content]');
  const valid = token => stillAllowed() && root.isConnected && token === generation;
  const load = async () => {
    const token = ++generation;
    error.hidden = true;
    try {
      const data = await apiRequest(`/api/admin/trash/assets?${new URLSearchParams({q:query,offset:String(offset),limit:'50'})}`);
      if (!valid(token)) return;
      if (offset && !data.items.length) { offset = Math.max(0, offset - 50); return load(); }
      content.innerHTML = html`<p>${data.total} deleted asset${data.total === 1 ? '' : 's'}</p><div class="table-wrap"><table><thead><tr><th>[[asset]]</th><th>[[environment]]</th><th>[[deleted_by]]</th><th>[[deleted_at]]</th><th>[[actions]]</th></tr></thead><tbody>${data.items.map(item=>html`<tr><td><strong>${esc(item.name)}</strong><div class="secondary-cell">${esc(item.type)}</div></td><td>${esc(item.environment_name)}</td><td>${esc(item.deleted_by_username)}<div class="secondary-cell">${item.deleted_by_admin ? t("superadmin") : t("user")}</div></td><td>${esc(new Date(item.deleted_at).toLocaleString())}</td><td><div class="row-actions"><button type="button" class="button" data-trash-restore="${esc(item.id)}" data-trash-name="${esc(item.name)}">[[restore]]</button><button type="button" class="button" data-trash-details="${esc(item.id)}">[[details]]</button><button type="button" class="button" data-trash-delete="${esc(item.id)}" data-trash-name="${esc(item.name)}">[[delete_permanently]]</button></div><div data-trash-snapshot="${esc(item.id)}" hidden></div></td></tr>`).join('') || html(["<tr><td colspan=\"5\">[[no_deleted_assets_found]]</td></tr>"])}</tbody></table></div><div class="ai-editor-actions"><button type="button" class="button" data-trash-previous ${offset ? '' : 'disabled'}>[[previous]]</button><button type="button" class="button" data-trash-next ${offset+data.items.length<data.total ? '' : 'disabled'}>[[next]]</button></div>`;
      content.querySelector('[data-trash-previous]').addEventListener('click',()=>{offset=Math.max(0,offset-50);load();});
      content.querySelector('[data-trash-next]').addEventListener('click',()=>{offset+=50;load();});
      content.querySelectorAll('[data-trash-details]').forEach(button=>button.addEventListener('click',async()=>{
        button.disabled=true;
        try {
          const item=await apiRequest(`/api/admin/trash/assets/${encodeURIComponent(button.dataset.trashDetails)}`);
          if(!valid(token))return;
          const details=[...content.querySelectorAll('[data-trash-snapshot]')].find(node=>node.dataset.trashSnapshot===item.id);
          const fields=document.createElement('dl');fields.className='asset-trash-snapshot';
          const format=value=>value === null || value === '' ? '—' : typeof value === 'boolean' ? (value ? 'Yes' : 'No') : Array.isArray(value) ? value.map(format).join(', ') || '—' : typeof value === 'object' ? Object.entries(value).map(([key,entry])=>`${key}: ${format(entry)}`).join('; ') || '—' : String(value);
          for(const [key,value] of Object.entries(item.snapshot)) {
            const label=document.createElement('dt'), text=document.createElement('dd');
            label.textContent=({id:'Asset ID',ip:'IP address',os:'Operating system',cpu:'CPU',ram:'RAM',portCount:'Ports',portTypes:'Port types and speeds',portVlans:'Port VLAN assignments'})[key] || key.replace(/([A-Z])/g,' $1').replace(/^./,letter=>letter.toUpperCase());
            text.textContent=format(value);fields.append(label,text);
          }
          details.replaceChildren(fields);details.hidden=false;
        } catch(failure){if(valid(token)){error.textContent=failure.message;error.hidden=false;}}
        finally{if(button.isConnected)button.disabled=false;}
      }));
      content.querySelectorAll('[data-trash-restore]').forEach(button=>button.addEventListener('click',async()=>{
        if(!confirm(`Restore ${button.dataset.trashName} to its original environment? Connections and group memberships will not be recreated. Rack devices return unassigned, and unavailable references are cleared.`))return;
        button.disabled=true;
        try {
          await apiRequest(`/api/admin/trash/assets/${encodeURIComponent(button.dataset.trashRestore)}/restore`,{method:'POST'});
          if(valid(token)) { await onRestored(); if(valid(token))await load(); }
        } catch(failure){if(valid(token)){error.textContent=failure.message;error.hidden=false;}}
        finally{if(button.isConnected)button.disabled=false;}
      }));
      content.querySelectorAll('[data-trash-delete]').forEach(button=>button.addEventListener('click',async()=>{
        if(!confirm(`Permanently delete ${button.dataset.trashName} from Trash? This cannot be undone.`))return;
        button.disabled=true;
        try {
          await apiRequest(`/api/admin/trash/assets/${encodeURIComponent(button.dataset.trashDelete)}`,{method:'DELETE'});
          if(valid(token))await load();
        } catch(failure){if(valid(token)){error.textContent=failure.message;error.hidden=false;}}
        finally{if(button.isConnected)button.disabled=false;}
      }));
    } catch(failure){if(valid(token)){error.textContent=failure.message;error.hidden=false;}}
  };
  root.querySelector('[data-trash-search]').addEventListener('submit',event=>{
    event.preventDefault();query=new FormData(event.currentTarget).get('q');offset=0;load();
  });
  await load();
}
