import { html, t } from './i18n.js?v=20261015-map-admin2';
export function createLoadingIndicator(doc = document) {
  const indicator = doc.createElement('div');
  indicator.className = 'loading-indicator';
  indicator.setAttribute('role', 'status');
  indicator.setAttribute('aria-live', 'polite');
  indicator.hidden = true;
  indicator.innerHTML = html(["<span class=\"loading-spinner\" aria-hidden=\"true\"></span><span class=\"loading-label\"></span>"]);
  doc.body.append(indicator);
  const tasks = new Map();
  const update = () => {
    indicator.hidden = tasks.size === 0;
    indicator.querySelector('.loading-label').textContent = t([...tasks.values()].at(-1) || '');
  };
  const begin = (label = 'Loading…') => {
    const id = Symbol();
    tasks.set(id, label);
    update();
    return () => { tasks.delete(id); update(); };
  };
  const afterPaint = async (task, label = 'Loading network map…') => {
    const finish = begin(label);
    try {
      // Give the browser a frame to paint the indicator before calculating layout.
      await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
      return await task();
    } finally { finish(); }
  };
  return { begin, afterPaint };
}
