import { html, t } from './i18n.js?v=20261015-map-admin2';
export async function openAIProviders(apiRequest, esc, selectedId = null) {
  let data;
  try { data = await apiRequest('/api/settings/ai/providers'); }
  catch (error) { alert(error.message); return; }
  const vendors = { openai: 'OpenAI', anthropic: 'Anthropic', gemini: 'Google Gemini', openrouter: 'OpenRouter', compatible: 'OpenAI-compatible' };
  const current = data.providers.find(provider => provider.id === selectedId);
  const editing = selectedId === 'new' || Boolean(current);
  const secure = window.isSecureContext || data.allow_insecure_http;
  const rows = data.providers.map(provider => html`<tr><td><strong>${esc(provider.name)}</strong><div class="secondary-cell">${esc(vendors[provider.vendor])}${provider.is_default ? ' · Default' : ''}</div></td><td>${esc(provider.model || '—')}</td><td>${provider.enabled ? t("enabled") : t("disabled")}<div class="secondary-cell">${esc(provider.test_status)} · ${provider.has_key ? 'Key saved' : 'No key'}</div></td><td>${provider.requests_today} / ${provider.request_limit}<div class="secondary-cell">${provider.total_requests} total</div></td><td><div class="ai-row-actions"><button type="button" class="button" data-ai-edit="${esc(provider.id)}">[[edit]]</button><button type="button" class="button" data-ai-test="${esc(provider.id)}" ${provider.has_key ? '' : 'disabled'}>[[test]]</button><button type="button" class="button" data-ai-delete="${esc(provider.id)}">[[delete]]</button></div></td></tr>`).join('');
  const editor = editing ? html`<form id="ai-provider-form" class="ai-provider-editor"><h3>${current ? t("edit_connection") : t("new_connection")}</h3><div class="form-grid"><div class="field"><label for="ai-name">[[connection_name]]</label><input id="ai-name" name="name" maxlength="120" required value="${esc(current?.name || '')}"></div><div class="field"><label for="ai-vendor">[[provider]]</label><select id="ai-vendor" name="vendor">${Object.entries(vendors).map(([value, label]) => html`<option value="${value}" ${current?.vendor === value ? 'selected' : ''}>${t(label)}</option>`).join('')}</select></div><div class="field full" id="ai-endpoint-field" ${current?.vendor === 'compatible' ? '' : 'hidden'}><label for="ai-endpoint">[[api_base_url]]</label><input id="ai-endpoint" name="base_url" type="url" maxlength="500" value="${esc(current?.vendor === 'compatible' ? current.base_url : '')}" placeholder="[[https_openrouter_ai_api_v1]]"></div><div class="field full"><label for="ai-key">[[api_key]]</label><input id="ai-key" name="api_key" type="password" maxlength="4096" autocomplete="new-password" ${secure && data.encryption_ready ? '' : 'disabled'} placeholder="${current?.has_key ? 'Saved key unchanged' : 'API key'}">${!secure ? html(["<span class=\"secondary-cell\">[[api_keys_require_an_https_connection]]</span>"]) : !data.encryption_ready ? html(["<span class=\"secondary-cell\">[[server_key_encryption_is_not_configured]]</span>"]) : ''}${current?.has_key ? html(["<label><input name=\"remove_key\" type=\"checkbox\">[[remove_saved_key]]</label>"]) : ''}</div><div class="field"><label for="ai-model">[[model]]</label><input id="ai-model" name="model" maxlength="200" list="ai-models" value="${esc(current?.model || '')}"><datalist id="ai-models">${(current?.models || []).map(model => html`<option value="${esc(model)}"></option>`).join('')}</datalist></div><div class="field"><label for="ai-limit">[[daily_request_limit]]</label><input id="ai-limit" name="request_limit" type="number" min="1" max="10000" value="${current?.request_limit || 100}" required></div><div class="field full checkbox-field"><label><input name="enabled" type="checkbox" ${current?.enabled ? 'checked' : ''}>[[enabled]]</label></div><fieldset class="field full ai-environments"><legend>[[allowed_environments]]</legend><p class="ai-environments-help">[[choose_which_environments_can_use_this_connection]]</p><div class="ai-environment-options">${data.environments.map(environment => html`<label><input name="environment_ids" type="checkbox" value="${esc(environment.id)}" ${current?.environment_ids.includes(environment.id) ? 'checked' : ''}><span>${esc(environment.name)}</span></label>`).join('') || html(["<span class=\"secondary-cell\">[[no_environments_available]]</span>"])}</div></fieldset></div><div class="ai-editor-actions"><button type="button" class="button" data-ai-cancel>[[cancel]]</button><button type="submit" class="button primary">[[save_connection]]</button></div></form>` : '';
  document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><section class="modal ai-settings-modal"><div class="modal-head"><h2>[[ai_providers]]</h2><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="ai-settings-error" role="alert" hidden></p><p class="ai-test-result" id="ai-test-result" role="status" hidden></p><div class="ai-settings-toolbar"><div class="field"><label for="ai-default">[[default_connection]]</label><select id="ai-default"><option value="">[[none]]</option>${data.providers.filter(provider => provider.enabled && provider.has_key && provider.model).map(provider => html`<option value="${esc(provider.id)}" ${provider.is_default ? 'selected' : ''}>${esc(provider.name)}</option>`).join('')}</select></div><button type="button" class="button" data-ai-new>[[new_connection]]</button></div><div class="table-wrap"><table class="ai-provider-table"><thead><tr><th>[[connection]]</th><th>[[model]]</th><th>[[status]]</th><th>[[requests_today]]</th><th>[[actions]]</th></tr></thead><tbody>${rows || html(["<tr><td colspan=\"5\">[[no_ai_connections]]</td></tr>"])}</tbody></table></div>${editor}</div><div class="modal-foot"><button type="button" class="button" data-administration-settings>[[back]]</button></div></section></div>`;
  const root = document.querySelector('.ai-settings-modal');
  if (editing) {
    const customInput = root.querySelector('#ai-model');
    const modelSelect = document.createElement('select');
    modelSelect.id = 'ai-model';
    modelSelect.name = 'model';
    const choices = [...new Set([...(current?.models || []), ...(current?.model ? [current.model] : [])])].sort();
    modelSelect.innerHTML = html`<option value="">${choices.length ? t("select_model") : t("no_models_loaded")}</option>${choices.map(model => html`<option value="${esc(model)}">${esc(model)}</option>`).join('')}<option value="__custom__">[[custom_model]]</option>`;
    modelSelect.value = current?.model || '';
    customInput.id = 'ai-model-custom';
    customInput.removeAttribute('list');
    customInput.setAttribute('aria-label', 'Custom model ID');
    customInput.placeholder = t("model_id");
    customInput.hidden = true;
    customInput.disabled = true;
    customInput.before(modelSelect);
    root.querySelector('#ai-models').remove();
    modelSelect.addEventListener('change', () => {
      const custom = modelSelect.value === '__custom__';
      modelSelect.name = custom ? '' : 'model';
      customInput.hidden = !custom;
      customInput.disabled = !custom;
      customInput.required = custom;
      if (custom) customInput.focus();
    });
    if (current) {
      const refresh = document.createElement('button');
      refresh.type = 'button';
      refresh.className = 'button icon-only ai-model-refresh';
      refresh.dataset.aiTest = current.id;
      refresh.title = t("refresh_models_from_saved_connection");
      refresh.setAttribute('aria-label', 'Refresh models');
      refresh.disabled = !current.has_key;
      refresh.innerHTML = html(["<img src=\"/frontend/icons/refresh-cw.svg\" width=\"16\" height=\"16\" alt=\"\">"]);
      const controls = document.createElement('div');
      controls.className = 'ai-model-controls';
      modelSelect.before(controls);
      controls.append(modelSelect, refresh);
    }
  }
  if (!window.isSecureContext && data.allow_insecure_http) {
    const warning = document.createElement('p');
    warning.className = 'form-error';
    warning.textContent = t("http_testing_enabled_api_keys_are_exposed_in_transit_use_a_temporary_restricted_key_and_re");
    root.querySelector('.modal-body').prepend(warning);
  }
  const errorMessage = message => { const element = root.querySelector('#ai-settings-error'); element.textContent = message; element.hidden = false; };
  const run = async (button, action) => {
    button.disabled = true;
    root.querySelector('#ai-settings-error').hidden = true;
    try { await action(); } catch (error) { errorMessage(error.message); }
    finally { if (button.isConnected) button.disabled = false; }
  };
  root.querySelector('[data-ai-new]').addEventListener('click', () => openAIProviders(apiRequest, esc, 'new'));
  root.querySelector('[data-ai-cancel]')?.addEventListener('click', () => openAIProviders(apiRequest, esc));
  root.querySelectorAll('[data-ai-edit]').forEach(button => button.addEventListener('click', () => openAIProviders(apiRequest, esc, button.dataset.aiEdit)));
  root.querySelectorAll('[data-ai-delete]').forEach(button => button.addEventListener('click', () => {
    if (!confirm(t("delete_this_ai_connection_and_its_saved_key"))) return;
    run(button, async () => { await apiRequest(`/api/settings/ai/providers/${button.dataset.aiDelete}`, { method: 'DELETE' }); await openAIProviders(apiRequest, esc); });
  }));
  root.querySelectorAll('[data-ai-test]').forEach(button => button.addEventListener('click', () => run(button, async () => {
    const result = await apiRequest(`/api/settings/ai/providers/${button.dataset.aiTest}/test`, { method: 'POST' });
    await openAIProviders(apiRequest, esc, button.dataset.aiTest);
    const message = document.getElementById('ai-test-result');
    if (message) { message.textContent = result.message; message.hidden = false; message.classList.toggle('form-error', !result.ok); }
  })));
  const defaultSelect = root.querySelector('#ai-default');
  defaultSelect.addEventListener('change', () => run(defaultSelect, async () => {
    await apiRequest('/api/settings/ai/default', { method: 'PUT', body: JSON.stringify({ provider_id: defaultSelect.value || null }) });
    await openAIProviders(apiRequest, esc, selectedId);
  }));
  root.querySelector('#ai-vendor')?.addEventListener('change', event => {
    root.querySelector('#ai-endpoint-field').hidden = event.target.value !== 'compatible';
  });
  root.querySelector('#ai-provider-form')?.addEventListener('submit', event => {
    event.preventDefault();
    const form = event.currentTarget;
    run(form.querySelector('[type="submit"]'), async () => {
      const values = new FormData(form);
      const payload = { name: values.get('name'), vendor: values.get('vendor'), base_url: values.get('base_url') || '',
        model: values.get('model') || '', enabled: values.has('enabled'), remove_key: values.has('remove_key'),
        environment_ids: values.getAll('environment_ids'), request_limit: Number(values.get('request_limit')) };
      const key = String(values.get('api_key') || '').trim();
      if (key) payload.api_key = key;
      const result = await apiRequest(`/api/settings/ai/providers${current ? '/' + current.id : ''}`, { method: current ? 'PUT' : 'POST', body: JSON.stringify(payload) });
      form.querySelector('#ai-key').value = '';
      await openAIProviders(apiRequest, esc, result.id);
    });
  });
}
