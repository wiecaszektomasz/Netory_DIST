import { assetRoomId } from './room-map.js?v=20261026-room-visibility1';
import { html, t } from './i18n.js?v=20261015-map-admin2';
import { esc, getPortType, getPortSpeed } from './utils.js?v=20261015-map-admin2';

export function rackAssetFields(asset, racks) {
  return html`<div class="field full" data-rack-settings ${asset.type === 'Virtual server' ? 'hidden' : ''}>
    <div class="rack-settings-heading"><div><strong>[[rack_placement]]</strong><p class="panel-sub">[[choose_where_this_device_sits_in_a_cabinet]]</p></div></div>
    <label class="rack-enable-toggle"><input type="checkbox" name="rackEnabled" ${asset.rackEnabled ? 'checked' : ''}><span><strong>[[mount_this_device_in_a_rack]]</strong><span class="rack-field-hint">[[enable_for_physical_devices_that_occupy_rack_units]]</span></span></label>
    <div class="rack-fields">
      <label class="rack-cabinet-field"><span>[[cabinet]]</span><select name="rackId"><option value="">[[not_assigned_place_later]]</option>${racks.map(rack => html`<option value="${esc(rack.id)}" data-capacity="${rack.capacityU}" ${asset.rackId === rack.id ? 'selected' : ''}>${esc(rack.name)}${rack.location ? ` · ${esc(rack.location)}` : ''} (${rack.capacityU}U)</option>`).join('')}</select><span class="rack-field-hint">${racks.length ? t("select_a_cabinet_or_leave_this_device_unassigned") : t("no_cabinets_available_create_one_in_rack_view_or_assign_this_device_later")}</span></label>
      <label><span>[[device_height_u]]</span><input name="rackUnits" type="number" min="1" max="100" value="${esc(asset.rackUnits || 1)}"><span class="rack-field-hint">[[number_of_rack_units_occupied]]</span></label>
      <label><span>[[starting_position_u]]</span><input name="rackStartU" type="number" min="1" max="100" placeholder="e.g. 10" value="${esc(asset.rackStartU ?? '')}"><span class="rack-field-hint">[[the_lowest_unit_occupied_by_this_device]]</span></label>
    </div><p class="panel-sub rack-position-note" data-rack-position-help>[[units_count_from_the_bottom_a_2u_device_starting_at_u10_occupies_u10_u11]]</p></div>`;
}

export function bindRackFields(form) {
  const container = form.querySelector('[data-rack-settings]');
  if (!container) return;
  const enabled = container.querySelector('[name="rackEnabled"]');
  const cabinet = container.querySelector('[name="rackId"]');
  const sync = () => {
    const virtual = form.querySelector('[name="type"]')?.value === 'Virtual server';
    container.hidden = virtual;
    container.querySelector('.rack-fields').hidden = !enabled.checked || virtual;
    const help = container.querySelector('[data-rack-position-help]');
    help.hidden = !enabled.checked || virtual;
    help.textContent = cabinet.value ? 'U1 is at the bottom. Starting U is the lowest unit occupied by this device; placements cannot overlap.' : 'No cabinet assigned. This device will appear in the unassigned rack devices list.';
    container.querySelectorAll('.rack-fields input, .rack-fields select').forEach(input => { input.disabled = !enabled.checked || virtual; });
    const start = container.querySelector('[name="rackStartU"]');
    start.disabled = !enabled.checked || virtual || !cabinet.value;
    start.required = !start.disabled;
    const capacity = Number(cabinet.selectedOptions[0]?.dataset.capacity) || 100;
    start.max = String(Math.max(1, capacity - (Number(container.querySelector('[name="rackUnits"]').value) || 1) + 1));
    container.querySelector('[name="rackUnits"]').required = enabled.checked && !virtual;
  };
  enabled.addEventListener('change', sync);
  cabinet.addEventListener('change', sync);
  container.querySelector('[name="rackUnits"]').addEventListener('input', sync);
  form.querySelector('[name="type"]')?.addEventListener('change', sync);
  sync();
}

export function rackPortDetails(data) {
  const assets = new Map((data.assets || []).map(asset => [asset.id, asset]));
  const peers = new Map();
  const add = (a, portA, b, portB, lag = '', connectionId = `${a}:${portA}:${b}:${portB}`) => {
    peers.set(`${a}:${Number(portA)}`, {device: assets.get(b), port: Number(portB), lag, connectionId});
    peers.set(`${b}:${Number(portB)}`, {device: assets.get(a), port: Number(portA), lag, connectionId});
  };
  for (const link of data.connections || []) add(link.deviceAId, link.portA, link.deviceBId, link.portB);
  for (const lag of data.lags || []) {
    const a = lag.membersA || (lag.portsA || []).map(port => ({deviceId:lag.deviceAId,port}));
    const b = lag.membersB || (lag.portsB || []).map(port => ({deviceId:lag.deviceBId,port}));
    a.forEach((member, index) => { if (b[index]) add(member.deviceId, member.port, b[index].deviceId, b[index].port, lag.name); });
  }
  return (asset, port) => {
    const peer = peers.get(`${asset.id}:${port}`);
    const internet = (asset.internetPorts || []).some(value => Number(value) === port);
    const config = asset.portVlans?.[port] || {untaggedVlan:1, taggedVlans:[]};
    const tagged = config.taggedVlans || [];
    const untagged = config.untaggedVlan;
    const patchPanel = asset.type === 'Patch panel';
    let label = `${asset.name} port ${port} ${patchPanel ? '' : `(${getPortType(asset, port)} · ${getPortSpeed(asset, port)})`}`.trim();
    label += peer ? `, connected to ${peer.device?.name || 'peer'} port ${peer.port} ${patchPanel ? '' : `(${getPortType(peer.device, peer.port)})`}`.trim()
      : internet ? ', connected directly to the Internet' : ', not connected';
    if (peer?.lag) label += ` · LAG ${peer.lag}`;
    if (!patchPanel) label += ` · Untagged VLAN: ${untagged ?? 'none'} · Tagged VLANs: ${tagged.length ? tagged.join(', ') : 'none'}`;
    return {label, connected:Boolean(peer || internet), connectionId:peer?.connectionId || (internet ? `internet-${asset.id}-${port}` : '')};
  };
}

function rackDeviceFace(asset, details) {
  const count = Math.max(0, Math.min(256, Number(asset.portCount) || 0));
  if (!count) return '';
  const columns = Math.min(26, count <= 8 ? count : Math.ceil(count / 2));
  const rows = Math.ceil(count / columns);
  const width = 180, height = Math.max(8 + rows * 7, (Number(asset.rackUnits) || 1) * 14);
  const step = 5.5, portWidth = 4.5;
  const ports = Array.from({length:count}, (_, index) => {
    const port = index + 1;
    const {label, connected, connectionId} = details(asset, port);
    const x = 4 + (index % columns) * step, y = 8 + Math.floor(index / columns) * 7;
    return html`<g role="img" data-rack-port="${esc(`${asset.id}:${port}`)}" ${connectionId ? `data-connection-id="${esc(connectionId)}"` : ''} aria-label="${esc(t(label))}"><title>${esc(t(label))}</title><rect class="map-port ${connected ? 'connected' : ''}" x="${x}" y="${y}" width="${portWidth}" height="4.5" rx="1"></rect><text class="map-port-label ${connected ? 'connected' : ''}" x="${x+portWidth/2}" y="${y+3.5}">${port}</text></g>`;
  }).join('');
  return html`<svg class="rack-device-face" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="group" aria-label="${esc(`${asset.name}, ${asset.type}, ${count} ports`)}"><rect class="map-node" x="0" y="0" width="${width}" height="${height}" rx="2"></rect><rect class="map-node-accent" x="0" y="0" width="2" height="${height}" rx="1"></rect><text class="rack-face-name" x="4" y="6">${esc(asset.name.slice(0,45))}</text>${ports}</svg>`;
}

export function renderRackRoomFilter(rooms = [], roomIds = []) {
  const selected = new Set(roomIds);
  return html`<details class="rack-room-filter"><summary>[[rooms_a35fb3]] ${selected.size ? `${selected.size} selected` : t("all")}</summary><div class="rack-room-options"><button class="button" type="button" data-map-all-rooms>[[all_rooms]]</button>${[...rooms, {id:'',name:'No room assigned'}].map(room => html`<label><input type="checkbox" data-map-room="${esc(room.id)}" ${selected.has(room.id) ? 'checked' : ''}>${esc(room.name)}</label>`).join('')}</div></details>`;
}

export function renderRackView(data, editable = false, { compact = false, roomIds = [], size = 100, showRoomFilter = true } = {}) {
  const rooms = data.rooms || [];
  const selected = new Set(roomIds);
  const racks = (data.racks || []).filter(rack => !selected.size || selected.has(rack.roomId || '')).sort((a, b) => String(a.roomId || '').localeCompare(String(b.roomId || '')) || (Number(a.displayOrder) || 1) - (Number(b.displayOrder) || 1) || a.name.localeCompare(b.name));
  const roomNames = new Map(rooms.map(room => [room.id, room.name]));
  const filter = showRoomFilter ? renderRackRoomFilter(rooms, roomIds) : '';
  const assets = data.assets || [];
  const portDetails = rackPortDetails(data);
  const cards = racks.map(rack => {
    const placed = assets.filter(asset => asset.rackEnabled && asset.rackId === rack.id);
    const used = placed.reduce((sum, asset) => sum + Number(asset.rackUnits), 0);
    const slots = Array.from({length:rack.capacityU}, (_, i) => html`<div class="rack-slot" style="grid-row:${i+1}"><span>U${rack.capacityU-i}</span></div>`).join('');
    const devices = placed.map(asset => {
      const end = asset.rackStartU + asset.rackUnits - 1;
      const face = rackDeviceFace(asset, portDetails);
      const ups = assets.find(item => item.id === asset.backupUpsId);
      const powerLabel = `Backup power${ups ? ` · UPS: ${ups.name}` : ''}`;
      const powerBadge = asset.backupPowerEnabled
        ? html`<svg class="map-backup-power rack-backup-power" viewBox="0 0 6 9" role="img" aria-label="${esc(powerLabel)}"><title>${esc(powerLabel)}</title><path d="M 4 0 L 0 5 H 2 L 1 9 L 6 3 H 3 Z"></path></svg>` : '';
      return `<${editable ? 'button' : 'div'} data-map-device-id="${esc(asset.id)}" class="rack-device ${asset.type === 'Patch panel' ? 'rack-patch-panel' : ''} ${asset.backupPowerEnabled ? 'has-backup-power' : ''} ${face ? 'rack-device-with-ports' : ''}" ${editable ? `type="button" data-rack-device="${esc(asset.id)}"` : ''} style="grid-row:${rack.capacityU-end+1}/span ${asset.rackUnits}" ${face ? '' : `title="${esc(`${asset.name} · U${asset.rackStartU}–U${end} · ${asset.type}`)}"`}>${face || html`<strong>${esc(asset.name)}</strong><span>${asset.rackUnits}U · ${esc(asset.type)}</span>`}${powerBadge}</${editable ? 'button' : 'div'}>`;
    }).join('');
    return html`<section class="rack-card"><div class="panel-head"><div><h3>${esc(rack.name)}</h3><div class="panel-sub">${esc(roomNames.get(rack.roomId) || 'No room assigned')} · ${esc(rack.location || 'Location not set')} · ${rack.capacityU}U · ${used}U used</div></div></div>${editable && !compact ? html`<div class="rack-actions"><button class="button" data-rack-assign="${esc(rack.id)}">[[assign_device]]</button>${compact ? '' : html`<button class="button" data-rack-edit="${esc(rack.id)}">[[edit_cabinet]]</button><button class="button" data-rack-delete="${esc(rack.id)}">[[delete]]</button>`}</div>` : ''}<div class="rack-cabinet" style="grid-template-rows:repeat(${rack.capacityU}, 24px)">${slots}${devices}</div></section>`;
  }).join('');
  const unassigned = assets.filter(asset => asset.rackEnabled && !asset.rackId);
  return html`<div class="rack-view ${compact ? 'rack-view-compact' : ''}"><div class="list-toolbar"><div><strong>${racks.length} cabinet${racks.length === 1 ? '' : 's'}</strong>${compact ? '' : html(["<div class=\"panel-sub\">[[u1_is_at_the_bottom_starting_u_is_the_lowest_unit_occupied_by_a_device]]</div>"])}</div>${editable && !compact ? html(["<button class=\"button primary\" data-rack-new>[[new_cabinet_8e12e1]]</button>"]) : ''}</div>${filter}<div class="rack-grid" style="zoom:${Math.max(25, Math.min(200, Number(size) || 100))/100}">${cards || html`<div class="empty-state">${(data.racks || []).length ? t("no_cabinets_in_the_selected_rooms") : t("no_rack_cabinets_yet")}</div>`}</div><section class="panel rack-unassigned"><h3>[[unassigned_rack_devices]]${unassigned.length})</h3>${unassigned.map(asset => editable ? html`<button data-map-device-id="${esc(asset.id)}" class="button ${asset.type === 'Patch panel' ? 'rack-patch-panel' : ''}" data-rack-device="${esc(asset.id)}">${esc(asset.name)} · ${asset.rackUnits}U</button>` : html`<span data-map-device-id="${esc(asset.id)}" class="tag ${asset.type === 'Patch panel' ? 'rack-patch-panel' : ''}">${esc(asset.name)} · ${asset.rackUnits}U</span>`).join('') || html(["<p class=\"panel-sub\">[[all_rack_enabled_devices_are_assigned]]</p>"])}</section></div>`;
}

export function firstFreeRackUnit(data, rackId, height, excludingId = '') {
  const rack = (data.racks || []).find(item => item.id === rackId);
  if (!rack || !Number.isInteger(height) || height < 1) return null;
  const placed = (data.assets || []).filter(asset => asset.id !== excludingId && asset.rackEnabled && asset.rackId === rackId);
  for (let start = 1; start + height - 1 <= rack.capacityU; start++) {
    if (placed.every(asset => start + height <= asset.rackStartU || start >= asset.rackStartU + asset.rackUnits)) return start;
  }
  return null;
}

export function bindRackMapControls(view, {expanded = false, onExpanded = () => {}, size = 100, onSize = () => {}} = {}) {
  const workspace = view.querySelector('.network-map-workspace');
  const scroll = view.querySelector('.network-map-scroll');
  const content = view.querySelector('.rack-view');
  const expand = view.querySelector('[data-map-expand]');
  const magnifier = view.querySelector('[data-rack-magnifier]');
  if (!workspace || !scroll || !content || !expand || !magnifier) return;
  const lens = view.ownerDocument.createElement('div');
  lens.className = 'map-magnifying-lens rack-magnifying-lens';
  lens.setAttribute('aria-hidden', 'true');
  lens.hidden = true;
  workspace.append(lens);
  let enabled = false, copy = null, lastPointer = null;
  const move = event => {
    if (!enabled || !copy) return;
    lastPointer = {clientX:event.clientX, clientY:event.clientY};
    const viewport = scroll.getBoundingClientRect();
    if (event.clientX < viewport.left || event.clientX > viewport.right || event.clientY < viewport.top || event.clientY > viewport.bottom) { lens.hidden = true; return; }
    const bounds = content.getBoundingClientRect();
    const frame = workspace.getBoundingClientRect();
    const size = Math.max(40, Math.min(200, viewport.width - 16, viewport.height - 16));
    lens.style.width = lens.style.height = `${size}px`;
    lens.style.left = `${Math.max(viewport.left, Math.min(event.clientX-size/2, viewport.right-size))-frame.left}px`;
    lens.style.top = `${Math.max(viewport.top, Math.min(event.clientY-size/2, viewport.bottom-size))-frame.top}px`;
    copy.style.width = `${bounds.width}px`;
    copy.style.transform = `translate(${size/2-(event.clientX-bounds.left)*3}px, ${size/2-(event.clientY-bounds.top)*3}px) scale(3)`;
    lens.hidden = false;
  };
  magnifier.addEventListener('click', () => {
    enabled = !enabled;
    magnifier.setAttribute('aria-pressed', String(enabled));
    magnifier.classList.toggle('active', enabled);
    scroll.classList.toggle('is-magnifying', enabled);
    lens.hidden = true;
    if (enabled) {
      copy = content.cloneNode(true);
      copy.inert = true;
      copy.setAttribute('aria-hidden', 'true');
      copy.removeAttribute('id');
      copy.querySelectorAll('[id]').forEach(element => element.removeAttribute('id'));
      lens.replaceChildren(copy);
      const bounds = scroll.getBoundingClientRect();
      move({clientX:bounds.left+bounds.width/2, clientY:bounds.top+bounds.height/2});
    } else { lens.replaceChildren(); copy = null; }
  });
  const slider = view.querySelector('[data-rack-size]');
  const sizeLabel = view.querySelector('[data-rack-size-value]');
  const applySize = value => {
    size = Math.max(25, Math.min(200, Number(value) || 100));
    const grid = content.querySelector?.('.rack-grid');
    if (grid) grid.style.zoom = String(size / 100);
    const enlargedGrid = copy?.querySelector?.('.rack-grid');
    if (enlargedGrid) enlargedGrid.style.zoom = String(size / 100);
    if (slider) slider.value = String(size);
    if (sizeLabel) sizeLabel.textContent = `${size}%`;
    onSize(size);
    if (enabled && lastPointer) move(lastPointer);
  };
  slider?.addEventListener('input', event => applySize(event.target.value));
  (view.querySelectorAll?.('[data-rack-size-step]') || []).forEach(button => button.addEventListener('click', () => applySize(size + Number(button.dataset.rackSizeStep))));
  view.querySelector('[data-rack-fit]')?.addEventListener('click', () => {
    applySize(100);
    // Scaling changes the number of cabinet columns, so remeasure after each
    // adjustment rather than fitting only the initial row arrangement.
    for (let attempt = 0; attempt < 4; attempt++) {
      const bounds = content.getBoundingClientRect();
      const width = Math.max(bounds.width, content.scrollWidth || 0);
      const height = Math.max(bounds.height, content.scrollHeight || 0);
      const availableWidth = Math.max(1, scroll.clientWidth - 24);
      const availableHeight = Math.max(1, scroll.clientHeight - 24);
      const ratio = Math.min(1, availableWidth / Math.max(1, width), availableHeight / Math.max(1, height));
      if (ratio >= .99 || size <= 25) break;
      applySize(Math.max(25, Math.floor(size * ratio)));
    }
    scroll.scrollLeft = scroll.scrollTop = 0;
    lens.hidden = true;
  });
  const setExpanded = value => {
    expanded = value;
    onExpanded(value);
    workspace.classList.toggle('is-expanded', value);
    expand.setAttribute('aria-expanded', String(value));
    expand.textContent = value ? 'Close large map' : 'Expand map';
    lens.hidden = true;
    expand.focus();
  };
  expand.addEventListener('click', () => setExpanded(!expanded));
  const portTarget = target => target?.closest?.('[data-rack-port]');
  const highlightPort = target => {
    const port = portTarget(target);
    const connectionId = port?.dataset.connectionId;
    const portId = port?.dataset.rackPort;
    for (const root of [content, copy]) {
      root?.querySelectorAll('[data-rack-port]').forEach(element => {
        const highlighted = Boolean(portId) && (connectionId
          ? element.dataset.connectionId === connectionId
          : element.dataset.rackPort === portId);
        element.querySelector('.map-port')?.classList.toggle('is-highlighted', highlighted);
      });
    }
  };
  scroll.addEventListener('pointerover', event => highlightPort(event.target));
  scroll.addEventListener('pointerout', event => highlightPort(event.relatedTarget));
  scroll.addEventListener('pointermove', move);
  scroll.addEventListener('pointerdown', move);
  scroll.addEventListener('pointerleave', () => { lens.hidden = true; });
  scroll.addEventListener('scroll', () => { if (lastPointer && !lens.hidden) move(lastPointer); });
  workspace.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (enabled) { event.preventDefault(); magnifier.click(); magnifier.focus(); }
      else if (expanded) { event.preventDefault(); setExpanded(false); }
    }
    if (event.key === 'Tab' && expanded) {
      const controls = [...workspace.querySelectorAll('button, input, select')].filter(element => !element.disabled && !element.closest('[hidden], [inert]'));
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && view.ownerDocument.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && view.ownerDocument.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  });
}

export function renderRooms(data, editable = false) {
  const rooms = data.rooms || [];
  return html`<section class="panel"><div class="panel-head"><div><h3>[[rooms]]</h3><p class="panel-sub">[[rooms_assets_intro]]</p></div>${editable ? html(["<button class=\"button primary\" data-room-new>[[new_room_3cc8fe]]</button>"]) : ''}</div><div class="table-wrap"><table><thead><tr><th>[[room]]</th><th>[[cabinets]]</th><th>[[assets]]</th><th></th></tr></thead><tbody>${rooms.map(room => html`<tr><td>${esc(room.name)}</td><td>${(data.racks || []).filter(rack => rack.roomId === room.id).length}</td><td>${(data.assets || []).filter(asset => assetRoomId(asset, data) === room.id).length}</td><td>${editable ? html`<div class="row-actions"><button data-room-assign="${esc(room.id)}">[[assign_assets_to_room]]</button><button data-room-edit="${esc(room.id)}">[[edit]]</button><button data-room-delete="${esc(room.id)}">[[delete]]</button></div>` : ''}</td></tr>`).join('') || html(["<tr><td colspan=\"4\">[[no_rooms_yet]]</td></tr>"])}</tbody></table></div></section>`;
}
