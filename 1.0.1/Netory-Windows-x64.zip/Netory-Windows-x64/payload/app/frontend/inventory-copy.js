export function assetCopyDraft(source) {
  const draft = structuredClone(source);
  delete draft.id;
  draft.name = `${source.name.slice(0, 233)} (copy)`;
  if (draft.hypervisorClusterId) draft.hypervisorId = `cluster:${draft.hypervisorClusterId}`;
  return draft;
}
