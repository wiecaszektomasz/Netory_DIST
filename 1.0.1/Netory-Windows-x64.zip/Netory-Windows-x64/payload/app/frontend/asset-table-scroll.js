export function bindAssetTableScroll(root) {
  const viewport = root.querySelector('[data-asset-scroll]');
  const scrollbar = root.querySelector('[data-asset-scrollbar]');
  const width = root.querySelector('[data-asset-scroll-width]');
  if (!viewport || !scrollbar || !width) return () => {};
  const table = viewport.querySelector('table');
  const fromTable = () => { scrollbar.scrollLeft = viewport.scrollLeft; };
  const fromScrollbar = () => { viewport.scrollLeft = scrollbar.scrollLeft; };
  const resize = () => {
    width.style.width = `${viewport.scrollWidth}px`;
    scrollbar.hidden = viewport.scrollWidth <= viewport.clientWidth + 1;
    fromTable();
  };
  viewport.addEventListener('scroll', fromTable, {passive: true});
  scrollbar.addEventListener('scroll', fromScrollbar, {passive: true});
  const observer = new ResizeObserver(resize);
  observer.observe(viewport);
  if (table) observer.observe(table);
  resize();
  return () => {
    observer.disconnect();
    viewport.removeEventListener('scroll', fromTable);
    scrollbar.removeEventListener('scroll', fromScrollbar);
  };
}
