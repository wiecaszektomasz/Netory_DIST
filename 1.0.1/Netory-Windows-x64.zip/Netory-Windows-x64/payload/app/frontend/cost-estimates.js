import { html, t } from './i18n.js?v=20261015-map-admin2';
import { esc } from './utils.js?v=20261015-map-admin2';

const currencyFormat = (value, currency) => new Intl.NumberFormat(undefined, {style: 'currency', currency}).format(Number(value));
const dateToday = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};
const selectedEstimates = new Map();
const basePath = id => `/api/environments/${encodeURIComponent(id)}/cost-estimates`;

export function costPricingFields(section, record, estimates) {
  const options = estimates.map(estimate => html`<option value="${esc(estimate.id)}" data-currency="${esc(estimate.currency)}" ${record?.costEstimateId === estimate.id ? 'selected' : ''}>${esc(estimate.name)} · ${esc(estimate.currency)}</option>`).join('');
  return html`<fieldset class="cost-pricing-fields full" data-cost-pricing ${section === 'assets' && record?.status !== 'Planned' ? 'hidden disabled' : ''}><legend>${section === 'assets' ? t("planned_device_cost") : t("license_cost")}</legend><div class="form-grid"><div class="field"><label for="record-cost-estimate">[[cost_estimate]]</label><select id="record-cost-estimate" name="costEstimateId"><option value="">[[not_assigned]]</option>${options}</select></div><div class="field"><label for="record-net-price">[[net_price]] <span data-cost-currency></span></label><input id="record-net-price" name="netPrice" type="number" min="0" max="999999999.99" step="0.01" value="${esc(record?.netPrice ?? '')}" placeholder="0.00"></div></div><p class="secondary-cell">[[price_excludes_tax]] ${section === 'licenses' ? t("enter_the_total_license_cost_not_a_per_seat_price_5921e2") : t("each_device_contributes_one_item_d20d23")}Tax is added once in the estimate summary.${estimates.length ? '' : ' Create a cost estimate in the left menu first.'}</p></fieldset>`;
}

export function bindCostPricing(form, section) {
  const fieldset = form.querySelector('[data-cost-pricing]');
  if (!fieldset) return;
  const status = form.querySelector('[name="status"]');
  const estimate = fieldset.querySelector('[name="costEstimateId"]');
  const price = fieldset.querySelector('[name="netPrice"]');
  let previousCurrency = estimate.selectedOptions[0]?.dataset.currency;
  const syncStatus = () => {
    const enabled = section === 'licenses' || status?.value === 'Planned';
    fieldset.hidden = !enabled;
    fieldset.disabled = !enabled;
  };
  const syncEstimate = event => {
    const currency = estimate.selectedOptions[0]?.dataset.currency || '';
    if (event && previousCurrency && currency && previousCurrency !== currency) price.value = '';
    fieldset.querySelector('[data-cost-currency]').textContent = currency ? `(${currency})` : '';
    price.required = Boolean(estimate.value);
    if (currency) previousCurrency = currency;
  };
  status?.addEventListener('change', syncStatus);
  estimate.addEventListener('change', syncEstimate);
  syncStatus(); syncEstimate();
}

export async function renderCostEstimates({root, environmentId, canEdit, apiRequest, modalRoot, closeModal, toast, isCurrent, onDeleted}) {
  root.innerHTML = html(["<section class=\"panel\"><div class=\"empty-state\" role=\"status\">[[loading_cost_estimates]]</div></section>"]);
  const token = Symbol('cost-load');
  root.costLoadToken = token;
  let estimates;
  let defaults;
  try {
    [estimates, defaults] = await Promise.all([apiRequest(basePath(environmentId)), apiRequest(basePath(environmentId) + '/defaults')]);
  } catch (error) {
    if (!isCurrent() || root.costLoadToken !== token) return;
    root.innerHTML = html`<section class="panel"><div class="empty-state"><strong>[[cost_estimates_could_not_be_loaded]]</strong><p>${esc(error.message)}</p><button class="button" data-cost-retry>[[retry]]</button></div></section>`;
    root.querySelector('[data-cost-retry]').addEventListener('click', reload);
    return;
  }
  if (!isCurrent() || root.costLoadToken !== token) return;
  function reload() {
    return renderCostEstimates({root, environmentId, canEdit, apiRequest, modalRoot, closeModal, toast, isCurrent, onDeleted});
  }
  const money = estimate => value => esc(currencyFormat(value, estimate.currency));
  root.innerHTML = html`<div class="overview-intro"><div><h2>[[project_cost_planning]]</h2><p>[[plan_net_costs_see_tax_and_the_complete_project_total]]</p></div>${canEdit ? html(["<button class=\"button primary\" data-cost-new>[[new_cost_estimate_7f653d]]</button>"]) : html(["<span class=\"tag\">[[read_only]]</span>"])}</div><div class="cost-estimate-layout"><section class="panel cost-estimate-list"><div class="panel-head"><strong>[[cost_estimates_ac443c]]${estimates.length})</strong></div>${estimates.length ? estimates.map(estimate => html`<button class="cost-estimate-choice" data-cost-id="${esc(estimate.id)}"><strong>${esc(estimate.name)}</strong><span>${esc(estimate.project_number || 'No project number')} · ${esc(estimate.currency)}</span><b>${money(estimate)(estimate.gross_total)}</b></button>`).join('') : html(["<div class=\"empty-state\"><strong>[[no_cost_estimates_yet]]</strong><p>[[create_an_estimate_then_assign_planned_devices_and_licenses_from_their_settings]]</p></div>"])}</section><div data-cost-detail></div></div>`;
  root.querySelector('[data-cost-new]')?.addEventListener('click', () => openEditor());
  root.querySelectorAll('[data-cost-id]').forEach(button => button.addEventListener('click', () => showEstimate(estimates.find(row => row.id === button.dataset.costId))));
  if (estimates.length) showEstimate(estimates.find(estimate => estimate.id === selectedEstimates.get(environmentId)) || estimates[0]);
  else root.querySelector('[data-cost-detail]').innerHTML = html(["<section class=\"panel\"><div class=\"empty-state\">[[choose_an_estimate_to_view_its_devices_licenses_custom_items_and_tax_summary]]</div></section>"]);

  function showEstimate(estimate) {
    selectedEstimates.set(environmentId, estimate.id);
    const format = money(estimate);
    root.querySelectorAll('[data-cost-id]').forEach(button => {
      const selected = button.dataset.costId === estimate.id;
      button.classList.toggle('active', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    root.querySelector('[data-cost-detail]').innerHTML = html`<section class="panel cost-estimate-detail"><div class="panel-head"><div><h2>${esc(estimate.name)}</h2><div class="panel-sub">[[project]] ${esc(estimate.project_number || '—')} · Valid until ${esc(estimate.valid_until)} · ${esc(estimate.currency)}</div></div>${canEdit ? html(["<div class=\"actions\"><button class=\"button\" data-cost-edit>[[estimate_settings]]</button><button class=\"button\" data-cost-delete>[[delete_estimate]]</button></div>"]) : ''}</div>${estimate.valid_until < dateToday() ? html(["<p class=\"cost-estimate-expired\">[[the_validity_date_has_passed]]</p>"]) : ''}<div class="cost-category-totals"><div><span>[[planned_devices]]</span><strong>${format(estimate.category_totals.device)}</strong></div><div><span>[[licenses]]</span><strong>${format(estimate.category_totals.license)}</strong></div><div><span>[[custom_items]]</span><strong>${format(estimate.category_totals.custom)}</strong></div></div><div class="table-wrap"><table><thead><tr><th>[[item]]</th><th>[[manufacturer_model]]</th><th>[[qty]]</th><th>[[unit_price_net]]</th><th>[[total_net]]</th></tr></thead><tbody>${estimate.lines.length ? estimate.lines.map(line => html`<tr><td class="primary-cell">${esc(line.name)}</td><td>${esc(line.manufacturer_model || '—')}</td><td>${esc(line.quantity)}</td><td>${format(line.unit_price)}</td><td>${format(line.net_total)}</td></tr>`).join('') : html(["<tr><td colspan=\"5\">[[no_priced_items_assigned_edit_a_planned_device_or_license_to_assign_it_or_add_a_custom_ite]]</td></tr>"])}</tbody></table></div>${estimate.excluded_devices.length ? html`<div class="cost-excluded"><strong>[[excluded_from_totals]]</strong><p>${estimate.excluded_devices.map(device => `${esc(device.name)} (${esc(device.status)})`).join(', ')} — only Planned devices contribute to this estimate.</p></div>` : ''}<div class="cost-final-summary"><div><span>[[net_subtotal]]</span><strong>${format(estimate.net_subtotal)}</strong></div><div><span>[[tax]]${esc(estimate.tax_rate)}%)</span><strong>${format(estimate.tax_total)}</strong></div><div class="cost-gross"><span>[[total_including_tax]]</span><strong>${format(estimate.gross_total)}</strong></div></div><p class="cost-summary-note">[[tax_is_calculated_once_on_the_net_subtotal_all_item_prices_exclude_tax]]</p></section>`;
    root.querySelector('[data-cost-edit]')?.addEventListener('click', () => openEditor(estimate));
    root.querySelector('[data-cost-delete]')?.addEventListener('click', async event => {
      if (!isCurrent() || !confirm(`Delete “${estimate.name}”? Custom items will be removed. Devices and licenses will remain, with their net prices preserved and estimate assignments cleared.`)) return;
      const button = event.currentTarget;
      button.disabled = true;
      try {
        const result = await apiRequest(basePath(environmentId) + '/' + encodeURIComponent(estimate.id), {method:'DELETE', headers:{'If-Match':String(estimate.version)}});
        onDeleted?.(result);
        selectedEstimates.delete(environmentId);
        if (isCurrent()) await reload();
        toast(t("cost_estimate_deleted"));
      } catch (error) { toast(error.message); if (button.isConnected) button.disabled = false; }
    });
  }

  function openEditor(existing = null) {
    if (!canEdit || !isCurrent()) return;
    const customRow = item => html`<div class="cost-custom-row"><div class="field"><label>[[description]]</label><input data-item-name aria-label="[[custom_item_description]]" maxlength="240" value="${esc(item.name || '')}" placeholder="[[installation_work]]" required></div><div class="field"><label>[[quantity]]</label><input data-item-quantity aria-label="[[quantity]]" type="number" min="0.001" max="1000000" step="0.001" value="${esc(item.quantity || '1')}" required></div><div class="field"><label>[[unit_price_net]]</label><input data-item-price aria-label="[[unit_net_price]]" type="number" min="0" max="999999999.99" step="0.01" value="${esc(item.unit_price ?? '0.00')}" required></div><button class="button icon-only" type="button" data-cost-remove aria-label="[[remove_custom_item]]">×</button></div>`;
    modalRoot.innerHTML = html`<div class="modal-backdrop"><form class="modal cost-estimate-modal"><div class="modal-head"><div><div class="eyebrow">[[cost_planning]]</div><h2>${existing ? t("estimate_settings") : t("new_cost_estimate")}</h2></div><button type="button" class="button icon-only" data-cost-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" data-cost-error role="alert" hidden></p><div class="form-grid"><div class="field"><label for="estimate-name">[[estimate_name]]</label><input id="estimate-name" name="name" value="${esc(existing?.name || '')}" maxlength="240" required></div><div class="field"><label for="estimate-project">[[project_number]]</label><input id="estimate-project" name="project_number" value="${esc(existing?.project_number || '')}" maxlength="120"></div><div class="field"><label for="estimate-valid">[[valid_until]]</label><input id="estimate-valid" name="valid_until" type="date" value="${esc(existing?.valid_until || dateToday())}" required></div><div class="field"><label for="estimate-currency">[[currency]]</label><select id="estimate-currency" name="currency">${['PLN','EUR','USD','GBP'].map(currency => html`<option ${currency === (existing?.currency || defaults.currency) ? 'selected' : ''}>${currency}</option>`).join('')}</select></div><div class="field"><label for="estimate-tax">[[tax_rate]]</label><input id="estimate-tax" name="tax_rate" type="number" min="0" max="100" step="0.01" value="${esc(existing?.tax_rate || '23.00')}" required></div></div><h3>[[custom_cost_items]]</h3><p class="secondary-cell">[[add_installation_work_materials_or_other_project_expenses_tax_is_added_to_the_final_summar]]</p><div data-cost-items>${(existing?.custom_items || []).map(customRow).join('')}</div><button class="button" type="button" data-cost-add>[[add_custom_item]]</button><p class="secondary-cell">[[device_and_license_prices_are_managed_in_their_own_settings_currency_changes_do_not_conver]]</p></div><div class="modal-foot"><button class="button" type="button" data-cost-close>[[cancel]]</button><button class="button primary" type="submit">${existing ? t("save_estimate") : t("create_estimate")}</button></div></form></div>`;
    const form = modalRoot.querySelector('form');
    form.querySelectorAll('[data-cost-close]').forEach(button => button.addEventListener('click', closeModal));
    form.querySelector('[data-cost-add]').addEventListener('click', () => {
      if (form.querySelectorAll('.cost-custom-row').length >= 500) return;
      form.querySelector('[data-cost-items]').insertAdjacentHTML('beforeend', customRow({}));
    });
    form.addEventListener('click', event => event.target.closest('[data-cost-remove]')?.closest('.cost-custom-row').remove());
    form.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); closeModal(); } });
    form.addEventListener('submit', async event => {
      event.preventDefault();
      if (!isCurrent() || !form.isConnected) return;
      const submit = form.querySelector('[type="submit"]');
      submit.disabled = true;
      const body = Object.fromEntries(new FormData(form));
      body.custom_items = [...form.querySelectorAll('.cost-custom-row')].map(row => ({name: row.querySelector('[data-item-name]').value, quantity: row.querySelector('[data-item-quantity]').value, unit_price: row.querySelector('[data-item-price]').value}));
      try {
        const saved = await apiRequest(basePath(environmentId) + (existing ? '/' + encodeURIComponent(existing.id) : ''), {method: existing ? 'PUT' : 'POST', headers: existing ? {'If-Match': String(existing.version)} : {}, body: JSON.stringify(body)});
        selectedEstimates.set(environmentId, saved.id);
        if (form.isConnected) closeModal();
        if (isCurrent()) await reload();
        toast(existing ? 'Cost estimate updated' : 'Cost estimate created');
      } catch (error) {
        if (form.isConnected) {
          const message = form.querySelector('[data-cost-error]');
          message.textContent = error.message; message.hidden = false; submit.disabled = false;
        }
      }
    });
    form.querySelector('[name="name"]').focus();
  }
}
