export function assetCopyDraft(e){const r=structuredClone(e);return delete r.id,r.name=`${e.name.slice(0,233)} (copy)`,r.hypervisorClusterId&&(r.hypervisorId=`cluster:${r.hypervisorClusterId}`),r}
