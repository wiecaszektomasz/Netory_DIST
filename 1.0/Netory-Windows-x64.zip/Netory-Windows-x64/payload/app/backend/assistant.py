import json
import base64
import re
from collections import Counter, deque
from datetime import date, datetime, timezone
from typing import Literal
from types import SimpleNamespace
from urllib.parse import quote

import httpx
from cryptography.fernet import InvalidToken
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from backend import assistant_config
from backend.assistant_config import (
    INVENTORY_FIELDS, RECORD_WRITE_FIELDS, RECORD_REQUIRED_FIELDS, ASSET_WRITE_FIELDS,
)
from backend.ai_providers import cipher, endpoint
from backend.db import get_db
from backend.models import AIProvider, AISettings, Membership, Asset, NetworkConnection, Vlan, ServerCluster, ServerClusterMember, NetworkDefinition, RackCabinet, Room, DeviceStack, DeviceStackMember, LinkAggregationGroup, Hypervisor, License, SpecialAccount
from backend.security import current_user, require_assistant_write
from backend.import_normalization import normalize_fields, SECTION_ALIASES, CHOICES
from backend.asset_types import ASSET_TYPES, normalize_asset_type
from backend.import_references import resolve_import_references
from backend.import_dates import date_clarification
from uuid import uuid4
from pydantic import ConfigDict, ValidationError

router = APIRouter(prefix='/api/assistant')

# Field allowlists and prompt text are centralized in assistant_config.py.


class Message(BaseModel):
    model_config = ConfigDict(extra='forbid')
    role: Literal['user', 'assistant']
    content: str = Field(min_length=1, max_length=6000)


class Attachment(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=1, max_length=160)
    content: str = Field(min_length=1, max_length=40000)


class AssetChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation: Literal['create', 'update']
    asset_id: str | None = Field(default=None, max_length=80)
    fields: dict = Field(min_length=1, max_length=48)


class ConnectionFields(BaseModel):
    model_config = ConfigDict(extra='forbid', strict=True)
    deviceAId: str = Field(min_length=1, max_length=244)
    portA: int = Field(ge=1, le=256)
    deviceBId: str = Field(min_length=1, max_length=244)
    portB: int = Field(ge=1, le=256)


class ConnectionChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation: Literal['connect']
    fields: ConnectionFields


class InventoryRecordChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation: Literal['create', 'update']
    section: Literal['assets', 'licenses', 'hypervisors', 'vlans', 'lans', 'wlans', 'stacks', 'clusters', 'lags', 'accounts', 'connections', 'rooms', 'racks']
    record_id: str | None = Field(default=None, min_length=1, max_length=80)
    fields: dict = Field(min_length=1, max_length=48)


def valid_record_id(value):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= 80


def validate_record_fields(section, fields):
    if section == 'assets':
        return validate_asset_fields(fields)
    normalize_fields(section, fields, RECORD_WRITE_FIELDS[section])
    if set(fields) - RECORD_WRITE_FIELDS[section]:
        raise ValueError(f'Unsupported or protected {section} fields: ' + ', '.join(sorted(set(fields) - RECORD_WRITE_FIELDS[section])))
    for field, value in fields.items():
        if field in ('capacityU', 'displayOrder'):
            if type(value) is not int or not 1 <= value <= (100 if field == 'capacityU' else 100000):
                raise ValueError('Invalid cabinet capacity or order')
        elif field in ('seats', 'assigned', 'idValue', 'vlanId', 'portA', 'portB'):
            minimum, maximum = (0, 2147483647) if field in ('seats', 'assigned') else (1, 256 if field in ('portA', 'portB') else 4094)
            if value == '' and field in ('seats', 'assigned', 'vlanId'):
                continue
            if type(value) is not int or not minimum <= value <= maximum:
                raise ValueError('Invalid inventory number')
        elif field == 'showOnMap':
            if type(value) is not bool:
                raise ValueError('Map visibility must be boolean')
        elif field in ('memberAssetIds', 'assignedAssetIds'):
            if not isinstance(value, list) or len(value) > 256 or any(not valid_record_id(item) for item in value) or len(value) != len(set(value)):
                raise ValueError('Member and assignment lists require unique asset IDs')
        elif field in ('portsA', 'portsB'):
            if not isinstance(value, list) or len(value) > 256 or any(type(port) is not int or not 1 <= port <= 256 for port in value) or len(value) != len(set(value)):
                raise ValueError('LAG ports must be unique port numbers')
        elif field in ('membersA', 'membersB'):
            if not isinstance(value, list) or len(value) > 256:
                raise ValueError('Invalid LAG member list')
            for member in value:
                if not isinstance(member, dict) or set(member) != {'deviceId', 'port'} or not valid_record_id(member['deviceId']) or type(member['port']) is not int or not 1 <= member['port'] <= 256:
                    raise ValueError('Invalid LAG member endpoint')
        elif field == 'parentInterface':
            if value is None:
                continue
            if not isinstance(value, dict):
                raise ValueError('Invalid network parent interface')
            if value.get('type') == 'vlan':
                if set(value) != {'type', 'vlanId'} or not valid_record_id(value['vlanId']):
                    raise ValueError('Invalid VLAN parent interface')
            elif value.get('type') == 'physical':
                if set(value) != {'type', 'deviceId', 'port'} or not valid_record_id(value['deviceId']) or type(value['port']) is not int or not 1 <= value['port'] <= 256:
                    raise ValueError('Invalid physical parent interface')
            else:
                raise ValueError('Invalid network parent interface type')
        else:
            limits = {'notes': 6000, 'dnsServers': 4000, 'dhcp': 4000, 'network': 120,
                      'gateway': 64, 'managementIp': 64, 'platform': 120, 'version': 120,
                      'type': 80, 'accountType': 80, 'deviceType': 80, 'security': 80,
                      'aggregationType': 16, 'masterDeviceId': 80, 'parentDeviceId': 80,
                      'vlanInterfaceId': 80, 'deviceAId': 80, 'deviceBId': 80, 'stackAId': 80, 'stackBId': 80}
            limit = 120 if section == 'lags' and field == 'name' else limits.get(field, 240)
            if not isinstance(value, str) or len(value) > limit:
                raise ValueError('Invalid inventory text')
            if field in ('expiry', 'rotation') and value:
                try:
                    date.fromisoformat(value)
                except ValueError:
                    raise ValueError('Dates must use YYYY-MM-DD') from None


def expand_port_map(value):
    expanded = {}
    for port_range, config in value.items():
        if not isinstance(port_range, str) or not re.fullmatch(r'[1-9][0-9]{0,2}(?:-[1-9][0-9]{0,2})?', port_range):
            raise ValueError('Port keys must be numbers or ranges such as 1-48')
        parts = port_range.split('-')
        first, last = int(parts[0]), int(parts[-1])
        if not 1 <= first <= last <= 256:
            raise ValueError('Port ranges must be between 1 and 256')
        for port in range(first, last + 1):
            key = str(port)
            if key in expanded:
                raise ValueError('Port ranges must not overlap')
            expanded[key] = config
    return expanded


def validate_asset_fields(fields):
    normalize_fields('assets', fields, ASSET_WRITE_FIELDS)
    if set(fields) - ASSET_WRITE_FIELDS:
        raise ValueError('Unsupported or protected asset fields: ' + ', '.join(sorted(set(fields) - ASSET_WRITE_FIELDS)))
    if 'type' in fields:
        fields['type'] = normalize_asset_type(fields['type'])
    for key, value in fields.items():
        if key in ('upsRatedVA', 'upsRatedW', 'upsRuntimeMinutes', 'upsBatteryCount'):
            if value is not None and (type(value) is not int or not 0 <= value <= 10000000):
                raise ValueError('UPS parameters must be non-negative integers or null')
        elif key == 'upsBatteryReplacementDate':
            if not isinstance(value, str):
                raise ValueError('UPS battery replacement date must be YYYY-MM-DD or empty')
            if value:
                try:
                    date.fromisoformat(value)
                except ValueError:
                    raise ValueError('Invalid UPS battery replacement date') from None
        elif key == 'backupUpsId':
            if not isinstance(value, str) or len(value) > 80:
                raise ValueError('Invalid backup UPS ID')
        elif key == 'portCount':
            if type(value) is not int or not 0 <= value <= 256:
                raise ValueError('Invalid port count')
        elif key in ('rackUnits', 'rackStartU'):
            if value is not None and (type(value) is not int or not 1 <= value <= 100):
                raise ValueError('Rack units and starting U must be integers from 1 to 100 or null')
        elif key == 'rackId':
            if value is not None and (not isinstance(value, str) or len(value) > 80):
                raise ValueError('Invalid rack cabinet ID')
        elif key in ('showOnMap', 'rackEnabled', 'backupPowerEnabled'):
            if type(value) is not bool:
                raise ValueError('Invalid map visibility')
        elif key == 'osFamily':
            if value not in ('', 'Windows', 'Linux', 'macOS', 'Other'):
                raise ValueError('Invalid operating system family')
        elif key == 'osEol':
            if not isinstance(value, str) or (value and not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value)):
                raise ValueError('OS end of life must be YYYY-MM-DD or empty')
            if value:
                date.fromisoformat(value)
        elif key == 'internetPorts':
            if not isinstance(value, list) or len(value) > 256 or any(type(port) is not int or not 1 <= port <= 256 for port in value) or len(value) != len(set(value)):
                raise ValueError('Invalid Internet ports')
        elif key in ('portTypes', 'portVlans'):
            if not isinstance(value, dict) or len(value) > 256:
                raise ValueError('Invalid port configuration')
            for port, config in expand_port_map(value).items():
                if not isinstance(config, dict):
                    raise ValueError('Invalid port configuration')
                if key == 'portTypes':
                    if set(config) != {'type', 'speed'} or any(not isinstance(v, str) or not v.strip() or len(v) > 64 for v in config.values()):
                        raise ValueError('Invalid port type or speed')
                else:
                    if set(config) != {'untaggedVlan', 'taggedVlans'}:
                        raise ValueError('Invalid port VLAN fields')
                    untagged, tagged = config['untaggedVlan'], config['taggedVlans']
                    if type(untagged) is not int or not 1 <= untagged <= 4094 or not isinstance(tagged, list) or len(tagged) > 4094 or any(type(v) is not int or not 1 <= v <= 4094 for v in tagged):
                        raise ValueError('Invalid port VLAN values')
                    if len(tagged) != len(set(tagged)) or untagged in tagged:
                        raise ValueError('Duplicate port VLANs')
        else:
            limits = {'notes': 6000, 'type': 80, 'deviceKind': 120, 'status': 40, 'serial': 160,
                      'ip': 64, 'ram': 160, 'hypervisorId': 80, 'hypervisorClusterId': 80, 'vlan': 120, 'osCatalogId': 80}
            if not isinstance(value, str) or len(value) > limits.get(key, 240):
                raise ValueError('Invalid asset text')


def validate_changes(changes, max_changes=50):
    if not isinstance(changes, list) or len(changes) > max_changes:
        raise ValueError('Invalid changes')
    parsed = []
    for item in changes:
        if isinstance(item, dict) and item.get('operation') in ('zabbix_import', 'zabbix_sync'):
            from backend.assistant_zabbix import validate_action
            change = validate_action(item)
        elif isinstance(item, dict) and item.get('operation') == 'connect':
            change = ConnectionChange.model_validate(item)
            if change.fields.deviceAId == change.fields.deviceBId:
                raise ValueError('Connection endpoints must be different assets')
        elif isinstance(item, dict) and 'section' in item:
            change = InventoryRecordChange.model_validate(item)
            validate_record_fields(change.section, change.fields)
            if change.operation == 'create':
                if change.record_id or any(not change.fields.get(field) for field in RECORD_REQUIRED_FIELDS[change.section]):
                    raise ValueError('New inventory records require their mandatory fields and no record ID')
            elif not change.record_id:
                raise ValueError('Updates require an existing record ID')
        else:
            change = AssetChange.model_validate(item)
            validate_asset_fields(change.fields)
            if change.operation == 'create' and (change.asset_id or not change.fields.get('name') or not change.fields.get('type')):
                raise ValueError('New assets require name and type')
            if change.operation == 'update' and not change.asset_id:
                raise ValueError('Updates require asset ID')
        parsed.append(change)
    result = [change.model_dump() for change in parsed]
    if any(change['operation'].startswith('zabbix_') for change in result) and len(result) != 1:
        raise ValueError('Zabbix operations require a separate proposal with exactly one action')
    enforce_global_write_access(result)
    return result


def enforce_global_write_access(changes):
    for change in changes:
        if change['operation'].startswith('zabbix_'):
            from backend.assistant_zabbix import enforce_write
            enforce_write()
            continue
        section = 'connections' if change['operation'] == 'connect' else change.get('section', 'assets')
        if not assistant_config.section_allowed(section, 'write'):
            raise HTTPException(403, f'Global assistant configuration disables changes to {section}.')
        if section == 'assets':
            for related, fields in assistant_config.ASSET_WRITE_SECTION_FIELDS.items():
                if fields.intersection(change['fields']) and not assistant_config.section_allowed(related, 'write'):
                    raise HTTPException(403, f'Global assistant configuration disables changes to {related} fields.')
        for related, fields in assistant_config.WRITE_REFERENCE_SECTIONS.get(section, {}).items():
            if fields.intersection(change['fields']) and not assistant_config.section_allowed(related):
                raise HTTPException(403, f'Global assistant configuration disables references to {related}.')


def resolve_new_asset_connections(state, changes):
    created_ids, names = {}, {}
    existing_names = {}
    for asset in state['assets']:
        existing_names.setdefault(asset['name'].strip().casefold(), []).append(asset['id'])
    existing_ids = {asset['id'] for asset in state['assets']}
    for index, change in enumerate(changes):
        if change['operation'] == 'create' and change.get('section', 'assets') == 'assets':
            created_ids[index] = str(uuid4())
            names.setdefault(change['fields']['name'].strip().casefold(), []).append(created_ids[index])
    resolved = []
    for change in changes:
        fields = dict(change['fields'])
        if change['operation'] == 'connect' or change.get('section') == 'connections':
            for field in ('deviceAId', 'deviceBId'):
                reference = fields.get(field)
                if not reference or reference in existing_ids:
                    continue
                reference = reference.strip()
                if reference in existing_ids:
                    fields[field] = reference
                    continue
                name = (reference[4:] if reference.casefold().startswith('new:') else reference).strip()
                candidates = names.get(name.casefold(), []) + existing_names.get(name.casefold(), [])
                if candidates:
                    if len(candidates) != 1:
                        raise HTTPException(422, 'New device reference is ambiguous. Use unique names and request a new proposal.')
                    fields[field] = candidates[0]
                else:
                    raise HTTPException(422, 'Connection references an unknown device in this environment. Request a new proposal including its creation or an existing inventory device.')
        resolved.append({**change, 'fields': fields})
    return created_ids, resolved


class ApplyInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    token: str = Field(min_length=1, max_length=100000)


class ChatInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    environment_id: str
    messages: list[Message] = Field(min_length=1, max_length=20)
    web_search: bool = Field(default=False, strict=True)
    write_mode: bool = Field(default=False, strict=True)
    attachment: Attachment | None = None


def connection(db, environment_id, lock=False):
    if not assistant_config.environment_allowed(environment_id):
        raise HTTPException(403, 'Global assistant configuration disables this environment.')
    config = db.get(AISettings, 1)
    query = select(AIProvider).where(AIProvider.id == (config.default_provider_id if config else None))
    row = db.scalar(query.with_for_update() if lock else query)
    if not row or not row.enabled or not row.model or not row.api_key_encrypted:
        raise HTTPException(409, 'An administrator must enable and select a default AI connection.')
    if environment_id not in row.environment_ids:
        raise HTTPException(403, 'The default AI connection is not allowed for this environment. Ask an administrator to update Allowed environments.')
    return row


def inventory_context(db, environment):
    # Explicit column allowlists keep secrets and free-text notes out of provider context.
    context = {'environment': environment.name, 'snapshot_date': datetime.now(timezone.utc).date().isoformat()}
    for name, (model, fields) in INVENTORY_FIELDS.items():
        columns = [getattr(model, field) for field in fields]
        context[name] = [{field: value.isoformat() if isinstance(value, date) else value for field, value in zip(fields, row)}
                         for row in db.execute(select(*columns).where(model.environment_id == environment.id))]
    from backend.operating_systems import catalog
    operating_systems = {item['id']: item for item in catalog(db)}
    context['operating_systems'] = [{key: entry[key] for key in ('id', 'name', 'family', 'eol')} for entry in operating_systems.values()]
    for asset in context['assets']:
        entry = operating_systems.get(asset['os_catalog_id'])
        if entry:
            asset.update(os=entry['name'], os_family=entry['family'], os_eol=entry['eol'])
    # Compute availability from the complete snapshot before provider truncation.
    occupied = set()
    for link in context['connections']:
        occupied.add((link['device_a_id'], link['port_a']))
        occupied.add((link['device_b_id'], link['port_b']))
    for lag in context['lags']:
        for side in ('a', 'b'):
            for member in lag.get(f'ports_{side}') or []:
                if isinstance(member, dict):
                    occupied.add((member.get('deviceId') or lag.get(f'device_{side}_id'), member.get('port')))
                else:
                    occupied.add((lag.get(f'device_{side}_id'), member))
    for asset in context['assets']:
        internet = set(asset.get('internet_ports') or [])
        asset['free_ports'] = [port for port in range(1, (asset.get('port_count') or 0) + 1)
                               if port not in internet and (asset['id'], port) not in occupied]
    context['asset_summary'] = {
        'total': len(context['assets']),
        'counts_by_type': dict(sorted(Counter(asset['type'] for asset in context['assets']).items())),
    }
    context['rack_summary'] = rack_summary(context)
    context['vlan_summary'] = vlan_summary(context)
    from backend.assistant_zabbix import summary
    context['integrations'] = summary(db, environment.id)
    apply_global_read_access(context)
    serialized = json.dumps(context, ensure_ascii=True, separators=(',', ':'))
    return serialized


def apply_global_read_access(context):
    """Restrict assistant context and derived metadata without altering default snapshots."""
    denied = {section for section in assistant_config.KNOWN_SECTIONS
              if not assistant_config.section_allowed(section)}
    if not denied and all(assistant_config.section_allowed(section, 'write')
                          for section in assistant_config.KNOWN_SECTIONS):
        return
    context['assistant_access'] = {
        'read_disabled': sorted(denied),
        'write_disabled': sorted(section for section in assistant_config.KNOWN_SECTIONS
                                 if not assistant_config.section_allowed(section, 'write')),
    }
    for name, rows in context.items():
        if not isinstance(rows, list):
            continue
        if name == 'networks':
            context[name] = [row for row in rows if assistant_config.section_allowed(
                'wlans' if row['network_type'] == 'WLAN' else 'lans')]
        elif assistant_config.SNAPSHOT_SECTIONS.get(name, name) in denied:
            context[name] = []
    for section in ('connections', 'stacks', 'stack_members', 'clusters', 'cluster_members', 'lags'):
        if 'assets' in denied:
            context[section] = []
    for asset in context['assets']:
        for section, fields in assistant_config.ASSET_SECTION_FIELDS.items():
            if section in denied:
                for field in fields:
                    asset.pop(field, None)
        if denied.intersection({'connections', 'lags'}):
            asset.pop('free_ports', None)
        if 'connections' in denied:
            asset.pop('internet_ports', None)
    for rack in context['racks']:
        if 'rooms' in denied:
            rack.pop('room_id', None)
    for network in context['networks']:
        if 'assets' in denied:
            network.pop('parent_device_id', None)
            network.pop('parent_interface', None)
        if 'vlans' in denied:
            for field in ('vlan_interface_id', 'vlan_number', 'parent_interface'):
                network.pop(field, None)
    for license in context['licenses']:
        if 'assets' in denied:
            license.pop('assigned_asset_ids', None)
    for vlan in context['vlans']:
        if 'assets' in denied:
            vlan.pop('master_device_id', None)
    for lag in context['lags']:
        if 'stacks' in denied:
            lag.pop('stack_a_id', None)
            lag.pop('stack_b_id', None)
    for hypervisor in context['hypervisors']:
        if 'clusters' in denied:
            hypervisor.pop('cluster', None)
    if 'assets' in denied:
        context.pop('asset_summary', None)
    if denied.intersection({'assets', 'racks'}):
        context.pop('rack_summary', None)
    if denied.intersection({'assets', 'vlans', 'connections', 'lags'}):
        context.pop('vlan_summary', None)


def vlan_summary(context):
    """Keep complete VLAN existence and switch-port counts through truncation."""
    configured = Counter()
    unconnected = Counter()
    for asset in context['assets']:
        if asset.get('type') != 'Switch':
            continue
        free = set(asset.get('free_ports', []))
        for port in range(1, (asset.get('port_count') or 0) + 1):
            config = (asset.get('port_vlans') or {}).get(str(port), {'untaggedVlan': 1})
            numbers = set(config.get('taggedVlans') or [])
            if config.get('untaggedVlan') is not None:
                numbers.add(config['untaggedVlan'])
            for number in numbers:
                configured[str(number)] += 1
                if port in free:
                    unconnected[str(number)] += 1
    return {
        'record_counts_by_number': dict(Counter(str(vlan['vlan_number']) for vlan in context['vlans'])),
        'switch_port_counts_by_number': dict(configured),
        'unconnected_switch_port_counts_by_number': dict(unconnected),
    }


def unconnected_vlan_removal(question, context):
    """Build exact port patches from the full snapshot for a bounded removal request."""
    match = re.fullmatch(
        r'\s*(?:please\s+)?remove\s+vlan\s+(\d+)\s+from\s+(?:all\s+)?'
        r'(?:unconnected|unconnect|disconnected|unused)\s+(?:switch\s+)?ports'
        r'(?:\s+(?:in|on|of)\s+(.+?))?\s*[.!]?\s*', question, re.I)
    if not match:
        return None
    if any(not assistant_config.section_allowed(section) for section in assistant_config.PORT_MEMBERSHIP_READ_SECTIONS):
        return {'answer': 'Global assistant section access prevents checking the complete port and VLAN configuration.', 'changes': []}
    number = int(match[1])
    if not 1 <= number <= 4094:
        return {'answer': 'Choose a VLAN number from 1 to 4094.', 'changes': []}
    scope = (match[2] or 'switches').strip().rstrip('.!').strip()
    switches = [asset for asset in context['assets'] if asset.get('type') == 'Switch']
    if scope.casefold() not in ('switches', 'all switches'):
        range_match = re.fullmatch(r'(?:switches\s+)?from\s+(\S+)\s+to\s+(\S+)', scope, re.I)
        if range_match:
            start = re.fullmatch(r'(.+?)(\d+)', range_match[1])
            end = re.fullmatch(r'(.+?)(\d+)', range_match[2])
            if not start or not end or start[1].casefold() != end[1].casefold() or int(start[2]) > int(end[2]) or int(end[2]) - int(start[2]) > 500:
                return {'answer': 'Specify a valid switch name range.', 'changes': []}
            names = [f'{start[1]}{i:0{len(start[2])}d}' for i in range(int(start[2]), int(end[2]) + 1)]
        else:
            names = [re.sub(r'^switch\s+', '', scope, flags=re.I)]
        selected = []
        for name in names:
            matches = [asset for asset in switches if asset['name'].casefold() == name.casefold()]
            if len(matches) != 1:
                return {'answer': f'Switch {name} is missing or ambiguous in the selected inventory. No changes proposed.', 'changes': []}
            selected.append(matches[0])
        switches = selected
    changes, port_count, native_count = [], 0, 0
    for asset in switches:
        patches = {}
        for port in asset['free_ports']:
            config = (asset.get('port_vlans') or {}).get(str(port), {'untaggedVlan': 1, 'taggedVlans': []})
            if config.get('untaggedVlan', 1) == number:
                native_count += 1
            if number in (config.get('taggedVlans') or []):
                patches[str(port)] = {'untaggedVlan': config.get('untaggedVlan', 1),
                                      'taggedVlans': [vlan for vlan in config['taggedVlans'] if vlan != number]}
        if patches:
            port_count += len(patches)
            changes.append({'operation': 'update', 'asset_id': asset['id'], 'fields': {'portVlans': patches}})
    if native_count:
        return {'answer': f'VLAN {number} is the untagged VLAN on {native_count} unconnected ports in the requested switches. Which VLAN should replace it? No changes proposed.', 'changes': []}
    if len(changes) > 50:
        return {'answer': f'This requires {len(changes)} device updates, exceeding the 50-change proposal limit. Specify a switch range of at most 50 devices. No changes proposed.', 'changes': []}
    answer = (f'Proposing removal of tagged VLAN {number} from {port_count} unconnected ports on {len(changes)} switches, checked across all {len(switches)} requested switches. Connected ports and other VLANs are preserved.'
              if changes else f'VLAN {number} is not assigned to unconnected ports in the {len(switches)} requested switches. No changes needed.')
    return {'answer': answer, 'changes': changes}


def connected_vlan_addition(question, context):
    """Add tagging using complete server-computed occupied-port membership."""
    match = re.fullmatch(
        r'\s*(?:please\s+)?add\s+vlan\s+(\d+)\s+to\s+(?:all\s+)?connected\s+'
        r'(?:switch\s+)?ports?\s+(?:in|on|of)\s+(?:switch\s+)?(\S+?)\s*[.!]?\s*', question, re.I)
    if not match:
        return None
    if any(not assistant_config.section_allowed(section) for section in assistant_config.PORT_MEMBERSHIP_READ_SECTIONS):
        return {'answer': 'Global assistant section access prevents checking the complete port and VLAN configuration.', 'changes': []}
    number, name = int(match[1]), match[2]
    switches = [asset for asset in context['assets']
                if asset.get('type') == 'Switch' and asset['name'].casefold() == name.casefold()]
    if len(switches) != 1:
        return {'answer': f'Switch {name} is missing or ambiguous in the selected inventory. No changes proposed.', 'changes': []}
    if not 1 <= number <= 4094:
        return {'answer': 'Choose a VLAN number from 1 to 4094.', 'changes': []}
    asset = switches[0]
    free = set(asset['free_ports'])
    connected = [port for port in range(1, (asset.get('port_count') or 0) + 1) if port not in free]
    patches = {}
    for port in connected:
        config = (asset.get('port_vlans') or {}).get(str(port), {'untaggedVlan': 1, 'taggedVlans': []})
        native = config.get('untaggedVlan', 1)
        tagged = list(config.get('taggedVlans') or [])
        if number != native and number not in tagged:
            patches[str(port)] = {'untaggedVlan': native, 'taggedVlans': tagged + [number]}
    if not connected:
        return {'answer': f'No connected ports are recorded on {asset["name"]} in the complete inventory.', 'changes': []}
    if not patches:
        return {'answer': f'VLAN {number} is already present on all {len(connected)} connected ports on {asset["name"]}. No changes needed.', 'changes': []}
    return {'answer': f'Proposing to add VLAN {number} as tagged on {len(patches)} connected ports on {asset["name"]}: ' +
            ', '.join(patches) + '. Connected ports include cable connections, LAG members and Internet assignments. Existing untagged and tagged VLANs and unconnected ports are preserved.',
            'changes': [{'operation': 'update', 'asset_id': asset['id'], 'fields': {'portVlans': patches}}]}


def inventory_count_answer(question, context):
    """Answer unfiltered count questions from the complete selected inventory."""
    match = re.fullmatch(
        r'\s*how many (switches|assets|devices)'
        r'(?:\s+(?:(?:do\s+)?we have|are there))?'
        r'(?:\s+in (?:the |our )?(?:selected |current )?environment)?\s*[?.!]?\s*',
        question, re.I,
    )
    if not match:
        return None
    if not assistant_config.section_allowed('assets'):
        return 'Asset inventory access is disabled by the global assistant configuration.'
    noun = match.group(1).lower()
    summary = context['asset_summary']
    count = summary['counts_by_type'].get('Switch', 0) if noun == 'switches' else summary['total']
    label = {'switches': 'switch', 'assets': 'asset', 'devices': 'device'}[noun] if count == 1 else noun
    return f'The selected environment has {count} {label} recorded in inventory.'


def vlan_existence_answer(question, context):
    match = re.fullmatch(r'\s*(?:is|does)\s+vlan\s+(\d+)\s+(?:exist|exists|configured|present)(?:\s+in\s+(?:the\s+)?inventory)?\s*\??\s*', question, re.I)
    if not match:
        return None
    if not assistant_config.section_allowed('vlans'):
        return 'VLAN access is disabled by the global assistant configuration.'
    number = str(int(match[1]))
    count = (context['vlan_summary']['record_counts_by_number'].get(number, 0)
             if 'vlan_summary' in context else sum(str(row['vlan_number']) == number for row in context['vlans']))
    if count:
        return f'Yes, VLAN {number} exists in the selected environment inventory ({count} recorded definition(s)).'
    return f'No definition for VLAN {number} is recorded in the selected environment inventory.'


def rack_summary(context):
    """Classify physical placement from rack fields, never location or chat history."""
    mounted = [asset for asset in context['assets']
               if asset.get('rack_enabled') and asset.get('rack_id')]
    assigned_ids = {asset['id'] for asset in mounted}
    occupied_racks = {asset['rack_id'] for asset in mounted}
    return {
        'unassigned_switch_ids': [asset['id'] for asset in context['assets']
                                  if asset.get('type') == 'Switch' and asset['id'] not in assigned_ids],
        'empty_cabinet_ids': [rack['id'] for rack in context['racks']
                              if rack['id'] not in occupied_racks],
        'assigned_device_ids_by_cabinet': {
            rack['id']: [asset['id'] for asset in mounted if asset['rack_id'] == rack['id']]
            for rack in context['racks']},
    }


def validate_bulk_rack_coverage(question, context, changes):
    """Reject incomplete proposals for an explicit whole-type cabinet assignment."""
    match = re.fullmatch(r'\s*(?:please\s+)?assign\s+all\s+(ups(?:\s+units)?|switches|patch\s+panels)\s+to\s+(.+?)\s*[.!]?\s*', question, re.I)
    if not match:
        return
    asset_type = {'switches': 'Switch', 'patch panels': 'Patch panel'}.get(
        re.sub(r'\s+', ' ', match[1].lower()), 'UPS')
    rack_name = match[2].strip().rstrip('.!').strip()
    racks = [rack for rack in context['racks'] if rack['name'].casefold() == rack_name.casefold()]
    if len(racks) != 1:
        return
    rack_id = racks[0]['id']
    updates = {change['asset_id']: change['fields'] for change in changes
               if change['operation'] == 'update' and not change.get('section')}
    missing = []
    for asset in context['assets']:
        if asset['type'] != asset_type:
            continue
        fields = updates.get(asset['id'], {})
        enabled = fields.get('rackEnabled', asset.get('rack_enabled', False))
        cabinet = fields.get('rackId', asset.get('rack_id'))
        position = fields.get('rackStartU', asset.get('rack_start_u'))
        if not enabled or cabinet != rack_id or not position:
            missing.append(asset['name'])
    if missing:
        names = ', '.join(missing[:10])
        raise ValueError(f'Incomplete bulk rack assignment: {len(missing)} requested devices are missing ({names}). Request a complete proposal or an explicit smaller batch')


def provider_inventory_context(serialized, messages, limit=120000):
    """Bound provider input and prioritize explicitly named records; traces use the full snapshot."""
    if messages and topology_request(messages[-1].content):
        inventory = json.loads(serialized)
        if not inventory.get('context_scope', {}).get('partial'):
            trace = topology_trace(inventory, messages[-1].content, messages)
            if trace is not None:
                inventory['requested_topology_trace'] = trace
                serialized = json.dumps(inventory, ensure_ascii=True, separators=(',', ':'))
    if len(serialized) <= limit:
        return serialized
    inventory = json.loads(serialized)
    question = ' '.join(message.content for message in messages if message.role == 'user').casefold()
    selected = {key: value for key, value in inventory.items() if not isinstance(value, list)}
    selected['context_scope'] = {
        'partial': True,
        'section_totals': {key: len(value) for key, value in inventory.items() if isinstance(value, list)},
        'instruction': 'Omitted records still exist. Never infer missing connections or complete paths from these partial lists. requested_topology_trace, when present, was calculated from the full inventory and is authoritative for that requested path, including its port VLAN settings. Do not ask the user to supply a path already provided by that trace. Only asset_summary, rack_summary, vlan_summary and section_totals provide complete counts and membership.',
    }
    sections = {key: [] for key, value in inventory.items() if isinstance(value, list)}
    selected.update(sections)
    encode = lambda value: json.dumps(value, ensure_ascii=True, separators=(',', ':'))
    used = len(encode(selected))
    prioritized, remaining = [], []
    # Compact VLAN definitions must precede large per-port asset records.
    for section in sorted(inventory, key=lambda key: key != 'vlans'):
        records = inventory[section]
        if not isinstance(records, list):
            continue
        for record in records:
            record = {key: value for key, value in record.items() if value is not None and value != '' and value != [] and value != {}}
            names = [record.get(key) for key in ('name', 'hostname', 'ip', 'serial', 'id', 'product', 'system')]
            named = any(isinstance(name, str) and name and re.search(r'(?<![\w-])' + re.escape(name.casefold()) + r'(?![\w-])', question) for name in names)
            (prioritized if named else remaining).append((section, record))
    for section, record in prioritized + remaining:
        cost = len(encode(record)) + 1
        if used + cost <= limit:
            sections[section].append(record)
            used += cost
    return encode(selected)


def generate_reply(row, key, system, messages):
    proposal_mode = getattr(row, 'proposal_mode', False)
    output_tokens = 8192 if proposal_mode else 2048
    base = endpoint(row.vendor, row.base_url)
    headers = {'Authorization': f'Bearer {key}'}
    if row.vendor == 'gemini':
        url = base + '/models/' + quote(row.model.removeprefix('models/'), safe='') + ':generateContent'
        headers = {'x-goog-api-key': key}
        body = {'systemInstruction': {'parts': [{'text': system}]},
                'contents': [{'role': 'model' if message.role == 'assistant' else 'user', 'parts': [{'text': message.content}]} for message in messages],
                'generationConfig': {'maxOutputTokens': output_tokens if proposal_mode else 4096}}
        if proposal_mode:
            body['generationConfig']['responseMimeType'] = 'application/json'
    elif row.vendor == 'anthropic':
        url = base + '/messages'
        headers = {'x-api-key': key, 'anthropic-version': '2023-06-01'}
        body = {'model': row.model, 'system': system, 'messages': [message.model_dump() for message in messages], 'max_tokens': output_tokens}
    else:
        url = base + '/chat/completions'
        body = {'model': row.model, 'messages': [{'role': 'system', 'content': system}] + [message.model_dump() for message in messages]}
        body['max_completion_tokens' if row.vendor == 'openai' else 'max_tokens'] = output_tokens
        if proposal_mode and row.vendor in ('openai', 'openrouter'):
            body['response_format'] = {'type': 'json_object'}
    try:
        with httpx.Client(timeout=httpx.Timeout(120, connect=10, write=20, pool=10), follow_redirects=False, trust_env=False) as client:
            response = client.post(url, headers=headers, json=body)
        if response.status_code == 503:
            raise HTTPException(503, 'The AI provider is temporarily unavailable or overloaded. Wait a little and send your question again. If it continues, choose another available model in AI providers.')
        if response.status_code in (500, 502, 504):
            raise HTTPException(502, 'The AI provider encountered a temporary server error. Wait a little and send your question again.')
        if response.status_code == 429:
            raise HTTPException(429, 'The AI provider rate limit or quota was reached. Check the provider account or try later.')
        if response.status_code in (401, 403):
            raise HTTPException(502, 'The AI provider rejected access. Check the saved key, model permissions, and account.')
        if row.vendor == 'openrouter' and response.status_code == 404:
            raise HTTPException(502, 'OpenRouter has no available endpoint for this model and account settings. Check the model ID, provider availability, and OpenRouter privacy settings, or select another model.')
        if response.status_code != 200:
            raise HTTPException(502, f'AI provider returned HTTP {response.status_code}. Check the model and provider account.')
        result = response.json()
        if row.vendor == 'gemini':
            truncated = result['candidates'][0].get('finishReason') == 'MAX_TOKENS'
            answer = '\n'.join(part['text'] for part in result['candidates'][0]['content']['parts'] if isinstance(part.get('text'), str) and not part.get('thought'))
        elif row.vendor == 'anthropic':
            truncated = result.get('stop_reason') == 'max_tokens'
            answer = '\n'.join(part['text'] for part in result['content'] if part.get('type') == 'text')
        else:
            truncated = result['choices'][0].get('finish_reason') == 'length'
            answer = result['choices'][0]['message']['content']
        if not isinstance(answer, str) or not answer.strip():
            raise ValueError()
        if proposal_mode and (truncated or len(answer) > 65000):
            raise HTTPException(502, 'The AI proposal exceeded the response limit. Nothing was saved. Retry using port ranges or fewer devices.')
        return answer if proposal_mode else answer[:18000]
    except httpx.TimeoutException:
        raise HTTPException(504, 'The AI provider took too long to answer. Your question is preserved; try again or choose a faster model.') from None
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError, AttributeError):
        raise HTTPException(502, 'Could not obtain an answer from the AI provider. Try again or check the selected model.') from None


def assistant_write_allowed(db, user, environment_id):
    if user.is_admin:
        return True
    if not user.assistant_write_enabled:
        return False
    return db.scalar(select(Membership.role).where(
        Membership.user_id == user.id, Membership.environment_id == environment_id
    )) == 'editor'


@router.get('/status')
def assistant_status(environment_id: str, user=Depends(current_user), db: Session = Depends(get_db)):
    from backend.main import environment_access
    environment_access(db, user, environment_id)
    write_allowed = assistant_write_allowed(db, user, environment_id)
    try:
        row = connection(db, environment_id)
    except HTTPException as error:
        return {'available': False, 'message': error.detail, 'write_allowed': write_allowed}
    today = datetime.now(timezone.utc).date()
    return {'available': True, 'provider': row.name, 'model': row.model,
            'web_search_supported': False, 'write_allowed': write_allowed,
            'remaining': max(0, row.request_limit - (row.requests_today if row.usage_date == today else 0))}


def switch_outage_answer(context, question):
    """Answer outage questions locally using the full authorized inventory."""
    if not re.search(r'\b(turn\s+off|switch\s+off|power\s+off|shut\s*down|down|outage|fails?|failure)\b', question, re.I):
        return None
    if any(not assistant_config.section_allowed(section) for section in assistant_config.TOPOLOGY_READ_SECTIONS):
        return None
    switches = [asset for asset in context.get('assets', []) if asset.get('type') == 'Switch'
                and asset.get('name') and re.search(r'(?<![\w-])' + re.escape(asset['name']) + r'(?![\w-])', question, re.I)]
    if len(switches) != 1:
        return None
    switch = switches[0]
    from backend.infrastructure_graph import InfrastructureGraph
    infrastructure = InfrastructureGraph(context)
    assets = infrastructure.assets
    graph = infrastructure.network
    upstream = {key for key, asset in assets.items() if asset.get('type') in {'Router', 'Firewall', 'Firewall / UTM'}}
    before, after = infrastructure.reachable(), infrastructure.reachable(switch['id'])
    server_types = {'Physical server', 'Virtual server'}
    servers_only = bool(re.search(r'\bservers?\b', question, re.I)) and not re.search(r'\b(devices?|assets?|everything)\b', question, re.I)
    label = 'Servers' if servers_only else 'Devices'
    def included(key):
        return key != switch['id'] and (not servers_only or assets[key].get('type') in server_types)
    if upstream:
        affected = {key for key in before - after if included(key)}
        # Include hosted VMs even when their NICs are not represented as cables.
        affected.update(key for key, asset in assets.items() if asset.get('type') == 'Virtual server'
                        and asset.get('hypervisor_id') in affected)
        heading = f"{label} that lose their recorded path to every router/firewall when {switch['name']} is turned off:"
    else:
        affected = {key for key in graph[switch['id']] if included(key)}
        heading = (f"No router/firewall is recorded, so complete outage impact cannot be determined. "
                   f"{label} directly connected to {switch['name']} (their links to this switch will go down):")
    lines = []
    for key in sorted(affected, key=lambda key: assets[key]['name'].casefold()):
        asset = assets[key]
        ports = []
        for link in context.get('connections', []):
            a, b = link['device_a_id'], link['device_b_id']
            if a == switch['id'] and b == key:
                ports.append(f"{switch['name']} port {link['port_a']} → {asset['name']} port {link['port_b']}")
            elif b == switch['id'] and a == key:
                ports.append(f"{switch['name']} port {link['port_b']} → {asset['name']} port {link['port_a']}")
        detail = '; '.join(ports) or ('hosted on ' + assets[asset['hypervisor_id']]['name']
                  if asset.get('hypervisor_id') in affected else 'downstream network path lost')
        lines.append(f"- {asset['name']} ({asset['type']}): {detail}")
    if not lines:
        lines.append('None identified from the recorded topology.' if upstream else f'No directly connected {label.lower()} are recorded.')
    return (heading + '\n\n' + '\n'.join(lines) + '\n\n'
            'This checks recorded physical links, LAGs and stack connectivity before and after removing the switch. '
            'Devices with a remaining upstream path are excluded. VLANs and live forwarding state can change the actual impact; '
            'network loss does not mean the servers are powered off.')


def topology_request(question):
    """Recognize path questions and VLAN passing in either word order."""
    return re.search(
        r'\b(trace|path|route|tagging|tagged|untagged|trunk)\b|'
        r'\b(pass|passing|carry|allow|extend)\b.*\bvlans?\b|'
        r'\bvlans?\b.*\b(pass|passing|carry|allow|extend)\b',
        question, re.I | re.S)


def topology_trace(context, question, messages=None):
    """Resolve named endpoints and traverse recorded links, without inferring cables."""
    if not topology_request(question):
        return None
    if any(not assistant_config.section_allowed(section) for section in assistant_config.TOPOLOGY_READ_SECTIONS):
        return {'status': 'restricted_sections', 'instruction': 'Global assistant section access prevents a complete topology and VLAN trace.'}
    assets = {asset['id']: asset for asset in context['assets']}
    mentions = []
    endpoint_patterns = {}
    for asset in assets.values():
        name = asset.get('name') or ''
        match = re.search(r'(?<![\w-])' + re.escape(name) + r'(?![\w-])', question, re.I) if name else None
        aliases = [name]
        parts = name.split('-')
        aliases.extend('-'.join(parts[index:]) for index in range(1, len(parts) - 1))
        if asset.get('type') and sum(other.get('type', '').casefold() == asset['type'].casefold() for other in assets.values()) == 1:
            aliases.append(asset['type'])
        aliases = [alias for alias in aliases if alias and sum((other.get('name', '').casefold() == alias.casefold() or other.get('name', '').casefold().endswith('-' + alias.casefold()) or other.get('type', '').casefold() == alias.casefold()) for other in assets.values()) == 1]
        pattern = '(?:' + '|'.join(re.escape(alias) for alias in aliases) + ')' if aliases else re.escape(name)
        endpoint_patterns[asset['id']] = pattern
        match = re.search(r'(?<![\w-])' + pattern + r'(?![\w-])', question, re.I)
        if match:
            mentions.append((match.start(), asset['id']))
    if not mentions and messages and not re.search(r'\b(from|to|port|router)\b', question, re.I):
        # Only user requests may supply endpoints. Earlier AI answers can contain invented links.
        for message in reversed(messages[:-1]):
            if message.role == 'user':
                earlier = topology_trace(context, message.content)
                if earlier is not None:
                    return earlier
    if len(mentions) == 1 and re.search(r'\brouter\b', question, re.I):
        routers = [asset['id'] for asset in assets.values() if asset['type'] == 'Router']
        if len(routers) == 1 and routers[0] != mentions[0][1]:
            mentions.append((re.search(r'\brouter\b', question, re.I).start(), routers[0]))
    mentions.sort()
    if len(mentions) != 2:
        return {'status': 'unresolved_endpoints', 'instruction': 'Ask for two unambiguous device names; do not guess a router.'}
    source, target = [item[1] for item in mentions]
    # Mention order is not direction: "port 10 in SW-03 ... from router" starts at the router.
    for asset_id in (source, target):
        name = assets[asset_id]['name']
        origin = re.search(r'\bfrom\s+(?:the\s+)?(?:' + endpoint_patterns[asset_id] + r')(?![\w-])', question, re.I)
        if assets[asset_id]['type'] == 'Router':
            origin = origin or re.search(r'\bfrom\s+(?:the\s+)?router\b', question, re.I)
        if origin:
            source, target = asset_id, target if asset_id == source else source
            break
    target_name = endpoint_patterns[target]
    port_match = re.search(r'\bport\s+(\d+)\s+(?:in|on|of|at)\s+`?' + target_name + r'(?![\w-])', question, re.I)
    port_match = port_match or re.search(target_name + r'`?\s*(?:,\s*)?(?:on\s+)?port\s+(\d+)\b', question, re.I)
    target_port = int(port_match[1]) if port_match else None
    port_limit = assets[target].get('port_count')
    if target_port is not None and not 1 <= target_port <= (256 if port_limit is None else port_limit):
        return {'status': 'invalid_target_port', 'target_name': assets[target]['name'],
                'instruction': 'The requested destination port does not exist; ask for a valid port.'}
    logical = {asset_id: ('asset', asset_id) for asset_id in assets}
    stacks = {}
    for member in context['stack_members']:
        asset_id = member['asset_id']
        if asset_id in assets and assets[asset_id]['type'] == 'Switch':
            node = ('stack', member['stack_id'])
            logical[asset_id] = node
            stacks.setdefault(node, []).append(asset_id)
    graph = {node: [] for node in logical.values()}

    def endpoint(asset_id, port):
        asset = assets[asset_id]
        configs = asset.get('port_vlans')
        config = configs.get(str(port), {'untaggedVlan': 1, 'taggedVlans': []}) if isinstance(configs, dict) else None
        return {'device_id': asset_id, 'device_name': asset['name'], 'port': port,
                'vlan_config': config}

    def node_name(node):
        if node[0] == 'asset':
            return assets[node[1]]['name']
        stack = next((item for item in context.get('stacks', []) if item['id'] == node[1]), None)
        return stack['name'] if stack else 'Stack (' + ', '.join(assets[item]['name'] for item in stacks[node]) + ')'

    def add_link(a, b, detail):
        if a in logical and b in logical and logical[a] != logical[b]:
            graph[logical[a]].append((logical[b], detail, False))
            graph[logical[b]].append((logical[a], detail, True))

    for link in context['connections']:
        a, b = link['device_a_id'], link['device_b_id']
        if a in assets and b in assets:
            add_link(a, b, {'kind': 'connection', **link,
                           'endpoints_a': [endpoint(a, link['port_a'])],
                           'endpoints_b': [endpoint(b, link['port_b'])]})
    for lag in context['lags']:
        groups = {}
        # Group paired LAG members by logical endpoints, retaining physical port identity.
        for a, b in zip(lag['ports_a'], lag['ports_b']):
            if isinstance(a, dict) and isinstance(b, dict) and a['deviceId'] in assets and b['deviceId'] in assets:
                groups.setdefault((logical[a['deviceId']], logical[b['deviceId']]), []).append((a, b))
        for pairs in groups.values():
            add_link(pairs[0][0]['deviceId'], pairs[0][1]['deviceId'], {
                'kind': 'lag', 'lag_id': lag['id'], 'lag_name': lag['name'],
                'endpoints_a': [endpoint(a['deviceId'], a['port']) for a, b in pairs],
                'endpoints_b': [endpoint(b['deviceId'], b['port']) for a, b in pairs]})
    source_node, target_node = logical[source], logical[target]
    previous = {source_node: None}
    queue = deque([source_node])
    while queue and target_node not in previous:
        current = queue.popleft()
        # End devices cannot serve as transit switches.
        if current != source_node and current[0] != 'stack' and assets[current[1]]['type'] not in ('Router', 'Switch', 'Firewall'):
            continue
        for neighbor, link, reverse in graph[current]:
            # A host's requested port selects the final cable, not an unrelated
            # ingress plus an imagined internal forwarding path between host ports.
            if neighbor == target_node and target_port is not None and assets[target]['type'] not in ('Router', 'Switch', 'Firewall', 'Firewall / UTM'):
                destination_ports = link['endpoints_a' if reverse else 'endpoints_b']
                if not any(item['device_id'] == target and item['port'] == target_port for item in destination_ports):
                    continue
            if neighbor not in previous:
                previous[neighbor] = (current, link, reverse)
                queue.append(neighbor)
    result = {'source_id': source, 'target_id': target,
              'source_name': assets[source]['name'], 'target_name': assets[target]['name']}
    if target_port is not None:
        result['target_port'] = endpoint(target, target_port)
    if target_node not in previous:
        return {**result, 'status': 'no_recorded_path', 'hops': []}
    hops = []
    current = target_node
    while previous[current] is not None:
        parent, link, reverse = previous[current]
        hops.append({'from_id': parent[1], 'from_name': node_name(parent),
                     'to_id': current[1], 'to_name': node_name(current), 'link': link,
                     'from_ports': link['endpoints_b' if reverse else 'endpoints_a'],
                     'to_ports': link['endpoints_a' if reverse else 'endpoints_b']})
        current = parent
    hops.reverse()
    nodes = [source_node]
    current = target_node
    tail = []
    while previous[current] is not None:
        tail.append(current)
        current = previous[current][0]
    nodes.extend(reversed(tail))
    switches = [{'logical_id': node[1], 'name': node_name(node), 'kind': node[0],
                 'members': [{'device_id': item, 'device_name': assets[item]['name']}
                             for item in (stacks[node] if node[0] == 'stack' else [node[1]])],
                 'ingress_ports': hops[index - 1]['to_ports'] if index else [],
                 'egress_ports': hops[index]['from_ports'] if index < len(hops) else []}
                for index, node in enumerate(nodes)]
    if target_port is not None:
        switches[-1]['egress_ports'] = [result['target_port']]
    return {**result, 'status': 'recorded_path', 'hops': hops, 'devices_on_path': switches,
            'limitation': 'One shortest recorded path; live forwarding, spanning tree and VLAN continuity are not verified.'}


def recorded_path_answer(trace):
    """Render exact inventory endpoints without asking a model to rewrite the route."""
    status = trace['status']
    if status == 'restricted_sections':
        return 'Global assistant section access prevents a complete path and VLAN trace. Ask an administrator to review assistant_config.py.'
    if status == 'unresolved_endpoints':
        return 'Please specify the router and destination device names so I can calculate the recorded path.'
    if status == 'invalid_target_port':
        return f"The requested port does not exist on {trace['target_name']}. Please specify a valid destination port."
    if status == 'no_recorded_path':
        return f"No path is recorded from {trace['source_name']} to {trace['target_name']}. Check the inventory connections and stack membership."

    def ports_text(ports):
        items = []
        for port in ports:
            text = f"{port['device_name']} port {port['port']}"
            config = port['vlan_config']
            if config is None:
                text += ' (VLAN settings unavailable)'
            else:
                tagged = ', '.join(map(str, config['taggedVlans'])) or 'none'
                text += f" (untagged VLAN {config['untaggedVlan']}; tagged VLANs: {tagged})"
            items.append(text)
        return '; '.join(items)

    lines = ['Recorded path:']
    for index, device in enumerate(trace['devices_on_path'], 1):
        label = device['name']
        if device['kind'] == 'stack':
            label += ' — one logical switch; members: ' + ', '.join(member['device_name'] for member in device['members'])
        lines.append(f'{index}. {label}')
        if device['ingress_ports']:
            lines.append('   Ingress: ' + ports_text(device['ingress_ports']))
        if device['egress_ports']:
            lines.append('   Egress: ' + ports_text(device['egress_ports']))
    lines.append('These are recorded VLAN settings, not recommended changes. This is one recorded path; live forwarding and VLAN continuity are not verified.')
    lines.append('For a tagged VLAN trunk, carry the required VLAN as tagged on both ends of every uplink, including the ingress and egress of each intermediate switch and every LAG member. '
                 'Preserve existing tagged VLANs and the native/untagged VLAN. For an untagged cable, the same intended VLAN must be untagged at both endpoints. '
                 'At an access endpoint, use the required VLAN untagged only if that endpoint expects untagged traffic; a VLAN-aware endpoint may require tagged traffic. '
                 'A device management VLAN or a VLAN definition alone does not configure its physical ports. Netory documents these settings; it does not configure live devices.')
    lines.append('Check the required VLAN on every listed ingress and egress port at both ends of each cable, including every LAG member. '
                 'Within a stack, ingress and egress may be on different members; no physical stack ports are recorded. '
                 'Specify the VLAN number and whether the destination needs tagged or untagged traffic before choosing changes.')
    answer = '\n'.join(lines)
    if len(answer) > 6000:
        return 'The complete recorded path exceeds the reply limit. Specify a shorter segment to list every port and VLAN setting.'
    return answer


def build_system(payload, context, write_allowed):
    inventory = json.loads(context)
    trace = inventory.get('requested_topology_trace')
    if trace is None and not inventory.get('context_scope', {}).get('partial'):
        trace = topology_trace(inventory, payload.messages[-1].content, payload.messages)
    if trace is not None:
        inventory['requested_topology_trace'] = trace
        context = json.dumps(inventory, ensure_ascii=True, separators=(',', ':'))
    system = (assistant_config.BASE_SYSTEM_POLICY.replace('INVENTORY JSON:\n', assistant_config.ZABBIX_POLICY + 'INVENTORY JSON:\n') + context)
    if payload.write_mode:
        system = system.replace('a read-only IT inventory assistant', 'an IT inventory assistant proposing reviewed inventory changes')
        system = system.replace('No credentials or tools are available. Do not invent assets or links.',
                                assistant_config.WRITABLE_CAPABILITIES)
        system += (
            assistant_config.PROPOSAL_OUTPUT_POLICY + ', '.join(sorted(ASSET_WRITE_FIELDS))
            + assistant_config.UPS_AND_IMPORT_POLICY + json.dumps(ASSET_TYPES)
            + assistant_config.ASSET_TYPE_POLICY + json.dumps(SECTION_ALIASES)
            + assistant_config.CHOICE_VALUES_POLICY + json.dumps(CHOICES)
            + assistant_config.PORT_AND_RECORD_POLICY
            + json.dumps({section: sorted(fields) for section, fields in RECORD_WRITE_FIELDS.items()})
            + '. Mandatory fields for creation: '
            + json.dumps({section: sorted(fields) for section, fields in RECORD_REQUIRED_FIELDS.items()})
            + assistant_config.CONNECTION_AND_REVIEW_POLICY
        )
        if payload.attachment:
            system += '\nATTACHMENT DATA: ' + json.dumps(payload.attachment.model_dump(), ensure_ascii=True)
    elif write_allowed:
        system += (assistant_config.READ_ONLY_WORKFLOW_POLICY)
    if inventory.get('assistant_access'):
        system += assistant_config.GLOBAL_ACCESS_POLICY
    return system


@router.post('/chat')
def assistant_chat(payload: ChatInput, user=Depends(current_user), db: Session = Depends(get_db)):
    from backend.main import environment_access
    environment = environment_access(db, user, payload.environment_id)
    write_allowed = assistant_write_allowed(db, user, environment.id)
    if (payload.write_mode or payload.attachment) and not write_allowed:
        raise HTTPException(403, 'Writable AI chat permission and Read/write environment access are required.')
    if payload.attachment and not payload.write_mode:
        raise HTTPException(422, 'Enable asset changes before attaching a file.')
    if payload.web_search:
        raise HTTPException(422, 'Web search is disabled. Refresh the page to use inventory chat.')
    if payload.messages[-1].role != 'user' or payload.messages[0].role != 'user' or any(a.role == b.role for a, b in zip(payload.messages, payload.messages[1:])):
        raise HTTPException(422, 'Conversation must alternate user and assistant messages and end with a question.')
    if sum(len(message.content) for message in payload.messages) > 30000:
        raise HTTPException(413, 'Conversation is too long. Start a new chat.')
    revision = environment.revision
    context = inventory_context(db, environment)
    reference_context = json.loads(context)
    reference_state = {section: reference_context.get(section, [])
                       for section in ('assets', 'rooms', 'racks', 'vlans', 'stacks', 'clusters')}
    row = connection(db, environment.id, lock=True)
    question = payload.messages[-1].content
    if not payload.attachment:
        from backend.cost_estimates import assistant_cost_answer
        cost_answer = assistant_cost_answer(db, environment.id, question)
        if cost_answer is not None:
            response = {'answer': cost_answer, 'model': row.model}
            if payload.write_mode:
                response.update(changes=[], proposal_token=None)
            db.commit()
            return response
    from backend.assistant_diagnostics import infrastructure_diagnostics, asset_impact_answer
    diagnostics = (asset_impact_answer(reference_context, question) or infrastructure_diagnostics(reference_context, question)) if not payload.attachment else None
    if diagnostics is not None:
        response = {'answer': diagnostics, 'model': row.model}
        if payload.write_mode:
            response.update(changes=[], proposal_token=None)
        db.commit()
        return response
    outage = switch_outage_answer(reference_context, question) if not payload.attachment else None
    if outage is not None:
        response = {'answer': outage, 'model': row.model}
        if payload.write_mode:
            response.update(changes=[], proposal_token=None)
        db.commit()
        return response
    from backend.assistant_connectivity import connectivity_answer
    connectivity = connectivity_answer(reference_context, question) if not payload.attachment else None
    if connectivity is not None:
        response = {'answer': connectivity, 'model': row.model}
        if payload.write_mode:
            response.update(changes=[], proposal_token=None)
        db.commit()
        return response
    from backend.assistant_relationships import relationship_answer
    relationships = relationship_answer(reference_context, question) if not payload.attachment else None
    if relationships is not None:
        response = {'answer': relationships, 'model': row.model}
        if payload.write_mode:
            response.update(changes=[], proposal_token=None)
        db.commit()
        return response
    removal = unconnected_vlan_removal(question, reference_context) if payload.write_mode and not payload.attachment else None
    if removal is None and payload.write_mode and not payload.attachment:
        removal = connected_vlan_addition(question, reference_context)
    if removal is not None:
        changes = validate_changes(removal['changes'])
        proposal_data = json.dumps({'user_id': user.id, 'environment_id': environment.id,
                                   'revision': revision, 'changes': changes}).encode()
        if len(proposal_data) > 70000:
            raise HTTPException(422, 'The complete proposal is too large. Specify a smaller switch range. Nothing was saved.')
        token = cipher().encrypt(proposal_data).decode() if changes else None
        db.commit()
        return {**removal, 'changes': changes, 'model': row.model, 'proposal_token': token}
    is_integration_question = bool(re.search(r'\bzabbix\b|\bintegrations?\b', question, re.I))
    existence = None if is_integration_question else inventory_count_answer(question, reference_context)
    if existence is None and not is_integration_question:
        existence = vlan_existence_answer(question, reference_context)
    if existence is not None and not payload.attachment:
        response = {'answer': existence, 'model': row.model}
        if payload.write_mode:
            response.update(changes=[], proposal_token=None)
        db.commit()
        return response
    from backend.assistant_vlan_path import tagged_path_plan
    path_plan = tagged_path_plan(reference_context, payload.messages, payload.write_mode) if not payload.attachment else None
    if path_plan is not None:
        response = {'answer': path_plan['answer'], 'model': row.model}
        if payload.write_mode:
            changes = validate_changes(path_plan['changes'], max_changes=500)
            proposal_data = json.dumps({'user_id': user.id, 'environment_id': environment.id,
                                       'revision': revision, 'changes': changes, 'local_vlan_path': True}).encode()
            if len(proposal_data) > 70000 or len(path_plan['answer']) > 6000:
                raise HTTPException(422, 'The complete tagged path is too large. Specify a shorter segment. Nothing was saved.')
            response.update(changes=changes, proposal_token=cipher().encrypt(proposal_data).decode() if changes else None)
        db.commit()
        return response
    # Render trace advice directly, including initial tagging questions, so no model
    # can omit a switch's ingress, egress, or a physical stack member's identity.
    advice = re.search(r'\b(which|what)\s+ports?\b|\b(?:tell|show|give)\b|\bhow\b', question, re.I)
    mutation = re.search(r'\b(set|update|apply|configure|change|create|add)\b', question, re.I)
    trace_request = topology_request(question)
    explicit_write = re.search(r'\b(?:update|change|configure)\s+(?:the\s+)?inventory\b|\b(?:apply|propose)\s+(?:the\s+)?changes\b', question, re.I)
    if trace_request and not explicit_write and not payload.attachment and not re.search(r'\btranslate\b', question, re.I) and (not mutation or advice):
        trace = topology_trace(json.loads(context), question, payload.messages)
        if trace is not None:
            response = {'answer': recorded_path_answer(trace), 'model': row.model}
            if payload.write_mode:
                response.update(changes=[], proposal_token=None)
            db.commit()
            return response
    today = datetime.now(timezone.utc).date()
    if row.usage_date != today:
        row.usage_date, row.requests_today = today, 0
    if row.requests_today >= row.request_limit:
        raise HTTPException(429, 'Daily request limit reached for this AI connection.')
    try:
        key = cipher().decrypt(row.api_key_encrypted.encode()).decode()
    except (InvalidToken, UnicodeError):
        raise HTTPException(503, 'Stored API key could not be decrypted.') from None
    row.requests_today += 1
    row.total_requests += 1
    # Reserve quota before the external request, without holding a database lock during generation.
    vendor = SimpleNamespace(vendor=row.vendor, model=row.model, base_url=row.base_url, proposal_mode=payload.write_mode)
    db.commit()
    from backend.assistant_zabbix import live_context
    reference_context = live_context(db, user, environment.id, question, reference_context)
    context = json.dumps(reference_context, ensure_ascii=True, separators=(',', ':'))
    context = provider_inventory_context(context, payload.messages)
    system = build_system(payload, context, write_allowed)
    # Earlier assistant replies may contain data from a section that was revoked.
    # With read restrictions, do not send that old conversation to the provider.
    local_cost_history = any(message.role == 'assistant' and message.content.startswith(assistant_config.LOCAL_COST_ANSWER_MARKER)
                             for message in payload.messages)
    local_infrastructure_history = any(
        message.role == 'assistant' and (message.content.startswith((
            'Local infrastructure evidence', 'Recorded relationships for ', 'Recorded impact of losing ',
            'Servers that lose their recorded path', 'Devices that lose their recorded path',
            'Recorded connections for ', 'No direct cable/LAG ', 'VLAN ')) or
            (message.content.startswith('Yes. ') and 'Checked against the full authorized inventory' in message.content))
        for message in payload.messages)
    provider_messages = ([payload.messages[-1]]
                         if reference_context.get('assistant_access', {}).get('read_disabled') or local_cost_history or local_infrastructure_history
                         else payload.messages)
    answer = generate_reply(vendor, key, system, provider_messages)
    if not payload.write_mode:
        return {'answer': answer, 'model': vendor.model}
    try:
        clean_answer = answer.strip()
        if clean_answer.startswith('```json\n') and clean_answer.endswith('```'):
            clean_answer = clean_answer[8:-3].strip()
        elif clean_answer.startswith('```\n') and clean_answer.endswith('```'):
            clean_answer = clean_answer[4:-3].strip()
        result = json.loads(clean_answer)
        if not isinstance(result['answer'], str) or len(result['answer']) > 6000:
            raise ValueError('Proposal answer must be text up to 6000 characters')
        changes = validate_changes(result['changes'])
        from backend.assistant_zabbix import validate_discovered
        validate_discovered(changes, reference_context)
        if not any(change['operation'].startswith('zabbix_') for change in changes):
            clarification = date_clarification(payload.attachment, payload.messages, changes)
            if clarification:
                return {'answer': clarification, 'model': vendor.model, 'changes': [], 'proposal_token': None}
            resolve_import_references(reference_state, changes)
            if changes:
                validate_bulk_rack_coverage(question, reference_context, changes)
            try:
                resolve_new_asset_connections(reference_state, changes)
            except HTTPException as error:
                raise ValueError(error.detail) from None
    except json.JSONDecodeError:
        if vendor.vendor == 'openrouter':
            if clean_answer and not clean_answer.startswith(('{', '[', '`')):
                return {'answer': clean_answer[:5800] + '\n\nNo inventory changes were proposed or saved.',
                        'model': vendor.model, 'changes': [], 'proposal_token': None}
            raise HTTPException(502, 'The selected OpenRouter model did not return valid proposal JSON. Nothing was saved. Turn off Propose inventory changes for ordinary chat, or select a model with JSON mode support for changes.') from None
        raise HTTPException(502, 'The AI returned incomplete or invalid proposal JSON. Nothing was saved. Retry using port ranges or fewer devices.') from None
    except (KeyError, TypeError, ValidationError):
        raise HTTPException(502, 'The AI returned an invalid change proposal structure. Nothing was saved; try again.') from None
    except ValueError as error:
        raise HTTPException(502, f'The AI returned an invalid change proposal: {error}. Nothing was saved; try again.') from None
    proposal_data = json.dumps({'user_id': user.id, 'environment_id': environment.id,
                                        'revision': revision, 'changes': changes}).encode()
    if len(proposal_data) > 70000:
        raise HTTPException(502, 'The AI proposal is too large. Nothing was saved. Retry using port ranges or fewer devices.')
    token = cipher().encrypt(proposal_data).decode() if changes else None
    return {'answer': result['answer'], 'model': vendor.model, 'changes': changes, 'proposal_token': token}


@router.post('/apply')
def apply_changes(payload: ApplyInput, user=Depends(require_assistant_write), db: Session = Depends(get_db)):
    from backend.main import environment_access, read_inventory, save_environment_data
    from backend.schemas import InventoryState
    from fastapi import Response
    try:
        if base64.urlsafe_b64encode(base64.b64decode(payload.token, altchars=b'-_', validate=True)).decode() != payload.token:
            raise ValueError()
        proposal = json.loads(cipher().decrypt(payload.token.encode(), ttl=1800))
        if proposal['user_id'] != user.id:
            raise ValueError('Proposal belongs to another user')
        changes = validate_changes(proposal['changes'], max_changes=500 if proposal.get('local_vlan_path') is True else 50)
    except (InvalidToken, ValueError, KeyError, TypeError):
        raise HTTPException(422, 'Invalid or expired proposal. Request a new proposal.') from None
    environment = environment_access(db, user, proposal['environment_id'], write=True)
    connection(db, environment.id)
    if changes and changes[0]['operation'].startswith('zabbix_'):
        from backend.assistant_zabbix import apply_action
        return apply_action(db, user, environment, proposal)
    state = read_inventory(db, environment.id)
    try:
        resolve_import_references(state, changes)
    except ValueError as error:
        raise HTTPException(422, str(error)) from None
    records = {section: {record['id']: record for record in rows} for section, rows in state.items()}
    created_ids, changes = resolve_new_asset_connections(state, changes)
    for index, change in enumerate(changes):
        if change['operation'] == 'connect':
            state['connections'].append({'id': str(uuid4()), **change['fields']})
            continue
        section = change.get('section', 'assets')
        fields = {field: expand_port_map(value) if section == 'assets' and field in ('portTypes', 'portVlans') else value
                  for field, value in change['fields'].items()}
        if change['operation'] == 'create':
            record = {'id': created_ids.get(index) or str(uuid4()), **fields}
            state[section].append(record)
        else:
            record_id = change.get('record_id') or change.get('asset_id')
            record = records[section].get(record_id)
            if record is None:
                raise HTTPException(409, 'The inventory record no longer exists in this environment. Request a new proposal.')
            for field, value in fields.items():
                if section == 'assets' and field in ('portTypes', 'portVlans') and value:
                    record[field] = {**record.get(field, {}), **value}
                else:
                    record[field] = value
        if section == 'assets':
            for field in ('portTypes', 'portVlans'):
                if any(int(port) > record.get('portCount', 0) for port in fields.get(field, {})):
                    raise HTTPException(422, 'Proposed port configuration exceeds the asset port count.')
    return save_environment_data(environment.id, InventoryState.model_validate(state), Response(),
                                 if_match=proposal['revision'], accept_network_overlap=False, user=user, db=db)
