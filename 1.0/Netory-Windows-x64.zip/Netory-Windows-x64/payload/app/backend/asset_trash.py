"""Server-side retention for logical asset deletions, independent of live inventory."""
from datetime import timezone
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from backend.audit import AuditedRoute
from backend.db import get_db
from backend.models import TrashedAsset
from backend.security import require_admin

router = APIRouter(prefix='/api/admin/trash/assets', route_class=AuditedRoute,
                   dependencies=[Depends(require_admin)])


def archive_assets(db, environment, assets, user):
    for asset in assets:
        db.add(TrashedAsset(id=str(uuid4()), asset_id=asset['id'],
            environment_id=environment.id, environment_name=environment.name,
            name=asset['name'], type=asset['type'], snapshot=asset,
            deleted_by_id=user.id if user else None,
            deleted_by_username=user.username if user else 'System',
            deleted_by_admin=bool(user and user.is_admin)))


def summary(row):
    data = {key: getattr(row, key) for key in ('id', 'asset_id', 'environment_id',
        'environment_name', 'name', 'type', 'deleted_at', 'deleted_by_username', 'deleted_by_admin')}
    if data['deleted_at'].tzinfo is None:
        data['deleted_at'] = data['deleted_at'].replace(tzinfo=timezone.utc)
    return data


@router.get('')
def list_trash(q: str = Query(default='', max_length=200), offset: int = Query(default=0, ge=0),
               limit: int = Query(default=50, ge=1, le=100), db: Session = Depends(get_db)):
    query = select(TrashedAsset)
    if q.strip():
        query = query.where(or_(*(column.icontains(q.strip(), autoescape=True) for column in
            (TrashedAsset.name, TrashedAsset.type, TrashedAsset.environment_name, TrashedAsset.deleted_by_username))))
    total = db.scalar(select(func.count()).select_from(query.subquery()))
    rows = db.scalars(query.order_by(TrashedAsset.deleted_at.desc(), TrashedAsset.id.desc()).offset(offset).limit(limit))
    return {'items': [summary(row) for row in rows], 'total': total, 'offset': offset, 'limit': limit}


@router.get('/{trash_id}')
def trash_details(trash_id: str, db: Session = Depends(get_db)):
    row = db.get(TrashedAsset, trash_id)
    if not row:
        raise HTTPException(404, 'Trashed asset not found')
    return {**summary(row), 'snapshot': row.snapshot}


@router.delete('/{trash_id}', status_code=204)
def permanently_delete_asset(trash_id: str, db: Session = Depends(get_db)):
    row = db.get(TrashedAsset, trash_id)
    if not row:
        raise HTTPException(404, 'Trashed asset not found')
    db.delete(row)
    db.commit()
    return Response(status_code=204)


@router.post('/{trash_id}/restore')
def restore_asset(trash_id: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    from copy import deepcopy
    from backend.main import advance_environment_revision, read_inventory, replace_inventory
    from backend.audit import inventory_changes
    from backend.models import Asset, Environment
    from backend.schemas import InventoryState

    row = db.scalar(select(TrashedAsset).where(TrashedAsset.id == trash_id).with_for_update())
    if not row:
        raise HTTPException(404, 'Trashed asset not found')
    environment = db.scalar(select(Environment).where(Environment.id == row.environment_id).with_for_update())
    if not environment:
        raise HTTPException(409, 'The original environment no longer exists. The asset remains in Trash.')
    if db.get(Asset, (row.asset_id, environment.id)):
        raise HTTPException(409, 'An asset with this ID already exists in the original environment. The asset remains in Trash.')
    revision = advance_environment_revision(db, environment, None)
    before = read_inventory(db, environment.id)
    inventory = deepcopy(before)
    asset = deepcopy(row.snapshot)
    # Restore device details without claiming its old cabinet space or recreating cables.
    asset['costEstimateId'] = ''
    asset['netPrice'] = ''
    asset['rackId'] = ''
    asset['rackStartU'] = None
    assets = {item['id']: item for item in inventory['assets']}
    if asset.get('hypervisorId') not in assets:
        asset['hypervisorId'] = ''
    if asset.get('hypervisorClusterId') not in {item['id'] for item in inventory['clusters']}:
        asset['hypervisorClusterId'] = ''
    ups = assets.get(asset.get('backupUpsId'))
    if not ups or ups['type'] != 'UPS':
        asset['backupPowerEnabled'] = False
        asset['backupUpsId'] = ''
    from backend.operating_systems import catalog
    if asset.get('osCatalogId') not in {item['id'] for item in catalog(db)}:
        asset['osCatalogId'] = ''
    # Keep valid port assignments, dropping VLAN references that no longer exist.
    vlans = {int(item['idValue']) for item in inventory['vlans']} | {1}
    for config in asset.get('portVlans', {}).values():
        if config.get('untaggedVlan') not in vlans:
            config['untaggedVlan'] = 1
        config['taggedVlans'] = [number for number in config.get('taggedVlans', [])
                                 if number in vlans and number != config['untaggedVlan']]
    inventory['assets'].append(asset)
    replace_inventory(db, environment.id, InventoryState(**inventory), user, accept_overlaps=True)
    db.flush()
    inventory_changes(db, user, environment, before, read_inventory(db, environment.id))
    db.delete(row)
    db.commit()
    return {'environment_id': environment.id, 'asset_id': asset['id'], 'revision': revision}
