"""Zabbix inventory source. Tokens never leave the server."""
import asyncio
import logging
import re
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from ipaddress import ip_address
from urllib.parse import urlsplit
from uuid import uuid4

import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, SecretStr
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from backend.audit import AuditedRoute
from backend.db import SessionLocal, get_db
from backend.models import Asset, Environment, ZabbixIntegration
from backend.security import current_user, require_admin
from cryptography.fernet import Fernet
from backend.config import settings

router = APIRouter(prefix='/api/environments/{environment_id}/integrations/zabbix', route_class=AuditedRoute)


class ConnectionInput(BaseModel):
    url: str = Field(max_length=500)
    api_key: SecretStr | None = None
    enabled: bool = True
    interval_minutes: int = Field(default=15, ge=1, le=1440)


class ImportInput(BaseModel):
    host_ids: list[str] = Field(min_length=1, max_length=500)
    asset_type: str = 'auto'
    asset_types: dict[str, str] = Field(default_factory=dict, max_length=500)


def access(db, user, environment_id, write=False):
    from backend.main import environment_access
    return environment_access(db, user, environment_id, write=write)


def connection(db, environment_id):
    row = db.scalar(select(ZabbixIntegration).where(ZabbixIntegration.environment_id == environment_id))
    if not row:
        raise HTTPException(404, 'Configure a Zabbix connection first')
    return row


def public(row):
    if not row:
        return None
    return dict(url=row.url, has_key=True, enabled=row.enabled, interval_minutes=row.interval_minutes,
                imported_count=len(row.mappings or {}), last_sync=row.last_sync, last_error=row.last_error)


def cipher():
    try:
        return Fernet((settings.zabbix_encryption_key or settings.wlan_encryption_key).encode('ascii'))
    except (ValueError, UnicodeError):
        raise HTTPException(503, 'Configure ZABBIX_ENCRYPTION_KEY (Fernet) on the server before saving an API token') from None


def rpc(row, method, params):
    try:
        token = cipher().decrypt(row.token_encrypted.encode()).decode()
        with httpx.Client(timeout=30, follow_redirects=False) as client:
            response = client.post(row.url, headers={'Authorization': f'Bearer {token}'},
                                   json={'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})
            response.raise_for_status()
            data = response.json()
        if 'error' in data or not isinstance(data.get('result'), list):
            raise ValueError()
        return data['result']
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(502, 'Zabbix request failed. Check the API URL, token, TLS certificate and API permissions.') from None


def hosts(row, host_ids=None, group_id=None):
    params = dict(output=['hostid', 'host', 'name'], selectInterfaces=['ip', 'dns', 'main', 'type'],
                  selectInventory=['name', 'os', 'os_full', 'type', 'vendor', 'serialno_a'],
                  selectParentTemplates=['name'])
    if host_ids is not None:
        params['hostids'] = host_ids
    if group_id:
        params['groupids'] = [group_id]
    return rpc(row, 'host.get', params)


def parameters(host, items):
    inventory = host.get('inventory') or {}
    values = {item['key_']: str(item.get('lastvalue', '')).strip() for item in items
              if str(item.get('lastclock', '0')) != '0' and str(item.get('state', '0')) == '0'}
    def item(*keys):
        return next((values[key] for key in keys if values.get(key)), '')
    cpu_model = item('system.hw.cpu[0,model]', 'system.hw.cpu[,model]', 'system.hw.cpu[all,model]')
    cpu_count = item('system.cpu.num', 'system.cpu.num[]', 'system.cpu.num[online]')
    cpu = cpu_model
    if cpu_count.isdigit() and 0 < int(cpu_count) <= 1048576:
        count_label = f"{int(cpu_count)} logical CPU{'s' if int(cpu_count) != 1 else ''}"
        cpu = f'{cpu_model} · {count_label}' if cpu_model else count_label
    ram = ''
    memory = item('vm.memory.size[total]', 'vm.memory.size', 'vm.memory.size[]')
    try:
        size = Decimal(memory)
        if size.is_finite() and 0 < size <= Decimal(2) ** 80:
            for divisor, unit in ((1024 ** 4, 'TiB'), (1024 ** 3, 'GiB'), (1024 ** 2, 'MiB'), (1024, 'KiB'), (1, 'B')):
                if size >= divisor:
                    ram = f"{size / divisor:.2f}".rstrip('0').rstrip('.') + f' {unit}'
                    break
    except (InvalidOperation, ValueError):
        pass
    hostname = item('system.hostname', 'system.hostname[host]', 'system.hostname[shorthost]') or host.get('host', '')
    os = inventory.get('os_full') or inventory.get('os') or item('system.sw.os', 'system.sw.os[full]', 'system.uname')
    interfaces = sorted(host.get('interfaces', []), key=lambda x: x.get('main') != '1')
    ip = next((x.get('ip') for x in interfaces if x.get('ip') and x['ip'] not in ('0.0.0.0', '::')), '')
    try:
        ip = str(ip_address(ip))
    except ValueError:
        ip = ''
    templates = ' '.join(x.get('name', '') for x in host.get('parentTemplates', []))
    hint = f"{templates} {inventory.get('type', '')}".lower()
    kind = 'Physical server'
    for pattern, candidate in [('firewall|fortigate|palo alto', 'Firewall / UTM'), ('switch', 'Switch'), ('router|mikrotik', 'Router'), ('network|snmp|cisco|juniper', 'Network device'), ('vmware guest|virtual machine', 'Virtual server')]:
        if re.search(pattern, hint):
            kind = candidate
            break
    ports = None
    count = item('net.if.number', 'ifNumber', 'net.if.count')
    if count.isdigit() and 0 < int(count) <= 256:
        ports = int(count)
    # Standard SNMP interface discovery items share one index across in/out/status.
    indices = {m.group(1) for key in values if (m := re.match(r'^net\.if\.(?:in|out|status|type|speed)\[(?:if[A-Za-z0-9]+\.)?(\d+)(?:,.*?)?\]$', key))}
    if ports is None and indices:
        ports = min(len(indices), 256)
    result = dict(hostname=hostname[:240], ip=ip, os=os[:240], detected_type=kind, cpu=cpu[:240], ram=ram,
                  manufacturer=(inventory.get('vendor') or '')[:240], serial=(inventory.get('serialno_a') or '')[:160])
    if ports is not None and kind in ('Switch', 'Router', 'Firewall / UTM', 'Network device'):
        result['port_count'] = ports
    return result


def sync(db, row, host_ids=None, asset_type='auto', user=None, asset_types=None):
    from backend.asset_types import ASSET_TYPES
    if asset_type != 'auto' and asset_type not in set(ASSET_TYPES) - {'Monitor', 'Patch panel'}:
        raise HTTPException(422, 'Choose a supported asset type')
    asset_types = asset_types or {}
    if any(value not in set(ASSET_TYPES) - {'Monitor', 'Patch panel'} for value in asset_types.values()):
        raise HTTPException(422, 'Choose a supported asset type for every selected host')
    if set(asset_types) - set(host_ids or []):
        raise HTTPException(422, 'Asset type overrides must belong to selected hosts')
    importing = host_ids is not None
    requested = list(dict.fromkeys(host_ids if importing else (row.mappings or {}).keys()))
    if not requested:
        row.last_sync = datetime.now(timezone.utc)
        row.last_error = None
        db.commit()
        return dict(updated=0, missing=[])
    found = hosts(row, requested)
    by_host = {}
    for start in range(0, len(requested), 100):
        for item in rpc(row, 'item.get', dict(hostids=requested[start:start+100], output=['hostid', 'key_', 'lastvalue', 'lastclock', 'state'])):
            by_host.setdefault(item['hostid'], []).append(item)
    # Lock the same revision row used by inventory saves, after network requests.
    db.execute(update(Environment).where(Environment.id == row.environment_id).values(revision=Environment.revision + 1))
    db.refresh(row)
    mappings = dict(row.mappings or {})
    from backend.main import read_inventory
    from backend.audit import inventory_changes
    from types import SimpleNamespace
    before = read_inventory(db, row.environment_id)
    updated = 0
    for host in found:
        hid = host['hostid']
        if hid not in requested:
            continue
        if not importing and hid not in mappings:
            # A host may have been unlinked while the Zabbix request was running.
            continue
        asset_id = mappings.get(hid)
        asset = db.get(Asset, (asset_id, row.environment_id)) if asset_id else None
        if not asset and (not importing or asset_id):
            # Removed or archived assets stay removed until explicitly unlinked.
            continue
        info = parameters(host, by_host.get(hid, []))
        if not asset:
            name = (host.get('name') or host.get('host') or hid)[:240]
            if db.scalar(select(Asset).where(Asset.environment_id == row.environment_id, Asset.name == name)):
                name = name[:190] + f' [Zabbix {hid}]'[:50]
            asset = Asset(id=str(uuid4()), environment_id=row.environment_id, name=name,
                          type=asset_types.get(hid, info['detected_type'] if asset_type == 'auto' else asset_type), port_count=0)
            db.add(asset)
            mappings[hid] = asset.id
        for key in ('hostname', 'ip', 'manufacturer', 'serial'):
            if info.get(key):
                setattr(asset, key, info[key])
        if asset.type in ('Physical server', 'Virtual server', 'Computer'):
            for key in ('cpu', 'ram'):
                if info.get(key):
                    setattr(asset, key, info[key])
        if info.get('os') and asset.type in ('Physical server', 'Virtual server', 'Computer'):
            asset.os = info['os']
            asset.os_catalog_id = None
            asset.os_eol = None
            asset.os_family = ('Windows' if 'windows' in asset.os.lower() else 'macOS' if 'darwin' in asset.os.lower() else 'Linux' if re.search('linux|ubuntu|debian|centos|red hat', asset.os, re.I) else 'Other')
        # Never shrink ports: existing cables, VLANs and port settings must stay valid.
        if info.get('port_count') is not None:
            asset.port_count = max(asset.port_count or 0, info['port_count'])
        asset.port_vlans = {**{str(port): {'untaggedVlan': 1, 'taggedVlans': []}
                               for port in range(1, (asset.port_count or 0) + 1)},
                            **(asset.port_vlans or {})}
        updated += 1
    row.mappings = mappings
    db.flush()
    environment = db.get(Environment, row.environment_id)
    inventory_changes(db, user or SimpleNamespace(id=None, username='Zabbix sync', is_admin=False),
                      environment, before, read_inventory(db, row.environment_id))
    row.last_sync = datetime.now(timezone.utc)
    row.last_error = None
    db.commit()
    return dict(updated=updated, missing=sorted(set(requested) - {h['hostid'] for h in found}))


@router.get('')
def get_connection(environment_id: str, user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id)
    return public(db.scalar(select(ZabbixIntegration).where(ZabbixIntegration.environment_id == environment_id)))


@router.put('')
def save_zabbix_connection(environment_id: str, payload: ConnectionInput, user=Depends(require_admin), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    url = payload.url.strip().rstrip('/')
    try:
        parsed = urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError()
        parsed.port
    except ValueError:
        raise HTTPException(422, 'Use an HTTP or HTTPS Zabbix URL without credentials, query or fragment') from None
    if not parsed.path.endswith('/api_jsonrpc.php'):
        url += '/api_jsonrpc.php'
    if len(url) > 500:
        raise HTTPException(422, 'API URL is too long')
    row = db.scalar(select(ZabbixIntegration).where(ZabbixIntegration.environment_id == environment_id))
    key = payload.api_key.get_secret_value().strip() if payload.api_key else ''
    if not row and not key:
        raise HTTPException(422, 'An API token is required')
    if row and row.url != url:
        raise HTTPException(409, 'Disconnect the existing source before changing its URL')
    if not row:
        row = ZabbixIntegration(id=str(uuid4()), environment_id=environment_id, url=url, mappings={})
        db.add(row)
    if key:
        if len(key) > 1024 or not key.isascii() or any(c.isspace() for c in key):
            raise HTTPException(422, 'Enter a valid API token')
        row.token_encrypted = cipher().encrypt(key.encode()).decode()
    row.enabled = payload.enabled
    row.interval_minutes = payload.interval_minutes
    db.commit()
    return public(row)


@router.delete('', status_code=204)
def disconnect_zabbix(environment_id: str, user=Depends(require_admin), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    db.delete(connection(db, environment_id))
    db.commit()


@router.post('/test')
def test_zabbix_connection(environment_id: str, user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    row = connection(db, environment_id)
    rpc(row, 'hostgroup.get', dict(output=['groupid'], limit=1))
    rpc(row, 'host.get', dict(output=['hostid'], limit=1))
    rpc(row, 'item.get', dict(output=['itemid'], limit=1))
    return {'ok': True, 'message': 'Connection successful. API token can read host groups, hosts and items.'}


@router.get('/groups')
def groups(environment_id: str, user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    return rpc(connection(db, environment_id), 'hostgroup.get', dict(output=['groupid', 'name'], with_hosts=True, sortfield='name'))


@router.get('/hosts')
def discover_hosts(environment_id: str, group_id: str = '', user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    row = connection(db, environment_id)
    assets = {asset.id: asset.type for asset in db.scalars(select(Asset).where(Asset.environment_id == environment_id))}
    result = []
    for host in hosts(row, group_id=group_id):
        info = parameters(host, [])
        linked = host['hostid'] in (row.mappings or {})
        result.append(dict(id=host['hostid'], name=host['name'] or host['host'], hostname=host['host'],
                           ip=info['ip'], detected_type=info['detected_type'],
                           asset_type=assets.get((row.mappings or {}).get(host['hostid']), info['detected_type']),
                           templates=[t['name'] for t in host.get('parentTemplates', [])], imported=linked))
    return result


@router.post('/import')
def import_hosts(environment_id: str, payload: ImportInput, user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    return sync(db, connection(db, environment_id), payload.host_ids, payload.asset_type, user=user, asset_types=payload.asset_types)


@router.delete('/hosts/{host_id}', status_code=204)
def unlink_host(environment_id: str, host_id: str, user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    # Serialize mapping changes with inventory saves and background synchronization.
    db.execute(update(Environment).where(Environment.id == environment_id).values(revision=Environment.revision + 1))
    row = connection(db, environment_id)
    db.refresh(row)
    mappings = dict(row.mappings or {})
    mappings.pop(host_id, None)
    row.mappings = mappings
    db.commit()


@router.post('/sync')
def sync_now(environment_id: str, user=Depends(current_user), db: Session=Depends(get_db)):
    access(db, user, environment_id, True)
    return sync(db, connection(db, environment_id), user=user)


async def scheduler():
    while True:
        await asyncio.sleep(60)
        await asyncio.to_thread(sync_due)


def sync_due():
    try:
        with SessionLocal() as db:
            ids = list(db.scalars(select(ZabbixIntegration.id).where(ZabbixIntegration.enabled.is_(True))))
        for integration_id in ids:
            with SessionLocal() as db:
                row = db.get(ZabbixIntegration, integration_id)
                if not row or not row.enabled:
                    continue
                last = row.last_sync.replace(tzinfo=timezone.utc) if row.last_sync else None
                if last and (datetime.now(timezone.utc) - last).total_seconds() < row.interval_minutes * 60:
                    continue
                try:
                    sync(db, row)
                except Exception:
                    db.rollback()
                    row = db.get(ZabbixIntegration, integration_id)
                    if row:
                        row.last_error = 'Automatic sync failed. Check connection and API permissions, then sync again.'
                        row.last_sync = datetime.now(timezone.utc)
                        db.commit()
    except Exception:
        logging.getLogger(__name__).exception('Zabbix scheduler could not run')
