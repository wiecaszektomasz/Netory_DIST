from backend.management_controller import public_controller, normalize_controller
import asyncio
from contextlib import asynccontextmanager, suppress
from datetime import date, datetime, timezone
from typing import Literal
from ipaddress import ip_address, ip_network
from pathlib import Path
from uuid import uuid4

from fastapi import Query, Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import and_, or_, func, delete, select, update
from sqlalchemy.orm import Session

from backend.audit import AuditedRoute, actor_snapshot, audit_context, inventory_changes, purge_expired, retention_days
from backend.models import AuditLog, AuditSettings, SessionSettings, MapSettings
from backend.schemas import AuditRetentionUpdate, SessionSettingsUpdate, AssistantPermissionUpdate, MapSettingsUpdate
from backend.asset_trash import router as asset_trash_router, archive_assets
from backend.cost_estimates import router as cost_estimates_router, pricing_fields, save_pricing, prune_pricing
from backend.ai_providers import router as ai_provider_router
from backend.assistant import router as assistant_router
from backend.operating_systems import router as os_router, catalog as os_catalog
from backend.network_validation import validate_network_parameters
from backend.network_features import synchronize_vlan_networks, mirror_networks_to_vlans, check_new_overlaps, network_warnings
from backend.config import settings
from backend.languages import available_languages
from backend.login_protection import check_login, insert_missing, policy_data, read_policy
from backend.models import LoginAttempt, LoginProtectionSettings
from backend.schemas import LoginProtectionUpdate
from backend.wlan_secrets import encrypt_password, decrypt_password
from backend.db import get_db
from backend.inventory_copy import copy_inventory
from backend.models import RackCabinet, Room
from backend.racks import validate_racks, validate_rooms
from backend.models import ServerCluster, ServerClusterMember, Asset, DeviceStack, DeviceStackMember, Environment, Hypervisor, License, LinkAggregationGroup, Membership, NetworkConnection, NetworkDefinition, SpecialAccount, User, UserSession, Vlan
from backend.schemas import EnvironmentCreate, EnvironmentRename, InventoryState, LicenseInput, LoginRequest, MembershipCreate, MembershipUpdate, UserCreate, UserPasswordChange, UserPasswordReset, UserPreferencesUpdate, UserStatusUpdate
from backend.security import SESSION_COOKIE, create_session, current_user, digest_token, hash_password, require_admin, verify_password, idle_timeout_minutes


ROOT = Path(__file__).resolve().parent.parent
PREDEFINED_PORT_SPEEDS = {
    "Fast Ethernet": "100 Mbps",
    "Gigabit Ethernet": "1 Gbps",
    "Gigabit SFP": "1 Gbps",
    "2.5G Ethernet": "2.5 Gbps",
    "5G Ethernet": "5 Gbps",
    "10G Ethernet": "10 Gbps",
    "10G SFP+": "10 Gbps",
    "25G SFP28": "25 Gbps",
    "40G QSFP+": "40 Gbps",
    "50G SFP56": "50 Gbps",
    "100G QSFP28": "100 Gbps",
    "200G QSFP56": "200 Gbps",
    "400G QSFP-DD": "400 Gbps",
}
from backend.zabbix import router as zabbix_router, scheduler as zabbix_scheduler


@asynccontextmanager
async def lifespan(app):
    task = asyncio.create_task(zabbix_scheduler())
    try:
        yield
    finally:
        task.cancel()
        with suppress(asyncio.CancelledError):
            await task


app = FastAPI(title="Netory", docs_url=None, redoc_url=None, dependencies=[Depends(audit_context)], lifespan=lifespan)
from backend.notes_board import router as notes_board_router
app.include_router(notes_board_router)
app.include_router(zabbix_router)
app.include_router(ai_provider_router)
app.include_router(assistant_router)
app.include_router(os_router)
app.include_router(asset_trash_router)
app.include_router(cost_estimates_router)
app.router.route_class = AuditedRoute
app.mount("/frontend", StaticFiles(directory=ROOT / "frontend"), name="frontend")

@app.middleware("http")
async def revalidate_frontend(request: Request, call_next):
    response = await call_next(request)
    if request.url.path in ("/", "/app.js", "/styles.css") or request.url.path.startswith("/frontend/"):
        response.headers["Cache-Control"] = "no-cache, must-revalidate"
    return response



@app.get("/api/languages")
def list_languages(response: Response):
    response.headers['Cache-Control'] = 'no-store'
    return [{"code": code, "name": catalog.get('_name', code), "translations": catalog}
            for code, catalog in available_languages().items()]


def environment_access(db: Session, user: User, environment_id: str, write: bool = False) -> Environment:
    environment = db.get(Environment, environment_id)
    if not environment:
        raise HTTPException(status_code=404, detail="Client not found")
    if user.is_admin:
        return environment
    membership = db.scalar(select(Membership).where(
        Membership.user_id == user.id,
        Membership.environment_id == environment_id,
    ))
    if not membership:
        raise HTTPException(status_code=404, detail="Client not found")
    if write and membership.role != "editor":
        raise HTTPException(status_code=403, detail="Editor access required")
    return environment


def _date(value):
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(str(value))
    except ValueError as error:
        raise HTTPException(status_code=422, detail=f"Invalid date: {value}") from error


def _optional_text(value):
    value = str(value or "").strip()
    return value or None


def _ip_address_value(value, label):
    value = _optional_text(value)
    if value is None:
        return None
    try:
        ip_address(value)
    except ValueError as error:
        raise HTTPException(status_code=422, detail=f"{label} must be a valid IPv4 or IPv6 address") from error
    return value


def _network_value(value):
    value = _optional_text(value)
    if value is None:
        return None
    if "/" not in value:
        raise HTTPException(status_code=422, detail="Network requires an IPv4 or IPv6 network address with a CIDR prefix")
    try:
        network = ip_network(value, strict=True)
    except ValueError as error:
        try:
            correct = ip_network(value, strict=False)
        except ValueError:
            raise HTTPException(status_code=422, detail="Network must be a valid IPv4 or IPv6 network address with a CIDR prefix") from error
        raise HTTPException(status_code=422, detail=f"Network address has host bits set. Use {correct}") from error
    return str(network)


def _dns_servers_value(value):
    value = _optional_text(value)
    if value is None:
        return None
    servers = [server.strip() for server in value.split(",") if server.strip()]
    if not servers:
        return None
    for server in servers:
        try:
            ip_address(server)
        except ValueError as error:
            raise HTTPException(status_code=422, detail="DNS servers must be valid IPv4 or IPv6 addresses separated by commas") from error
    return ", ".join(servers)


def _integer(value, label, minimum=0, maximum=None):
    if value in (None, ""):
        return None
    if isinstance(value, bool) or (isinstance(value, float) and not value.is_integer()):
        raise HTTPException(status_code=422, detail=f"{label} must be a whole number")
    try:
        number = int(value)
    except (TypeError, ValueError) as error:
        raise HTTPException(status_code=422, detail=f"{label} must be a whole number") from error
    if number < minimum or (maximum is not None and number > maximum):
        raise HTTPException(status_code=422, detail=f"{label} is outside the allowed range")
    return number


def _required_text(row, field, label):
    value = str(row.get(field) or "").strip()
    if not value:
        raise HTTPException(status_code=422, detail=f"{label} is required")
    return value


def read_inventory(db: Session, environment_id: str):
    costs = pricing_fields(db, environment_id)
    rooms = list(db.scalars(select(Room).where(Room.environment_id == environment_id)))
    racks = list(db.scalars(select(RackCabinet).where(RackCabinet.environment_id == environment_id)))
    operating_systems = {item['id']: item for item in os_catalog(db)}
    assets = list(db.scalars(select(Asset).where(Asset.environment_id == environment_id)))
    vlans = list(db.scalars(select(Vlan).where(Vlan.environment_id == environment_id)))
    networks = list(db.scalars(select(NetworkDefinition).where(NetworkDefinition.environment_id == environment_id)))
    stacks = list(db.scalars(select(DeviceStack).where(DeviceStack.environment_id == environment_id)))
    stack_members = list(db.scalars(
        select(DeviceStackMember)
        .where(DeviceStackMember.environment_id == environment_id)
        .order_by(DeviceStackMember.stack_id, DeviceStackMember.member_order)
    ))
    member_ids_by_stack = {}
    for member in stack_members:
        member_ids_by_stack.setdefault(member.stack_id, []).append(member.asset_id)
    clusters = list(db.scalars(select(ServerCluster).where(ServerCluster.environment_id == environment_id)))
    cluster_members = list(db.scalars(
        select(ServerClusterMember)
        .where(ServerClusterMember.environment_id == environment_id)
        .order_by(ServerClusterMember.cluster_id, ServerClusterMember.member_order)
    ))
    member_ids_by_cluster = {}
    for member in cluster_members:
        member_ids_by_cluster.setdefault(member.cluster_id, []).append(member.asset_id)
    licenses = list(db.scalars(select(License).where(License.environment_id == environment_id)))
    hypervisors = list(db.scalars(select(Hypervisor).where(Hypervisor.environment_id == environment_id)))
    accounts = list(db.scalars(select(SpecialAccount).where(SpecialAccount.environment_id == environment_id)))
    connections = list(db.scalars(select(NetworkConnection).where(NetworkConnection.environment_id == environment_id)))
    lags = list(db.scalars(select(LinkAggregationGroup).where(LinkAggregationGroup.environment_id == environment_id)))
    return {
        "rooms": [{"id": row.id, "name": row.name} for row in rooms],
        "racks": [{"id": row.id, "name": row.name, "capacityU": row.capacity_u, "displayOrder": row.display_order, "location": row.location or "", "roomId": row.room_id or ""} for row in racks],
        "assets": [{
            **costs.get(("assets", row.id), {"netPrice": "", "costEstimateId": ""}),
            "id": row.id, "name": row.name, "type": row.type, "deviceKind": row.device_kind or "", "status": row.status, "hostname": row.hostname or "",
            "manufacturer": row.manufacturer or "", "serial": row.serial or "", "location": row.location or "",
            "warrantyExpiry": row.warranty_expiry.isoformat() if row.warranty_expiry else "",
            "ip": row.ip or "", "portCount": row.port_count, "internetPorts": row.internet_ports or [],
            "portTypes": row.port_types or {},
            "portVlans": row.port_vlans or {},
            "showOnMap": row.show_on_map,
            "backupPowerEnabled": bool(row.backup_power_enabled), "backupUpsId": row.backup_ups_id or "",
            **(row.ups_parameters or {}),
            **public_controller(row.management_controller),
            "cpu": row.cpu or "", "ram": row.ram or "",
            "storage": row.storage or "", "os": operating_systems.get(row.os_catalog_id, {}).get('name', row.os or ''),
            "osCatalogId": row.os_catalog_id or '',
            "osFamily": operating_systems.get(row.os_catalog_id, {}).get('family', row.os_family or ''),
            "osEol": operating_systems.get(row.os_catalog_id, {}).get('eol', row.os_eol.isoformat() if row.os_eol else '') or '',
            "rackEnabled": row.rack_enabled, "rackUnits": row.rack_units, "rackId": row.rack_id or "", "rackStartU": row.rack_start_u,
            "hypervisorId": row.hypervisor_id or "",
            "hypervisor": row.hypervisor or "", "hypervisorClusterId": row.hypervisor_cluster_id or "",
            "vlan": row.vlan or "", "notes": row.notes or "",
        } for row in assets],
        "vlans": [{
            "id": row.id, "name": row.name, "idValue": str(row.vlan_number), "network": row.network or "",
            "linkedNetworks": [{"id": network.id, "name": network.name, "network": network.network or "", "gateway": network.gateway or "", "dnsServers": network.dns_servers or "", "dhcp": network.dhcp or ""} for network in networks if network.network_type == "LAN" and network.parent_interface == {"type": "vlan", "vlanId": row.id}],
            "gateway": row.gateway or "", "masterDeviceId": row.master_device_id or "", "isDefault": row.is_default,
            "location": row.location or "",
            "purpose": row.purpose or "", "notes": row.notes or "",
        } for row in vlans],
        "lans": [{
            "parentInterface": row.parent_interface,
            "id": row.id, "name": row.name, "network": row.network or "", "gateway": row.gateway or "",
            "dnsServers": row.dns_servers or "", "dhcp": row.dhcp or "", "vlanId": str(row.vlan_number) if row.vlan_number is not None else "",
            "location": row.location or "", "purpose": row.purpose or "", "notes": row.notes or "",
        } for row in networks if row.network_type == "LAN"],
        "wlans": [{
            "parentDeviceId": row.parent_device_id or "", "vlanInterfaceId": row.vlan_interface_id or "",
            "id": row.id, "name": row.name, "ssid": row.ssid or "", "security": row.security or "",
            "wifiPassword": decrypt_password(row.wifi_password_encrypted),
            "authServer": row.auth_server or "", "network": row.network or "", "gateway": row.gateway or "",
            "dnsServers": row.dns_servers or "", "dhcp": row.dhcp or "",
            "vlanId": str(row.vlan_number) if row.vlan_number is not None else "",
            "location": row.location or "", "purpose": row.purpose or "", "notes": row.notes or "",
        } for row in networks if row.network_type == "WLAN"],
        "stacks": [{
            "id": row.id, "name": row.name, "deviceType": row.device_type,
            "memberAssetIds": member_ids_by_stack.get(row.id, []),
        } for row in stacks],
        "clusters": [{
            "id": row.id, "name": row.name, "memberAssetIds": member_ids_by_cluster.get(row.id, []),
            "showOnMap": row.show_on_map, "location": row.location or "", "notes": row.notes or "",
        } for row in clusters],
        "lags": [{
            "id": row.id, "name": row.name, "aggregationType": row.aggregation_type or "Static", "deviceAId": row.device_a_id, "stackAId": row.stack_a_id,
            "membersA": row.ports_a, "portsA": [member["port"] for member in row.ports_a],
            "deviceBId": row.device_b_id, "stackBId": row.stack_b_id,
            "membersB": row.ports_b, "portsB": [member["port"] for member in row.ports_b],
        } for row in lags],
        "licenses": [{
            **costs.get(("licenses", row.id), {"netPrice": "", "costEstimateId": ""}),
            "id": row.id, "product": row.product, "vendor": row.vendor or "", "licenseKey": row.license_key or "",
            "type": row.type or "", "seats": str(row.seats) if row.seats is not None else "",
            "assigned": str(row.assigned) if row.assigned is not None else "",
            "assignedAssetIds": row.assigned_asset_ids or [],
            "expiry": row.expiry.isoformat() if row.expiry else "", "owner": row.owner or "", "notes": row.notes or "",
        } for row in licenses],
        "hypervisors": [{
            "id": row.id, "name": row.name, "platform": row.platform, "version": row.version or "",
            "managementIp": row.management_ip or "", "cluster": row.cluster or "", "location": row.location or "",
            "capacity": row.capacity or "", "notes": row.notes or "",
        } for row in hypervisors],
        "accounts": [{
            "id": row.id, "name": row.name, "system": row.system, "username": row.username or "",
            "accountType": row.account_type or "", "owner": row.owner or "", "vault": row.vault or "",
            "rotation": row.rotation.isoformat() if row.rotation else "", "notes": row.notes or "",
        } for row in accounts],
        "connections": [{
            "id": row.id, "deviceAId": row.device_a_id, "portA": row.port_a,
            "deviceBId": row.device_b_id, "portB": row.port_b,
        } for row in connections],
    }


def replace_inventory(db: Session, environment_id: str, state: InventoryState, user=None, accept_overlaps=False):
    data = state.model_dump()
    operating_systems = {item['id']: item for item in os_catalog(db)}
    previous_os = {row.id: row for row in db.scalars(select(Asset).where(Asset.environment_id == environment_id))}
    existing = {
        'rooms': [{'id': row.id, 'name': row.name} for row in db.scalars(select(Room).where(Room.environment_id == environment_id))],
        'racks': [{'id': row.id, 'name': row.name, 'capacityU': row.capacity_u, 'displayOrder': row.display_order, 'location': row.location or '', 'roomId': row.room_id or ''} for row in db.scalars(select(RackCabinet).where(RackCabinet.environment_id == environment_id))],
    }
    if data['rooms'] is None:
        data['rooms'] = existing['rooms']
    if data['racks'] is None:
        data['racks'] = existing['racks']
    previous_rooms = {rack['id']: rack.get('roomId', '') for rack in existing['racks']}
    for rack in data['racks']:
        rack.setdefault('roomId', previous_rooms.get(rack.get('id'), ''))
    validate_rooms(data['rooms'], data['racks'])
    built_rooms = [Room(id=row['id'], environment_id=environment_id, name=row['name'].strip()) for row in data['rooms']]
    from backend.asset_types import normalize_asset_type
    for row in data['assets']:
        try:
            row['type'] = normalize_asset_type(row.get('type'))
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from None
        old = previous_os.get(str(row.get('id')))
        for public, column, default in [('rackEnabled', 'rack_enabled', False), ('rackUnits', 'rack_units', None), ('rackId', 'rack_id', ''), ('rackStartU', 'rack_start_u', None)]:
            row.setdefault(public, getattr(old, column, default) if old else default)
    validate_racks(data['racks'], data['assets'])
    previous_rack_orders = {row.id: row.display_order for row in db.scalars(select(RackCabinet).where(RackCabinet.environment_id == environment_id))}
    for index, row in enumerate(data['racks']):
        row.setdefault('displayOrder', previous_rack_orders.get(row.get('id'), index + 1))
    validate_racks(data['racks'], data['assets'])
    built_racks = [RackCabinet(id=row['id'], environment_id=environment_id,
                  name=row.get('name') or f"Rack {index + 1}", capacity_u=row['capacityU'], display_order=row['displayOrder'], location=row.get('location') or None, room_id=row.get('roomId') or None)
                  for index, row in enumerate(data['racks'])]
    previous_network_passwords = {
        row.id: row.wifi_password_encrypted
        for row in db.scalars(select(NetworkDefinition).where(
            NetworkDefinition.environment_id == environment_id,
            NetworkDefinition.network_type == "WLAN",
        ))
    }
    previous_vlans = list(db.scalars(select(Vlan).where(Vlan.environment_id == environment_id)))
    previous_networks = list(db.scalars(select(NetworkDefinition).where(NetworkDefinition.environment_id == environment_id)))
    synchronize_vlan_networks(data, previous_vlans, previous_networks)
    previous_assets = list(db.scalars(select(Asset).where(Asset.environment_id == environment_id)))
    previous_power = {asset.id: (asset.backup_power_enabled, asset.backup_ups_id) for asset in previous_assets}
    previous_ups = {asset.id: asset.ups_parameters or {} for asset in previous_assets}
    previous_controllers = {asset.id: asset.management_controller or {} for asset in previous_assets}
    previous_warranties = {asset.id: asset.warranty_expiry for asset in previous_assets}
    assets = data["assets"]
    asset_ids = {str(row.get("id", "")) for row in assets}
    if "" in asset_ids or len(asset_ids) != len(assets):
        raise HTTPException(status_code=422, detail="Every asset needs a unique ID")
    for section in ("vlans", "lans", "wlans", "stacks", "clusters", "lags", "licenses", "hypervisors", "accounts", "connections"):
        ids = [str(row.get("id", "")) for row in data[section]]
        if "" in ids or len(ids) != len(set(ids)):
            raise HTTPException(status_code=422, detail=f"Every {section} record needs a unique ID")
    network_ids = [str(row["id"]) for section in ("lans", "wlans") for row in data[section]]
    if len(network_ids) != len(set(network_ids)):
        raise HTTPException(status_code=422, detail="Networks and WLANs must have distinct record IDs")
    asset_by_id = {str(row["id"]): row for row in assets}
    names = [str(row.get("name", "")).strip().casefold() for row in assets]
    if len(names) != len(set(names)):
        raise HTTPException(status_code=409, detail="Asset names must be unique within a client")

    cluster_by_id = {str(row["id"]): row for row in data["clusters"]}
    built_assets = []
    for row in assets:
        previous_enabled, previous_ups_id = previous_power.get(row.get('id'), (False, None))
        backup_enabled = row.get('backupPowerEnabled', previous_enabled)
        if not isinstance(backup_enabled, bool):
            raise HTTPException(status_code=422, detail='Backup power enabled must be a boolean')
        backup_ups_id = row.get('backupUpsId', previous_ups_id) if backup_enabled else None
        if backup_enabled:
            if not backup_ups_id or backup_ups_id == row.get('id') or not any(
                asset.get('id') == backup_ups_id and asset.get('type') == 'UPS' for asset in assets
            ):
                raise HTTPException(status_code=422, detail='Choose a different UPS in this environment for backup power')
        ups_parameters = {}
        if row.get('type') == 'UPS':
            for key in ['upsRatedVA', 'upsRatedW', 'upsRuntimeMinutes', 'upsBatteryCount']:
                value = row.get(key, previous_ups.get(row.get('id'), {}).get(key))
                if value is not None and value != '':
                    try:
                        number = int(str(value))
                    except (ValueError, TypeError):
                        raise HTTPException(status_code=422, detail=f'{key} must be a non-negative whole number')
                    if number < 0 or number > 10000000:
                        raise HTTPException(status_code=422, detail=f'{key} must be between 0 and 10000000')
                    ups_parameters[key] = number
            replacement = row.get('upsBatteryReplacementDate', previous_ups.get(row.get('id'), {}).get('upsBatteryReplacementDate'))
            if replacement:
                try:
                    ups_parameters['upsBatteryReplacementDate'] = date.fromisoformat(replacement).isoformat()
                except (ValueError, TypeError):
                    raise HTTPException(status_code=422, detail='Invalid UPS battery replacement date')
        device_kind = _optional_text(row.get("deviceKind"))
        if device_kind and len(device_kind) > 120:
            raise HTTPException(status_code=422, detail="Device kind must be at most 120 characters")
        if row.get("type") == "Monitor" and any(row.get(key) for key in (
            "ip", "vlan", "portCount", "portTypes", "portVlans", "internetPorts", "showOnMap",
        )):
            raise HTTPException(status_code=422, detail="Monitors cannot have network configuration")
        port_count = _integer(row.get("portCount"), "Port count", 0, 256) or 0
        internet_ports = row.get("internetPorts", [])
        if not isinstance(internet_ports, list):
            raise HTTPException(status_code=422, detail="Internet-connected ports must be a list")
        if any(isinstance(port, bool) or not isinstance(port, int) for port in internet_ports):
            raise HTTPException(status_code=422, detail="Internet-connected ports must be whole numbers")
        if len(internet_ports) != len(set(internet_ports)):
            raise HTTPException(status_code=422, detail="A port cannot be connected to the Internet more than once")
        if any(port < 1 or port > port_count for port in internet_ports):
            raise HTTPException(status_code=422, detail="Internet connection port exceeds the device port count")
        show_on_map = row.get("showOnMap", str(row.get("type", "")).strip() == "Virtual server")
        if not isinstance(show_on_map, bool):
            raise HTTPException(status_code=422, detail="Add to map must be true or false")
        host_id = _optional_text(row.get("hypervisorId"))
        if host_id and (host_id not in asset_by_id or asset_by_id[host_id].get("type") != "Physical server"):
            raise HTTPException(status_code=422, detail="Virtual server host must be a physical server in this client")
        cluster_id = _optional_text(row.get("hypervisorClusterId"))
        if cluster_id and cluster_id not in cluster_by_id:
            raise HTTPException(status_code=422, detail="Virtual server cluster must belong to this client")
        if cluster_id and row.get("type") != "Virtual server":
            raise HTTPException(status_code=422, detail="Only virtual servers can use a cluster as their hypervisor")
        if host_id and cluster_id:
            raise HTTPException(status_code=422, detail="Choose either a physical hypervisor host or a server cluster")
        port_types_raw = row.get("portTypes")
        port_types = {}
        if port_types_raw is not None:
            if not isinstance(port_types_raw, dict):
                raise HTTPException(status_code=422, detail="Port types must be an object")
            legacy_port_types = {
                "ETH 1 Gb/s": ("Gigabit Ethernet", "1 Gbps"),
                "ETH 10 Gb/s": ("10G Ethernet", "10 Gbps"),
                "SFP": ("Gigabit SFP", "1 Gbps"),
                "SFP+": ("10G SFP+", "10 Gbps"),
                "QSFP28 100G": ("100G QSFP28", "100 Gbps"),
            }
            for key, val in port_types_raw.items():
                try:
                    p_num = int(key)
                except (ValueError, TypeError):
                    raise HTTPException(status_code=422, detail="Port numbers in port types must be integers")
                if p_num < 1 or p_num > port_count:
                    continue
                if isinstance(val, str):
                    legacy_val = val.strip()
                    port_type, port_speed = legacy_port_types.get(legacy_val, (legacy_val or "Gigabit Ethernet", "1 Gbps"))
                elif isinstance(val, dict):
                    raw_type, raw_speed = val.get("type"), val.get("speed")
                    if not isinstance(raw_type, str) or not isinstance(raw_speed, str):
                        raise HTTPException(status_code=422, detail="Port type and speed values must be strings")
                    port_type = raw_type.strip() or "Gigabit Ethernet"
                    port_speed = raw_speed.strip() or "1 Gbps"
                else:
                    raise HTTPException(status_code=422, detail="Port values must include a type and speed")
                port_type, port_speed = port_type[:64], port_speed[:64]
                expected_speed = PREDEFINED_PORT_SPEEDS.get(port_type)
                if expected_speed and port_speed != expected_speed:
                    raise HTTPException(
                        status_code=422,
                        detail=f"{port_type} ports must use {expected_speed}",
                    )
                if (port_type, port_speed) != ("Gigabit Ethernet", "1 Gbps"):
                    port_types[str(p_num)] = {"type": port_type, "speed": port_speed}
        port_vlans_raw = row.get("portVlans", {})
        if not isinstance(port_vlans_raw, dict):
            raise HTTPException(status_code=422, detail="Port VLAN configuration must be an object")
        port_vlans = {}
        for key, config in port_vlans_raw.items():
            try:
                port_number = int(key)
            except (ValueError, TypeError):
                raise HTTPException(status_code=422, detail="Port numbers in port VLAN configuration must be integers")
            if str(port_number) in port_vlans:
                raise HTTPException(status_code=422, detail=f"Port {port_number} VLAN configuration is duplicated")
            if port_number < 1 or port_number > port_count:
                continue
            if not isinstance(config, dict):
                raise HTTPException(status_code=422, detail=f"Port {port_number} VLAN configuration must be an object")
            untagged_vlan = config.get("untaggedVlan", 1)
            if isinstance(untagged_vlan, bool) or not isinstance(untagged_vlan, int) or not 1 <= untagged_vlan <= 4094:
                raise HTTPException(status_code=422, detail=f"Port {port_number} must have one untagged VLAN ID between 1 and 4094")
            tagged_vlans = config.get("taggedVlans", [])
            if not isinstance(tagged_vlans, list):
                raise HTTPException(status_code=422, detail=f"Port {port_number} tagged VLANs must be a list")
            if any(isinstance(vlan, bool) or not isinstance(vlan, int) or not 1 <= vlan <= 4094 for vlan in tagged_vlans):
                raise HTTPException(status_code=422, detail=f"Port {port_number} tagged VLANs must be whole numbers between 1 and 4094")
            if len(tagged_vlans) != len(set(tagged_vlans)):
                raise HTTPException(status_code=422, detail=f"Port {port_number} cannot list a tagged VLAN more than once")
            if untagged_vlan in tagged_vlans:
                raise HTTPException(status_code=422, detail=f"Port {port_number} cannot use the same VLAN as tagged and untagged")
            port_vlans[str(port_number)] = {
                "untaggedVlan": untagged_vlan,
                "taggedVlans": tagged_vlans,
            }
        for port_number in range(1, port_count + 1):
            port_vlans.setdefault(str(port_number), {"untaggedVlan": 1, "taggedVlans": []})
        old_os = previous_os.get(str(row['id']))
        os_id = row.get('osCatalogId', old_os.os_catalog_id if old_os else None) or None
        if 'osCatalogId' not in row and old_os and row.get('os', old_os.os) != old_os.os:
            os_id = None
        os_entry = operating_systems.get(os_id) if os_id else None
        if os_id and not os_entry:
            raise HTTPException(422, 'Unknown operating system catalog entry')
        os_name = os_entry['name'] if os_entry else _optional_text(row.get('os', old_os.os if old_os else None))
        os_family = os_entry['family'] if os_entry else row.get('osFamily', old_os.os_family if old_os else None)
        os_eol = os_entry['eol'] if os_entry else row.get('osEol', old_os.os_eol.isoformat() if old_os and old_os.os_eol else '')
        if os_family and os_family not in ('Windows', 'Linux', 'macOS', 'Other'):
            raise HTTPException(422, 'Invalid operating system family')
        if os_name and len(os_name) > 240:
            raise HTTPException(422, 'Operating system name must be at most 240 characters')
        if not os_name and (os_family or os_eol):
            raise HTTPException(422, 'Custom operating system requires a name')
        built_assets.append(Asset(
            id=str(row["id"]), environment_id=environment_id,
            name=_required_text(row, "name", "Asset name"), type=_required_text(row, "type", "Asset type"),
            backup_power_enabled=backup_enabled, backup_ups_id=backup_ups_id,
            ups_parameters=ups_parameters,
            management_controller=normalize_controller(row, previous_controllers.get(row.get("id")), data["vlans"]),
            device_kind=device_kind if row.get("type") == "Other" else None,
            warranty_expiry=_date(row["warrantyExpiry"]) if "warrantyExpiry" in row else previous_warranties.get(str(row["id"])),
            status=str(row.get("status") or "In service"), hostname=_optional_text(row.get("hostname")),
            manufacturer=_optional_text(row.get("manufacturer")), serial=_optional_text(row.get("serial")),
            location=_optional_text(row.get("location")), ip=_ip_address_value(row.get("ip"), "Management IP"), port_count=port_count,
            internet_ports=internet_ports, port_types=port_types, port_vlans=port_vlans, show_on_map=show_on_map,
            cpu=_optional_text(row.get("cpu")), ram=_optional_text(row.get("ram")), storage=_optional_text(row.get("storage")),
            os=os_name, os_catalog_id=os_id, os_family=os_family or None, os_eol=_date(os_eol),
            rack_enabled=row['rackEnabled'], rack_units=row.get('rackUnits') or None,
            rack_id=row.get('rackId') or None, rack_start_u=row.get('rackStartU') or None,
            hypervisor=_optional_text(row.get("hypervisor")),
            hypervisor_id=host_id, hypervisor_cluster_id=cluster_id, vlan=_optional_text(row.get("vlan")),
            notes=_optional_text(row.get("notes")),
        ))

    default_vlans = [vlan for vlan in previous_vlans if vlan.is_default]
    if len(default_vlans) > 1:
        raise HTTPException(status_code=409, detail="This client has more than one predefined default VLAN")
    previous_default_vlan = default_vlans[0] if default_vlans else None
    built_vlans = []
    vlan_keys = set()
    for row in data["vlans"]:
        vlan_number = _integer(row.get("idValue", row.get("id")), "VLAN ID", 1, 4094)
        if vlan_number is None:
            raise HTTPException(status_code=422, detail="VLAN ID is required")
        master_id = _optional_text(row.get("masterDeviceId"))
        if master_id and master_id not in asset_by_id:
            raise HTTPException(status_code=422, detail="VLAN master device must belong to this client")
        vlan_key = (vlan_number, master_id)
        if vlan_key in vlan_keys:
            raise HTTPException(
                status_code=409,
                detail=f"VLAN ID {vlan_number} is already used with this master device assignment",
            )
        vlan_keys.add(vlan_key)
        is_default = bool(previous_default_vlan and str(row["id"]) == previous_default_vlan.id)
        if previous_default_vlan and is_default and (vlan_number != 1 or master_id):
            raise HTTPException(status_code=422, detail="The predefined default VLAN must remain VLAN 1 without a master device")
        if previous_default_vlan and vlan_number == 1 and not master_id and not is_default:
            raise HTTPException(status_code=409, detail="The predefined default VLAN cannot be replaced")
        built_vlans.append(Vlan(
            id=str(row["id"]), environment_id=environment_id, name=_required_text(row, "name", "VLAN name"),
            vlan_number=vlan_number, network=_network_value(row.get("network")),
            gateway=_ip_address_value(row.get("gateway"), "Gateway"), is_default=is_default,
            master_device_id=master_id, location=_optional_text(row.get("location")),
            purpose=_optional_text(row.get("purpose")), notes=_optional_text(row.get("notes")),
        ))
    if previous_default_vlan and not any(vlan.id == previous_default_vlan.id for vlan in built_vlans):
        built_vlans.append(Vlan(
            id=previous_default_vlan.id, environment_id=environment_id,
            name=previous_default_vlan.name, vlan_number=1, network=previous_default_vlan.network,
            gateway=previous_default_vlan.gateway, master_device_id=None, is_default=True,
            location=previous_default_vlan.location, purpose=previous_default_vlan.purpose,
            notes=previous_default_vlan.notes,
        ))
    elif not previous_default_vlan and not any(vlan.vlan_number == 1 and not vlan.master_device_id for vlan in built_vlans):
        built_vlans.append(Vlan(
            id=str(uuid4()), environment_id=environment_id, name="Default VLAN",
            vlan_number=1, master_device_id=None, is_default=True,
            purpose="Predefined default VLAN; untagged on ports by default",
        ))
    else:
        for vlan in built_vlans:
            if vlan.vlan_number == 1 and not vlan.master_device_id:
                vlan.is_default = True
                break
    existing_vlan_numbers = {vlan.vlan_number for vlan in built_vlans}
    previously_assigned_vlan_numbers = set()
    for asset in previous_assets:
        for config in (asset.port_vlans or {}).values():
            if not isinstance(config, dict):
                continue
            untagged_vlan = config.get("untaggedVlan")
            if isinstance(untagged_vlan, int) and not isinstance(untagged_vlan, bool):
                previously_assigned_vlan_numbers.add(untagged_vlan)
            tagged_vlans = config.get("taggedVlans", [])
            if isinstance(tagged_vlans, list):
                previously_assigned_vlan_numbers.update(
                    vlan for vlan in tagged_vlans
                    if isinstance(vlan, int) and not isinstance(vlan, bool)
                )
    incoming_vlans_by_id = {vlan.id: vlan.vlan_number for vlan in built_vlans}
    for vlan in previous_vlans:
        if (
            vlan.vlan_number in previously_assigned_vlan_numbers
            and incoming_vlans_by_id.get(vlan.id) != vlan.vlan_number
        ):
            raise HTTPException(
                status_code=409,
                detail=f"VLAN {vlan.vlan_number} is assigned to a network port and cannot be removed or changed",
            )
    for row, asset in zip(assets, built_assets):
        for port, config in asset.port_vlans.items():
            configured_vlan_numbers = ([config["untaggedVlan"]] if config["untaggedVlan"] is not None else []) + config["taggedVlans"]
            missing_vlan_numbers = [number for number in configured_vlan_numbers if number not in existing_vlan_numbers]
            if missing_vlan_numbers:
                missing_text = ", ".join(str(number) for number in missing_vlan_numbers)
                raise HTTPException(
                    status_code=422,
                    detail=f"{row['name']} port {port} references VLAN ID(s) not defined in VLANs: {missing_text}",
                )

    security_options = {
        "Open", "WPA2-Personal", "WPA2-Enterprise", "WPA3-Personal", "WPA3-Enterprise",
        "WPA2/WPA3-Personal", "WPA2/WPA3-Enterprise", "Other",
    }
    built_networks = []
    for network_type, section in (("LAN", "lans"), ("WLAN", "wlans")):
        if network_type == "WLAN":
            mirror_networks_to_vlans(built_vlans, built_networks)
        names = [str(row.get("name", "")).strip().casefold() for row in data[section]]
        if len(names) != len(set(names)):
            raise HTTPException(status_code=409, detail=f"{'Network' if network_type == 'LAN' else network_type} names must be unique within a client")
        for row in data[section]:
            vlan_number = _integer(row.get("vlanId"), "VLAN ID", 1, 4094)
            parent = row.get("parentInterface")
            if parent is not None:
                if network_type != "LAN" or not isinstance(parent, dict):
                    raise HTTPException(status_code=422, detail="Choose a valid network parent interface")
                if parent.get("type") == "physical":
                    if set(parent) != {"type", "deviceId", "port"} or not isinstance(parent.get("deviceId"), str):
                        raise HTTPException(status_code=422, detail="Physical parent requires a device and port")
                    device = next((asset for asset in built_assets if asset.id == parent["deviceId"]), None)
                    port = parent.get("port")
                    if not device or isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= (device.port_count or 0):
                        raise HTTPException(status_code=422, detail="Network parent must reference an existing physical port in this client")
                elif parent.get("type") == "vlan":
                    if set(parent) != {"type", "vlanId"} or not isinstance(parent.get("vlanId"), str):
                        raise HTTPException(status_code=422, detail="VLAN parent requires a configured VLAN interface")
                    vlan = next((vlan for vlan in built_vlans if vlan.id == parent["vlanId"]), None)
                    if not vlan:
                        raise HTTPException(status_code=422, detail="Network parent VLAN interface must belong to this client")
                    vlan_number = vlan.vlan_number
                else:
                    raise HTTPException(status_code=422, detail="Network parent interface must be physical or VLAN")
            parent_device_id = None
            vlan_interface_id = None
            if network_type == "WLAN":
                parent_device_id = _optional_text(row.get("parentDeviceId"))
                if parent_device_id and asset_by_id.get(parent_device_id, {}).get("type") not in {"Network device", "Router", "Firewall / UTM", "Switch", "Access point", "Wi-Fi controller"}:
                    raise HTTPException(status_code=422, detail="WLAN parent device must be a network device in this environment")
                vlan_interface_id = _optional_text(row.get("vlanInterfaceId"))
                selected_vlan = next((v for v in built_vlans if v.id == vlan_interface_id), None)
                if vlan_interface_id and selected_vlan is None:
                    raise HTTPException(status_code=422, detail="Choose an existing VLAN in this environment")
                if not vlan_interface_id and "vlanInterfaceId" not in row and vlan_number is not None:
                    matches = [v for v in built_vlans if v.vlan_number == vlan_number]
                    if len(matches) != 1:
                        raise HTTPException(status_code=422, detail="Choose an existing, unambiguous VLAN in this environment")
                    selected_vlan = matches[0]
                    vlan_interface_id = selected_vlan.id
                vlan_number = selected_vlan.vlan_number if selected_vlan else None
                if selected_vlan and selected_vlan.network:
                    row["network"] = selected_vlan.network
                    if selected_vlan.gateway:
                        row["gateway"] = selected_vlan.gateway
                old_wlan = next((old for old in previous_networks if old.id == str(row["id"]) and old.network_type == "WLAN"), None)
                old_vlan = next((old for old in previous_vlans if old_wlan and old.id == old_wlan.vlan_interface_id), None)
                if old_vlan and old_vlan.network and (not selected_vlan or not selected_vlan.network):
                    if row.get("network") == old_wlan.network == old_vlan.network:
                        row["network"] = None
                    if row.get("gateway") == old_wlan.gateway == old_vlan.gateway:
                        row["gateway"] = None
                elif selected_vlan and selected_vlan.network and not selected_vlan.gateway:
                    if old_vlan and row.get("gateway") == old_wlan.gateway == old_vlan.gateway:
                        row["gateway"] = None
            if network_type == "LAN" and vlan_number is not None and (parent is None or parent.get("type") != "vlan"):
                if not any(v.vlan_number == vlan_number for v in built_vlans):
                    raise HTTPException(status_code=422, detail="Network VLAN ID must reference an existing VLAN in this environment")
            ssid = _optional_text(row.get("ssid"))
            security = _optional_text(row.get("security"))
            if network_type == "WLAN":
                if not ssid:
                    raise HTTPException(status_code=422, detail="WLAN SSID is required")
                if security not in security_options:
                    raise HTTPException(status_code=422, detail="Choose a valid WLAN security mode")
            built_networks.append(NetworkDefinition(
                id=str(row["id"]), environment_id=environment_id, network_type=network_type, parent_interface=parent, parent_device_id=parent_device_id, vlan_interface_id=vlan_interface_id,
                name=_required_text(row, "name", "Network name" if network_type == "LAN" else "WLAN name"),
                ssid=ssid if network_type == "WLAN" else None,
                security=security if network_type == "WLAN" else None,
                auth_server=_optional_text(row.get("authServer")) if network_type == "WLAN" else None,
                wifi_password_encrypted=(
                    encrypt_password(row["wifiPassword"]) if "wifiPassword" in row
                    else previous_network_passwords.get(str(row["id"]))
                ) if network_type == "WLAN" else None,
                network=_network_value(row.get("network")),
                gateway=_ip_address_value(row.get("gateway"), "Gateway"),
                dns_servers=_dns_servers_value(row.get("dnsServers")),
                dhcp=_optional_text(row.get("dhcp")), vlan_number=vlan_number,
                location=_optional_text(row.get("location")), purpose=_optional_text(row.get("purpose")),
                notes=_optional_text(row.get("notes")),
            ))

    mirror_networks_to_vlans(built_vlans, built_networks)
    for record in built_vlans + built_networks:
        validate_network_parameters(record.network, record.gateway, getattr(record, "dhcp", None))
    if user is not None:
        check_new_overlaps(db, environment_id, built_networks, previous_networks, user, accept_overlaps)

    stackable_types = {"Switch", "Router", "Firewall / UTM"}
    built_stacks = []
    built_stack_members = []
    stacked_asset_ids = set()
    stack_names = set()
    for row in data["stacks"]:
        stack_id = str(row["id"])
        name = _required_text(row, "name", "Stack name")
        normalized_name = name.casefold()
        if normalized_name in stack_names:
            raise HTTPException(status_code=409, detail="Stack names must be unique within a client")
        stack_names.add(normalized_name)
        device_type = _required_text(row, "deviceType", "Stack device type")
        if device_type not in stackable_types:
            raise HTTPException(status_code=422, detail="Stacks can contain switches, routers, or firewalls / UTM devices")
        member_asset_ids = row.get("memberAssetIds", [])
        if not isinstance(member_asset_ids, list) or any(not isinstance(asset_id, str) or not asset_id for asset_id in member_asset_ids):
            raise HTTPException(status_code=422, detail="Stack members must be a list of asset IDs")
        if len(member_asset_ids) < 2:
            raise HTTPException(status_code=422, detail="A device stack must contain at least two members")
        if len(member_asset_ids) != len(set(member_asset_ids)):
            raise HTTPException(status_code=422, detail="A device cannot appear in a stack more than once")
        for member_order, asset_id in enumerate(member_asset_ids):
            member_asset = asset_by_id.get(asset_id)
            if not member_asset or member_asset.get("type") != device_type:
                raise HTTPException(status_code=422, detail="Stack members must be devices of the selected type in this client")
            if asset_id in stacked_asset_ids:
                raise HTTPException(status_code=409, detail="A device can belong to only one stack")
            stacked_asset_ids.add(asset_id)
            built_stack_members.append(DeviceStackMember(
                stack_id=stack_id, asset_id=asset_id, environment_id=environment_id, member_order=member_order,
            ))
        built_stacks.append(DeviceStack(
            id=stack_id, environment_id=environment_id, name=name, device_type=device_type,
        ))

    built_clusters = []
    built_cluster_members = []
    clustered_asset_ids = set()
    cluster_names = set()
    for row in data["clusters"]:
        cluster_id = str(row["id"])
        name = _required_text(row, "name", "Cluster name")
        if name.casefold() in cluster_names:
            raise HTTPException(status_code=409, detail="Cluster names must be unique within a client")
        cluster_names.add(name.casefold())
        show_on_map = row.get("showOnMap", True)
        if not isinstance(show_on_map, bool):
            raise HTTPException(status_code=422, detail="Cluster Add to map must be true or false")
        member_ids = row.get("memberAssetIds", [])
        if not isinstance(member_ids, list) or any(not isinstance(member_id, str) or not member_id for member_id in member_ids):
            raise HTTPException(status_code=422, detail="Cluster members must be a list of asset IDs")
        if len(member_ids) < 2:
            raise HTTPException(status_code=422, detail="A server cluster must contain at least two physical servers")
        if len(member_ids) != len(set(member_ids)):
            raise HTTPException(status_code=422, detail="A server cannot appear in a cluster more than once")
        for member_order, asset_id in enumerate(member_ids):
            if asset_by_id.get(asset_id, {}).get("type") != "Physical server":
                raise HTTPException(status_code=422, detail="Cluster members must be physical servers in this client")
            if asset_id in clustered_asset_ids:
                raise HTTPException(status_code=409, detail="A physical server can belong to only one cluster")
            clustered_asset_ids.add(asset_id)
            built_cluster_members.append(ServerClusterMember(
                cluster_id=cluster_id, asset_id=asset_id, environment_id=environment_id, member_order=member_order,
            ))
        built_clusters.append(ServerCluster(
            id=cluster_id, environment_id=environment_id, name=name, show_on_map=show_on_map,
            location=_optional_text(row.get("location")), notes=_optional_text(row.get("notes")),
        ))

    built_licenses = []
    for row in data["licenses"]:
        assigned_asset_ids = row.get("assignedAssetIds", [])
        if assigned_asset_ids is None:
            assigned_asset_ids = []
        if not isinstance(assigned_asset_ids, list) or any(not isinstance(asset_id, str) or not asset_id for asset_id in assigned_asset_ids):
            raise HTTPException(status_code=422, detail="Assigned devices must be a list of valid asset IDs")
        if len(assigned_asset_ids) != len(set(assigned_asset_ids)):
            raise HTTPException(status_code=422, detail="A device cannot be assigned to the same license more than once")
        if any(asset_id not in asset_by_id for asset_id in assigned_asset_ids):
            raise HTTPException(status_code=422, detail="Assigned devices must belong to this client")
        seats = _integer(row.get("seats"), "Seats", 0)
        assigned = _integer(row.get("assigned"), "Other assigned seats", 0)
        if seats is not None and (assigned or 0) + len(assigned_asset_ids) > seats:
            raise HTTPException(status_code=422, detail="Assigned seats and devices cannot exceed the license seat count")
        built_licenses.append(License(
            id=str(row["id"]), environment_id=environment_id, product=_required_text(row, "product", "License product"),
            vendor=_optional_text(row.get("vendor")), license_key=_optional_text(row.get("licenseKey")),
            type=_optional_text(row.get("type")), seats=seats, assigned=assigned,
            assigned_asset_ids=assigned_asset_ids, expiry=_date(row.get("expiry")),
            owner=_optional_text(row.get("owner")), notes=_optional_text(row.get("notes")),
        ))
    built_hypervisors = [Hypervisor(
        id=str(row["id"]), environment_id=environment_id, name=_required_text(row, "name", "Hypervisor name"),
        platform=_required_text(row, "platform", "Hypervisor platform"), version=_optional_text(row.get("version")),
        management_ip=_ip_address_value(row.get("managementIp"), "Management IP"), cluster=_optional_text(row.get("cluster")),
        location=_optional_text(row.get("location")), capacity=_optional_text(row.get("capacity")),
        notes=_optional_text(row.get("notes")),
    ) for row in data["hypervisors"]]
    built_accounts = [SpecialAccount(
        id=str(row["id"]), environment_id=environment_id, name=_required_text(row, "name", "Account name"),
        system=_required_text(row, "system", "Account system"), username=_optional_text(row.get("username")),
        account_type=_optional_text(row.get("accountType")), owner=_optional_text(row.get("owner")),
        vault=_optional_text(row.get("vault")), rotation=_date(row.get("rotation")), notes=_optional_text(row.get("notes")),
    ) for row in data["accounts"]]

    built_lags = []
    occupied_ports = set()
    lag_names = set()
    for row in data["lags"]:
        name = _required_text(row, "name", "LAG name")
        aggregation_type = row.get("aggregationType") or "Static"
        if aggregation_type not in {"Static", "Dynamic"}:
            raise HTTPException(status_code=422, detail="LAG aggregation type must be Static or Dynamic")
        if len(name) > 120:
            raise HTTPException(status_code=422, detail="LAG name must be 120 characters or fewer")
        if name.casefold() in lag_names:
            raise HTTPException(status_code=409, detail="LAG names must be unique within a client")
        lag_names.add(name.casefold())
        stack_by_id = {str(stack["id"]): stack for stack in data["stacks"]}
        stack_members_by_id = {
            str(stack["id"]): list(stack.get("memberAssetIds", []))
            for stack in data["stacks"]
        }
        stack_a_id = _optional_text(row.get("stackAId"))
        stack_b_id = _optional_text(row.get("stackBId"))

        def lag_endpoint_members(side, stack_id):
            endpoint_id = str(row.get(f"device{side}Id", ""))
            if stack_id:
                if stack_id not in stack_by_id:
                    raise HTTPException(status_code=422, detail=f"LAG stack {side} must belong to this client")
                stack_members = stack_members_by_id[stack_id]
                requested = row.get(f"members{side}")
                if not isinstance(requested, list):
                    raise HTTPException(status_code=422, detail="LAG stack member ports must be a list")
                members = []
                for item in requested:
                    if not isinstance(item, dict) or item.get("deviceId") not in stack_members:
                        raise HTTPException(status_code=422, detail="LAG ports on a stack must belong to its physical members")
                    port = item.get("port")
                    if isinstance(port, bool) or not isinstance(port, int):
                        raise HTTPException(status_code=422, detail="LAG member ports must be whole numbers")
                    device = asset_by_id.get(item["deviceId"])
                    if not device or port < 1 or port > int(device.get("portCount") or 0):
                        raise HTTPException(status_code=422, detail="LAG port exceeds its physical device's port count")
                    members.append({"deviceId": device["id"], "port": port})
                member_order = {asset_id: index for index, asset_id in enumerate(stack_members)}
                members.sort(key=lambda item: (member_order[item["deviceId"]], item["port"]))
                if len(members) < 2:
                    raise HTTPException(status_code=422, detail="A LAG needs at least two paired ports on each endpoint")
                if len({(item["deviceId"], item["port"]) for item in members}) != len(members):
                    raise HTTPException(status_code=422, detail="A port cannot appear more than once in the same LAG")
                return stack_members[0], members

            device = asset_by_id.get(endpoint_id)
            if not device:
                raise HTTPException(status_code=422, detail=f"LAG device {side} must belong to this client")
            ports = row.get(f"ports{side}")
            if not isinstance(ports, list):
                raise HTTPException(status_code=422, detail="LAG member ports must be lists")
            if any(isinstance(port, bool) or not isinstance(port, int) for port in ports):
                raise HTTPException(status_code=422, detail="LAG member ports must be whole numbers")
            members = [{"deviceId": device["id"], "port": port} for port in ports]
            members.sort(key=lambda item: item["port"])
            if any(port < 1 or port > int(device.get("portCount") or 0) for port in ports):
                raise HTTPException(status_code=422, detail=f"LAG port exceeds {device['name']}'s port count")
            if len(members) < 2:
                raise HTTPException(status_code=422, detail="A LAG needs at least two paired ports on each endpoint")
            if len({item["port"] for item in members}) != len(members):
                raise HTTPException(status_code=422, detail="A port cannot appear more than once in the same LAG")
            return device["id"], members

        anchor_a, members_a = lag_endpoint_members("A", stack_a_id)
        anchor_b, members_b = lag_endpoint_members("B", stack_b_id)
        if len(members_a) != len(members_b):
            raise HTTPException(status_code=422, detail="A LAG needs at least two paired ports on each device")
        endpoint_assets_a = set(stack_members_by_id[stack_a_id]) if stack_a_id else {str(row.get("deviceAId", ""))}
        endpoint_assets_b = set(stack_members_by_id[stack_b_id]) if stack_b_id else {str(row.get("deviceBId", ""))}
        if endpoint_assets_a & endpoint_assets_b:
            raise HTTPException(status_code=422, detail="A LAG must connect two different devices or stacks")
        for member in members_a + members_b:
            endpoint = (member["deviceId"], member["port"])
            if endpoint in occupied_ports:
                raise HTTPException(status_code=409, detail="A port cannot belong to more than one connection or LAG")
            occupied_ports.add(endpoint)
        built_lags.append(LinkAggregationGroup(
            id=str(row["id"]), environment_id=environment_id, name=name, aggregation_type=aggregation_type,
            device_a_id=anchor_a, ports_a=members_a,
            device_b_id=anchor_b, ports_b=members_b,
            stack_a_id=stack_a_id, stack_b_id=stack_b_id,
        ))

    built_connections = []
    for row in data["connections"]:
        device_a = asset_by_id.get(str(row.get("deviceAId", "")))
        device_b = asset_by_id.get(str(row.get("deviceBId", "")))
        port_a = _integer(row.get("portA"), "Port number", 1)
        port_b = _integer(row.get("portB"), "Port number", 1)
        if port_a is None or port_b is None:
            raise HTTPException(status_code=422, detail="Both connection ports are required")
        if not device_a or not device_b or device_a["id"] == device_b["id"]:
            raise HTTPException(status_code=422, detail="Connection endpoints must be two different assets in this client")
        if port_a > int(device_a.get("portCount") or 0) or port_b > int(device_b.get("portCount") or 0):
            raise HTTPException(status_code=422, detail="Connection port exceeds the device port count")
        for endpoint in ((device_a["id"], port_a), (device_b["id"], port_b)):
            if endpoint in occupied_ports:
                raise HTTPException(status_code=409, detail="A port cannot have more than one connection")
            occupied_ports.add(endpoint)
        built_connections.append(NetworkConnection(
            id=str(row["id"]), environment_id=environment_id,
            device_a_id=device_a["id"], port_a=port_a, device_b_id=device_b["id"], port_b=port_b,
        ))
    for row in assets:
        device_id = str(row["id"])
        for port in row.get("internetPorts", []):
            if (device_id, port) in occupied_ports:
                raise HTTPException(status_code=409, detail=f"{asset_by_id[device_id]['name']} port {port} cannot connect to a device, a LAG, and the Internet at the same time")
            occupied_ports.add((device_id, port))

    retained_ids = {asset.id for asset in built_assets}
    removed_ids = set(previous_os) - retained_ids
    if removed_ids:
        environment = db.get(Environment, environment_id)
        archive_assets(db, environment, [asset for asset in read_inventory(db, environment_id)['assets']
                                       if asset['id'] in removed_ids], user)

    db.execute(delete(NetworkConnection).where(NetworkConnection.environment_id == environment_id))
    db.execute(delete(LinkAggregationGroup).where(LinkAggregationGroup.environment_id == environment_id))
    db.execute(delete(Vlan).where(Vlan.environment_id == environment_id))
    db.execute(delete(NetworkDefinition).where(NetworkDefinition.environment_id == environment_id))
    db.execute(delete(ServerClusterMember).where(ServerClusterMember.environment_id == environment_id))
    db.execute(delete(ServerCluster).where(ServerCluster.environment_id == environment_id))
    db.execute(delete(DeviceStackMember).where(DeviceStackMember.environment_id == environment_id))
    db.execute(delete(DeviceStack).where(DeviceStack.environment_id == environment_id))
    db.execute(delete(License).where(License.environment_id == environment_id))
    db.execute(delete(Hypervisor).where(Hypervisor.environment_id == environment_id))
    db.execute(delete(SpecialAccount).where(SpecialAccount.environment_id == environment_id))
    db.execute(delete(Asset).where(Asset.environment_id == environment_id))
    db.execute(delete(RackCabinet).where(RackCabinet.environment_id == environment_id))
    db.execute(delete(Room).where(Room.environment_id == environment_id))
    db.add_all(built_rooms)
    db.add_all(built_racks)
    db.add_all(built_assets)
    db.flush()
    db.add_all(built_vlans + built_networks + built_stacks + built_clusters + built_lags + built_licenses + built_hypervisors + built_accounts + built_connections)
    db.flush()
    db.add_all(built_stack_members + built_cluster_members)
    for section in ("assets", "licenses"):
        for record in data[section]:
            save_pricing(db, environment_id, section, record["id"], record)
        prune_pricing(db, environment_id, section, [record["id"] for record in data[section]])


@app.get("/")
def index():
    return FileResponse(ROOT / "index.html")


@app.get("/styles.css")
def styles():
    return FileResponse(ROOT / "styles.css", media_type="text/css")


@app.get("/app.js")
def frontend_script():
    return FileResponse(ROOT / "app.js", media_type="application/javascript")


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/login")
def login(payload: LoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    username = payload.username.strip().lower()
    user = db.scalar(select(User).where(User.username == username))
    if user:
        actor_snapshot(request, user)
    check_login(db, username, payload.password, user)
    token = create_session(db, user)
    response.set_cookie(
        SESSION_COOKIE, token, httponly=True, secure=settings.cookie_secure,
        samesite="strict", max_age=settings.session_days * 86400, path="/",
    )
    return {"id": user.id, "username": user.username, "is_admin": user.is_admin, "assistant_write_enabled": user.is_admin or user.assistant_write_enabled}


@app.get("/api/session/status")
def session_status(user: User = Depends(current_user)):
    return {"active": True}


@app.post("/api/session/activity", status_code=204)
def session_activity(user: User = Depends(current_user)):
    return None


def configured_map_layout(db: Session):
    policy = db.get(MapSettings, 1)
    return policy.layout if policy else 'elk'


@app.get("/api/settings/network-map")
def get_map_settings(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    return {"layout": configured_map_layout(db)}


@app.put("/api/settings/network-map")
def update_map_settings(payload: MapSettingsUpdate, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    insert_missing(db, MapSettings, {"id": 1, "layout": "elk"}, "id")
    policy = db.scalar(select(MapSettings).where(MapSettings.id == 1).with_for_update().execution_options(populate_existing=True))
    policy.layout = payload.layout
    db.commit()
    return {"layout": policy.layout}


@app.get("/api/settings/session-timeout")
def get_session_timeout(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    return {"idle_timeout_minutes": idle_timeout_minutes(db)}


@app.put("/api/settings/session-timeout")
def update_session_timeout(payload: SessionSettingsUpdate, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    insert_missing(db, SessionSettings, {"id": 1, "idle_timeout_minutes": 30}, "id")
    policy = db.scalar(select(SessionSettings).where(SessionSettings.id == 1).with_for_update().execution_options(populate_existing=True))
    policy.idle_timeout_minutes = payload.idle_timeout_minutes
    db.commit()
    return {"idle_timeout_minutes": policy.idle_timeout_minutes}


@app.get("/api/settings/login-protection")
def get_login_protection(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    return policy_data(read_policy(db))


@app.put("/api/settings/login-protection")
def update_login_protection(
    payload: LoginProtectionUpdate,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    insert_missing(db, LoginProtectionSettings, {
        "id": 1, "enabled": True, "max_failed_attempts": 5, "block_minutes": 15,
    }, "id")
    policy = db.scalar(select(LoginProtectionSettings).where(
        LoginProtectionSettings.id == 1
    ).with_for_update().execution_options(populate_existing=True))
    for key, value in payload.model_dump().items():
        setattr(policy, key, value)
    # New policy starts with fresh counters, including when re-enabling protection.
    db.execute(delete(LoginAttempt))
    db.commit()
    return policy_data(policy)


@app.post("/api/logout", status_code=204)
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        session = db.get(UserSession, digest_token(token))
        if session:
            actor = db.get(User, session.user_id)
            if actor:
                actor_snapshot(request, actor)
            db.delete(session)
            db.commit()
    response.delete_cookie(SESSION_COOKIE, path="/", secure=settings.cookie_secure, httponly=True, samesite="strict")


@app.get("/api/state")
def get_state(user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.is_admin:
        environments = list(db.scalars(select(Environment).order_by(Environment.name)))
    else:
        environments = list(db.scalars(
            select(Environment).join(Membership).where(Membership.user_id == user.id).order_by(Environment.name)
        ))
    membership_roles = {} if user.is_admin else {
        row.environment_id: row.role for row in db.scalars(select(Membership).where(Membership.user_id == user.id))
    }
    warnings = network_warnings(db, user)
    state = {
        "mapLayout": configured_map_layout(db),
        "user": {"id": user.id, "username": user.username, "is_admin": user.is_admin, "assistant_write_enabled": user.is_admin or user.assistant_write_enabled, "theme": user.theme, "language": user.language, "dashboard": user.dashboard},
        "environments": [{
            "id": item.id, "name": item.name, "data": read_inventory(db, item.id), "revision": item.revision,
            "role": "admin" if user.is_admin else membership_roles[item.id],
        } for item in environments],
        "activeEnvironmentId": environments[0].id if environments else None,
    }

    for environment in state["environments"]:
        for section in ("lans", "wlans"):
            for network in environment["data"][section]:
                network["overlaps"] = warnings.get(environment["id"], {}).get(network["id"], [])
    return state


@app.post("/api/environments", status_code=201)
def create_environment(payload: EnvironmentCreate, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    name = payload.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Client name cannot be blank")
    environment = Environment(id=str(uuid4()), name=name, revision=1)
    db.add(environment)
    db.flush()
    db.add(Vlan(
        id=str(uuid4()), environment_id=environment.id, name="Default VLAN", vlan_number=1,
        purpose="Predefined default VLAN; untagged on ports by default", is_default=True,
    ))
    db.commit()
    return {"id": environment.id, "name": environment.name, "data": read_inventory(db, environment.id), "revision": environment.revision}


def require_copy_json(request: Request):
    # A JSON content type prevents browser form submissions from issuing a
    # cookie-authenticated copy request without a CORS preflight.
    if request.headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/json":
        raise HTTPException(status_code=415, detail="Copy requests require application/json")


def build_environment_copy(db: Session, source: Environment, name: str, user: User):
    name = name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Environment name cannot be blank")
    inventory = copy_inventory(read_inventory(db, source.id))
    environment = Environment(id=str(uuid4()), name=name, revision=1)
    db.add(environment)
    db.flush()
    replace_inventory(db, environment.id, InventoryState(**inventory), user=user, accept_overlaps=True)
    db.flush()
    return {"id": environment.id, "name": environment.name, "data": read_inventory(db, environment.id), "revision": environment.revision, "role": "admin"}


@app.post("/api/environments/copy-all", status_code=201)
def copy_all_environments(request: Request, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    require_copy_json(request)
    sources = list(db.scalars(select(Environment).order_by(Environment.name)))
    copies = [build_environment_copy(db, source, source.name[:73] + " (copy)", user) for source in sources]
    db.commit()
    return {"environments": copies}


@app.post("/api/environments/{environment_id}/copy", status_code=201)
def copy_environment(environment_id: str, payload: EnvironmentCreate, request: Request, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    require_copy_json(request)
    source = environment_access(db, user, environment_id)
    copied = build_environment_copy(db, source, payload.name, user)
    db.commit()
    return copied


@app.patch("/api/environments/{environment_id}")
def rename_environment(environment_id: str, payload: EnvironmentRename, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    environment = db.get(Environment, environment_id)
    if not environment:
        raise HTTPException(status_code=404, detail="Client not found")
    name = payload.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Client name cannot be blank")
    environment.name = name
    db.commit()
    return {"id": environment.id, "name": environment.name}


@app.delete("/api/environments/{environment_id}", status_code=204)
def delete_environment(environment_id: str, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    environment = db.get(Environment, environment_id)
    if not environment:
        raise HTTPException(status_code=404, detail="Client not found")
    archive_assets(db, environment, read_inventory(db, environment_id)['assets'], user)
    db.delete(environment)
    db.commit()


def advance_environment_revision(db: Session, environment: Environment, if_match: int | None) -> int:
    expected_revision = environment.revision if if_match is None else if_match
    result = db.execute(
        update(Environment)
        .where(Environment.id == environment.id, Environment.revision == expected_revision)
        .values(revision=Environment.revision + 1)
        .execution_options(synchronize_session=False)
    )
    if result.rowcount != 1:
        raise HTTPException(status_code=409, detail="Client data changed elsewhere. Reload before saving.")
    return expected_revision + 1


@app.put("/api/environments/{environment_id}/licenses/{license_id}")
def save_license(
    environment_id: str,
    license_id: str,
    payload: LicenseInput,
    response: Response,
    if_match: int | None = Header(default=None),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    environment = environment_access(db, user, environment_id, write=True)
    license_record = db.scalar(select(License).where(
        License.id == license_id,
        License.environment_id == environment_id,
    ))
    asset_ids = set(db.scalars(select(Asset.id).where(
        Asset.environment_id == environment_id,
        Asset.id.in_(payload.assigned_asset_ids or [""]),
    )))
    if len(asset_ids) != len(payload.assigned_asset_ids):
        raise HTTPException(status_code=422, detail="Assigned devices must belong to this client")
    if payload.seats is not None and (payload.assigned or 0) + len(asset_ids) > payload.seats:
        raise HTTPException(status_code=422, detail="Assigned seats and devices cannot exceed the license seat count")

    revision = advance_environment_revision(db, environment, if_match)
    values = {
        "product": payload.product.strip(),
        "vendor": _optional_text(payload.vendor),
        "license_key": _optional_text(payload.license_key),
        "type": _optional_text(payload.type),
        "seats": payload.seats,
        "assigned": payload.assigned,
        "assigned_asset_ids": payload.assigned_asset_ids,
        "expiry": payload.expiry,
        "owner": _optional_text(payload.owner),
        "notes": _optional_text(payload.notes),
    }
    if not values["product"]:
        raise HTTPException(status_code=422, detail="License product cannot be blank")
    if license_record:
        for key, value in values.items():
            setattr(license_record, key, value)
    else:
        license_record = License(id=license_id, environment_id=environment_id, **values)
        db.add(license_record)
    db.flush()
    cost_fields = {}
    if "net_price" in payload.model_fields_set:
        cost_fields["netPrice"] = payload.net_price
    if "cost_estimate_id" in payload.model_fields_set:
        cost_fields["costEstimateId"] = payload.cost_estimate_id
    save_pricing(db, environment_id, "licenses", license_id, cost_fields)
    db.commit()
    response.headers["ETag"] = str(revision)
    return {"revision": revision}


@app.delete("/api/environments/{environment_id}/licenses/{license_id}", status_code=204)
def delete_license(
    environment_id: str,
    license_id: str,
    response: Response,
    if_match: int | None = Header(default=None),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    environment = environment_access(db, user, environment_id, write=True)
    license_record = db.scalar(select(License).where(
        License.id == license_id,
        License.environment_id == environment_id,
    ))
    if not license_record:
        raise HTTPException(status_code=404, detail="License not found")
    revision = advance_environment_revision(db, environment, if_match)
    db.delete(license_record)
    from backend.models import CostPricing
    db.execute(delete(CostPricing).where(CostPricing.environment_id == environment_id, CostPricing.section == "licenses", CostPricing.record_id == license_id))
    db.commit()
    response.headers["ETag"] = str(revision)


@app.get("/api/environments/{environment_id}/data")
def get_environment_data(environment_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    environment = environment_access(db, user, environment_id)
    return {"revision": environment.revision, "data": read_inventory(db, environment_id)}


@app.put("/api/environments/{environment_id}/data")
def save_environment_data(
    environment_id: str,
    payload: InventoryState,
    response: Response,
    if_match: int | None = Header(default=None),
    accept_network_overlap: bool = Header(default=False, alias="X-Accept-Network-Overlap"),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    environment = environment_access(db, user, environment_id, write=True)
    previous_revision = environment.revision
    version_update = update(Environment).where(Environment.id == environment_id)
    if if_match is not None:
        version_update = version_update.where(Environment.revision == if_match)
    result = db.execute(version_update.values(revision=Environment.revision + 1).execution_options(synchronize_session=False))
    if result.rowcount != 1:
        raise HTTPException(status_code=409, detail="Client data changed elsewhere. Reload before saving.")
    previous_inventory = read_inventory(db, environment_id)
    replace_inventory(db, environment_id, payload, user, accept_network_overlap)
    db.flush()
    inventory_changes(db, user, environment, previous_inventory, read_inventory(db, environment_id))
    environment.revision = previous_revision + 1
    db.commit()
    response.headers["ETag"] = str(environment.revision)
    return {"revision": environment.revision, "data": read_inventory(db, environment_id), "networkWarnings": network_warnings(db, user)}


@app.post("/api/environments/{environment_id}/members", status_code=201)
def add_member(environment_id: str, payload: MembershipCreate, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    if not db.get(Environment, environment_id):
        raise HTTPException(status_code=404, detail="Client not found")
    member = db.get(User, payload.user_id)
    if not member:
        raise HTTPException(status_code=404, detail="User not found")
    if member.is_admin:
        raise HTTPException(status_code=403, detail="Administrator access is managed separately")
    if not member.is_active:
        raise HTTPException(status_code=409, detail="Cannot grant access to an inactive user")
    existing = db.scalar(select(Membership).where(
        Membership.user_id == member.id,
        Membership.environment_id == environment_id,
    ))
    if existing:
        existing.role = payload.role
    else:
        db.add(Membership(user_id=member.id, environment_id=environment_id, role=payload.role))
    db.commit()
    return {"username": member.username, "role": payload.role}


@app.patch("/api/environments/{environment_id}/members/{user_id}")
def update_member(environment_id: str, user_id: str, payload: MembershipUpdate, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    if not db.get(Environment, environment_id):
        raise HTTPException(status_code=404, detail="Client not found")
    membership = db.scalar(select(Membership).where(
        Membership.environment_id == environment_id,
        Membership.user_id == user_id,
    ))
    if not membership:
        raise HTTPException(status_code=404, detail="Client membership not found")
    member = db.get(User, user_id)
    if not member or member.is_admin:
        raise HTTPException(status_code=403, detail="Administrator access is managed separately")
    membership.role = payload.role
    db.commit()
    return {"id": member.id, "username": member.username, "role": membership.role}


@app.get("/api/environments/{environment_id}/members")
def list_members(environment_id: str, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    if not db.get(Environment, environment_id):
        raise HTTPException(status_code=404, detail="Client not found")
    rows = db.execute(
        select(Membership, User).join(User, Membership.user_id == User.id)
        .where(Membership.environment_id == environment_id).order_by(User.username)
    )
    return [{"id": member.id, "username": member.username, "role": membership.role}
            for membership, member in rows]


@app.delete("/api/environments/{environment_id}/members/{user_id}", status_code=204)
def remove_member(environment_id: str, user_id: str, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    membership = db.scalar(select(Membership).where(
        Membership.environment_id == environment_id,
        Membership.user_id == user_id,
    ))
    if not membership:
        raise HTTPException(status_code=404, detail="Client membership not found")
    db.delete(membership)
    db.commit()


@app.get("/api/users")
def list_users(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    users = list(db.scalars(select(User).order_by(User.username)))
    memberships = db.scalars(select(Membership)).all()
    roles_by_user: dict[str, dict[str, str]] = {}
    for membership in memberships:
        roles_by_user.setdefault(membership.user_id, {})[membership.environment_id] = membership.role
    return [{
        "id": item.id,
        "username": item.username,
        "is_admin": item.is_admin,
        "is_active": item.is_active,
        "assistant_write_enabled": item.is_admin or item.assistant_write_enabled,
        "environment_roles": roles_by_user.get(item.id, {}),
    } for item in users]


@app.post("/api/users", status_code=201)
def create_user(payload: UserCreate, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    username = payload.username.strip().lower()
    if not username:
        raise HTTPException(status_code=422, detail="Username cannot be blank")
    if db.scalar(select(User).where(User.username == username)):
        raise HTTPException(status_code=409, detail="That username already exists")
    new_user = User(
        id=str(uuid4()),
        username=username,
        password_hash=hash_password(payload.password),
        is_admin=payload.is_admin,
        is_active=True,
        theme="default",
    )
    db.add(new_user)
    db.commit()
    return {"id": new_user.id, "username": new_user.username, "is_admin": new_user.is_admin, "is_active": True}


@app.put("/api/users/{user_id}/assistant-permission")
def update_assistant_permission(
    user_id: str,
    payload: AssistantPermissionUpdate,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(404, "User not found")
    if target.is_admin:
        raise HTTPException(403, "Superadmins always have writable AI chat access")
    target.assistant_write_enabled = payload.assistant_write_enabled
    db.commit()
    return {"id": target.id, "assistant_write_enabled": target.assistant_write_enabled}


@app.patch("/api/users/{user_id}")
def update_user_status(
    user_id: str,
    payload: UserStatusUpdate,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.is_admin:
        raise HTTPException(status_code=403, detail="Administrator accounts are managed separately")
    if target.id == user.id and not payload.is_active:
        raise HTTPException(status_code=400, detail="You cannot deactivate your own account")
    target.is_active = payload.is_active
    if not payload.is_active:
        db.execute(delete(UserSession).where(UserSession.user_id == target.id))
    db.commit()
    return {"id": target.id, "username": target.username, "is_active": target.is_active}


@app.delete("/api/users/{user_id}", status_code=204)
def delete_user(
    user_id: str,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.is_admin:
        raise HTTPException(status_code=403, detail="Administrator accounts are managed separately")
    if target.id == user.id:
        raise HTTPException(status_code=400, detail="You cannot delete your own account")
    db.delete(target)
    db.commit()


@app.post("/api/users/{user_id}/password", status_code=204)
def reset_user_password(
    user_id: str,
    payload: UserPasswordReset,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.is_admin:
        raise HTTPException(status_code=403, detail="Administrator passwords are managed separately")
    target.password_hash = hash_password(payload.password)
    db.execute(delete(UserSession).where(UserSession.user_id == target.id))
    db.commit()


@app.post("/api/users/me/change-password", status_code=204)
def change_own_password(
    payload: UserPasswordChange,
    request: Request,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(payload.current_password, user.password_hash):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    user.password_hash = hash_password(payload.new_password)
    token = request.cookies.get(SESSION_COOKIE)
    current_session_hash = digest_token(token) if token else ""
    db.execute(delete(UserSession).where(
        UserSession.user_id == user.id,
        UserSession.token_hash != current_session_hash,
    ))
    db.commit()


@app.patch("/api/users/me/preferences")
def update_user_preferences(
    payload: UserPreferencesUpdate,
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    if payload.dashboard is not None:
        if not payload.environmentId:
            raise HTTPException(status_code=422, detail="Choose an environment for dashboard preferences")
        environment_access(db, user, payload.environmentId)
        saved = user.dashboard or {}
        preferences = dict(saved) if 'environments' in saved else {'default': saved or None, 'environments': {}}
        preferences['environments'] = {**preferences.get('environments', {}), payload.environmentId: payload.dashboard.model_dump()}
        user.dashboard = preferences
    if payload.language is not None:
        user.language = payload.language
    if payload.theme is not None:
        user.theme = payload.theme
    db.commit()
    result = {"theme": user.theme, "language": user.language}
    if payload.dashboard is not None:
        result['dashboard'] = user.dashboard
    return result


@app.get("/api/audit-logs")
def list_audit_logs(
    before: str | None = Query(default=None, max_length=36),
    limit: int = Query(default=50, ge=1, le=100),
    q: str = Query(default="", max_length=240),
    account: str = Query(default="", max_length=120),
    action: str = Query(default="", max_length=120),
    result: Literal["all", "success", "failed"] = "all",
    sort: Literal["time", "account", "action"] = "time",
    direction: Literal["asc", "desc"] = "desc",
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    purge_expired(db)
    query = select(AuditLog).where(AuditLog.message.is_not(None))
    def utc(value):
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)
    if date_from and date_to and utc(date_from) > utc(date_to):
        raise HTTPException(status_code=422, detail="Start time must be before end time")
    if q.strip():
        query = query.where(AuditLog.message.icontains(q.strip(), autoescape=True))
    if account.strip():
        query = query.where(AuditLog.username.icontains(account.strip(), autoescape=True))
    if action:
        query = query.where(AuditLog.action == action)
    if result != "all":
        query = query.where(AuditLog.status_code < 400 if result == "success" else AuditLog.status_code >= 400)
    if date_from:
        query = query.where(AuditLog.created_at >= utc(date_from))
    if date_to:
        query = query.where(AuditLog.created_at <= utc(date_to))
    total = db.scalar(select(func.count()).select_from(query.subquery()))
    primary = {"time": AuditLog.created_at, "account": AuditLog.username, "action": AuditLog.action}[sort]
    columns = [primary] + ([] if sort == "time" else [AuditLog.created_at]) + [AuditLog.id]
    if before:
        cursor = db.get(AuditLog, before)
        if not cursor:
            raise HTTPException(status_code=422, detail="Log cursor expired. Refresh the activity log.")
        predicates = []
        for index, column in enumerate(columns):
            value = getattr(cursor, column.key)
            predicates.append(and_(
                *(previous == getattr(cursor, previous.key) for previous in columns[:index]),
                column > value if direction == "asc" else column < value,
            ))
        query = query.where(or_(*predicates))
    rows = list(db.scalars(query.order_by(
        *(column.asc() if direction == "asc" else column.desc() for column in columns)
    ).limit(limit + 1)))
    page = rows[:limit]
    db.commit()
    return {"items": [{
        "id": row.id, "created_at": row.created_at.isoformat() + ("Z" if row.created_at.tzinfo is None else ""),
        "user_id": row.user_id, "username": row.username, "is_admin": row.is_admin,
        "action": row.action, "message": row.message, "method": row.method, "resource": row.resource,
        "target_ids": row.target_ids, "status_code": row.status_code,
    } for row in page], "total": total, "next_cursor": page[-1].id if len(rows) > limit else None}


@app.get("/api/settings/audit-retention")
def get_audit_retention(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    return {"retention_days": retention_days(db)}


@app.put("/api/settings/audit-retention")
def update_audit_retention(
    payload: AuditRetentionUpdate,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    insert_missing(db, AuditSettings, {"id": 1, "retention_days": 90}, "id")
    policy = db.scalar(select(AuditSettings).where(AuditSettings.id == 1).with_for_update().execution_options(populate_existing=True))
    policy.retention_days = payload.retention_days
    db.flush()
    purge_expired(db)
    db.commit()
    return {"retention_days": policy.retention_days}
