"""Persistent per-username login blocking for SQLite and MySQL deployments."""
from datetime import datetime, timedelta, timezone
from math import ceil

from fastapi import HTTPException
from sqlalchemy import delete, select
from sqlalchemy.dialects.mysql import insert as mysql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from backend.models import LoginAttempt, LoginProtectionSettings
from backend.security import digest_token, hash_password, verify_password


DUMMY_PASSWORD_HASH = hash_password("dummy-password-for-unknown-login-users")


def now_utc():
    return datetime.now(timezone.utc)


def aware(value):
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value


def insert_missing(db, model, values, key):
    if db.bind.dialect.name == "sqlite":
        statement = sqlite_insert(model).values(**values).on_conflict_do_nothing(index_elements=[key])
    else:
        statement = mysql_insert(model).values(**values)
        statement = statement.on_duplicate_key_update(**{key: statement.inserted[key]})
    db.execute(statement)


def read_policy(db):
    policy = db.get(LoginProtectionSettings, 1)
    return policy or LoginProtectionSettings(id=1, enabled=True, max_failed_attempts=5, block_minutes=15)


def policy_data(policy):
    return {"enabled": policy.enabled, "max_failed_attempts": policy.max_failed_attempts, "block_minutes": policy.block_minutes}


def check_login(db, username, password, user):
    policy = read_policy(db)
    attempt = None
    now = now_utc()
    if policy.enabled:
        # Remove expired entries, including unknown usernames, to bound retained history.
        db.execute(delete(LoginAttempt).where(LoginAttempt.reset_at <= now))
        username_hash = digest_token(username)
        insert_missing(db, LoginAttempt, {
            "username_hash": username_hash, "failed_attempts": 0,
            "reset_at": now + timedelta(minutes=policy.block_minutes),
        }, "username_hash")
        # SQLite's insert acquires its write lock; MySQL locks this username's row.
        attempt = db.scalar(select(LoginAttempt).where(
            LoginAttempt.username_hash == username_hash
        ).with_for_update().execution_options(populate_existing=True))
        now = now_utc()
        if attempt.blocked_until and aware(attempt.blocked_until) > now:
            retry = max(1, ceil((aware(attempt.blocked_until) - now).total_seconds()))
            db.commit()
            raise HTTPException(status_code=429, detail="Too many failed sign-in attempts. Try again later.", headers={"Retry-After": str(retry)})
        if aware(attempt.reset_at) <= now:
            attempt.failed_attempts = 0
            attempt.blocked_until = None

    valid_password = verify_password(password, user.password_hash if user else DUMMY_PASSWORD_HASH)
    if not user or not user.is_active or not valid_password:
        blocked = False
        if attempt:
            attempt.failed_attempts += 1
            attempt.reset_at = now_utc() + timedelta(minutes=policy.block_minutes)
            if attempt.failed_attempts >= policy.max_failed_attempts:
                attempt.blocked_until = attempt.reset_at
                blocked = True
        db.commit()  # Failed attempts must persist even though the request raises an error.
        if blocked:
            raise HTTPException(status_code=429, detail="Too many failed sign-in attempts. Try again later.", headers={"Retry-After": str(policy.block_minutes * 60)})
        raise HTTPException(status_code=401, detail="Invalid username or password")
    if attempt:
        db.delete(attempt)
    # create_session commits this transaction after authentication.
