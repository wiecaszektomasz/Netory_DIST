"""Validate cabinet capacity and non-overlapping, environment-local placements."""
from fastapi import HTTPException


def whole(value, label, maximum=100):
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= maximum:
        raise HTTPException(422, f'{label} must be a whole number from 1 to {maximum}')
    return value


def validate_racks(racks, assets):
    by_id = {}
    for rack in racks:
        id = rack.get('id')
        if not isinstance(id, str) or not id or len(id) > 80 or id in by_id:
            raise HTTPException(422, 'Cabinets require unique IDs')
        whole(rack.get('capacityU'), 'Cabinet capacity')
        whole(rack.get('displayOrder', 1), 'Cabinet display order', 100000)
        for field in ['name', 'location']:
            if not isinstance(rack.get(field, ''), str) or len(rack.get(field, '')) > 240:
                raise HTTPException(422, 'Cabinet name and location must be text up to 240 characters')
        by_id[id] = rack
    occupied = {}
    for asset in assets:
        enabled = asset.get('rackEnabled', False)
        if not isinstance(enabled, bool):
            raise HTTPException(422, 'Rack enabled must be true or false')
        if asset.get('rackId') is not None and not isinstance(asset.get('rackId'), str):
            raise HTTPException(422, 'Cabinet reference must be text')
        rack_id = asset.get('rackId') or ''
        start = asset.get('rackStartU')
        units = asset.get('rackUnits')
        if not enabled:
            if rack_id or start not in (None, '') or units not in (None, ''):
                raise HTTPException(422, 'Enable rack mounting before setting rack placement')
            continue
        if asset.get('type') == 'Virtual server':
            raise HTTPException(422, 'Virtual servers cannot occupy rack units')
        whole(units, 'Device height')
        if not rack_id:
            if start not in (None, ''):
                raise HTTPException(422, 'Choose a cabinet before setting a position')
            continue
        if not isinstance(rack_id, str) or rack_id not in by_id:
            raise HTTPException(422, 'Cabinet must belong to this environment')
        whole(start, 'Starting U')
        if start + units - 1 > by_id[rack_id]['capacityU']:
            raise HTTPException(422, 'Device extends beyond the cabinet capacity')
        for unit in range(start, start + units):
            key = (rack_id, unit)
            if key in occupied:
                raise HTTPException(409, f'Rack U{unit} is already occupied by {occupied[key]}')
            occupied[key] = asset.get('name', 'another device')


def validate_rooms(rooms, racks):
    ids, names = set(), set()
    for room in rooms:
        id, name = room.get('id'), room.get('name')
        if not isinstance(id, str) or not id.strip() or len(id) > 80 or id in ids:
            raise HTTPException(422, 'Rooms require unique IDs')
        if not isinstance(name, str) or not name.strip() or len(name) > 240:
            raise HTTPException(422, 'Room name must contain 1–240 characters')
        if name.strip().casefold() in names:
            raise HTTPException(409, 'Room names must be unique within this environment')
        ids.add(id)
        names.add(name.strip().casefold())
    for rack in racks:
        room = rack.get('roomId')
        if room is not None and not isinstance(room, str):
            raise HTTPException(422, 'Room reference must be text')
        if room and room not in ids:
            raise HTTPException(422, 'Cabinet room must belong to this environment')
