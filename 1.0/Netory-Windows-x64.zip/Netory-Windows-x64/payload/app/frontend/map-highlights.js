// Bind independently of zoom/magnifier setup so port hover always works.
export function bindConnectionHighlights(view, svg, getCopy = () => null, onHighlight = () => {}) {
  let pinned = '';
  const target = element => element?.closest?.('[data-connection-id]') || null;
  const highlight = id => {
    svg.classList.toggle('has-link-focus', Boolean(id));
    getCopy()?.classList.toggle('has-link-focus', Boolean(id));
    view.querySelectorAll('[data-connection-id]').forEach(element => element.classList.toggle('is-highlighted', Boolean(id) && element.dataset.connectionId === id));
    onHighlight();
  };
  const pin = element => { const id = target(element)?.dataset.connectionId || ''; pinned = pinned === id ? '' : id; highlight(pinned); };
  svg.addEventListener('click', event => pin(event.target));
  view.querySelectorAll('.connection-row').forEach(row => {
    row.addEventListener('click', () => pin(row));
    row.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') {event.preventDefault(); pin(row);} });
  });
  view.onpointerover = event => {const entered = target(event.target), from = target(event.relatedTarget); if (entered && view.contains(entered) && entered.dataset.connectionId !== from?.dataset.connectionId) highlight(entered.dataset.connectionId);};
  view.onpointerout = event => {const exited = target(event.target), to = target(event.relatedTarget); if (exited && view.contains(exited) && exited.dataset.connectionId !== to?.dataset.connectionId) highlight(to?.dataset.connectionId || pinned);};
  view.onfocusin = event => {const focused = target(event.target); if (focused) highlight(focused.dataset.connectionId);};
  view.onfocusout = event => highlight(target(event.relatedTarget)?.dataset.connectionId || pinned);
}
