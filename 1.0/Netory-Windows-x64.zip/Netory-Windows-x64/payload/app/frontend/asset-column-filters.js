const exactColumns = new Set(['type', 'status', 'showOnMap', 'backupPowerEnabled']);
const normalize = value => String(value ?? '').trim().toLocaleLowerCase();

export function matchesAssetColumnFilters(values, filters) {
  return [...filters].every(([column, query]) => {
    if (!query || !values.has(column)) return true;
    const text = normalize(values.get(column));
    return exactColumns.has(column) ? text === normalize(query) : text.includes(normalize(query));
  });
}

export function bindAssetColumnFilters(view, filters) {
  const table = view.querySelector('[data-asset-filter-table]');
  if (!table) return;
  const headings = [...table.querySelectorAll('thead th[data-asset-column]')];
  const rows = [...table.querySelectorAll('tbody tr[data-asset-row]')].map(row => ({
    row, values: new Map([...row.querySelectorAll('[data-asset-cell]')]
      .map(cell => [cell.dataset.assetCell, cell.textContent.replace(/\s+/g, ' ').trim()])),
  }));
  const filterRow = document.createElement('tr');
  filterRow.className = 'asset-column-filter-row';
  const controls = [];
  const emptyRow = document.createElement('tr');
  const emptyCell = document.createElement('td');
  emptyCell.colSpan = headings.length + 1;
  emptyCell.className = 'asset-filter-empty';
  emptyCell.textContent = 'No assets match these filters.';
  emptyRow.append(emptyCell);
  emptyRow.hidden = true;
  table.querySelector('tbody').append(emptyRow);
  const count = view.querySelector('.count-label');
  const clear = view.querySelector('[data-clear-asset-filters]');
  const apply = () => {
    let visible = 0;
    rows.forEach(({row, values}) => {
      row.hidden = !matchesAssetColumnFilters(values, filters);
      if (!row.hidden) visible++;
    });
    emptyRow.hidden = visible > 0 || !rows.length;
    if (count) count.textContent = `${visible} of ${rows.length} records`;
    if (clear) clear.disabled = ![...filters.values()].some(Boolean);
  };
  for (const heading of headings) {
    const column = heading.dataset.assetColumn;
    const cell = document.createElement('th');
    const control = document.createElement(exactColumns.has(column) ? 'select' : 'input');
    control.setAttribute('aria-label', `Filter ${heading.textContent.trim()}`);
    control.dataset.assetColumnFilter = column;
    if (exactColumns.has(column)) {
      const all = document.createElement('option');
      all.value = ''; all.textContent = 'All'; control.append(all);
      const choices = new Set(rows.map(({values}) => values.get(column)));
      if (filters.get(column)) choices.add(filters.get(column));
      [...choices].filter(Boolean).sort((a,b) => a.localeCompare(b)).forEach(value => {
        const option = document.createElement('option');
        option.value = value; option.textContent = value; control.append(option);
      });
    } else {
      control.type = 'search';
      control.placeholder = 'Filter…';
      control.autocomplete = 'off';
    }
    control.value = filters.get(column) || '';
    control.addEventListener(exactColumns.has(column) ? 'change' : 'input', () => {
      if (control.value) filters.set(column, control.value); else filters.delete(column);
      apply();
    });
    controls.push(control); cell.append(control); filterRow.append(cell);
  }
  filterRow.append(document.createElement('th'));
  table.querySelector('thead').append(filterRow);
  clear?.addEventListener('click', () => {
    filters.clear(); controls.forEach(control => { control.value = ''; }); apply();
  });
  apply();
}
