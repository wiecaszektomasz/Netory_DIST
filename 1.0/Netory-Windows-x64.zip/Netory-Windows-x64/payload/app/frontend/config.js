import { html, t } from './i18n.js?v=20261015-map-admin2';
const navIcons = {
  accessPoint: html(["<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"3\" y=\"12\" width=\"18\" height=\"8\" rx=\"2\"></rect><path d=\"M6 12V5m12 7V5M9 4a5 5 0 0 1 6 0M10.5 7a2.5 2.5 0 0 1 3 0\"></path><circle cx=\"7\" cy=\"16\" r=\"1\"></circle><path d=\"M11 16h6\"></path></svg>"]),
  rj45: html(["<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M7 3h10v5l3 3v10H4V11l3-3z\"></path><path d=\"M8 3v5m2-5v5m2-5v5m2-5v5m2-5v5M8 16h8\"></path></svg>"]),
  wireless: html(["<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"18\" r=\"1.4\"></circle><path d=\"M8.8 15a4.5 4.5 0 0 1 6.4 0M5.6 11.8a9 9 0 0 1 12.8 0M2.7 8.7a13 13 0 0 1 18.6 0\"></path></svg>"])
};

export const sections = {
  integrations: { get label() { return t('integrations'); }, icon: '⇄' },
  overview: { get label() { return t("overview"); }, icon: '⌂' },
  notesBoard: { get label() { return t('notes_board'); }, icon: '▧' },
  networkMap: { get label() { return t("network_map"); }, icon: html(["<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><circle cx=\"6\" cy=\"6\" r=\"2\"></circle><circle cx=\"18\" cy=\"7\" r=\"2\"></circle><circle cx=\"12\" cy=\"18\" r=\"2\"></circle><path d=\"m7.7 7.1 8.5-.2M7.1 7.8l3.8 8.4m5.9-7.4-3.8 7.5\"></path></svg>"]) },
  rooms: { get label() { return t("rooms"); }, icon: '▣' },
  racks: { get label() { return t("rack_cabinets"); }, icon: '▤' },
  switches: { get label() { return t("switches"); }, icon: '▦' },
  routers: { get label() { return t("routers_firewalls"); }, icon: '◇' },
  wifi: { get label() { return t("wi_fi"); }, icon: navIcons.accessPoint },
  servers: { get label() { return t("servers"); }, icon: '▤' },
  clusters: { get label() { return t("server_clusters"); }, icon: '▤' },
  storage: { get label() { return t("storage"); }, icon: '▧' },
  computers: { get label() { return t("computers"); }, icon: '▣' },
  printers: { get label() { return t("printers"); }, icon: '▤' },
  monitors: { get label() { return t("monitors"); }, icon: '▭' },
  patchPanels: { get label() { return t("patch_panels"); }, icon: '▦' },
  ups: { get label() { return t("ups"); }, icon: '▣' },
  otherDevices: { get label() { return t("other_devices_bb70b2"); }, icon: '◇' },
  vlans: { get label() { return t("vlans"); }, icon: '⌘' },
  lans: { get label() { return t("networks"); }, icon: navIcons.rj45 },
  wlans: { get label() { return t("wlan"); }, icon: navIcons.wireless },
  stacks: { get label() { return t("device_stacks"); }, icon: '▤' },
  lags: { get label() { return t("lags"); }, icon: '⇉' },
  licenses: { get label() { return t("licenses"); }, icon: '▣' },
  accounts: { get label() { return t("accounts"); }, icon: '♙' },
  costEstimates: { get label() { return t("cost_estimates"); }, icon: html(["<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><rect x=\"5\" y=\"2\" width=\"14\" height=\"20\" rx=\"2\"></rect><path d=\"M8 6h8M8 11h2m4 0h2M8 15h2m4 0h2M8 19h2m4 0h2\"></path></svg>"]) },
  settings: { get label() { return t("settings"); }, icon: '⚙' }
};

export const networkDeviceTypes = ['Network device', 'Router', 'Firewall / UTM', 'Switch', 'Access point', 'Wi-Fi controller'];

export const assetCategoryTypes = {
  switches: ['Switch'],
  routers: ['Router', 'Firewall / UTM'],
  wifi: ['Access point', 'Wi-Fi controller'],
  servers: ['Physical server', 'Virtual server'],
  storage: ['Storage'],
  computers: ['Computer'],
  printers: ['Printer'],
  monitors: ['Monitor'],
  patchPanels: ['Patch panel'],
  ups: ['UPS'],
  otherDevices: ['Other', 'Network device']
};

export const assetCategoryDefaults = {
  switches: 'Switch',
  routers: 'Router',
  wifi: 'Access point',
  servers: 'Physical server',
  storage: 'Storage',
  computers: 'Computer',
  printers: 'Printer',
  monitors: 'Monitor',
  patchPanels: 'Patch panel',
  ups: 'UPS',
  otherDevices: 'Other'
};

export const schemas = {
  rooms: [['name', 'Room name', 'text', true]],
  racks: [['capacityU', 'Capacity (U)', 'number', true], ['location', 'Location', 'text']],
  assets: [
    ['name', 'Asset name', 'text', true], ['type', 'Type', 'select', true, ['Physical server', 'Virtual server', ...networkDeviceTypes, 'Storage', 'Computer', 'Printer', 'Monitor', 'UPS', 'Patch panel', 'Other']],
    ['warrantyExpiry', 'Warranty expiry date', 'date'],
    ['deviceKind', 'Device kind (keyboard, mouse, etc.)', 'text'],
    ['status', 'Status', 'select', false, ['In service', 'Maintenance', 'Retired', 'Planned']],
    ['powerSettings', 'Backup power', 'power-settings'], ['rackSettings', 'Rack placement', 'rack-settings'], ['showOnMap', 'Add to map', 'checkbox'], ['hostname', 'Hostname', 'text'],
    ['manufacturer', 'Manufacturer / model', 'text'], ['serial', 'Serial number', 'text'], ['location', 'Location / rack', 'text'],
    ['ip', 'Management IP', 'text'], ['portCount', 'Number of ports', 'number'], ['ports', 'Port configuration & connections', 'ports-editor'],
    ['upsRatedVA', 'Rated apparent power (VA)', 'number'], ['upsRatedW', 'Rated power (W)', 'number'],
    ['upsRuntimeMinutes', 'Estimated runtime (minutes)', 'number'], ['upsBatteryCount', 'Battery count', 'number'],
    ['upsBatteryReplacementDate', 'Battery replacement date', 'date'],
    ['managementController', 'Remote management', 'management-controller'],
    ['cpu', 'CPU / cores', 'text'], ['ram', 'RAM', 'text'], ['storage', 'Storage', 'text'],
    ['os', 'Operating system', 'os-picker'], ['hypervisorId', 'Hypervisor host or cluster', 'server-picker'], ['vlan', 'MGMT VLAN', 'management-vlan-picker'], ['notes', 'Notes', 'textarea']
  ],
  vlans: [
    ['name', 'VLAN name', 'text', true], ['id', 'VLAN ID', 'number', true], ['network', 'Network / CIDR', 'text'],
    ['gateway', 'Gateway', 'text'], ['masterDeviceId', 'Master device', 'device-picker'],
    ['location', 'Site / location', 'text'], ['purpose', 'Purpose', 'text'], ['notes', 'Notes', 'textarea']
  ],
  lans: [
    ['name', 'Network name', 'text', true], ['network', 'Network / CIDR', 'text'], ['gateway', 'Gateway', 'text'],
    ['dnsServers', 'DNS servers (comma-separated)', 'text'], ['dhcp', 'DHCP server IP / start-end range', 'textarea'],
    ['parentInterface', 'Parent interface', 'network-interface-picker'], ['vlanId', 'VLAN ID (optional)', 'existing-vlan-number-picker'], ['location', 'Site / location', 'text'],
    ['purpose', 'Purpose', 'text'], ['notes', 'Notes', 'textarea']
  ],
  wlans: [
    ['name', 'WLAN name', 'text', true], ['ssid', 'SSID', 'text', true], ['parentDeviceId', 'Parent device', 'wlan-device-picker'],
    ['security', 'Security mode', 'select', true, ['Open', 'WPA2-Personal', 'WPA2-Enterprise', 'WPA3-Personal', 'WPA3-Enterprise', 'WPA2/WPA3-Personal', 'WPA2/WPA3-Enterprise', 'Other']],
    ['wifiPassword', 'Wi-Fi password', 'password'],
    ['authServer', 'Authentication / RADIUS server', 'text'], ['network', 'Network / CIDR', 'text'],
    ['gateway', 'Gateway', 'text'], ['dnsServers', 'DNS servers (comma-separated)', 'text'],
    ['dhcp', 'DHCP server IP / start-end range', 'textarea'], ['vlanInterfaceId', 'VLAN', 'wlan-vlan-picker'],
    ['location', 'Site / location', 'text'], ['purpose', 'Purpose', 'text'], ['notes', 'Notes', 'textarea']
  ],
  stacks: [
    ['name', 'Stack name', 'text', true],
    ['deviceType', 'Device type', 'select', true, ['Switch', 'Router', 'Firewall / UTM']],
    ['memberAssetIds', 'Stack members', 'stack-members', true],
    ['notes', 'Notes', 'textarea']
  ],
  clusters: [
    ['name', 'Cluster name', 'text', true],
    ['memberAssetIds', 'Physical server members', 'cluster-members', true],
    ['showOnMap', 'Add to map', 'checkbox'],
    ['location', 'Location', 'text'], ['notes', 'Notes', 'textarea']
  ],
  lags: [
    ['name', 'LAG name', 'text', true],
    ['aggregationType', 'Aggregation type', 'select', true, ['Static', 'Dynamic']],
    ['endpointAId', 'First device or stack', 'lag-device-picker', true],
    ['portsA', 'Ports on first device', 'lag-ports', true],
    ['endpointBId', 'Second device or stack', 'lag-device-picker', true],
    ['portsB', 'Ports on second device', 'lag-ports', true]
  ],
  licenses: [
    ['product', 'Product', 'text', true], ['vendor', 'Vendor', 'text'], ['licenseKey', 'License key / reference', 'text'],
    ['type', 'License type', 'select', false, ['Subscription', 'Perpetual', 'OEM', 'Open source', 'Other']],
    ['seats', 'Seats', 'number'], ['assigned', 'Other assigned seats', 'number'], ['expiry', 'Expiry date', 'date'],
    ['owner', 'Owner / team', 'text'], ['notes', 'Notes', 'textarea']
  ],
  hypervisors: [
    ['name', 'Name', 'text', true], ['platform', 'Platform', 'select', true, ['VMware vSphere', 'Microsoft Hyper-V', 'Proxmox VE', 'Nutanix AHV', 'KVM', 'Other']],
    ['version', 'Version', 'text'], ['managementIp', 'Management IP', 'text'], ['cluster', 'Cluster', 'text'],
    ['location', 'Location', 'text'], ['capacity', 'Capacity / notes', 'text'], ['notes', 'Notes', 'textarea']
  ],
  accounts: [
    ['name', 'Account / service name', 'text', true], ['system', 'System / platform', 'text', true],
    ['username', 'Username', 'text'], ['accountType', 'Account type', 'select', false, ['Administrator', 'Service account', 'Break-glass', 'API / integration', 'Other']],
    ['owner', 'Account owner', 'text'], ['vault', 'Password vault reference', 'text'], ['rotation', 'Last credential rotation', 'date'],
    ['notes', 'Notes', 'textarea']
  ]
};

export function emptyData() {
  return { ...Object.fromEntries(Object.keys(schemas).map(section => [section, []])), connections: [] };
}


export function assetFields(category, type, hasNetwork = false) {
  const basic = ['powerSettings', 'rackSettings', 'warrantyExpiry', 'name', 'type', 'status', 'manufacturer', 'serial', 'location', 'notes'];
  let keys;
  if (type === 'Patch panel') {
    keys = [...basic.filter(key => key !== 'powerSettings'), 'showOnMap', 'portCount', 'ports'];
  } else if (type === 'UPS') {
    keys = [...basic, 'showOnMap', 'hostname', 'ip', 'portCount', 'ports', 'vlan', 'upsRatedVA', 'upsRatedW', 'upsRuntimeMinutes', 'upsBatteryCount', 'upsBatteryReplacementDate'];
  } else if (category === 'monitors' || (category === 'otherDevices' && type !== 'Network device' && !hasNetwork)) {
    keys = [...basic, ...(category === 'otherDevices' ? ['deviceKind'] : [])];
  } else if (category === 'printers') {
    keys = [...basic, 'showOnMap', 'hostname', 'ip', 'portCount', 'ports', 'vlan'];
  }
  return schemas.assets.filter(([key]) => key !== 'managementController' || ['Physical server', 'Virtual server'].includes(type))
    .filter(([key]) => keys ? keys.includes(key) : !key.startsWith('ups') && (key !== 'deviceKind' || (category === 'otherDevices' && type === 'Other')))
    .map(field => field[0] === 'type' && assetCategoryTypes[category]
      ? [...field.slice(0, 4), assetCategoryTypes[category]] : field);
}
