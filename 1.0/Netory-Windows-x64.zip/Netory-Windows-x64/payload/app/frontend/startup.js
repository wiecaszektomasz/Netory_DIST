import { html, t, loadLanguages } from './i18n.js?v=20261015-map-admin2';
export function startApplication({doc = document, win = window, load = async () => { await loadLanguages(); return import('../app.js?v=20261021-notes-board1'); }, delay = setTimeout, reload = () => location.reload()} = {}) {
  const root = doc.getElementById('auth-root');
  const connecting = () => Boolean(root?.querySelector('.auth-panel[role="status"]'));
  function showFailure(message) {
    if (!connecting()) return;
    root.innerHTML = html(["<div class=\"auth-screen\"><div class=\"auth-panel\"><h1>[[netory_could_not_start]]</h1><p role=\"alert\" data-startup-error></p><button type=\"button\" class=\"button primary\" data-startup-retry>[[reload_netory]]</button></div></div>"]);
    root.querySelector('[data-startup-error]').textContent = message;
    root.querySelector('[data-startup-retry]').addEventListener('click', reload);
  }
  win.addEventListener('error', event => showFailure(event.message || 'A startup script failed. Reload Netory to retry.'));
  win.addEventListener('unhandledrejection', event => showFailure(event.reason?.message || 'A startup request failed. Reload Netory to retry.'));
  delay(() => showFailure('Startup is taking too long. Reload Netory. If it happens again, check the browser Console for the first error.'), 20000);
  load().catch(error => showFailure(error.message || 'Could not load application scripts. Reload Netory to retry.'));
}

if (typeof document !== 'undefined') startApplication();
