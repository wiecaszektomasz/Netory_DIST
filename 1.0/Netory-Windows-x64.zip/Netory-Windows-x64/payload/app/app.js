import { renderNotesBoard } from './frontend/notes-board.js?v=20261021-notes-board1';
import { managementControllerFields, bindManagementController, collectManagementController } from './frontend/management-controller.js?v=20261021-notes-board1';
import { renderIntegrations } from './frontend/integrations.js?v=20261021-notes-board1';
import { html, t, setLanguage, localizeShell, languages, loadLanguages } from './frontend/i18n.js?v=20261015-map-admin2';
import { renderCostEstimates, costPricingFields, bindCostPricing } from './frontend/cost-estimates.js?v=20261015-map-admin2';
import { openAssetTrash } from './frontend/asset-trash.js?v=20261015-map-admin2';
import { bindAssetColumnFilters } from './frontend/asset-column-filters.js?v=20261015-map-admin2';
import { renderDashboard, openDashboardConfiguration, environmentDashboard } from './frontend/dashboard.js?v=20261015-map-admin2';
import { powerSupplyFields, bindPowerSupplyFields } from './frontend/power-supply.js?v=20261021-notes-board1';
import { renderRooms, renderRackView, rackAssetFields, bindRackFields, firstFreeRackUnit } from './frontend/racks.js?v=20261015-map-admin2';
import { assetCopyDraft } from './frontend/inventory-copy.js?v=20261015-map-admin2';
import { saveWithOverlapConfirmation } from './frontend/network-warnings.js?v=20261015-map-admin2';
import { assetFields, assetCategoryDefaults, assetCategoryTypes, emptyData, networkDeviceTypes, schemas, sections } from './frontend/config.js?v=20261021-notes-board1';
import { createNetworkMapRenderer } from './frontend/network-map.js?v=20261021-notes-board1';
import { createLoadingIndicator } from './frontend/loading.js?v=20261015-map-admin2';
import { osPicker, bindOSPicker, collectOS, openOSManager } from './frontend/operating-systems.js?v=20261015-map-admin2';
import { openAIProviders } from './frontend/ai-providers.js?v=20261015-map-admin2';
import { createAssistant } from './frontend/assistant.js?v=20261015-map-admin2';
import { createId, defaultPortSpeed, defaultPortType, esc, getPortInfo, getPortSpeed, getPortType, predefinedPortTypes, validateFormValues } from './frontend/utils.js?v=20261021-notes-board1';

    (() => {
      const KEY = 'stackroom.inventory.v1';
      let storeAvailable = false;
      let portfolio = { environments: [], activeEnvironmentId: null };
      let activeEnvironmentId = null;
      let data = emptyData();
      let operatingSystems = [];
      let currentUser = null;
      let mapLayout = 'elk';
      let saveQueue = Promise.resolve();
      let current = 'overview';
      let recordFormGeneration = 0;
      const rackRoomFilters = new Map();
      const assetColumnFilters = new Map();
      let permissionUsers = [];
      let permissionUserId = null;
      let permissionPage = 0;
      let permissionSearch = '';
      let permissionFilter = 'all';
      const permissionPending = new Set();
      let query = '';
      const columnVisibilityStorageKey = 'netory.visible-columns.v1';
      let columnVisibility = (() => {
        try {
          const saved = JSON.parse(localStorage.getItem(columnVisibilityStorageKey) || '{}');
          return saved && typeof saved === 'object' ? saved : {};
        } catch { return {}; }
      })();
      const view = document.getElementById('view');
      const loading = createLoadingIndicator();
      let renderGeneration = 0;
      const assistant = createAssistant({ apiRequest, getEnvironment: () => portfolio.environments.find(item => item.id === activeEnvironmentId), getUser: () => currentUser, onApplied: (id, result) => {
        const environment = portfolio.environments.find(item => item.id === id);
        if (environment) { environment.data = result.data; environment.revision = result.revision; }
        if (activeEnvironmentId === id) { data = { ...emptyData(), ...result.data }; render(); }
      } });
      const { renderNetworkMap, bindNetworkMapInteractions } = createNetworkMapRenderer({
        getLayoutMode: () => mapLayout, getData: () => data, allPortConnections, empty, esc, lagEndpointName, view, getPortSpeed, getPortType,
        canEdit: () => Boolean(currentUser?.is_admin || portfolio.environments.find(item => item.id === activeEnvironmentId)?.role === 'editor'),
        renderAfterPaint: loading.afterPaint, onRenderError: error => toast(error.message)
      });
      function networkInterfaceLabel(parent) {
        if (!parent) return 'Not assigned';
        if (parent.type === 'physical') {
          const device = data.assets.find(asset => asset.id === parent.deviceId);
          return `${device?.name || 'Missing device'} · Port ${parent.port}`;
        }
        const vlan = (data.vlans || []).find(vlan => vlan.id === parent.vlanId);
        const device = data.assets.find(asset => asset.id === vlan?.masterDeviceId);
        return vlan ? `VLAN ${vlan.idValue} · ${vlan.name}${device ? ` · ${device.name}` : ''}` : 'Missing VLAN';
      }

      async function apiRequest(path, options = {}) {
        const background = path.startsWith('/api/session/') || path.startsWith('/api/assistant/status');
        const finish = background ? () => {} : loading.begin(options.method && options.method !== 'GET' ? 'Working…' : 'Loading…');
        try {
          const response = await fetch(path, {
            credentials: 'same-origin',
            ...options,
            headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
          });
          if (!response.ok) {
            const body = await response.json().catch(() => ({}));
            const fallback = path === '/api/assistant/chat' && response.status === 504
              ? 'The assistant request timed out. Your question is preserved; try again or choose a faster model.'
              : t('message_0', {0: (response.status)});
            const error = new Error(typeof body.detail === 'string' ? body.detail : body.detail?.message || fallback);
            error.detail = body.detail;
            error.status = response.status;
            if (response.status === 401 && currentUser) showLogin('Your session expired. Please sign in again.');
            throw error;
          }
          return response.status === 204 ? null : await response.json();
        } finally { finish(); }
      }
      function applyRemoteState(state) {
        currentUser = state.user;
        mapLayout = state.mapLayout === 'physical' ? 'physical' : 'elk';
        setLanguage(currentUser.language || 'en');
        localizeShell();
        document.documentElement.dataset.theme = currentUser.theme || 'default';
        portfolio = { environments: state.environments || [], activeEnvironmentId: state.activeEnvironmentId || null };
        activeEnvironmentId = portfolio.activeEnvironmentId;
        const active = portfolio.environments.find(item => item.id === activeEnvironmentId);
        data = active ? { ...emptyData(), ...active.data } : emptyData();
        storeAvailable = true;
        document.querySelector('.shell').hidden = false;
        document.getElementById('auth-root').innerHTML = '';
        document.getElementById('logout-button').hidden = false;
        render();
      }
      function showLogin(message = '') {
        renderGeneration += 1;
        view.removeAttribute('aria-busy');
        currentUser = null;
        assistant.sync();
        document.getElementById('modal-root').innerHTML = '';
        portfolio = { environments: [], activeEnvironmentId: null };
        activeEnvironmentId = null;
        data = emptyData();
        document.querySelector('.shell').hidden = true;
        document.getElementById('logout-button').hidden = true;
        document.getElementById('auth-root').innerHTML = html`<div class="auth-screen"><form class="auth-panel" id="login-form"><div class="brand"><div class="brand-mark">N</div><div><div class="brand-name">[[netory]]</div><div class="brand-sub">[[it_asset_register]]</div></div></div><div class="eyebrow">[[secure_workspace]]</div><h1>[[sign_in]]</h1><p class="auth-error" id="login-error" role="alert">${esc(message)}</p><div class="field"><label for="login-username">[[username]]</label><input id="login-username" name="username" autocomplete="username" required autofocus></div><div class="field"><label for="login-password">[[password]]</label><input id="login-password" name="password" type="password" autocomplete="current-password" required></div><button class="button primary" type="submit">[[sign_in]]</button></form></div>`;
        document.getElementById('login-form').addEventListener('submit', async event => {
          event.preventDefault();
          const form = event.currentTarget;
          const submit = form.querySelector('[type="submit"]');
          submit.disabled = true;
          try {
            const values = Object.fromEntries(new FormData(form).entries());
            await apiRequest('/api/login', { method: 'POST', body: JSON.stringify(values) });
            await bootstrap();
          } catch (error) {
            document.getElementById('login-error').textContent = error.message;
            submit.disabled = false;
          }
        });
      }
      async function bootstrap() {
        try {
          let state = await apiRequest('/api/state');
          operatingSystems = await apiRequest('/api/operating-systems');
          if (!state.environments.length && state.user.is_admin) {
            try { state = await migrateBrowserData(state); }
            catch (error) { toast(t('message_1', {0: (error.message)})); }
          }
          applyRemoteState(state);
        } catch (error) {
          showLogin(error.status === 401 ? '' : error.message);
        }
      }
      async function migrateBrowserData(state) {
        let parsed;
        try { parsed = JSON.parse(localStorage.getItem(KEY) || 'null'); }
        catch (error) { toast(t("browser_data_could_not_be_read_it_has_not_been_changed")); return state; }
        if (!parsed) return state;
        const savedPortfolio = parsed.portfolio?.environments ? parsed.portfolio : parsed.environments ? parsed : null;
        const sourceEnvironments = savedPortfolio?.environments || [{ name: 'Default environment', data: parsed.data || parsed }];
        if (!sourceEnvironments.length || !confirm(t('message_2', {0: (sourceEnvironments.length)}))) return state;
        for (const source of sourceEnvironments) {
          const environment = await apiRequest('/api/environments', {
            method: 'POST', body: JSON.stringify({ name: source.name || 'Imported environment' })
          });
          const imported = { ...emptyData(), ...(source.data || {}) };
          const wrapper = { environments: [{ id: environment.id, name: environment.name, data: imported }] };
          normalizePortfolio(wrapper);
          await apiRequest(`/api/environments/${encodeURIComponent(environment.id)}/data`, {
            method: 'PUT', headers: { 'If-Match': String(environment.revision) }, body: JSON.stringify(wrapper.environments[0].data)
          });
        }
        return apiRequest('/api/state');
      }
      function save() {
        const active = portfolio.environments.find(item => item.id === activeEnvironmentId);
        if (!active) return Promise.resolve(false);
        active.data = data;
        const environmentId = active.id;
        const snapshot = structuredClone(data);
        saveQueue = saveQueue.catch(() => {}).then(async () => {
          const target = portfolio.environments.find(item => item.id === environmentId);
          if (!target) return;
          const path = `/api/environments/${encodeURIComponent(environmentId)}/data`;
          const options = {method: 'PUT', headers: {'If-Match': String(target.revision)}, body: JSON.stringify(snapshot)};
          const result = await saveWithOverlapConfirmation(apiRequest, path, options, confirm);
          if (result.data) {
            for (const section of ['vlans', 'lans', 'wlans']) {
              if (JSON.stringify(target.data[section]) === JSON.stringify(snapshot[section])) target.data[section] = result.data[section];
            }
          }
          if (result.networkWarnings) {
            for (const environment of portfolio.environments) {
              for (const section of ['lans', 'wlans']) {
                for (const network of environment.data[section] || []) network.overlaps = result.networkWarnings[environment.id]?.[network.id] || [];
              }
            }
          }
          target.revision = result.revision;
          storeAvailable = true;
          if (currentUser && activeEnvironmentId === environmentId) render();
          return true;
        }).catch(error => {
          storeAvailable = false;
          const status = document.querySelector('.side-bottom');
          if (status) status.textContent = t('message_3', {0: (error.message)});
          toast(t('message_4', {0: (error.message)}));
          return false;
        });
        return saveQueue;
      }
      function saveLicense(record, remove = false) {
        const active = portfolio.environments.find(item => item.id === activeEnvironmentId);
        if (!active) return Promise.reject(new Error(t("select_a_client_before_saving_a_license")));
        const environmentId = active.id;
        const url = `/api/environments/${encodeURIComponent(environmentId)}/licenses/${encodeURIComponent(record.id)}`;
        const operation = saveQueue.catch(() => {}).then(async () => {
          const target = portfolio.environments.find(item => item.id === environmentId);
          if (!target) throw new Error(t("the_selected_client_is_no_longer_available"));
          const result = await apiRequest(url, {
            method: remove ? 'DELETE' : 'PUT',
            headers: { 'If-Match': String(target.revision) },
            ...(remove ? {} : { body: JSON.stringify({
              product: record.product,
              vendor: record.vendor || null,
              license_key: record.licenseKey || null,
              type: record.type || null,
              seats: record.seats === '' ? null : Number(record.seats),
              assigned: record.assigned === '' ? null : Number(record.assigned),
              assigned_asset_ids: record.assignedAssetIds || [],
              expiry: record.expiry || null,
              owner: record.owner || null,
              notes: record.notes || null,
              net_price: record.netPrice || null,
              cost_estimate_id: record.costEstimateId || null
            }) })
          });
          target.revision = result?.revision || Number(target.revision) + 1;
          storeAvailable = true;
          return true;
        });
        saveQueue = operation.catch(error => {
          storeAvailable = false;
          const status = document.querySelector('.side-bottom');
          if (status) status.textContent = t('message_5', {0: (error.message)});
          toast(t('message_6', {0: (error.message)}));
          return false;
        });
        return operation;
      }
      function normalizePortfolio(targetPortfolio = portfolio) {
        let changed = false;
        targetPortfolio.environments.forEach(environment => {
          for (const section of ['lans', 'wlans', 'stacks', 'clusters', 'lags']) {
            if (!Array.isArray(environment.data[section])) {
              environment.data[section] = [];
              changed = true;
            }
          }
          if (!Array.isArray(environment.data.connections)) {
            environment.data.connections = [];
            changed = true;
          }
          for (const section of ['lans', 'wlans']) {
            if (!Array.isArray(environment.data[section])) {
              environment.data[section] = [];
              changed = true;
            }
          }
          (environment.data.assets || []).forEach(asset => {
            if (!Array.isArray(asset.internetPorts)) {
              asset.internetPorts = [];
              changed = true;
            }
          });
          (environment.data.vlans || []).forEach(vlan => {
            if (!vlan.masterDeviceId && Array.isArray(vlan.devices)) {
              vlan.masterDeviceId = vlan.devices[0] || '';
              changed = true;
            }
            if (Array.isArray(vlan.devices)) { delete vlan.devices; changed = true; }
          });
        });
        return changed;
      }
      const displayName = key => sections[key]?.label || key;
      const isAssetCategory = key => Object.hasOwn(assetCategoryTypes, key);
      const recordName = (section, row) => section === 'vlans' ? row.name : (row.name || row.product || row.username || 'Untitled');
      const fields = section => schemas[section];
      const valueFor = (section, row, key) => section === 'vlans' && key === 'id' ? row.idValue : row[key];
      function stackNameForAsset(assetId) {
        return (data.stacks || []).find(stack => (stack.memberAssetIds || []).includes(assetId))?.name || '';
      }
      function clusterForAsset(assetId) {
        return (data.clusters || []).find(cluster => (cluster.memberAssetIds || []).includes(assetId));
      }
      function clusterMemberControl(selectedIds = [], editingClusterId = '') {
        const selected = new Set(selectedIds);
        const available = data.assets.filter(asset => asset.type === 'Physical server' &&
          !(data.clusters || []).some(cluster => cluster.id !== editingClusterId &&
            (cluster.memberAssetIds || []).includes(asset.id)));
        return html`<select name="memberAssetIds" multiple size="${Math.min(8, Math.max(3, available.length))}" required>${available.map(asset =>
          html`<option value="${esc(asset.id)}" ${selected.has(asset.id) ? 'selected' : ''}>${esc(asset.name)}${asset.hostname ? ` (${esc(asset.hostname)})` : ''}</option>`
        ).join('')}</select><span class="secondary-cell">[[select_at_least_two_physical_servers_each_server_can_belong_to_one_cluster_and_remains_edi]]</span>`;
      }
      function lagConnections(lags = data.lags || []) {
        const membersFor = (lag, side) => {
          const members = lag[`members${side}`];
          if (Array.isArray(members)) return members;
          return (lag[`ports${side}`] || []).map(port => ({
            deviceId: lag[`device${side}Id`], port: Number(port)
          }));
        };
        return lags.flatMap(lag => membersFor(lag, 'A').map((memberA, index) => {
          const memberB = membersFor(lag, 'B')[index];
          if (!memberB) return null;
          return {
          id: `${lag.id}-member-${index + 1}`,
          lagId: lag.id,
          lagName: lag.name,
          deviceAId: memberA.deviceId,
          portA: Number(memberA.port),
          deviceBId: memberB.deviceId,
          portB: Number(memberB.port)
          };
        }).filter(Boolean));
      }
      function allPortConnections() {
        return [...(data.connections || []), ...lagConnections()];
      }
      function lagsForAsset(assetId) {
        return (data.lags || []).filter(lag => lagConnections([lag]).some(link =>
          link.deviceAId === assetId || link.deviceBId === assetId
        ));
      }
      function lagsForStack(stackId) {
        return (data.lags || []).filter(lag => lag.stackAId === stackId || lag.stackBId === stackId);
      }
      function lagEndpointName(lag, side) {
        const stackId = lag[`stack${side}Id`];
        if (stackId) return (data.stacks || []).find(stack => stack.id === stackId)?.name || 'Deleted stack';
        return data.assets.find(asset => asset.id === lag[`device${side}Id`])?.name || 'Deleted device';
      }
      function lagMemberTokens(lag, side) {
        const members = lag[`members${side}`];
        if (Array.isArray(members)) return members.map(member => `${member.deviceId}:${member.port}`);
        return (lag[`ports${side}`] || []).map(port => `${lag[`device${side}Id`]}:${port}`);
      }
      function selectedLagMembers(endpointId, tokens) {
        const endpoint = lagEndpoint(endpointId);
        if (!endpoint) return [];
        const memberOrder = new Map(endpoint.members.map((id, index) => [id, index]));
        return tokens.map(token => {
          const splitAt = token.lastIndexOf(':');
          return { deviceId: token.slice(0, splitAt), port: Number(token.slice(splitAt + 1)) };
        }).sort((left, right) =>
          (memberOrder.get(left.deviceId) ?? Number.MAX_SAFE_INTEGER) -
          (memberOrder.get(right.deviceId) ?? Number.MAX_SAFE_INTEGER) || left.port - right.port
        );
      }
      function stackMemberControl(deviceType, selectedIds = [], editingStackId = '') {
        const selected = new Set(selectedIds);
        const available = data.assets.filter(asset => {
          if (asset.type !== deviceType) return false;
          const existingStack = (data.stacks || []).find(stack =>
            stack.id !== editingStackId && (stack.memberAssetIds || []).includes(asset.id));
          return !existingStack || selected.has(asset.id);
        });
        const options = available.map(asset =>
          html`<option value="${esc(asset.id)}" ${selected.has(asset.id) ? 'selected' : ''}>${esc(asset.name)} — ${esc(asset.type)} · ${Number(asset.portCount) || 0} ports</option>`
        ).join('');
        const hint = available.length
          ? 'Select at least two unstacked devices of this type. Members stay editable in their device lists.'
          : 'Add at least two unstacked devices of this type before creating this stack.';
        return html`<select name="memberAssetIds" multiple size="${Math.min(8, Math.max(3, available.length))}" required>${options}</select><span class="secondary-cell">${hint}</span>`;
      }
      function lagEndpoints() {
        const devices = data.assets.filter(asset => Number(asset.portCount) > 0).map(asset => ({
          id: `asset:${asset.id}`, name: asset.name, type: asset.type
        }));
        const stacks = (data.stacks || []).map(stack => ({
          id: `stack:${stack.id}`, name: stack.name, type: `${stack.deviceType} stack`,
          members: stack.memberAssetIds || []
        })).filter(stack => stack.members.some(id => Number(data.assets.find(asset => asset.id === id)?.portCount) > 0));
        return [...devices, ...stacks];
      }
      function lagEndpoint(value) {
        const [kind, id] = String(value || '').split(/:(.*)/s, 2);
        if (kind === 'asset') {
          const asset = data.assets.find(item => item.id === id);
          return asset ? { id: value, members: [asset.id], stackId: '' } : null;
        }
        if (kind === 'stack') {
          const stack = (data.stacks || []).find(item => item.id === id);
          return stack ? { id: value, members: stack.memberAssetIds || [], stackId: stack.id } : null;
        }
        return null;
      }
      function lagDevicePicker(name, selectedId = '') {
        const endpoints = lagEndpoints();
        return html`<select name="${name}" data-lag-device><option value="">[[select_device_or_stack]]</option>${endpoints.map(endpoint =>
          html`<option value="${esc(endpoint.id)}" ${selectedId === endpoint.id ? 'selected' : ''}>${esc(endpoint.name)} — ${esc(endpoint.type)}</option>`
        ).join('')}</select>${endpoints.length < 2 ? html(["<span class=\"secondary-cell\">[[add_port_counts_to_at_least_two_devices_or_stacks_before_creating_a_lag]]</span>"]) : ''}`;
      }
      function lagPortPicker(side, endpointId, selectedTokens = [], editingLagId = '') {
        const endpoint = lagEndpoint(endpointId);
        if (!endpoint) return html`<div class="lag-port-picker" data-lag-ports="${side}"><span class="port-empty">[[select_a_device_or_stack_to_choose_its_lag_ports]]</span></div>`;
        const selected = new Set(selectedTokens);
        const occupied = new Set(allPortConnections().filter(link => link.lagId !== editingLagId).flatMap(link => [
          `${link.deviceAId}:${link.portA}`, `${link.deviceBId}:${link.portB}`
        ]));
        const groups = endpoint.members.flatMap(assetId => {
          const asset = data.assets.find(item => item.id === assetId);
          if (!asset) return [];
          const internetPorts = new Set((asset.internetPorts || []).map(Number));
          const availableCount = Array.from({ length: Number(asset.portCount) || 0 }, (_, index) => index + 1)
            .filter(port => !occupied.has(`${asset.id}:${port}`) && !internetPorts.has(port)).length;
          const options = Array.from({ length: Number(asset.portCount) || 0 }, (_, index) => {
            const port = index + 1;
            const token = `${asset.id}:${port}`;
            const internetConnected = internetPorts.has(port);
            const unavailable = !selected.has(token) && (occupied.has(token) || internetConnected);
            const status = internetConnected ? 'Connected to Internet' : 'Already connected';
            const portInfo = getPortInfo(asset, port);
            const details = `${portInfo.type} · ${portInfo.speed}`;
            return html`<label class="lag-port-option ${unavailable ? 'disabled' : ''}" title="${unavailable ? status : `Port ${port} (${esc(details)})`}"><input type="checkbox" name="ports${side}" value="${esc(token)}" aria-label="${esc(`${asset.name}, port ${port} (${details})${unavailable ? `, ${status}` : ''}`)}" ${selected.has(token) ? 'checked' : ''} ${unavailable ? 'disabled' : ''}><span class="lag-port-number">${port}</span></label>`;
          });
          return [html`<section class="lag-port-group" aria-label="${esc(asset.name)} ports"><div class="lag-port-group-head"><strong>${esc(asset.name)}</strong><span>${availableCount} free / ${Number(asset.portCount) || 0}</span></div><div class="lag-port-grid">${options.join('')}</div></section>`];
        });
        const selectedCount = selected.size;
        return html`<div class="lag-port-picker" data-lag-ports="${side}">${groups.join('')}<div class="lag-port-picker-foot"><span data-lag-port-count="${side}">${selectedCount} selected</span><span>[[gray_ports_are_already_assigned]]</span></div></div>`;
      }
      function portHasConnection(deviceId, port, exceptLagId = '') {
        if ((data.assets.find(asset => asset.id === deviceId)?.internetPorts || []).map(Number).includes(Number(port))) return true;
        return allPortConnections().some(link =>
          link.lagId !== exceptLagId &&
          (link.deviceAId === deviceId && Number(link.portA) === Number(port) ||
            link.deviceBId === deviceId && Number(link.portB) === Number(port))
        );
      }

      function renderNav() {
        const advancedKeys = ['rooms', 'racks', 'vlans', 'stacks', 'clusters', 'lags'];
        const otherKeys = ['computers', 'printers', 'monitors', 'ups', 'patchPanels', 'otherDevices'];
        const navButton = ([key, item]) => html`<button class="nav-item ${current === key ? 'active' : ''}" data-page="${key}"><span class="nav-icon">${item.icon}</span>${item.label}</button>`;
        const primary = Object.entries(sections).filter(([key]) =>
          !advancedKeys.includes(key) && !otherKeys.includes(key) && key !== 'settings' && key !== 'costEstimates' && key !== 'integrations'
        ).map(navButton).join('');
        const advanced = html`<details class="nav-advanced" id="advanced-navigation"><summary class="nav-item ${advancedKeys.includes(current) ? 'active' : ''}"><span class="nav-icon">⚙</span>[[advanced]]<span class="nav-chevron" aria-hidden="true">▾</span></summary><div class="nav-advanced-items" aria-label="[[advanced_categories]]"><div class="nav-advanced-panel">${advancedKeys.map(key => navButton([key, sections[key]])).join('')}</div></div></details>`;
        const other = html`<details class="nav-advanced" id="other-device-navigation"><summary class="nav-item ${otherKeys.includes(current) ? 'active' : ''}"><span class="nav-icon">◇</span>[[other_devices]]<span class="nav-chevron" aria-hidden="true">▾</span></summary><div class="nav-advanced-items" aria-label="[[other_device_categories]]"><div class="nav-advanced-panel">${otherKeys.map(key => navButton([key, sections[key]])).join('')}</div></div></details>`;
        document.getElementById('navigation').innerHTML = primary + other + advanced + navButton(['costEstimates', sections.costEstimates]) + navButton(['integrations', sections.integrations]) +
          (currentUser?.is_admin ? navButton(['settings', sections.settings]) : '');
        document.querySelectorAll('#navigation .nav-advanced').forEach(menu => {
        let closeTimer;
        menu.addEventListener('toggle', () => {
          if (menu.open) document.querySelectorAll('#navigation .nav-advanced').forEach(other => { if (other !== menu) other.open = false; });
          positionAdvancedMenu();
        });
        menu.addEventListener('pointerenter', event => {
          clearTimeout(closeTimer);
          if (event.pointerType === 'mouse') { menu.open = true; positionAdvancedMenu(); }
        });
        menu.addEventListener('pointerleave', event => {
          if (event.pointerType === 'mouse') closeTimer = setTimeout(() => {
            if (!menu.matches(':hover') && !menu.contains(document.activeElement)) menu.open = false;
          }, 180);
        });
        menu.addEventListener('focusout', event => {
          if (!menu.contains(event.relatedTarget) && !menu.matches(':hover')) menu.open = false;
        });
        menu.addEventListener('keydown', event => {
          if (event.key === 'Escape') {
            menu.open = false;
            menu.querySelector('summary').focus();
            event.preventDefault();
          }
        });
        });
      }
      function positionAdvancedMenu() {
        document.querySelectorAll('#navigation .nav-advanced[open]').forEach(menu => {
        const trigger = menu.querySelector('summary').getBoundingClientRect();
        const flyout = menu.querySelector('.nav-advanced-items');
        const mobile = window.innerWidth <= 600;
        const left = mobile ? trigger.left : trigger.right;
        flyout.style.left = `${Math.max(12, Math.min(left, window.innerWidth - flyout.offsetWidth - 12))}px`;
        flyout.style.top = `${Math.max(12, Math.min(mobile ? trigger.bottom : trigger.top, window.innerHeight - flyout.offsetHeight - 12))}px`;
        });
      }
      window.addEventListener('resize', positionAdvancedMenu);
      window.addEventListener('scroll', positionAdvancedMenu, true);
      function render() {
        const generation = ++renderGeneration;
        view.removeAttribute('aria-busy');
        assistant.sync();
        if (current === 'settings' && !currentUser?.is_admin) current = 'overview';
        renderNav();
        const active = portfolio.environments.find(item => item.id === activeEnvironmentId);
        const canEdit = Boolean(active && (currentUser?.is_admin || active.role === 'editor'));
        const environmentSelect = document.getElementById('environment-select');
        environmentSelect.innerHTML = portfolio.environments.map(item => html`<option value="${esc(item.id)}" ${item.id === activeEnvironmentId ? 'selected' : ''}>${esc(item.name)}</option>`).join('');
        document.querySelector('main')?.classList.toggle('map-page', current === 'networkMap');
        document.getElementById('page-title').textContent = displayName(current);
        const addLabels = { rooms: 'New room', racks: 'New cabinet', overview: 'Add asset', networkMap: 'Add asset', switches: 'Add switch', routers: 'Add router / firewall', wifi: 'Add Wi-Fi device', servers: 'Add server', clusters: 'Create cluster', storage: 'Add storage', computers: 'Add computer', printers: 'Add printer', monitors: 'Add monitor', ups: 'Add UPS', patchPanels: 'Add patch panel', otherDevices: 'Add device', vlans: 'Add VLAN', lans: 'Add network', wlans: 'Add WLAN', stacks: 'Create stack', lags: 'Create LAG', licenses: 'Add license', accounts: 'Add account' };
        document.getElementById('add-label').textContent = t(addLabels[current] || 'Add asset');
        document.getElementById('add-button').style.display = !canEdit || current === 'networkMap' || current === 'racks' || current === 'settings' || current === 'costEstimates' || current === 'integrations' || current === 'notesBoard' ? 'none' : '';
        document.querySelector('.environment-control').hidden = current === 'settings';
        document.getElementById('logout-button').hidden = false;
        if (current === 'settings') {
          view.innerHTML = renderAdministrationSettings();
          document.querySelector('.side-bottom').innerHTML = html`<span class="local-dot"></span>${esc(currentUser.username)}`;
          return;
        }
        if (!active) {
          view.innerHTML = currentUser?.is_admin
            ? html(["<section class=\"panel\"><div class=\"empty-state\"><strong>[[no_clients_configured_yet]]</strong><button class=\"button primary\" data-env-create>[[create_first_client]]</button></div></section>"])
            : html(["<section class=\"panel\"><div class=\"empty-state\"><strong>[[no_client_access_assigned]]</strong>[[ask_an_administrator_to_add_your_account_to_a_client]]</div></section>"]);
          document.querySelector('.side-bottom').innerHTML = html`<span class="local-dot"></span>${esc(currentUser?.username || 'Signed in')}`;
          return;
        }
        if (current === 'notesBoard') {
          const notesEnvironment = activeEnvironmentId;
          const notesUser = currentUser;
          renderNotesBoard({root: view, environmentId: notesEnvironment, canEdit, apiRequest,
            isCurrent: () => generation === renderGeneration && current === 'notesBoard' && activeEnvironmentId === notesEnvironment && currentUser === notesUser});
        } else if (current === 'integrations') {
          const integrationEnvironment = activeEnvironmentId;
          const integrationUser = currentUser;
          renderIntegrations({ root: view, environmentId: integrationEnvironment, canEdit, isAdmin: Boolean(currentUser?.is_admin), apiRequest,
            isCurrent: () => generation === renderGeneration && current === 'integrations' && activeEnvironmentId === integrationEnvironment && currentUser === integrationUser,
            onChanged: async () => {
              const result = await apiRequest(`/api/environments/${encodeURIComponent(integrationEnvironment)}/data`);
              if (currentUser !== integrationUser) return;
              const target = portfolio.environments.find(item => item.id === integrationEnvironment);
              if (target) { target.data = result.data; target.revision = result.revision; }
              if (activeEnvironmentId === integrationEnvironment) data = { ...emptyData(), ...result.data };
            }
          });
        } else if (current === 'costEstimates') {
          const costEnvironmentId = activeEnvironmentId;
          const costUser = currentUser;
          renderCostEstimates({root: view, environmentId: costEnvironmentId, canEdit, apiRequest, modalRoot: document.getElementById('modal-root'), closeModal, toast, onDeleted: result => { const target = portfolio.environments.find(item => item.id === costEnvironmentId); if (target) { target.data = result.data; target.revision = result.revision; } if (activeEnvironmentId === costEnvironmentId && currentUser === costUser) data = result.data; }, isCurrent: () => current === 'costEstimates' && activeEnvironmentId === costEnvironmentId && currentUser === costUser});
        } else if (current === 'networkMap') {
          view.setAttribute('aria-busy', 'true');
          view.innerHTML = html(["<section class=\"panel\"><div class=\"empty-state\">[[loading_network_map]]</div></section>"]);
          loading.afterPaint(() => {
            if (generation !== renderGeneration) return;
            try {
              view.innerHTML = renderNetworkMap();
              bindNetworkMapInteractions();
            } finally { view.removeAttribute('aria-busy'); }
          }).catch(error => {
            if (generation !== renderGeneration) return;
            console.error('Could not load the network map', error);
            view.innerHTML = html`<section class="panel"><div class="empty-state">[[could_not_load_the_network_map_open_it_again_to_retry]]<p>${esc(error.message || 'Unknown rendering error')}</p></div></section>`;
            toast(error.message);
          });
        } else {
          if (current === 'racks') {
            const selected = rackRoomFilters.get(activeEnvironmentId) || new Set();
            const validRooms = new Set(['', ...(data.rooms || []).map(room => room.id)]);
            for (const id of selected) if (!validRooms.has(id)) selected.delete(id);
            rackRoomFilters.set(activeEnvironmentId, selected);
            const filterOpen = view.querySelector('.rack-room-filter')?.open || false;
            view.innerHTML = renderRackView(data, canEdit, {roomIds: [...selected]});
            view.querySelector('.rack-room-filter').open = filterOpen;
            view.querySelectorAll('[data-map-room]').forEach(input => input.addEventListener('change', () => {
              if (input.checked) selected.add(input.dataset.mapRoom);
              else selected.delete(input.dataset.mapRoom);
              render();
            }));
            view.querySelector('[data-map-all-rooms]').addEventListener('click', () => {
              selected.clear();
              render();
            });
          } else {
            view.innerHTML = current === 'rooms' ? renderRooms(data, canEdit) : current === 'overview' ? renderOverview() : renderList(current);
            if (current === 'assets' || isAssetCategory(current)) {
              const filterScope = JSON.stringify([currentUser?.id, activeEnvironmentId, current]);
              if (!assetColumnFilters.has(filterScope)) assetColumnFilters.set(filterScope, new Map());
              bindAssetColumnFilters(view, assetColumnFilters.get(filterScope));
            }
          }
        }
        document.querySelector('.side-bottom').innerHTML = html`<span class="local-dot" style="background:${storeAvailable ? 'var(--lime)' : '#e6a46e'}"></span>${esc(currentUser?.username || 'Signed in')}`;
      }
      function renderAdministrationSettings() {
        return html`<div class="administration-settings"><section class="panel"><div class="panel-head"><div><div class="eyebrow">[[administration_settings]]</div><div class="panel-title">[[main_settings]]</div><div class="panel-sub">[[manage_accounts_client_environments_and_sign_in_security]]</div></div></div><div class="license-row"><div><div class="primary-cell">[[users_and_access]]</div><div class="secondary-cell">[[create_accounts_and_manage_their_access_to_client_environments]]</div></div><button class="button" data-user-manager>[[manage_users]]</button></div><div class="license-row"><div><div class="primary-cell">[[client_environments]]</div><div class="secondary-cell">[[create_rename_or_delete_client_environments]]</div></div><button class="button" data-environment-manager>[[manage_clients]]</button></div><div class="license-row"><div><div class="primary-cell">[[login_protection]]</div><div class="secondary-cell">[[configure_failed_login_limits_block_duration_and_global_protection]]</div></div><button class="button" data-login-protection>[[configure_login_protection]]</button></div><div class="license-row"><div><div class="primary-cell">[[network_map_layout]]</div><div class="secondary-cell">[[network_map_layout_description]]</div></div><button type="button" class="button" data-network-map-settings>[[configure_network_map_layout]]</button></div><div class="license-row"><div><div class="primary-cell">[[session_timeout]]</div><div class="secondary-cell">[[sign_users_out_after_a_period_of_inactivity]]</div></div><button class="button" data-session-timeout>[[configure_session_timeout]]</button></div><div class="license-row"><div><div class="primary-cell">[[activity_logs]]</div><div class="secondary-cell">[[review_actions_by_all_users_and_superadmins_and_configure_retention]]</div></div><button class="button" data-activity-logs>[[view_activity_logs]]</button></div><div class="license-row"><div><div class="primary-cell">[[ai_providers]]</div><div class="secondary-cell">[[manage_ai_connections_models_and_allowed_environments]]</div></div><button type="button" class="button" data-ai-providers>[[manage_ai_providers]]</button></div></section><section class="panel"><div class="panel-head"><div><div class="panel-title">[[assets_settings]]</div><div class="panel-sub">[[manage_shared_settings_for_inventory_assets]]</div></div></div><div class="license-row"><div><div class="primary-cell">[[operating_systems]]</div><div class="secondary-cell">[[manage_the_shared_os_list_families_and_end_of_life_dates]]</div></div><button class="button" data-os-manager>[[manage_operating_systems]]</button></div><div class="license-row"><div><div class="primary-cell">[[asset_trash]]</div><div class="secondary-cell">[[view_assets_deleted_by_users_and_superadmins_or_remove_them_permanently]]</div></div><button type="button" class="button" data-asset-trash>[[open_trash]]</button></div></section></div>`;
      }
      function renderOverview() {
        return renderDashboard(data, environmentDashboard(currentUser?.dashboard, activeEnvironmentId)) + (!storeAvailable ? html(["<p class=\"secondary-cell\">[[the_server_could_not_confirm_the_latest_save_changes_may_not_have_been_saved]]</p>"]) : '');
      }
      function daysUntil(date) {
        const now = new Date();
        const [year, month, day] = date.split('-').map(Number);
        return Math.round((Date.UTC(year, month - 1, day) - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000);
      }
      function empty(message) { return html`<div class="empty-state"><strong>${esc(message)}</strong>[[add_records_as_your_inventory_grows]]</div>`; }
      function renderList(section) {
        const assetCategory = assetCategoryTypes[section];
        const active = portfolio.environments.find(item => item.id === activeEnvironmentId);
        const canEdit = Boolean(currentUser?.is_admin || active?.role === 'editor');
        const assetList = section === 'assets' || Boolean(assetCategory);
        const source = assetList ? data.assets || [] : data[section] || [];
        const rows = source.filter(row =>
          (!assetCategory || assetCategory.includes(row.type)) &&
          `${JSON.stringify(Object.fromEntries(Object.entries(row).filter(([key]) => key !== 'wifiPassword')))} ${section === 'switches' || section === 'routers' ? `${stackNameForAsset(row.id)} ${lagsForAsset(row.id).map(lag => lag.name).join(' ')}` : ''}`.toLowerCase().includes(query.toLowerCase())
        );
        const deviceColumns = {
          computers: ['name', 'hostname', 'ip', 'cpu', 'ram', 'storage', 'os', 'location', 'status'],
          printers: ['name', 'hostname', 'ip', 'manufacturer', 'location', 'status'],
          patchPanels: ['name', 'manufacturer', 'portCount', 'location', 'status'],
          ups: ['name', 'manufacturer', 'upsRatedVA', 'upsRatedW', 'upsRuntimeMinutes', 'location', 'status'],
          monitors: ['name', 'manufacturer', 'serial', 'location', 'status'],
          otherDevices: ['name', 'type', 'deviceKind', 'manufacturer', 'serial', 'location', 'status'],
        };
        const defaultColumns = deviceColumns[section] || { assets: ['name', 'type', 'hostname', 'ip', 'portCount', 'cpu', 'ram', 'location', 'status'], clusters: ['name', 'memberAssetIds', 'showOnMap', 'location'], servers: ['name', 'type', 'clusterName', 'hostname', 'ip', 'portCount', 'cpu', 'ram', 'hypervisorId', 'location', 'status'], switches: ['name', 'type', 'stackName', 'lags', 'hostname', 'ip', 'portCount', 'location', 'status'], routers: ['name', 'type', 'stackName', 'lags', 'hostname', 'ip', 'portCount', 'location', 'status'], vlans: ['name', 'id', 'network', 'gateway', 'linkedNetworks', 'masterDeviceId', 'location', 'purpose'], lans: ['name', 'network', 'parentInterface', 'gateway', 'dnsServers', 'dhcp', 'vlanId', 'location', 'purpose'], wlans: ['name', 'ssid', 'parentDeviceId', 'security', 'network', 'vlanInterfaceId', 'location', 'purpose'], stacks: ['name', 'deviceType', 'memberAssetIds', 'lags'], lags: ['name', 'aggregationType', 'deviceAId', 'portsA', 'deviceBId', 'portsB'], licenses: ['product', 'vendor', 'type', 'seats', 'assigned', 'assignedAssetIds', 'expiry', 'owner'], hypervisors: ['name', 'platform', 'version', 'managementIp', 'cluster', 'location'], accounts: ['name', 'system', 'username', 'accountType', 'owner', 'vault', 'rotation'] }[section === 'servers' ? 'servers' : assetList ? (section === 'switches' || section === 'routers' ? section : 'assets') : section];
        const assetConfigurationColumns = {
          assets: ['name', 'type', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'cpu', 'ram', 'storage', 'os', 'hypervisorId', 'vlan', 'warrantyExpiry', 'notes'],
          switches: ['name', 'type', 'stackName', 'lags', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'vlan', 'os', 'warrantyExpiry', 'notes'],
          routers: ['name', 'type', 'stackName', 'lags', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'vlan', 'os', 'warrantyExpiry', 'notes'],
          wifi: ['name', 'type', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'vlan', 'os', 'warrantyExpiry', 'notes'],
          clusters: ['name', 'memberAssetIds', 'showOnMap', 'location', 'notes'],
          servers: ['name', 'type', 'clusterName', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'cpu', 'ram', 'storage', 'os', 'hypervisorId', 'vlan', 'warrantyExpiry', 'notes'],
          storage: ['name', 'type', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'storage', 'os', 'warrantyExpiry', 'notes'],
          computers: ['name', 'type', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'cpu', 'ram', 'storage', 'os', 'vlan', 'warrantyExpiry', 'notes'],
          printers: ['name', 'type', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'vlan', 'warrantyExpiry', 'notes'],
          patchPanels: ['name', 'type', 'status', 'manufacturer', 'serial', 'portCount', 'location', 'showOnMap', 'warrantyExpiry', 'notes'],
          ups: ['name', 'type', 'status', 'manufacturer', 'serial', 'location', 'ip', 'upsRatedVA', 'upsRatedW', 'upsRuntimeMinutes', 'upsBatteryCount', 'upsBatteryReplacementDate', 'warrantyExpiry', 'notes'],
          monitors: ['name', 'type', 'status', 'manufacturer', 'serial', 'location', 'warrantyExpiry', 'notes'],
          otherDevices: ['name', 'type', 'deviceKind', 'status', 'showOnMap', 'hostname', 'manufacturer', 'serial', 'location', 'ip', 'portCount', 'vlan', 'warrantyExpiry', 'notes']
        };
        for (const key of Object.keys(assetCategoryTypes)) {
          assetConfigurationColumns[key] = [...(assetConfigurationColumns[key] || []), 'backupPowerEnabled', 'backupUpsId'];
        }
        assetConfigurationColumns.servers.push('managementControllerEnabled', 'managementControllerType', 'managementControllerIp', 'managementControllerModel', 'managementControllerVlan');
        const recordConfigurationColumns = {
          vlans: ['name', 'id', 'network', 'gateway', 'linkedNetworks', 'masterDeviceId', 'location', 'purpose', 'notes'],
          lans: ['name', 'network', 'parentInterface', 'gateway', 'dnsServers', 'dhcp', 'vlanId', 'location', 'purpose', 'notes'],
          wlans: ['name', 'ssid', 'parentDeviceId', 'security', 'authServer', 'network', 'gateway', 'dnsServers', 'dhcp', 'vlanInterfaceId', 'vlanId', 'location', 'purpose', 'notes'],
          stacks: ['name', 'deviceType', 'memberAssetIds', 'lags', 'notes'],
          lags: ['name', 'aggregationType', 'deviceAId', 'portsA', 'deviceBId', 'portsB'],
          licenses: ['product', 'vendor', 'licenseKey', 'type', 'seats', 'assigned', 'assignedAssetIds', 'expiry', 'owner', 'notes'],
          hypervisors: ['name', 'platform', 'version', 'managementIp', 'cluster', 'location', 'capacity', 'notes'],
          accounts: ['name', 'system', 'username', 'accountType', 'owner', 'vault', 'rotation', 'notes']
        };
        const columns = [...new Set([...defaultColumns, ...(assetList ? assetConfigurationColumns[section] || assetConfigurationColumns.assets : recordConfigurationColumns[section] || [])])];
        const labels = { managementControllerEnabled: 'Management controller', managementControllerType: 'Controller type', managementControllerIp: 'Controller IP', managementControllerModel: 'Controller model', managementControllerVlan: 'Controller MGMT VLAN', backupPowerEnabled: 'Backup power', backupUpsId: 'Backup UPS', upsRatedVA: 'Rated power (VA)', upsRatedW: 'Rated power (W)', upsRuntimeMinutes: 'Runtime (min)', upsBatteryCount: 'Batteries', upsBatteryReplacementDate: 'Battery replacement', warrantyExpiry: 'Warranty expiry', deviceKind: 'Device kind', name: 'Name', id: 'VLAN ID', idValue: 'VLAN ID', product: 'Product', type: 'Type', deviceType: 'Device type', aggregationType: 'Aggregation type', clusterName: 'Server cluster', stackName: 'Device stack', memberAssetIds: 'Members', lags: 'LAGs', deviceAId: 'Device A', portsA: 'Ports A', deviceBId: 'Device B', portsB: 'Ports B', showOnMap: 'Show on map', hostname: 'Hostname', manufacturer: 'Manufacturer / model', serial: 'Serial number', ip: 'IP address', portCount: 'Ports', cpu: 'CPU', ram: 'RAM', storage: 'Storage', os: 'Operating system', hypervisorId: 'Hypervisor host or cluster', vlan: 'VLAN', location: 'Location', status: 'Status', network: 'Network / CIDR', gateway: 'Gateway', dnsServers: 'DNS servers', dhcp: 'DHCP', vlanId: 'VLAN ID', ssid: 'SSID', security: 'Security', authServer: 'Auth / RADIUS', masterDeviceId: 'Master device', purpose: 'Purpose', vendor: 'Vendor', licenseKey: 'License key / reference', seats: 'Seats', assigned: 'Used seats', assignedAssetIds: 'Assigned devices', expiry: 'Expiry', owner: 'Owner', platform: 'Platform', version: 'Version', managementIp: 'Management IP', cluster: 'Cluster', capacity: 'Capacity / notes', system: 'System', username: 'Username', accountType: 'Account type', vault: 'Vault reference', rotation: 'Last credential rotation', notes: 'Notes' };
        labels.vlan = 'MGMT VLAN';
        labels.parentDeviceId = 'Parent device';
        labels.vlanInterfaceId = 'VLAN';
        labels.parentInterface = 'Parent interface';
        labels.linkedNetworks = 'Linked networks';
        const savedColumns = Array.isArray(columnVisibility[section]) ? columnVisibility[section] : defaultColumns;
        const visibleColumns = columns.filter(key => savedColumns.includes(key));
        const cellValue = (row, key) => {
          if (key === 'os') return `${esc(row.os || '—')}${row.os ? html`<div class="secondary-cell">[[end_of_life]] ${esc(row.osEol || 'Not published / unknown')}</div>` : ''}`;
          if (key === 'name' && ['lans', 'wlans'].includes(section)) {
            const warnings = (row.overlaps || []).map(other => html`<div class="network-overlap-warning" role="note">⚠ ${esc(other.relation)} ${esc(other.name)}${other.network ? ` (${esc(other.network)})` : ''}</div>`).join('');
            return `${esc(row.name)}${warnings}`;
          }
          if (key === 'linkedNetworks') return (row.linkedNetworks || []).map(network => html`<div class="vlan-linked-network"><strong>${esc(network.name)}</strong><div>${esc(network.network || 'No CIDR')}${network.gateway ? ` · Gateway: ${esc(network.gateway)}` : ''}</div>${network.dnsServers ? html`<div>[[dns]] ${esc(network.dnsServers)}</div>` : ''}${network.dhcp ? html`<div>[[dhcp_7cf5bc]] ${esc(network.dhcp)}</div>` : ''}</div>`).join('') || '—';
          if (key === 'status') {
            const status = valueFor(section, row, key) || 'In service';
            const statusClass = { 'in service': 'in-service', maintenance: 'maintenance', planned: 'planned', retired: 'retired' }[String(status).trim().toLowerCase()] || 'unknown';
            return html`<span class="tag asset-status asset-status-${statusClass}">${esc(status)}</span>`;
          }
          if (key === 'showOnMap') return row.showOnMap ? 'Yes' : 'No';
          if (key === 'vlan') {
            const vlan = (data.vlans || []).find(item =>
              Number(item.idValue) === Number(row.vlan) && Number.isInteger(Number(row.vlan))
            );
            return esc(vlan ? `${vlan.idValue} — ${vlan.name}` : row.vlan || '—');
          }
          if (key === 'parentInterface') return esc(networkInterfaceLabel(row.parentInterface));
          if (key === 'vlanInterfaceId') return row.vlanInterfaceId ? esc(networkInterfaceLabel({type: 'vlan', vlanId: row.vlanInterfaceId})) : esc(row.vlanId || 'Not assigned');
          if (key === 'parentDeviceId') return deviceName(row.parentDeviceId);
          if (key === 'masterDeviceId') return deviceName(row.masterDeviceId);
          if (key === 'hypervisorId') return row.hypervisorClusterId
            ? esc((data.clusters || []).find(cluster => cluster.id === row.hypervisorClusterId)?.name || 'Deleted cluster') + html([" <span class=\"tag blue\">[[cluster]]</span>"])
            : serverName(row.hypervisorId);
          if (key === 'clusterName') {
            const cluster = clusterForAsset(row.id);
            return cluster ? html`<span class="tag blue">${esc(cluster.name)}</span>` : '—';
          }
          if (key === 'stackName') {
            const stackName = stackNameForAsset(row.id);
            return stackName ? html`<span class="tag blue">${esc(stackName)}</span>` : '—';
          }
          if (key === 'lags') {
            const groups = lagsForAsset(row.id).map(lag => {
              const side = lagMemberTokens(lag, 'A').some(token => token.startsWith(`${row.id}:`)) ? 'A' : 'B';
              const ports = lagMemberTokens(lag, side)
                .filter(token => token.startsWith(`${row.id}:`))
                .map(token => token.slice(token.lastIndexOf(':') + 1));
              return html`<span class="tag blue" title="Ports ${esc(ports.join(', '))}">${esc(lag.name)} · ${ports.length} ports</span>`;
            });
            return groups.join(' ') || '—';
          }
          if (key === 'deviceAId' || key === 'deviceBId') return section === 'lags'
            ? lagEndpointName(row, key === 'deviceAId' ? 'A' : 'B')
            : deviceName(row[key]);
          if (key === 'portsA' || key === 'portsB') return esc((row[key] || []).join(', '));
          if (key === 'lags' && section === 'stacks') {
            return lagsForStack(row.id).map(lag => html`<span class="tag blue">${esc(lag.name)}</span>`).join(' ') || '—';
          }
          if (key === 'managementControllerEnabled') return row.type === 'Physical server' ? t(row.managementControllerEnabled ? 'Yes' : 'No') : '—';
          if (key === 'backupPowerEnabled') return t(row.backupPowerEnabled ? 'Yes' : 'No');
          if (key === 'backupUpsId') return esc(data.assets.find(asset => asset.id === row.backupUpsId)?.name || '—');
          if (key === 'memberAssetIds') return esc((row.memberAssetIds || []).map(id => data.assets.find(asset => asset.id === id)?.name).filter(Boolean).join(', ') || '—');
          if (key === 'assignedAssetIds') return esc((row.assignedAssetIds || []).map(id => data.assets.find(asset => asset.id === id)?.name).filter(Boolean).join(', ') || '—');
          if (key === 'assigned' && section === 'licenses') return (Number(row.assigned) || 0) + (row.assignedAssetIds || []).length;
          if (key === 'type' && section === 'servers') return serverTypeCell(row.type);
          if (key === 'portCount') {
            const count = Number(row.portCount) || 0;
            if (!count) return '0';
            const typeCounts = {};
            for (let p = 1; p <= count; p += 1) {
              const info = getPortInfo(row, p);
              const label = `${info.type} · ${info.speed}`;
              typeCounts[label] = (typeCounts[label] || 0) + 1;
            }
            const breakdown = Object.entries(typeCounts).map(([t, c]) => `${c}× ${t}`).join(', ');
            return html`<span title="${esc(breakdown)}">${count}</span>`;
          }
          return esc(valueFor(section, row, key) || '—');
        };
        const columnPicker = html`<details class="column-picker"><summary class="button">[[view_columns]] <span aria-hidden="true">⌄</span></summary><div class="column-picker-menu">${columns.map(key => html`<label><input type="checkbox" data-column-visibility="${esc(key)}" data-column-section="${esc(section)}" ${visibleColumns.includes(key) ? 'checked' : ''}>${esc(t(labels[key] || key))}</label>`).join('')}</div></details>`;
        return html`<div class="list-toolbar"><input id="search-input" class="search" type="search" placeholder="${esc(t('Search {section}...', {section: displayName(section)}))}" value="${esc(query)}"><div class="list-toolbar-actions"><div class="count-label">${t('{count} records', {count: rows.length})}</div>${assetList ? html(["<button type=\"button\" class=\"button\" data-clear-asset-filters>[[clear_filters]]</button>"]) : ''}${columnPicker}</div></div>
            <section class="panel"><div class="table-wrap"><table ${assetList ? 'data-asset-filter-table' : ''}><thead><tr>${visibleColumns.map(key => html`<th ${assetList ? `data-asset-column="${esc(key)}"` : ''}>${t(labels[key] || key)}</th>`).join('')}<th></th></tr></thead><tbody>${rows.length ? rows.map(row => html`<tr ${assetList ? 'data-asset-row' : ''}>${visibleColumns.map(key => html`<td ${assetList ? `data-asset-cell="${esc(key)}"` : ''}>${cellValue(row, key)}</td>`).join('')}<td><div class="row-actions">${canEdit ? html`<button title="[[edit_record]]" data-edit="${esc(row.id)}">[[edit]]</button>${isAssetCategory(current) || current === 'assets' ? html`<button title="[[copy_asset]]" data-copy-asset="${esc(row.id)}">[[copy]]</button>` : ''}<button title="[[delete_record]]" data-delete="${esc(row.id)}">[[delete]]</button>` : ''}</div></td></tr>`).join('') : html`<tr><td colspan="${visibleColumns.length + 1}">${empty(rows.length ? t("no_matching_records") : t("no_records_in_this_section"))}</td></tr>`}</tbody></table></div></section>`;
      }
        function serverTypeCell(type) {
          if (type === 'Physical server') return html`<span class="server-type"><span class="server-kind-icon physical" role="img" aria-label="[[physical_server]]" title="[[physical_server]]"><i></i><i></i><i></i></span><span>[[physical_server]]</span></span>`;
          if (type === 'Virtual server') return html`<span class="server-type"><span class="server-kind-icon virtual" role="img" aria-label="[[virtual_machine]]" title="[[virtual_machine]]"></span><span>[[virtual_server]]</span></span>`;
          return esc(type || '—');
        }
      function deviceName(id) {
        return esc(data.assets.find(asset => asset.id === id)?.name || '—');
      }
      function serverName(id) {
        return esc(data.assets.find(asset => asset.id === id && asset.type === 'Physical server')?.name || '—');
      }
      function connectionForPort(assetId, portNumber) {
        const connection = allPortConnections().find(link =>
          (link.deviceAId === assetId && Number(link.portA) === portNumber) ||
          (link.deviceBId === assetId && Number(link.portB) === portNumber));
        if (!connection) return null;
        return connection.deviceAId === assetId
          ? { deviceId: connection.deviceBId, port: Number(connection.portB), lagId: connection.lagId, lagName: connection.lagName }
          : { deviceId: connection.deviceAId, port: Number(connection.portA), lagId: connection.lagId, lagName: connection.lagName };
      }
      function parsePortVlanConfig(untaggedValue, taggedValue) {
        const untaggedText = String(untaggedValue || '').trim();
        let untaggedVlan = null;
        if (!untaggedText || !/^\d+$/.test(untaggedText) || Number(untaggedText) < 1 || Number(untaggedText) > 4095) {
          return { error: 'Every port must have one untagged VLAN ID between 1 and 4095.' };
        }
        untaggedVlan = Number(untaggedText);
        const taggedText = String(taggedValue || '').trim();
        const taggedVlans = taggedText ? taggedText.split(',').map(value => value.trim()) : [];
        if (taggedVlans.some(value => !/^\d+$/.test(value) || Number(value) < 1 || Number(value) > 4095)) {
          return { error: 'Tagged VLANs must be comma-separated VLAN IDs between 1 and 4095.' };
        }
        const taggedNumbers = taggedVlans.map(Number);
        if (taggedNumbers.length !== new Set(taggedNumbers).size) {
          return { error: 'Each tagged VLAN can only be listed once.' };
        }
        if (untaggedVlan !== null && taggedNumbers.includes(untaggedVlan)) {
          return { error: 'A VLAN cannot be both tagged and untagged on the same port.' };
        }
        const configuredVlanIds = new Set((data.vlans || []).map(vlan => Number(vlan.idValue)));
        const missing = [untaggedVlan, ...taggedNumbers].filter(vlan => vlan !== null && !configuredVlanIds.has(vlan));
        if (missing.length) {
          return { error: t('message_7', {0: (missing.length === 1 ? '' : 's'), 1: ([...new Set(missing)].join(', '))}) };
        }
        return { value: { untaggedVlan, taggedVlans: taggedNumbers } };
      }
      function portsUsingVlan(vlanNumber) {
        const id = Number(vlanNumber);
        return (data.assets || []).flatMap(asset =>
          Object.entries(asset.portVlans || {}).flatMap(([port, config]) => {
            const taggedVlans = Array.isArray(config.taggedVlans) ? config.taggedVlans.map(Number) : [];
            return Number(config.untaggedVlan) === id || taggedVlans.includes(id)
              ? [{ assetName: asset.name, port }]
              : [];
          })
        );
      }
      const switchPortTemplates = [
        { name: '8 Gigabit + 2 10G SFP+ uplinks', portCount: 10, groups: [{ count: 8, type: 'Gigabit Ethernet' }, { count: 2, type: '10G SFP+' }] },
        { name: '8 multigig 2.5G + 2 10G SFP+ uplinks', portCount: 10, groups: [{ count: 8, type: '2.5G Ethernet' }, { count: 2, type: '10G SFP+' }] },
        { name: '16 Gigabit + 2 10G SFP+ uplinks', portCount: 18, groups: [{ count: 16, type: 'Gigabit Ethernet' }, { count: 2, type: '10G SFP+' }] },
        { name: '16 multigig 2.5G + 2 10G SFP+ uplinks', portCount: 18, groups: [{ count: 16, type: '2.5G Ethernet' }, { count: 2, type: '10G SFP+' }] },
        { name: '24 Gigabit + 2 10G SFP+ uplinks', portCount: 26, groups: [{ count: 24, type: 'Gigabit Ethernet' }, { count: 2, type: '10G SFP+' }] },
        { name: '24 Gigabit + 4 10G SFP+ uplinks', portCount: 28, groups: [{ count: 24, type: 'Gigabit Ethernet' }, { count: 4, type: '10G SFP+' }] },
        { name: '24 Gigabit + 2 25G SFP28 uplinks', portCount: 26, groups: [{ count: 24, type: 'Gigabit Ethernet' }, { count: 2, type: '25G SFP28' }] },
        { name: '48 Gigabit + 2 SFP+ uplinks', portCount: 50, groups: [{ count: 48, type: 'Gigabit Ethernet' }, { count: 2, type: '10G SFP+' }] },
        { name: '48 Gigabit + 4 10G Ethernet uplinks', portCount: 52, groups: [{ count: 48, type: 'Gigabit Ethernet' }, { count: 4, type: '10G Ethernet' }] },
        { name: '48 Gigabit + 4 SFP+ uplinks', portCount: 52, groups: [{ count: 48, type: 'Gigabit Ethernet' }, { count: 4, type: '10G SFP+' }] },
        { name: '48 Gigabit + 6 10G SFP+ uplinks', portCount: 54, groups: [{ count: 48, type: 'Gigabit Ethernet' }, { count: 6, type: '10G SFP+' }] },
        { name: '48 Gigabit + 4 40G QSFP+ uplinks', portCount: 52, groups: [{ count: 48, type: 'Gigabit Ethernet' }, { count: 4, type: '40G QSFP+' }] },
        { name: '48 Gigabit + 4 25G SFP28 uplinks', portCount: 52, groups: [{ count: 48, type: 'Gigabit Ethernet' }, { count: 4, type: '25G SFP28' }] },
        { name: '24 multigig 2.5G + 4 10G SFP+ uplinks', portCount: 28, groups: [{ count: 24, type: '2.5G Ethernet' }, { count: 4, type: '10G SFP+' }] },
        { name: '48 multigig 2.5G + 4 10G SFP+ uplinks', portCount: 52, groups: [{ count: 48, type: '2.5G Ethernet' }, { count: 4, type: '10G SFP+' }] },
        { name: '24 5G + 4 25G SFP28 uplinks', portCount: 28, groups: [{ count: 24, type: '5G Ethernet' }, { count: 4, type: '25G SFP28' }] },
        { name: '24 10G + 4 25G SFP28 uplinks', portCount: 28, groups: [{ count: 24, type: '10G Ethernet' }, { count: 4, type: '25G SFP28' }] },
        { name: '24 10G + 4 40G QSFP+ uplinks', portCount: 28, groups: [{ count: 24, type: '10G Ethernet' }, { count: 4, type: '40G QSFP+' }] },
        { name: '24 10G + 2 100G QSFP28 uplinks', portCount: 26, groups: [{ count: 24, type: '10G Ethernet' }, { count: 2, type: '100G QSFP28' }] },
        { name: '32 25G + 4 100G QSFP28 uplinks', portCount: 36, groups: [{ count: 32, type: '25G SFP28' }, { count: 4, type: '100G QSFP28' }] },
        { name: '32 10G + 4 100G QSFP28 uplinks', portCount: 36, groups: [{ count: 32, type: '10G Ethernet' }, { count: 4, type: '100G QSFP28' }] },
        { name: '48 10G + 6 40G QSFP+ uplinks', portCount: 54, groups: [{ count: 48, type: '10G Ethernet' }, { count: 6, type: '40G QSFP+' }] },
      ];
      function renderPortEditor(asset, portCount, draft = {}) {
        const patchPanel = asset?.type === 'Patch panel';
        const count = Math.max(0, Math.min(256, Number.parseInt(portCount, 10) || 0));
        if (!count && patchPanel) return html(["<div class=\"port-empty\">[[set_the_number_of_ports_above_to_configure_connections]]</div>"]);
        if (!count) return html(["<div class=\"port-empty\">[[set_the_number_of_ports_above_to_configure_port_types_speeds_and_connections]]</div>"]);
        const peers = asset?.id ? data.assets.filter(device => device.id !== asset.id) : [];
        const internetPorts = new Set((asset?.internetPorts || []).map(Number));
        const configuredVlans = [...(data.vlans || [])]
          .sort((first, second) => Number(first.idValue) - Number(second.idValue))
          .map(vlan => `${esc(vlan.idValue)} — ${esc(vlan.name)}`).join(', ');
        const portRows = Array.from({ length: count }, (_, index) => {
          const number = index + 1;
          const savedInfo = asset ? getPortInfo(asset, number) : { type: defaultPortType, speed: defaultPortSpeed };
          const currentType = draft[number]?.portType ?? savedInfo.type;
          const standardType = predefinedPortTypes.some(item => item.type === currentType);
          const selectedType = standardType ? currentType : 'Other';
          const customType = draft[number]?.customType ?? (standardType || currentType === 'Other' ? '' : currentType);
          const customSpeed = draft[number]?.customSpeed ?? savedInfo.speed;
          const typeSelectHtml = html`<div class="port-type-col"><span class="port-field-label">[[type]]</span><select id="port-type-${number}" name="port-type-${number}" class="port-type-select" aria-label="Port ${number} type">${predefinedPortTypes.map(item => html`<option value="${esc(item.type)}" ${selectedType === item.type ? 'selected' : ''}>${esc(item.type)}</option>`).join('')}<option value="Other" ${selectedType === 'Other' ? 'selected' : ''}>[[other]]</option></select><input name="port-custom-type-${number}" class="port-custom-type" type="text" placeholder="[[custom_type]]" value="${esc(customType)}" aria-label="Port ${number} custom type" ${selectedType === 'Other' ? '' : 'hidden'}></div>`;
          const selectedPreset = predefinedPortTypes.find(item => item.type === currentType);
          const speedContent = selectedPreset
            ? html`<span class="port-speed-fixed" data-port-speed-value="${esc(selectedPreset.speed)}">${esc(selectedPreset.speed)}</span>`
            : html`<input name="port-custom-speed-${number}" class="port-custom-type" type="text" placeholder="[[custom_speed]]" value="${esc(customSpeed)}" aria-label="Port ${number} custom speed">`;
          const speedSelectHtml = html`<div class="port-type-col port-speed-col" data-port-speed="${number}" data-custom-speed="${esc(customSpeed)}"><span class="port-field-label">[[speed]]</span>${speedContent}</div>`;
          const saved = asset?.id ? connectionForPort(asset.id, number) || {} : {};
          const selected = draft[number] || { ...saved, internet: internetPorts.has(number) };
          const selectedPeer = peers.find(device => device.id === selected.deviceId);
          const internetSelected = Boolean(selected.internet);
          const lagLocked = Boolean(selected.lagId);
          const connectionDisabled = !asset?.id;
          return html`<div class="port-row ${patchPanel ? 'patch-panel-port-row' : ''}"><strong>[[port]] ${number}</strong>${patchPanel ? '' : typeSelectHtml + speedSelectHtml}<select id="peer-device-${number}" name="peer-device-${number}" aria-label="Port ${number} connected device" ${connectionDisabled || internetSelected || lagLocked ? 'disabled' : ''}><option value="">${connectionDisabled ? t("save_device_first") : t("not_connected")}</option>${peers.map(device => html`<option value="${esc(device.id)}" ${selected.deviceId === device.id ? 'selected' : ''}>${esc(device.name)}</option>`).join('')}</select><span class="port-to">${lagLocked ? html`<span class="tag blue">${esc(selected.lagName)}</span>` : t("to_port")}</span><input aria-label="Remote port for local port ${number}" name="peer-port-${number}" type="number" min="1" ${selectedPeer?.portCount ? `max="${esc(selectedPeer.portCount)}"` : ''} value="${selected.deviceId && !internetSelected ? esc(selected.port || '') : ''}" ${connectionDisabled || !selected.deviceId || internetSelected || lagLocked ? 'disabled' : ''}><label class="port-internet" for="internet-port-${number}"><input id="internet-port-${number}" name="internet-port-${number}" type="checkbox" ${internetSelected ? 'checked' : ''} ${lagLocked ? 'disabled' : ''}>[[internet_31deec]]</label></div>`;
        }).join('');
        const vlanRows = Array.from({ length: count }, (_, index) => {
          const number = index + 1;
          const savedVlanConfig = asset?.portVlans?.[number] || asset?.portVlans?.[String(number)] || {};
          const untaggedVlan = draft[number]?.untaggedVlan ?? savedVlanConfig.untaggedVlan ?? 1;
          const taggedVlans = draft[number]?.taggedVlans ?? (savedVlanConfig.taggedVlans || []).join(', ');
          return html`<div class="port-vlan-row" data-port-number="${number}"><strong>[[port]] ${number}</strong><input id="port-untagged-vlan-${number}" name="port-untagged-vlan-${number}" data-port-vlan-input inputmode="numeric" aria-label="Port ${number} untagged VLAN ID" placeholder="[[one_vlan_id]]" value="${esc(untaggedVlan)}"><input id="port-tagged-vlans-${number}" name="port-tagged-vlans-${number}" data-port-vlan-input aria-label="Port ${number} tagged VLAN IDs" placeholder="[[for_example_10_20_30]]" value="${esc(taggedVlans)}"></div>`;
        }).join('');
        const portVlanPopup = html`<div class="port-vlan-popup" id="port-vlan-popup" hidden><section class="port-vlan-dialog" role="dialog" aria-modal="true" aria-labelledby="port-vlan-title"><div class="port-vlan-dialog-heading"><div><strong id="port-vlan-title">[[vlan_configuration]]</strong><span>[[configure_vlans_for_all]] ${count} ports. Tagged VLAN IDs are comma-separated.</span></div><button type="button" class="button icon-only" data-port-vlan-cancel aria-label="[[close_vlan_configuration]]">×</button></div><p class="form-error" data-port-vlan-error role="alert" hidden></p><div class="port-vlan-table"><div class="port-vlan-table-heading"><span>[[port]]</span><span>[[untagged_vlan_id]]</span><span>[[tagged_vlan_ids]]</span></div>${vlanRows}</div><p class="secondary-cell">[[only_vlan_ids_already_defined_in_the_vlans_configuration_can_be_assigned]]${configuredVlans ? t('message_8', {0: (configuredVlans)}) : t("no_vlans_are_configured_yet")}</p><div class="port-vlan-actions"><button type="button" class="button" data-port-vlan-cancel>[[cancel]]</button><button type="button" class="button primary" data-port-vlan-done>[[done]]</button></div></section></div>`;
        return html`<div class="port-editor"><section class="port-editor-section"><div class="port-editor-heading"><strong>[[port_configuration_and_connections]]</strong><span>${patchPanel ? t("connect_each_port_to_a_device_or_the_internet") : t("set_each_port_s_type_and_speed_connect_it_to_a_device_or_the_internet")}${asset?.id ? '' : ' Save this device before connecting ports.'}</span>${patchPanel ? '' : html(["<button type=\"button\" class=\"button port-vlan-button\" data-port-vlan-open>[[vlan_configuration]]</button>"])}</div><div class="port-list port-connection-list">${portRows}</div></section>${patchPanel ? '' : portVlanPopup}</div>`;
      }
      function collectPortConnections(asset, formData) {
        const count = Math.max(0, Math.min(256, Number.parseInt(formData.get('portCount'), 10) || 0));
        const invalidLagPort = lagConnections().find(link =>
          (link.deviceAId === asset.id && Number(link.portA) > count) ||
          (link.deviceBId === asset.id && Number(link.portB) > count)
        );
        if (invalidLagPort) return { error: t('message_9', {0: (invalidLagPort.deviceAId === asset.id ? invalidLagPort.portA : invalidLagPort.portB), 1: (invalidLagPort.lagName)}) };
        const remaining = (data.connections || []).filter(link => link.deviceAId !== asset.id && link.deviceBId !== asset.id);
        const occupied = new Set([
          ...remaining.flatMap(link => [`${link.deviceAId}:${link.portA}`, `${link.deviceBId}:${link.portB}`]),
          ...lagConnections().flatMap(link => [`${link.deviceAId}:${link.portA}`, `${link.deviceBId}:${link.portB}`])
        ]);
        const newTargets = new Set();
        const requested = [];
        const internetPorts = [];
        for (let port = 1; port <= count; port += 1) {
          const internet = formData.get(`internet-port-${port}`) === 'on';
          const peerId = formData.get(`peer-device-${port}`);
          const existingLink = connectionForPort(asset.id, port);
          if (existingLink?.lagId) {
            if (port > count) return { error: t('message_10', {0: (port), 1: (existingLink.lagName)}) };
            continue;
          }
          if (internet) {
            if (peerId) return { error: t('message_11', {0: (port)}) };
            internetPorts.push(port);
            continue;
          }
          if (!peerId) continue;
          const peerPort = Number(formData.get(`peer-port-${port}`));
          const peer = data.assets.find(device => device.id === peerId);
          if (!peer || peer.id === asset.id) return { error: t('message_12', {0: (port)}) };
          if (!Number.isInteger(peerPort) || peerPort < 1) return { error: t('message_13', {0: (peer.name), 1: (port)}) };
          if (!Number(peer.portCount)) return { error: t('message_14', {0: (peer.name)}) };
          if (peerPort > Number(peer.portCount)) return { error: t('message_15', {0: (peer.name), 1: (peer.portCount)}) };
          const targetKey = `${peer.id}:${peerPort}`;
          if (occupied.has(targetKey) || newTargets.has(targetKey)) return { error: t('message_16', {0: (peer.name), 1: (peerPort)}) };
          newTargets.add(targetKey);
          requested.push({ id: createId('link'), deviceAId: asset.id, portA: port, deviceBId: peer.id, portB: peerPort });
        }
        return { connections: [...remaining, ...requested], internetPorts };
      }
      async function openForm(section, existing = null, assetCategory = null, initialValues = {}) {
        const formGeneration = ++recordFormGeneration;
        const formPage = current;
        let costEstimates = [];
        if (section === 'assets' || section === 'licenses') {
          const formEnvironment = activeEnvironmentId;
          const formUser = currentUser;
          try { costEstimates = await apiRequest(`/api/environments/${encodeURIComponent(formEnvironment)}/cost-estimates?catalog=true`); }
          catch (error) { toast(error.message); return; }
          if (activeEnvironmentId !== formEnvironment || currentUser !== formUser || current !== formPage || formGeneration !== recordFormGeneration) return;
        }
        if (section === 'assets' && !assetCategory && existing) {
          assetCategory = Object.entries(assetCategoryTypes).find(([, types]) => types.includes(existing.type))?.[0] || null;
        }
        const assetType = initialValues.type || existing?.type || assetCategoryDefaults[assetCategory];
        const spec = section === 'assets' ? assetFields(assetCategory, assetType, Boolean(initialValues.portCount || existing?.portCount || existing?.ip || existing?.vlan)) : fields(section);
        const assetItemNames = { switches: 'switch', routers: 'router / firewall', wifi: 'Wi-Fi device', servers: 'server', storage: 'storage item', computers: 'computer', printers: 'printer', monitors: 'monitor', ups: 'UPS', patchPanels: 'patch panel', otherDevices: 'other device' };
        const itemName = section === 'accounts' ? 'special account' : section === 'vlans' ? 'VLAN' : section === 'lans' ? 'network' : section === 'wlans' ? 'WLAN' : section === 'lags' ? 'LAG' : section === 'clusters' ? 'server cluster' : section === 'assets' ? (assetItemNames[assetCategory] || 'asset') : section.slice(0, -1);
        const title = t('{action} {item}', {action: t(existing ? 'Edit' : 'Add'), item: t(itemName)});
        const controls = spec.map(([key, label, type, required, options]) => {
          const currentValue = initialValues[key] !== undefined ? initialValues[key] : existing
            ? key === 'showOnMap' && existing.type === 'Virtual server' && existing.showOnMap === undefined
              ? true
              : key === 'aggregationType' ? valueFor(section, existing, key) || 'Static'
                : valueFor(section, existing, key) || ''
            : key === 'showOnMap' && section === 'clusters' ? true
              : key === 'status' ? 'In service'
              : key === 'aggregationType' ? 'Static'
              : key === 'type' && assetCategory ? assetCategoryDefaults[assetCategory]
                : '';
          const requiredAttr = required && section !== 'lags' ? 'required' : '';
          if (type === 'checkbox') {
            return html`<div data-device-field="${key}" class="field checkbox-field map-visibility-field"><label><input name="${key}" type="checkbox" ${currentValue ? 'checked' : ''}><span>${esc(t(label))}</span></label><span class="secondary-cell">${section === 'clusters' ? t("show_this_cluster_and_its_members_even_without_network_connections") : section === 'assets' && existing?.type === 'Virtual server' ? t("show_this_virtual_machine_on_the_network_map") : t("show_this_asset_even_when_it_has_no_network_connections")}</span></div>`;
          }
          let control;
          if (type === 'power-settings') control = powerSupplyFields({...(existing || {}), ...initialValues}, data.assets);
          else if (type === 'management-controller') control = managementControllerFields({...existing, ...initialValues}, data.vlans || []);
          else if (type === 'rack-settings') control = rackAssetFields({ ...(existing || {}), ...initialValues, type: assetType }, data.racks || []);
          else if (type === 'os-picker') control = osPicker({ ...(existing || {}), ...initialValues }, operatingSystems);
          else if (type === 'select') control = html`<select name="${key}" ${requiredAttr}><option value="">[[select]]</option>${options.map(option => html`<option value="${esc(option)}" ${currentValue === option ? 'selected' : ''}>${esc(t(option))}</option>`).join('')}</select>`;
          else if (type === 'password') control = html`<input id="wlan-password" name="${key}" type="password" value="${esc(currentValue)}" maxlength="1024" autocomplete="new-password"><button type="button" data-toggle-wlan-password aria-controls="wlan-password" aria-pressed="false">[[show_password]]</button><span class="secondary-cell">[[encrypted_in_the_database_clear_this_field_to_remove_the_saved_password]]</span>`;
          else if (type === 'textarea') control = html`<textarea name="${key}" placeholder="${key === 'dhcp' ? t('192.168.1.20-192.168.1.100 or DHCP server IP') : t('Add context for your team')}">${esc(currentValue)}</textarea>${key === 'dhcp' ? html(["<span class=\"secondary-cell\">[[enter_one_server_ip_or_one_start_end_range_the_range_must_stay_inside_the_subnet_and_exclu]]</span>"]) : ''}`;
          else if (type === 'ports-editor') control = html`<div id="ports-editor">${renderPortEditor({ ...(existing || initialValues), type: assetType }, initialValues.portCount || existing?.portCount || 0, initialValues.portDraft || {})}</div>`;
          else if (type === 'lag-device-picker') {
            const side = key.includes('A') ? 'A' : 'B';
            const endpointId = existing
              ? existing[`endpoint${side}Id`] || `${existing[`stack${side}Id`] ? 'stack' : 'asset'}:${existing[`stack${side}Id`] || existing[`device${side}Id`]}`
              : '';
            control = lagDevicePicker(key, endpointId);
          }
          else if (type === 'lag-ports') {
            const side = key.includes('A') ? 'A' : 'B';
            const endpointId = existing
              ? existing[`endpoint${side}Id`] || `${existing[`stack${side}Id`] ? 'stack' : 'asset'}:${existing[`stack${side}Id`] || existing[`device${side}Id`]}`
              : '';
            control = lagPortPicker(side, endpointId, existing ? lagMemberTokens(existing, side) : [], existing?.id || '');
          }
          else if (type === 'cluster-members') control = clusterMemberControl(existing?.memberAssetIds || [], existing?.id || '');
          else if (type === 'stack-members') control = stackMemberControl(
            existing?.deviceType || '', existing?.memberAssetIds || [], existing?.id || ''
          );
          else if (type === 'network-interface-picker') {
            const selected = existing?.parentInterface;
            const option = parent => html`<option value="${esc(JSON.stringify(parent))}" ${selected?.type === parent.type && (parent.type === 'physical' ? selected.deviceId === parent.deviceId && selected.port === parent.port : selected.vlanId === parent.vlanId) ? 'selected' : ''}>${esc(networkInterfaceLabel(parent))}</option>`;
            const physical = data.assets.flatMap(asset => Array.from({length: Number(asset.portCount) || 0}, (_, index) => option({type: 'physical', deviceId: asset.id, port: index + 1}))).join('');
            const vlans = (data.vlans || []).map(vlan => option({type: 'vlan', vlanId: vlan.id})).join('');
            control = html`<select name="parentInterface"><option value="">[[not_assigned]]</option><optgroup label="Physical interfaces">${physical}</optgroup><optgroup label="VLAN interfaces">${vlans}</optgroup></select><span class="secondary-cell">[[choose_a_physical_device_port_or_a_configured_vlan_interface_add_devices_and_vlans_first_f]]</span>`;
          }
          else if (type === 'wlan-device-picker') {
            control = html`<select name="parentDeviceId"><option value="">[[not_assigned]]</option>${data.assets.filter(asset => networkDeviceTypes.includes(asset.type)).map(asset => html`<option value="${esc(asset.id)}" ${currentValue === asset.id ? 'selected' : ''}>${esc(asset.name)} · ${esc(asset.type)}</option>`).join('')}</select>`;
          }
          else if (type === 'wlan-vlan-picker') {
            control = html`<select name="vlanInterfaceId"><option value="">[[not_assigned]]</option>${(data.vlans || []).map(vlan => html`<option value="${esc(vlan.id)}" ${currentValue === vlan.id ? 'selected' : ''}>${esc(vlan.idValue)} · ${esc(vlan.name)}${vlan.masterDeviceId ? ` · ${esc(data.assets.find(asset => asset.id === vlan.masterDeviceId)?.name || '')}` : ''}</option>`).join('')}</select><span class="secondary-cell">[[choose_an_existing_vlan_its_network_and_gateway_are_used_when_configured]]</span>`;
          }
          else if (type === 'device-picker') {
            const devices = data.assets.filter(asset => networkDeviceTypes.includes(asset.type));
            const options = html`<label class="asset-option"><input type="radio" name="masterDeviceId" value="" ${(existing?.masterDeviceId || existing?.devices?.[0] || '') === '' ? 'checked' : ''}><span>[[not_assigned]]</span></label>`;
            control = html`<div class="asset-picker"><div class="secondary-cell" style="padding:6px 0">[[choose_the_device_responsible_for_this_vlan_usually_a_router_firewall_or_utm]]</div>${devices.length ? options + devices.map(asset => html`<label class="asset-option"><input type="radio" name="masterDeviceId" value="${esc(asset.id)}" ${(existing?.masterDeviceId || existing?.devices?.[0]) === asset.id ? 'checked' : ''}><span>${esc(asset.name)} <span class="secondary-cell">${esc(asset.type)}${asset.hostname ? ` · ${esc(asset.hostname)}` : ''}</span></span></label>`).join('') : html(["<div class=\"asset-picker-empty\">[[no_network_devices_yet_add_them_under_switches_routers_firewalls_or_wi_fi_first]]</div>"])}</div>`;
          }
          else if (type === 'management-vlan-picker' || type === 'existing-vlan-number-picker') {
            const vlanOptions = new Map();
            (data.vlans || []).forEach(vlan => {
              const number = Number(vlan.idValue);
              if (!Number.isInteger(number) || number < 1 || number > 4095) return;
              const id = String(number);
              const names = vlanOptions.get(id) || new Set();
              if (vlan.name) names.add(vlan.name);
              vlanOptions.set(id, names);
            });
            const legacyValue = String(currentValue ?? '').trim();
            const legacyId = Number(legacyValue);
            const legacyIsConfigured = Number.isInteger(legacyId) && vlanOptions.has(String(legacyId));
            const legacyOption = type === 'management-vlan-picker' && legacyValue && !legacyIsConfigured
              ? html`<option value="${esc(currentValue)}" selected>[[current_value]] ${esc(currentValue)} (not a configured VLAN)</option>`
              : '';
            const options = [...vlanOptions.entries()]
              .sort(([first], [second]) => Number(first) - Number(second))
              .map(([id, names]) => html`<option value="${id}" ${String(legacyId) === id ? 'selected' : ''}>${id} — ${esc([...names].join(', ') || 'VLAN')}</option>`)
              .join('');
            control = html`<select name="${key}"><option value="">[[not_assigned]]</option>${legacyOption}${options}</select><span class="secondary-cell">[[choose_a_configured_vlan_for_this_device_s_management_interface]]</span>`;
          }
          else if (type === 'server-picker') {
            const servers = data.assets.filter(asset => asset.type === 'Physical server' && asset.id !== existing?.id);
            const selectedHost = initialValues.hypervisorId !== undefined ? currentValue
              : existing?.hypervisorClusterId ? `cluster:${existing.hypervisorClusterId}` : currentValue;
            control = html`<select name="hypervisorId"><option value="">[[not_assigned]]</option><optgroup label="Physical hosts">${servers.map(server => html`<option value="${esc(server.id)}" ${selectedHost === server.id ? 'selected' : ''}>${esc(server.name)}${server.hostname ? ` (${esc(server.hostname)})` : ''}</option>`).join('')}</optgroup><optgroup label="Server clusters">${(data.clusters || []).map(cluster => html`<option value="cluster:${esc(cluster.id)}" ${selectedHost === `cluster:${cluster.id}` ? 'selected' : ''}>${esc(cluster.name)} (${(cluster.memberAssetIds || []).length} hosts)</option>`).join('')}</optgroup></select><span class="secondary-cell">[[choose_the_physical_host_or_cluster_running_this_virtual_machine]]</span>`;
          }
          else {
            const vlanBounds = (section === 'vlans' && key === 'id') || (['lans', 'wlans'].includes(section) && key === 'vlanId') ? 'min="1" max="4095" step="1"' : '';
            const licenseSeatBounds = section === 'licenses' && ['seats', 'assigned'].includes(key) ? 'min="0" step="1"' : '';
            const placeholder = ['ip', 'gateway', 'managementIp'].includes(key) ? 'placeholder="IPv4 or IPv6 address"' : key === 'network' ? 'placeholder="IPv4 or IPv6 CIDR"' : '';
            control = html`<input name="${key}" type="${type}" value="${esc(currentValue)}" ${requiredAttr} ${key.startsWith('ups') ? 'min="0" step="1"' : key === 'portCount' ? 'min="0" max="256" step="1"' : licenseSeatBounds || vlanBounds} ${placeholder} ${key === 'deviceKind' ? 'maxlength="120" placeholder="Keyboard, mouse, scanner…"' : key === 'licenseKey' ? 'autocomplete="off"' : ''}>`;
            if (section === 'assets' && key === 'portCount' && !existing) {
              control += html`<div class="switch-template-picker" ${assetCategory === 'switches' ? '' : 'hidden'}><select name="switchPortTemplate" aria-label="[[switch_port_template]]"><option value="">[[choose_a_port_template]]</option>${switchPortTemplates.map((template, index) => html`<option value="${index}">${esc(template.name)}</option>`).join('')}</select><span class="secondary-cell">[[selecting_a_template_sets_the_port_count_and_assigns_types_and_speeds_you_can_still_adjust]]</span></div>`;
            }
          }
          if (type === 'power-settings' || type === 'rack-settings' || type === 'management-controller') return control;
          const virtualOnly = type === 'server-picker';
          const fullWidth = ['textarea', 'device-picker', 'server-picker', 'ports-editor', 'stack-members', 'cluster-members', 'lag-ports'].includes(type);
          return html`<div data-device-field="${key}" class="field ${fullWidth ? 'full' : ''}" ${virtualOnly ? 'data-virtual-only hidden' : ''}><label>${esc(t(label))}${required ? ' *' : ''}</label>${control}${virtualOnly && !(data.clusters || []).length && !data.assets.some(asset => asset.type === 'Physical server' && asset.id !== existing?.id) ? html(["<div class=\"secondary-cell\">[[add_physical_servers_or_create_a_server_cluster_to_select_a_hypervisor]]</div>"]) : ''}</div>`;
        }).join('');
        const assignedDevices = section === 'licenses' ? data.assets : [];
        const assignedDeviceIds = new Set(existing?.assignedAssetIds || []);
        const licenseAssignmentControl = section === 'licenses' ? html`<div class="field full"><label for="license-assigned-assets">[[assign_to_devices]]</label>${assignedDevices.length ? html`<select id="license-assigned-assets" name="assignedAssetIds" multiple size="${Math.min(6, Math.max(3, assignedDevices.length))}">${assignedDevices.map(asset => html`<option value="${esc(asset.id)}" ${assignedDeviceIds.has(asset.id) ? 'selected' : ''}>${esc(asset.name)} — ${esc(asset.type)}</option>`).join('')}</select>` : html(["<div class=\"asset-picker-empty\">[[add_a_device_to_this_client_before_assigning_it_a_license]]</div>"])}<span class="secondary-cell">[[select_devices_that_use_this_license_each_device_uses_one_seat_use_ctrl_click_command_clic]]</span></div>` : '';
        const networkHelp = section === 'vlans' ? html(["<p class=\"secondary-cell\" style=\"margin-top:14px\">[[entering_a_network_cidr_creates_or_updates_its_linked_network_in_networks_new_network_name]]</p>"]) : section === 'lans' ? html(["<p class=\"secondary-cell\" style=\"margin-top:14px\">[[address_ranges_are_checked_within_this_environment_before_saving_vlan_parents_also_show_th]]</p>"]) : section === 'wlans' ? html(["<p class=\"secondary-cell\" style=\"margin-top:14px\">[[wi_fi_passwords_are_encrypted_in_the_database_and_available_to_users_with_access_to_this_e]]</p>"]) : '';
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal ${section === 'assets' ? 'asset-modal' : ''}" id="record-form"><div class="modal-head"><div><div class="eyebrow">${displayName(assetCategory || section)}</div><h2>${t(title)}</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="form-error" role="alert" hidden></p><div class="form-grid">${controls}${licenseAssignmentControl}${["assets", "licenses"].includes(section) ? costPricingFields(section, {...(existing || {}), ...initialValues}, costEstimates) : ""}</div>${section === 'lags' ? html(["<p class=\"secondary-cell\" style=\"margin-top:14px\">[[select_at_least_two_free_ports_on_each_side_using_the_same_number_on_both_devices_ports_pa]]</p>"]) : networkHelp}</div><div class="modal-foot"><button type="button" class="button" data-close>[[cancel]]</button><button type="submit" class="button primary">${existing ? t("save_changes") : section === 'lags' ? t("create_lag") : t("add_record")}</button></div></form></div>`;
        if (section === 'wlans') {
          const form = document.getElementById('record-form');
          const picker = form.querySelector('[name="vlanInterfaceId"]');
          const network = form.querySelector('[name="network"]');
          const gateway = form.querySelector('[name="gateway"]');
          const applyVlan = event => {
            const vlan = (data.vlans || []).find(vlan => vlan.id === picker.value);
            const wasInherited = network.readOnly;
            network.readOnly = Boolean(vlan?.network);
            gateway.readOnly = Boolean(vlan?.network && vlan.gateway);
            if (vlan?.network) { network.value = vlan.network; gateway.value = vlan.gateway || ''; }
            else if (event || wasInherited) { network.value = ''; gateway.value = ''; }
          };
          picker.addEventListener('change', applyVlan);
          applyVlan();
        }
        if (section === 'assets') {
          const form = document.getElementById('record-form');
          const grid = form.querySelector('.modal-body > .form-grid');
          const fields = [...grid.children];
          const groups = [
            ['Device details', ['name', 'type', 'deviceKind', 'hostname', 'ip', 'manufacturer', 'serial', 'cpu', 'ram', 'storage', 'os', 'hypervisorId']],
            ['Remote management', ['managementController']],
            ['Status and cost planning', ['status', 'warrantyExpiry']],
            ['Network and ports', ['vlan', 'showOnMap', 'portCount', 'ports']],
            ['Location and power', ['location', 'rackSettings', 'powerSettings', 'upsRatedVA', 'upsRatedW', 'upsRuntimeMinutes', 'upsBatteryCount', 'upsBatteryReplacementDate']],
            ['Notes', ['notes']]
          ];
          for (const [title, keys] of groups) {
            const members = keys.flatMap(key => fields.filter(field => field.dataset.deviceField === key || (key === 'rackSettings' && field.hasAttribute('data-rack-settings')) || (key === 'powerSettings' && field.hasAttribute('data-power-settings')) || (key === 'managementController' && field.hasAttribute('data-management-controller'))));
            if (!members.length) continue;
            const container = document.createElement('fieldset');
            container.className = 'device-settings-group';
            const legend = document.createElement('legend');
            legend.textContent = title;
            const content = document.createElement('div');
            content.className = 'form-grid';
            container.append(legend, content);
            grid.append(container);
            members.forEach(field => content.append(field));
          }
          const statusField = form.querySelector('[name="status"]')?.closest('.field');
          const pricingFields = form.querySelector('[data-cost-pricing]');
          if (statusField && pricingFields) statusField.after(pricingFields);
        }
        bindCostPricing(document.getElementById('record-form'), section);
        document.querySelector('[data-toggle-wlan-password]')?.addEventListener('click', event => {
          const input = document.getElementById('wlan-password');
          const show = input.type === 'password';
          input.type = show ? 'text' : 'password';
          event.currentTarget.textContent = show ? 'Hide password' : 'Show password';
          event.currentTarget.setAttribute('aria-pressed', String(show));
        });
        document.getElementById('record-form').addEventListener('submit', async event => {
          event.preventDefault();
          const formData = new FormData(event.currentTarget);
          const values = Object.fromEntries(formData.entries());
          let duplicateMessage = validateFormValues(section, values);
          if (section === 'licenses') {
            const seats = Number(values.seats);
            const otherAssigned = Number(values.assigned) || 0;
            const assignedCount = formData.getAll('assignedAssetIds').length;
            if ((values.seats && (!Number.isInteger(seats) || seats < 0)) || !Number.isInteger(otherAssigned) || otherAssigned < 0) {
              duplicateMessage = 'Seat counts must be whole numbers greater than or equal to zero.';
            } else if (values.seats && otherAssigned + assignedCount > seats) {
              duplicateMessage = t('message_17', {0: (seats), 1: (otherAssigned + assignedCount)});
            }
          }
          if (section === 'assets') {
            const name = values.name.trim().toLocaleLowerCase();
            const duplicate = data.assets.some(asset => asset.id !== existing?.id && asset.name?.trim().toLocaleLowerCase() === name);
            if (duplicate) duplicateMessage = t('message_18', {0: (values.name.trim())});
          }
          if (section === 'vlans') {
            const vlanId = String(Number(values.id));
            const masterDeviceId = values.masterDeviceId || '';
            const duplicate = data.vlans.some(vlan =>
              vlan.id !== existing?.id &&
              String(Number(vlan.idValue ?? vlan.id)) === vlanId &&
              (vlan.masterDeviceId || '') === masterDeviceId
            );
            if (duplicate) duplicateMessage = t('message_19', {0: (values.id)});
            if (existing?.isDefault && Number(values.id) !== 1) {
              duplicateMessage = 'The predefined VLAN 1 cannot be renumbered.';
            }
            if (existing?.isDefault && values.masterDeviceId) {
              duplicateMessage = 'The predefined VLAN 1 cannot be assigned to a master device.';
            }
            const assignedPorts = existing && Number(existing.idValue ?? existing.id) !== Number(values.id)
              ? portsUsingVlan(existing.idValue ?? existing.id)
              : [];
            if (assignedPorts.length) {
              const locations = assignedPorts.slice(0, 3).map(item => `${item.assetName} port ${item.port}`).join(', ');
              duplicateMessage = t('message_20', {0: (existing.idValue), 1: (locations), 2: (assignedPorts.length > 3 ? ', and other ports' : '')});
            }
          }
          if (section === 'clusters') {
            const name = values.name.trim().toLocaleLowerCase();
            if ((data.clusters || []).some(cluster => cluster.id !== existing?.id && cluster.name.trim().toLocaleLowerCase() === name)) {
              duplicateMessage = 'A cluster with this name already exists in this environment.';
            }
            if (formData.getAll('memberAssetIds').length < 2) duplicateMessage = 'Select at least two physical servers to create a cluster.';
          }
          if (section === 'assets' && existing && values.type !== 'Physical server' && clusterForAsset(existing.id)) {
            duplicateMessage = 'Remove this server from its cluster before changing its type.';
          }
          if (section === 'stacks') {
            const name = values.name.trim().toLocaleLowerCase();
            const duplicate = data.stacks.some(stack => stack.id !== existing?.id && stack.name?.trim().toLocaleLowerCase() === name);
            if (duplicate) duplicateMessage = t('message_21', {0: (values.name.trim())});
            const members = formData.getAll('memberAssetIds');
            if (members.length < 2) duplicateMessage = 'Select at least two devices to create a stack.';
          }
          if (section === 'lags') {
            const name = values.name.trim().toLocaleLowerCase();
            const duplicate = data.lags.some(lag => lag.id !== existing?.id && lag.name?.trim().toLocaleLowerCase() === name);
            const portsA = formData.getAll('portsA');
            const portsB = formData.getAll('portsB');
            if (!name) duplicateMessage = 'Enter a name for this LAG.';
            else if (duplicate) duplicateMessage = t('message_22', {0: (values.name.trim())});
            else if (!values.endpointAId || !values.endpointBId || values.endpointAId === values.endpointBId) duplicateMessage = 'Choose two different devices or stacks for the LAG.';
            else if (portsA.length < 2 || portsB.length < 2 || portsA.length !== portsB.length) duplicateMessage = 'Select the same number of at least two ports on both devices.';
            else {
              const endpointA = lagEndpoint(values.endpointAId);
              const endpointB = lagEndpoint(values.endpointBId);
              const membersA = selectedLagMembers(values.endpointAId, portsA);
              const membersB = selectedLagMembers(values.endpointBId, portsB);
              const samePhysicalEndpoint = endpointA.members.some(assetId => endpointB.members.includes(assetId));
              const invalidA = membersA.find(member => portHasConnection(member.deviceId, member.port, existing?.id));
              const invalidB = membersB.find(member => portHasConnection(member.deviceId, member.port, existing?.id));
              if (samePhysicalEndpoint) duplicateMessage = 'A LAG must connect separate devices or stacks.';
              else if (invalidA || invalidB) duplicateMessage = t('message_23', {0: (invalidA?.port || invalidB.port)});
            }
          }
          if (duplicateMessage) {
            const error = document.getElementById('form-error');
            error.textContent = duplicateMessage;
            error.hidden = false;
            return;
          }
          const record = { ...initialValues, ...(existing || {}), ...values, id: existing?.id || createId(section[0]) };
          if (section === 'assets' && event.currentTarget.querySelector('[name="osCatalogId"]')) Object.assign(record, collectOS(values, operatingSystems));
          if (section === 'assets') {
            delete record.switchPortTemplate; delete record.portDraft; delete record.rackSettings;
            Object.assign(record, collectManagementController(event.currentTarget, record.type));
            record.backupPowerEnabled = formData.get('backupPowerEnabled') === 'on';
            record.backupUpsId = record.backupPowerEnabled ? values.backupUpsId || '' : '';
            record.rackEnabled = record.type !== 'Virtual server' && formData.get('rackEnabled') === 'on';
            record.rackUnits = record.rackEnabled ? Number(values.rackUnits || 1) : null;
            record.rackId = record.rackEnabled ? values.rackId || '' : '';
            record.rackStartU = record.rackId ? Number(values.rackStartU) : null;
          }
          if (section === 'licenses') record.assignedAssetIds = formData.getAll('assignedAssetIds');
          if (section === 'stacks' || section === 'clusters') record.memberAssetIds = formData.getAll('memberAssetIds');
          if (section === 'clusters') record.showOnMap = formData.get('showOnMap') === 'on';
          if (section === 'lags') {
            const endpointA = lagEndpoint(values.endpointAId);
            const endpointB = lagEndpoint(values.endpointBId);
            record.endpointAId = values.endpointAId;
            record.endpointBId = values.endpointBId;
            record.stackAId = endpointA.stackId;
            record.stackBId = endpointB.stackId;
            record.membersA = selectedLagMembers(values.endpointAId, formData.getAll('portsA'));
            record.membersB = selectedLagMembers(values.endpointBId, formData.getAll('portsB'));
            record.deviceAId = record.membersA[0].deviceId;
            record.deviceBId = record.membersB[0].deviceId;
            record.portsA = record.membersA.map(member => member.port);
            record.portsB = record.membersB.map(member => member.port);
          }
          if (section === 'licenses') {
            const submit = event.currentTarget.querySelector('[type="submit"]');
            submit.disabled = true;
            try {
              await saveLicense(record);
              data.licenses ||= [];
              if (existing) data.licenses = data.licenses.map(item => item.id === existing.id ? record : item);
              else data.licenses.unshift(record);
              closeModal(); render(); toast(existing ? 'Record updated' : 'Record added');
            } catch (error) {
              const message = document.getElementById('form-error');
              if (message) { message.textContent = error.message; message.hidden = false; }
              submit.disabled = false;
            }
            return;
          }
          let connectionResult;
          if (section === 'assets') {
            record.portCount = Math.max(0, Math.min(256, Number.parseInt(values.portCount, 10) || 0));
            record.showOnMap = formData.get('showOnMap') === 'on';
            const portTypes = {};
            const portVlans = {};
            for (let port = 1; port <= record.portCount; port += 1) {
              if (record.type === 'Patch panel') continue;
              const typeSelect = formData.get(`port-type-${port}`);
              const portType = typeSelect === 'Other'
                ? (formData.get(`port-custom-type-${port}`) || '').trim() || 'Other'
                : typeSelect || defaultPortType;
              const predefined = predefinedPortTypes.find(item => item.type === portType);
              const portSpeed = predefined
                ? predefined.speed
                : (formData.get(`port-custom-speed-${port}`) || '').trim() || defaultPortSpeed;
              if (portType !== defaultPortType || portSpeed !== defaultPortSpeed) {
                portTypes[port] = { type: portType, speed: portSpeed };
              }
              const vlanConfig = parsePortVlanConfig(
                formData.get(`port-untagged-vlan-${port}`),
                formData.get(`port-tagged-vlans-${port}`)
              );
              if (vlanConfig.error) {
                const error = document.getElementById('form-error');
                error.textContent = `Port ${port}: ${vlanConfig.error}`;
                error.hidden = false;
                return;
              }
              if (vlanConfig.value.untaggedVlan !== null || vlanConfig.value.taggedVlans.length) {
                portVlans[port] = vlanConfig.value;
              }
            }
            record.portTypes = portTypes;
            record.portVlans = portVlans;
            for (const key of Object.keys(record)) {
              if (/^peer-(device|port)-\d+$/.test(key) || /^port-(type|speed|custom-type|custom-speed|untagged-vlan|tagged-vlans)-\d+$/.test(key)) delete record[key];
            }
            connectionResult = collectPortConnections(record, formData);
            if (connectionResult.error) {
              const error = document.getElementById('form-error');
              error.textContent = connectionResult.error;
              error.hidden = false;
              return;
            }
            record.internetPorts = connectionResult.internetPorts;
          }
          if (section === 'assets') {
            const target = String(values.hypervisorId || '');
            record.hypervisorClusterId = record.type === 'Virtual server' && target.startsWith('cluster:') ? target.slice(8) : '';
            record.hypervisorId = record.type === 'Virtual server' && !target.startsWith('cluster:') ? target : '';
          }
          if (section === 'wlans') {
            const vlan = (data.vlans || []).find(vlan => vlan.id === values.vlanInterfaceId);
            record.vlanId = vlan?.idValue || '';
          }
          if (section === 'lans') {
            record.parentInterface = values.parentInterface ? JSON.parse(values.parentInterface) : null;
            if (record.parentInterface?.type === 'vlan') record.vlanId = (data.vlans || []).find(vlan => vlan.id === record.parentInterface.vlanId)?.idValue || '';
          }
          if (section === 'vlans') { record.idValue = values.id; delete record.id; record.id = existing?.id || createId('v'); }
          if (section === 'assets' && existing) {
            const dependent = (data.lans || []).find(network => network.parentInterface?.type === 'physical' && network.parentInterface.deviceId === existing.id && network.parentInterface.port > Number(record.portCount || 0));
            if (dependent) {
              const error = document.getElementById('form-error');
              error.textContent = t('message_24', {0: (dependent.name)});
              error.hidden = false;
              return;
            }
          }
          data[section] ||= [];
          const editedData = data;
          const editedUser = currentUser;
          const editedEnvironment = activeEnvironmentId;
          const editedForm = event.currentTarget;
          const previousAssets = section === 'assets' ? structuredClone(data.assets) : null;
          const previousConnections = section === 'assets' ? structuredClone(data.connections || []) : null;
          const previousRecords = ['lags', 'clusters', 'lans', 'vlans', 'wlans'].includes(section) ? structuredClone(data[section] || []) : null;
          const previousNetworkData = ['lans', 'vlans', 'wlans'].includes(section) ? {lans: structuredClone(data.lans || []), vlans: structuredClone(data.vlans || []), wlans: structuredClone(data.wlans || [])} : null;
          if (existing) data[section] = data[section].map(item => item.id === existing.id ? record : item);
          else data[section].unshift(record);
          if (section === 'vlans') data.lans = (data.lans || []).map(network => network.parentInterface?.type === 'vlan' && network.parentInterface.vlanId === record.id ? {...network, vlanId: record.idValue} : network);
          if (connectionResult) data.connections = connectionResult.connections;
          if (['lags', 'clusters', 'lans', 'vlans', 'wlans'].includes(section)) {
            const submit = event.currentTarget.querySelector('[type="submit"]');
            submit.disabled = true;
            if (!await save()) {
              data[section] = previousRecords;
              if (previousNetworkData) Object.assign(data, previousNetworkData);
              const active = portfolio.environments.find(item => item.id === activeEnvironmentId);
              if (active) active.data = data;
              const error = document.getElementById('form-error');
              error.textContent = t('message_25', {0: (section === 'lags' ? 'LAG' : section === 'lans' ? 'network' : section === 'vlans' ? 'VLAN' : section === 'wlans' ? 'WLAN' : 'cluster')});
              error.hidden = false;
              submit.disabled = false;
              return;
            }
          } else if (section === 'assets') {
            const submit = event.currentTarget.querySelector('[type="submit"]');
            submit.disabled = true;
            const saved = await save();
            if (!saved) {
              editedData.assets = previousAssets;
              editedData.connections = previousConnections;
            }
            if (currentUser !== editedUser || activeEnvironmentId !== editedEnvironment || data !== editedData || !editedForm.isConnected) return;
            if (!saved) {
              const error = document.getElementById('form-error');
              error.textContent = t("the_asset_was_not_saved_review_the_save_notification_and_try_again");
              error.hidden = false;
              submit.disabled = false;
              return;
            }
          } else save();
          closeModal(); render(); toast(existing ? 'Record updated' : 'Record added');
        });
        if (section === 'assets') {
          const form = document.getElementById('record-form');
          bindOSPicker(form, operatingSystems);
          bindRackFields(form);
          bindPowerSupplyFields(form);
          bindManagementController(form);
          const portCountInput = form.querySelector('[name="portCount"]');
          const assetTypeInput = form.querySelector('[name="type"]');
          const showOnMapInput = form.querySelector('[name="showOnMap"]');
          const updateHostField = () => {
            const isVirtualServer = assetTypeInput.value === 'Virtual server';
            const hostField = form.querySelector('[data-virtual-only]');
            if (hostField) hostField.hidden = !isVirtualServer;
            if (!existing && initialValues.showOnMap === undefined && !showOnMapInput?.dataset.userChanged && showOnMapInput) showOnMapInput.checked = isVirtualServer;
          };
          assetTypeInput.addEventListener('change', () => {
            updateHostField();
            if (existing) return;
            const selectedCategory = Object.entries(assetCategoryTypes)
              .find(([, types]) => types.includes(assetTypeInput.value))?.[0] || null;
            const values = Object.fromEntries(new FormData(form).entries());
            values.type = assetTypeInput.value;
            values.showOnMap = showOnMapInput?.checked || false;
            values.portDraft = {};
            form.querySelectorAll('[name^="port-type-"]').forEach(select => {
              const number = Number(select.name.slice('port-type-'.length));
              const customInput = form.querySelector(`[name="port-custom-type-${number}"]`);
              const speedColumn = form.querySelector(`[data-port-speed="${number}"]`);
              const customSpeedInput = speedColumn.querySelector('[name^="port-custom-speed-"]');
              values.portDraft[number] = {
                portType: select.value,
                customType: customInput?.value || '',
                customSpeed: customSpeedInput?.value || speedColumn.dataset.customSpeed || speedColumn.querySelector('[data-port-speed-value]')?.dataset.portSpeedValue || defaultPortSpeed,
                untaggedVlan: form.querySelector(`[name="port-untagged-vlan-${number}"]`)?.value || '',
                taggedVlans: form.querySelector(`[name="port-tagged-vlans-${number}"]`)?.value || ''
              };
            });
            openForm('assets', null, selectedCategory, values);
          });
          showOnMapInput?.addEventListener('change', () => { showOnMapInput.dataset.userChanged = 'true'; });
          updateHostField();
          portCountInput?.addEventListener('input', () => {
            portCountInput.dispatchEvent(new Event('change', { bubbles: true }));
          });
          form.addEventListener('change', event => {
            if (event.target === portCountInput || event.target.name === 'switchPortTemplate') {
              const draft = {};
              form.querySelectorAll('[name^="port-type-"]').forEach(select => {
                const number = Number(select.name.slice('port-type-'.length));
                const customInput = form.querySelector(`[name="port-custom-type-${number}"]`);
                const speedColumn = form.querySelector(`[data-port-speed="${number}"]`);
                const customSpeedInput = speedColumn.querySelector('[name^="port-custom-speed-"]');
                draft[number] = {
                  portType: select.value,
                  customType: customInput?.value || '',
                  customSpeed: customSpeedInput?.value || speedColumn.dataset.customSpeed || speedColumn.querySelector('[data-port-speed-value]')?.dataset.portSpeedValue || defaultPortSpeed,
                  untaggedVlan: form.querySelector(`[name="port-untagged-vlan-${number}"]`)?.value || '',
                  taggedVlans: form.querySelector(`[name="port-tagged-vlans-${number}"]`)?.value || '',
                };
              });
              form.querySelectorAll('[name^="peer-device-"]').forEach(select => {
                const number = Number(select.name.slice('peer-device-'.length));
                const savedConnection = connectionForPort(existing?.id, number) || {};
                draft[number] = {
                  ...(draft[number] || {}),
                  deviceId: select.value,
                  port: form.querySelector(`[name="peer-port-${number}"]`)?.value || '',
                  internet: form.querySelector(`[name="internet-port-${number}"]`)?.checked || false,
                  lagId: savedConnection.lagId,
                  lagName: savedConnection.lagName
                };
              });
              if (event.target.name === 'switchPortTemplate' && event.target.value !== '') {
                const template = switchPortTemplates[Number(event.target.value)];
                if (template) {
                  portCountInput.value = String(template.portCount);
                  let port = 1;
                  template.groups.forEach(group => {
                    for (let offset = 0; offset < group.count; offset += 1) {
                      const preset = predefinedPortTypes.find(item => item.type === group.type);
                      draft[port] = {
                        ...(draft[port] || {}),
                        portType: group.type,
                        customType: '',
                        customSpeed: preset?.speed || defaultPortSpeed
                      };
                      port += 1;
                    }
                  });
                }
              }
              form.querySelector('#ports-editor').innerHTML = renderPortEditor({ ...(existing || initialValues), type: assetType }, portCountInput.value, draft);
            }
            const typeMatch = /^port-type-(\d+)$/.exec(event.target.name || '');
            if (typeMatch) {
              const customInput = form.querySelector(`[name="port-custom-type-${typeMatch[1]}"]`);
              if (customInput) {
                customInput.hidden = event.target.value !== 'Other';
                if (event.target.value === 'Other') customInput.focus();
              }
              const predefined = predefinedPortTypes.find(item => item.type === event.target.value);
              const speedColumn = form.querySelector(`[data-port-speed="${typeMatch[1]}"]`);
              if (predefined && speedColumn) {
                const customSpeedInput = speedColumn.querySelector('[name^="port-custom-speed-"]');
                if (customSpeedInput?.value) speedColumn.dataset.customSpeed = customSpeedInput.value;
                speedColumn.innerHTML = html`<span class="port-field-label">[[speed]]</span><span class="port-speed-fixed" data-port-speed-value="${esc(predefined.speed)}">${esc(predefined.speed)}</span>`;
              } else if (speedColumn && !speedColumn.querySelector('[name^="port-custom-speed-"]')) {
                const customSpeed = speedColumn.dataset.customSpeed || defaultPortSpeed;
                speedColumn.innerHTML = html`<span class="port-field-label">[[speed]]</span><input name="port-custom-speed-${typeMatch[1]}" class="port-custom-type" type="text" placeholder="[[custom_speed]]" value="${esc(customSpeed)}" aria-label="Port ${typeMatch[1]} custom speed">`;
              }
            }
            const customSpeedMatch = /^port-custom-speed-(\d+)$/.exec(event.target.name || '');
            if (customSpeedMatch) {
              const speedColumn = form.querySelector(`[data-port-speed="${customSpeedMatch[1]}"]`);
              if (speedColumn) speedColumn.dataset.customSpeed = event.target.value;
            }
            const match = /^peer-device-(\d+)$/.exec(event.target.name || '');
            if (match) {
              const peerPortInput = form.querySelector(`[name="peer-port-${match[1]}"]`);
              const peer = data.assets.find(asset => asset.id === event.target.value);
              peerPortInput.disabled = !peer;
              if (!peer) peerPortInput.value = '';
              if (peer?.portCount) peerPortInput.max = peer.portCount;
              else peerPortInput.removeAttribute('max');
              if (peer) form.querySelector(`[name="internet-port-${match[1]}"]`).checked = false;
            }
            const internetMatch = /^internet-port-(\d+)$/.exec(event.target.name || '');
            if (internetMatch && event.target.checked) {
              const peerSelect = form.querySelector(`[name="peer-device-${internetMatch[1]}"]`);
              const peerPortInput = form.querySelector(`[name="peer-port-${internetMatch[1]}"]`);
              peerSelect.value = '';
              peerSelect.disabled = true;
              peerPortInput.value = '';
              peerPortInput.disabled = true;
            } else if (internetMatch) {
              const peerSelect = form.querySelector(`[name="peer-device-${internetMatch[1]}"]`);
              peerSelect.disabled = false;
            }
          });
          form.addEventListener('click', event => {
            const openVlan = event.target.closest('[data-port-vlan-open]');
            const popup = form.querySelector('#port-vlan-popup');
            if (openVlan) {
              popup.dataset.snapshot = JSON.stringify(
                [...popup.querySelectorAll('[data-port-vlan-input]')].map(input => input.value)
              );
              popup.querySelector('[data-port-vlan-error]').hidden = true;
              popup.querySelector('[data-port-vlan-error]').textContent = '';
              popup.hidden = false;
              popup.querySelector('[data-port-vlan-input]').focus();
              return;
            }
            if (event.target.closest('[data-port-vlan-cancel]')) {
              const snapshot = JSON.parse(popup.dataset.snapshot || '[]');
              popup.querySelectorAll('[data-port-vlan-input]').forEach((input, index) => {
                input.value = snapshot[index] ?? '';
              });
              popup.hidden = true;
              return;
            }
            if (event.target.closest('[data-port-vlan-done]')) {
              for (const row of popup.querySelectorAll('.port-vlan-row')) {
                const port = row.dataset.portNumber;
                const [untaggedInput, taggedInput] = row.querySelectorAll('[data-port-vlan-input]');
                const parsed = parsePortVlanConfig(untaggedInput.value, taggedInput.value);
                if (parsed.error) {
                  const error = popup.querySelector('[data-port-vlan-error]');
                  error.textContent = `Port ${port}: ${parsed.error}`;
                  error.hidden = false;
                  untaggedInput.focus();
                  return;
                }
              }
              const error = popup.querySelector('[data-port-vlan-error]');
              if (!error.hidden) {
                error.hidden = true;
                error.textContent = '';
              }
              popup.hidden = true;
            }
          });
        }
        if (section === 'stacks') {
          const form = document.getElementById('record-form');
          const deviceType = form.querySelector('[name="deviceType"]');
          deviceType.addEventListener('change', () => {
            form.querySelector('[name="memberAssetIds"]').outerHTML = stackMemberControl(
              deviceType.value, [], existing?.id || ''
            );
          });
        }
        if (section === 'lags') {
          const form = document.getElementById('record-form');
          const updateSelectedCounts = () => {
            for (const side of ['A', 'B']) {
              const count = form.querySelectorAll(`[name="ports${side}"]:checked`).length;
              const label = form.querySelector(`[data-lag-port-count="${side}"]`);
              if (label) label.textContent = `${count} selected`;
            }
          };
          form.addEventListener('change', event => {
            if (event.target.matches('input[name^="ports"]')) {
              updateSelectedCounts();
              return;
            }
            if (!event.target.matches('[data-lag-device]')) return;
            for (const side of ['A', 'B']) {
              const endpointId = form.querySelector(`[name="endpoint${side}Id"]`).value;
              const changed = event.target.name === `endpoint${side}Id`;
              const selected = changed
                ? []
                : Array.from(form.querySelectorAll(`[name="ports${side}"]:checked`), input => input.value);
              form.querySelector(`[data-lag-ports="${side}"]`).outerHTML = lagPortPicker(side, endpointId, selected, existing?.id || '');
            }
            updateSelectedCounts();
          });
        }
      }
      function closeModal() { document.getElementById('modal-root').innerHTML = ''; }
      function toast(message) {
        const root = document.getElementById('toast-root');
        root.innerHTML = html`<div class="toast">${esc(message)}</div>`;
        setTimeout(() => { root.innerHTML = ''; }, 2400);
      }
      async function openUserSettings() {
        await loadLanguages();
        const themes = [
          ['default', 'Default', 'The original Netory colors'],
          ['ocean', 'Ocean', 'A cool blue palette'],
          ['midnight', 'Midnight', 'Dark surfaces with cool accents']
        ];
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="user-settings-form"><div class="modal-head"><div><div class="eyebrow">[[account_settings]]</div><h2>[[your_preferences]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="user-settings-error" role="alert" hidden></p><div class="field"><label for="user-language">[[language]]</label><select id="user-language" name="language">${Object.entries(languages).map(([code, name]) => html`<option value="${esc(code)}" ${(currentUser.language || 'en') === code ? 'selected' : ''}>${esc(name)}</option>`).join('')}</select></div><div class="field"><label for="user-theme">[[application_colors]]</label><select id="user-theme" name="theme">${themes.map(([value, label, description]) => html`<option value="${value}" ${currentUser.theme === value ? 'selected' : ''}>${t(label)} — ${t(description)}</option>`).join('')}</select></div></div><div class="modal-foot"><button type="button" class="button" data-change-own-password>[[change_password]]</button><button type="button" class="button" data-close>[[cancel]]</button><button type="submit" class="button primary">[[save_preferences]]</button></div></form></div>`;
        document.getElementById('user-settings-form').addEventListener('submit', async event => {
          event.preventDefault();
          const form = event.currentTarget;
          const submit = form.querySelector('[type="submit"]');
          submit.disabled = true;
          try {
            const values = Object.fromEntries(new FormData(form).entries());
            const result = await apiRequest('/api/users/me/preferences', { method: 'PATCH', body: JSON.stringify(values) });
            currentUser.theme = result.theme;
            currentUser.language = result.language;
            setLanguage(result.language);
            localizeShell();
            render();
            document.documentElement.dataset.theme = result.theme;
            closeModal();
            toast(t("preferences_saved"));
          } catch (error) {
            const message = document.getElementById('user-settings-error');
            message.textContent = error.message;
            message.hidden = false;
            submit.disabled = false;
          }
        });
      }
      async function openActivityLogs(cursor = null, filters = {}, history = []) {
        if (!currentUser?.is_admin) return;
        try {
          const params = new URLSearchParams(filters);
          if (cursor) params.set('before', cursor);
          const [logs, policy] = await Promise.all([
            apiRequest(`/api/audit-logs?${params}`),
            apiRequest('/api/settings/audit-retention')
          ]);
          const rows = logs.items.map(item => html`<tr><td>${esc(new Date(item.created_at).toLocaleString())}</td><td>${esc(item.username)}${item.is_admin ? html([" <span class=\"tag blue\">[[superadmin]]</span>"]) : ''}</td><td>${esc(item.message)}</td><td><span class="tag">${item.status_code < 400 ? t("success") : t("failed")}</span></td></tr>`).join('');
          document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><section class="modal audit-log-modal"><div class="modal-head"><div><div class="eyebrow">[[superadmin_settings]]</div><h2>[[activity_logs]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="panel-sub">[[application_activity_from_all_accounts_including_your_own_searchable_by_account_activity_a]]</p><form id="audit-filter-form" class="audit-filters"><div class="field audit-search"><label for="audit-search">[[search_activity]]</label><input id="audit-search" name="q" type="search" maxlength="240" placeholder="[[asset_name_or_activity_text]]" value="${esc(filters.q || '')}"></div><div class="field"><label for="audit-account">[[account]]</label><input id="audit-account" name="account" maxlength="120" placeholder="[[username]]" value="${esc(filters.account || '')}"></div><div class="field"><label for="audit-action">[[activity]]</label><select id="audit-action" name="action">${[['','All activities'],['added','Added item'],['changed','Changed item'],['deleted','Deleted item'],['login','Sign-in'],['logout','Sign-out'],['create_user','Added user'],['delete_user','Deleted user'],['create_environment','Added client'],['rename_environment','Renamed client'],['delete_environment','Deleted client'],['add_member','Granted access'],['update_member','Changed access'],['remove_member','Removed access'],['save_license','Saved license'],['delete_license','Deleted license'],['update_login_protection','Login protection settings'],['update_audit_retention','Retention settings'],['change_own_password','Password change'],['reset_user_password','Password reset'],['update_user_status','Account status'],['update_assistant_permission','Writable AI chat permission'],['update_user_preferences','Preferences']].map(([value,label]) => html`<option value="${value}" ${(filters.action || '') === value ? 'selected' : ''}>${t(label)}</option>`).join('')}</select></div><div class="field"><label for="audit-result">[[result]]</label><select id="audit-result" name="result">${[['all','All results'],['success','Success'],['failed','Failed']].map(([value,label]) => html`<option value="${value}" ${(filters.result || 'all') === value ? 'selected' : ''}>${t(label)}</option>`).join('')}</select></div><div class="field"><label for="audit-sort">[[sort_by]]</label><select id="audit-sort" name="sort">${[['time','Time'],['account','Account'],['action','Activity type']].map(([value,label]) => html`<option value="${value}" ${(filters.sort || 'time') === value ? 'selected' : ''}>${t(label)}</option>`).join('')}</select></div><div class="field"><label for="audit-direction">[[order]]</label><select id="audit-direction" name="direction"><option value="desc" ${(filters.direction || 'desc') === 'desc' ? 'selected' : ''}>[[descending_newest_first]]</option><option value="asc" ${filters.direction === 'asc' ? 'selected' : ''}>[[ascending_oldest_first]]</option></select></div><div class="audit-filter-actions"><button type="submit" class="button primary">[[apply_filters]]</button><button type="button" class="button" id="audit-clear">[[clear_filters]]</button></div></form><p class="secondary-cell">${logs.total} matching entries · Showing ${logs.items.length}</p><details class="audit-retention"><summary>[[log_retention_settings]]</summary><form id="audit-retention-form" class="form-grid"><div class="field"><label for="audit-retention-days">[[keep_logs_for_days]]</label><input id="audit-retention-days" name="retention_days" type="number" min="1" max="3650" step="1" value="${policy.retention_days}" required></div><div class="field"><label>[[nbsp]]</label><button type="submit" class="button">[[save_retention]]</button></div><p class="form-error full" id="audit-retention-error" role="alert" hidden></p></form><p class="secondary-cell">[[reducing_retention_permanently_removes_older_entries_expired_logs_are_removed_when_api_act]]</p></details><div class="table-wrap audit-log-table"><table><thead><tr><th>[[time]]</th><th>[[account]]</th><th>[[action]]</th><th>[[result]]</th></tr></thead><tbody>${rows || html(["<tr><td colspan=\"4\">[[no_activity_logs_yet]]</td></tr>"])}</tbody></table></div></div><div class="modal-foot"><button type="button" class="button" data-administration-settings>[[back]]</button><button type="button" class="button" id="audit-refresh">[[refresh]]</button>${history.length ? html(["<button type=\"button\" class=\"button\" id=\"audit-previous\">[[previous_page]]</button>"]) : ''}${logs.next_cursor ? html(["<button type=\"button\" class=\"button\" id=\"audit-older\">[[next_page]]</button>"]) : ''}</div></section></div>`;
          document.getElementById('audit-refresh').addEventListener('click', () => openActivityLogs(null, filters));
          document.getElementById('audit-older')?.addEventListener('click', () => openActivityLogs(logs.next_cursor, filters, [...history, cursor]));
          document.getElementById('audit-previous')?.addEventListener('click', () => openActivityLogs(history.at(-1), filters, history.slice(0, -1)));
          document.getElementById('audit-clear').addEventListener('click', () => openActivityLogs());
          document.getElementById('audit-filter-form').addEventListener('submit', event => {
            event.preventDefault();
            openActivityLogs(null, Object.fromEntries(new FormData(event.currentTarget).entries()));
          });
          document.getElementById('audit-retention-form').addEventListener('submit', async event => {
            event.preventDefault();
            const submit = event.currentTarget.querySelector('[type="submit"]');
            submit.disabled = true;
            try {
              await apiRequest('/api/settings/audit-retention', { method: 'PUT', body: JSON.stringify({retention_days: Number(new FormData(event.currentTarget).get('retention_days'))}) });
              await openActivityLogs(null, filters);
              toast(t("log_retention_saved"));
            } catch (error) {
              const message = document.getElementById('audit-retention-error');
              message.textContent = error.message;
              message.hidden = false;
              submit.disabled = false;
            }
          });
        } catch (error) { toast(error.message); }
      }
      async function openNetworkMapSettings() {
        if (!currentUser?.is_admin) return;
        try {
          const settings = await apiRequest('/api/settings/network-map');
          document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="network-map-settings-form"><div class="modal-head"><h2>[[network_map_layout]]</h2><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="panel-sub">[[network_map_layout_description]]</p><label class="map-layout-switch"><span>[[netory_view]]</span><input type="checkbox" name="elk" role="switch" aria-label="[[use_elk_js_view]]" ${settings.layout === 'elk' ? 'checked' : ''}><span>[[elk_js_view]]</span></label><p class="form-error" id="network-map-settings-error" role="alert" hidden></p></div><div class="modal-foot"><button type="button" class="button" data-administration-settings>[[back]]</button><button type="submit" class="button primary">[[save]]</button></div></form></div>`;
          document.getElementById('network-map-settings-form').addEventListener('submit', async event => {
            event.preventDefault();
            const form = event.currentTarget;
            const submit = form.querySelector('[type="submit"]');
            submit.disabled = true;
            try {
              const layout = new FormData(form).has('elk') ? 'elk' : 'physical';
              const result = await apiRequest('/api/settings/network-map', {method: 'PUT', body: JSON.stringify({layout})});
              mapLayout = result.layout;
              closeModal();
              render();
              toast(t('network_map_layout_saved'));
            } catch (error) {
              const message = document.getElementById('network-map-settings-error');
              message.textContent = error.message;
              message.hidden = false;
              submit.disabled = false;
            }
          });
        } catch (error) { toast(error.message); }
      }
      async function openSessionTimeoutSettings() {
        try {
          const policy = await apiRequest('/api/settings/session-timeout');
          document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="session-timeout-form"><div class="modal-head"><h2>[[session_timeout]]</h2><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="panel-sub">[[applies_to_all_accounts_and_existing_sessions_mouse_keyboard_touch_and_scrolling_activity_]]</p><div class="field"><label for="idle-timeout">[[inactivity_timeout_minutes]]</label><input id="idle-timeout" name="idle_timeout_minutes" type="number" min="1" max="1440" step="1" value="${policy.idle_timeout_minutes}" required></div><p class="form-error" id="session-timeout-error" role="alert" hidden></p></div><div class="modal-foot"><button type="button" class="button" data-administration-settings>[[back]]</button><button type="submit" class="button primary">[[save_timeout]]</button></div></form></div>`;
          document.getElementById('session-timeout-form').addEventListener('submit', async event => {
            event.preventDefault();
            try {
              await apiRequest('/api/settings/session-timeout', {method: 'PUT', body: JSON.stringify({idle_timeout_minutes: Number(new FormData(event.currentTarget).get('idle_timeout_minutes'))})});
              closeModal();
              toast(t("session_timeout_saved"));
            } catch (error) {
              const message = document.getElementById('session-timeout-error');
              if (message) { message.textContent = error.message; message.hidden = false; }
            }
          });
        } catch (error) { toast(error.message); }
      }

      async function openLoginProtectionSettings() {
        if (!currentUser?.is_admin) return;
        try {
          const policy = await apiRequest('/api/settings/login-protection');
          document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="login-protection-form"><div class="modal-head"><div><div class="eyebrow">[[superuser_settings]]</div><h2>[[login_protection]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="login-protection-error" role="alert" hidden></p><p class="panel-sub">[[settings_apply_to_every_account_only_superusers_can_change_them]]</p><div class="form-grid"><div class="field full checkbox-field"><label><input type="checkbox" name="enabled" ${policy.enabled ? 'checked' : ''}> [[enable_brute_force_protection]]</label><span class="secondary-cell">[[turning_this_off_allows_unlimited_password_attempts_for_every_account]]</span></div><div class="field"><label for="login-max-attempts">[[failed_attempts_before_blocking]]</label><input id="login-max-attempts" name="max_failed_attempts" type="number" min="1" max="100" step="1" value="${policy.max_failed_attempts}" required></div><div class="field"><label for="login-block-minutes">[[block_duration_minutes]]</label><input id="login-block-minutes" name="block_minutes" type="number" min="1" max="1440" step="1" value="${policy.block_minutes}" required></div></div><p class="secondary-cell">[[successful_sign_in_clears_the_failed_attempt_counter_counters_also_reset_after_this_many_m]]</p></div><div class="modal-foot"><button type="button" class="button" data-administration-settings>[[back]]</button><button type="submit" class="button primary">[[save_login_protection]]</button></div></form></div>`;
          document.getElementById('login-protection-form').addEventListener('submit', async event => {
            event.preventDefault();
            const form = event.currentTarget;
            const submit = form.querySelector('[type="submit"]');
            submit.disabled = true;
            const values = new FormData(form);
            try {
              await apiRequest('/api/settings/login-protection', { method: 'PUT', body: JSON.stringify({
                enabled: values.has('enabled'),
                max_failed_attempts: Number(values.get('max_failed_attempts')),
                block_minutes: Number(values.get('block_minutes'))
              }) });
              closeModal();
              toast(t("login_protection_saved"));
            } catch (error) {
              const message = document.getElementById('login-protection-error');
              message.textContent = error.message;
              message.hidden = false;
              submit.disabled = false;
            }
          });
        } catch (error) { toast(error.message); }
      }
      function openOwnPasswordChange() {
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="own-password-form"><div class="modal-head"><div><div class="eyebrow">[[account_security]]</div><h2>[[change_password]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="own-password-error" role="alert" hidden></p><div class="form-grid"><div class="field full"><label for="current-password">[[current_password]]</label><input id="current-password" name="current_password" type="password" autocomplete="current-password" required></div><div class="field"><label for="new-own-password">[[new_password_at_least_14_characters]]</label><input id="new-own-password" name="new_password" type="password" autocomplete="new-password" minlength="14" maxlength="1024" required></div><div class="field"><label for="confirm-own-password">[[confirm_new_password]]</label><input id="confirm-own-password" name="confirm_password" type="password" autocomplete="new-password" minlength="14" maxlength="1024" required></div></div><p class="secondary-cell">[[your_current_session_stays_signed_in_other_sessions_will_be_signed_out]]</p></div><div class="modal-foot"><button type="button" class="button" data-user-settings>[[back]]</button><button type="submit" class="button primary">[[update_password]]</button></div></form></div>`;
        document.getElementById('own-password-form').addEventListener('submit', async event => {
          event.preventDefault();
          const form = event.currentTarget;
          const submit = form.querySelector('[type="submit"]');
          const values = Object.fromEntries(new FormData(form).entries());
          const message = document.getElementById('own-password-error');
          if (values.new_password !== values.confirm_password) {
            message.textContent = t("the_new_passwords_do_not_match");
            message.hidden = false;
            return;
          }
          submit.disabled = true;
          try {
            await apiRequest('/api/users/me/change-password', {
              method: 'POST',
              body: JSON.stringify({
                current_password: values.current_password,
                new_password: values.new_password
              })
            });
            closeModal();
            toast(t("password_changed"));
          } catch (error) {
            message.textContent = error.message;
            message.hidden = false;
            submit.disabled = false;
          }
        });
      }
      function renderPermissionAssignments() {
        const container = document.getElementById('permission-assignments');
        if (!container) return;
        const user = permissionUsers.find(item => item.id === permissionUserId);
        if (!user) { container.innerHTML = html(["<p class=\"secondary-cell\">[[create_a_user_to_manage_permissions]]</p>"]); return; }
        const chatControl = document.getElementById('assistant-permission-controls');
        chatControl.innerHTML = html`<label><input type="checkbox" id="user-assistant-write" ${user.assistant_write_enabled || user.is_admin ? 'checked' : ''} ${user.is_admin || !user.is_active ? 'disabled' : ''}> [[allow_writable_ai_chat]]</label><p class="secondary-cell">${user.is_admin ? t("superadmins_always_have_writable_ai_chat_access") : t("allows_reviewed_inventory_changes_including_licenses_connections_and_file_imports_in_envir")}</p>`;
        const chatCheckbox = document.getElementById('user-assistant-write');
        chatCheckbox.addEventListener('change', async () => {
          const enabled = chatCheckbox.checked;
          chatCheckbox.disabled = true;
          try {
            const result = await apiRequest(`/api/users/${encodeURIComponent(user.id)}/assistant-permission`, {
              method: 'PUT', body: JSON.stringify({assistant_write_enabled: enabled})
            });
            user.assistant_write_enabled = result.assistant_write_enabled;
            toast(t('message_26', {0: (enabled ? 'enabled' : 'disabled'), 1: (user.username)}));
          } catch (error) { chatCheckbox.checked = user.assistant_write_enabled; toast(error.message); }
          finally { chatCheckbox.disabled = false; }
        });
        if (user.is_admin) { container.innerHTML = html(["<p class=\"secondary-cell\">[[superadmins_have_full_access_to_all_environments_automatically]]</p>"]); return; }
        const environments = portfolio.environments.filter(environment => {
          const assigned = Boolean(user.environment_roles?.[environment.id]);
          return environment.name.toLowerCase().includes(permissionSearch.trim().toLowerCase()) &&
            (permissionFilter === 'all' || (permissionFilter === 'assigned' ? assigned : !assigned));
        }).sort((a, b) => a.name.localeCompare(b.name));
        const pageSize = 10;
        const pages = Math.max(1, Math.ceil(environments.length / pageSize));
        permissionPage = Math.min(permissionPage, pages - 1);
        const rows = environments.slice(permissionPage * pageSize, (permissionPage + 1) * pageSize).map(environment => {
          const role = user.environment_roles?.[environment.id] || '';
          return html`<div class="permission-row"><div class="primary-cell">${esc(environment.name)}</div><select data-user-environment="${esc(environment.id)}" data-user-id="${esc(user.id)}" data-current-role="${esc(role)}" aria-label="${esc(t('message_27', {0: (user.username), 1: (environment.name)}))}" ${user.is_active && !permissionPending.has(`${user.id}:${environment.id}`) ? '' : 'disabled'}><option value="" ${!role ? 'selected' : ''}>[[no_access]]</option><option value="viewer" ${role === 'viewer' ? 'selected' : ''}>[[read_only]]</option><option value="editor" ${role === 'editor' ? 'selected' : ''}>[[read_write]]</option></select></div>`;
        }).join('');
        container.innerHTML = html`${!user.is_active ? html(["<p class=\"secondary-cell\">[[activate_this_account_before_changing_its_permissions]]</p>"]) : ''}<p class="secondary-cell">${environments.length} matching environments · Changes save automatically</p>${rows || html(["<p class=\"secondary-cell\">[[no_environments_match_your_search]]</p>"])}<div class="permission-pagination"><button class="button" type="button" id="permission-previous" ${permissionPage === 0 ? 'disabled' : ''}>[[previous]]</button><span>[[page]] ${permissionPage + 1} of ${pages}</span><button class="button" type="button" id="permission-next" ${permissionPage + 1 >= pages ? 'disabled' : ''}>[[next]]</button></div>`;
        document.getElementById('permission-previous').addEventListener('click', () => { permissionPage -= 1; renderPermissionAssignments(); });
        document.getElementById('permission-next').addEventListener('click', () => { permissionPage += 1; renderPermissionAssignments(); });
      }
      async function openUserManager() {
        if (!currentUser?.is_admin) return;
        try {
          const users = await apiRequest('/api/users');
          permissionUsers = users;
          if (!users.some(user => user.id === permissionUserId)) permissionUserId = users.find(user => !user.is_admin)?.id || users[0]?.id || null;
          const userRows = users.map(user => {
            const account = html`<div class="primary-cell">${esc(user.username)}${user.is_admin ? html([" <span class=\"tag blue\">[[superuser]]</span>"]) : ''}</div><div class="secondary-cell">${user.is_admin ? t("full_access_to_every_environment") : user.is_active ? t("active_account") : t("inactive_account")}</div>`;
            const environmentAccess = html`<td>${user.is_admin ? t("all_environments") : html`<span data-access-count="${esc(user.id)}">${Object.keys(user.environment_roles || {}).length}</span> [[environments]]`}</td>`;
            const actions = user.is_admin ? '' : html`<button data-user-password="${esc(user.id)}">[[reset_password]]</button><button data-user-active="${esc(user.id)}" data-active="${user.is_active ? 'false' : 'true'}">${user.is_active ? t("deactivate") : t("activate")}</button>`;
            return html`<tr data-account-name="${esc(user.username.toLowerCase())}"><td>${account}</td>${environmentAccess}<td><div class="row-actions"><button data-manage-user-access="${esc(user.id)}">[[manage_access]]</button>${actions}${user.is_admin ? '' : html`<button data-user-delete="${esc(user.id)}" data-username="${esc(user.username)}">[[delete_permanently]]</button>`}</div></td></tr>`;
          }).join('');
          document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><section class="modal user-manager-modal permissions-manager-modal"><div class="modal-head"><div><div class="eyebrow">[[administration]]</div><h2>[[manage_users]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="panel-sub">[[set_each_user_s_access_per_environment_ro_is_read_only_rw_can_make_changes_superusers_have]]</p><details class="user-create-panel"><summary>[[create_a_user]]</summary><section aria-labelledby="user-create-title"><div class="user-create-heading"><div><div class="eyebrow">[[new_account]]</div><h3 id="user-create-title">[[create_a_user]]</h3><p class="panel-sub">[[choose_standard_access_or_grant_full_administrator_privileges]]</p></div></div><form id="user-create-form" class="user-create-form"><p class="form-error full" id="user-create-error" role="alert" hidden></p><div class="field"><label for="new-username">[[username]]</label><input id="new-username" name="username" autocomplete="off" maxlength="120" required></div><div class="field"><label for="new-password">[[temporary_password_at_least_14_characters]]</label><input id="new-password" name="password" type="password" autocomplete="new-password" minlength="14" maxlength="1024" required></div><div class="checkbox-field"><label for="new-user-admin"><input id="new-user-admin" name="is_admin" type="checkbox"> [[create_as_administrator_superuser]]</label><span class="secondary-cell">[[grants_full_access_to_all_client_environments_and_user_management]]</span></div><div class="user-create-actions"><button type="submit" class="button primary">[[create_account]]</button></div></form></section></details><section class="permissions-editor"><h3>[[environment_permissions]]</h3><div class="permission-controls"><div class="field"><label for="permission-user">[[user]]</label><select id="permission-user">${users.map(user => html`<option value="${esc(user.id)}" ${user.id === permissionUserId ? 'selected' : ''}>${esc(user.username)}${user.is_admin ? ' (superadmin)' : ''}</option>`).join('')}</select></div><div class="field"><label for="permission-search">[[search_environments]]</label><input id="permission-search" type="search" placeholder="[[environment_name]]" value="${esc(permissionSearch)}"></div><div class="field"><label for="permission-filter">[[show]]</label><select id="permission-filter"><option value="all">[[all_environments]]</option><option value="assigned">[[assigned_environments]]</option><option value="unassigned">[[no_access]]</option></select></div></div><div id="assistant-permission-controls" class="checkbox-field"></div><div id="permission-assignments"></div></section><div class="field account-search"><label for="account-search">[[search_accounts]]</label><input id="account-search" type="search" placeholder="[[username]]"></div><div class="user-access-table"><table><thead><tr><th>[[user]]</th><th>[[access_summary]]</th><th>[[account_actions]]</th></tr></thead><tbody>${userRows || html`<tr><td colspan="3"><div class="empty-state">[[no_accounts_found]]</div></td></tr>`}</tbody></table></div></div><div class="modal-foot"><button type="button" class="button" data-close>[[done]]</button></div></section></div>`;
          document.getElementById('permission-user').addEventListener('change', event => {
            permissionUserId = event.target.value; permissionPage = 0; renderPermissionAssignments();
          });
          document.getElementById('permission-search').addEventListener('input', event => {
            permissionSearch = event.target.value; permissionPage = 0; renderPermissionAssignments();
          });
          document.getElementById('permission-filter').value = permissionFilter;
          document.getElementById('permission-filter').addEventListener('change', event => {
            permissionFilter = event.target.value; permissionPage = 0; renderPermissionAssignments();
          });
          document.getElementById('account-search').addEventListener('input', event => {
            const term = event.target.value.trim().toLowerCase();
            document.querySelectorAll('[data-account-name]').forEach(row => { row.hidden = !row.dataset.accountName.includes(term); });
          });
          document.querySelectorAll('[data-manage-user-access]').forEach(button => button.addEventListener('click', () => {
            permissionUserId = button.dataset.manageUserAccess; permissionPage = 0;
            document.getElementById('permission-user').value = permissionUserId;
            renderPermissionAssignments();
            document.querySelector('.permissions-editor').scrollIntoView({behavior:'smooth', block:'start'});
          }));
          renderPermissionAssignments();
          document.getElementById('user-create-form').addEventListener('submit', async event => {
            event.preventDefault();
            const form = event.currentTarget;
            const submit = form.querySelector('[type="submit"]');
            submit.disabled = true;
            try {
              const values = Object.fromEntries(new FormData(form).entries());
              values.is_admin = values.is_admin === 'on';
              await apiRequest('/api/users', { method: 'POST', body: JSON.stringify(values) });
              await openUserManager();
              toast(`${values.is_admin ? 'Superuser' : 'User'} created`);
            } catch (error) {
              const message = document.getElementById('user-create-error');
              message.textContent = error.message;
              message.hidden = false;
              submit.disabled = false;
            }
          });
        } catch (error) {
          toast(t('message_28', {0: (error.message)}));
        }
      }
      function openPasswordReset(userId) {
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="password-reset-form"><div class="modal-head"><div><div class="eyebrow">[[user_account]]</div><h2>[[reset_password]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="password-reset-error" role="alert" hidden></p><div class="field"><label for="reset-password">[[new_password_at_least_14_characters]]</label><input id="reset-password" name="password" type="password" autocomplete="new-password" minlength="14" maxlength="1024" required></div><p class="secondary-cell">[[the_user_will_need_to_sign_in_again_with_the_new_password]]</p></div><div class="modal-foot"><button type="button" class="button" data-user-manager>[[cancel]]</button><button type="submit" class="button primary">[[reset_password]]</button></div></form></div>`;
        document.getElementById('password-reset-form').addEventListener('submit', async event => {
          event.preventDefault();
          const form = event.currentTarget;
          const submit = form.querySelector('[type="submit"]');
          submit.disabled = true;
          try {
            const values = Object.fromEntries(new FormData(form).entries());
            await apiRequest(`/api/users/${encodeURIComponent(userId)}/password`, { method: 'POST', body: JSON.stringify(values) });
            await openUserManager();
            toast(t("password_reset"));
          } catch (error) {
            const message = document.getElementById('password-reset-error');
            message.textContent = error.message;
            message.hidden = false;
            submit.disabled = false;
          }
        });
      }
      function openRackModal(title, body, mutate) {
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="rack-form"><div class="modal-head"><h2>${esc(t(title))}</h2><button class="button" type="button" data-close>×</button></div><div class="modal-body"><p class="form-error" id="rack-error" role="alert" hidden></p>${body}</div><div class="modal-foot"><button class="button" type="button" data-close>[[cancel]]</button><button class="button primary" type="submit">[[save]]</button></div></form></div>`;
        const form = document.getElementById('rack-form');
        const target = data, actor = currentUser, environment = activeEnvironmentId;
        const stillCurrent = () => data === target && currentUser === actor && activeEnvironmentId === environment && form.isConnected;
        form.addEventListener('submit', async event => {
          event.preventDefault();
          if (!stillCurrent()) return;
          const backup = structuredClone({rooms: target.rooms || [], racks: target.racks || [], assets: target.assets});
          const submit = form.querySelector('[type="submit"]');
          submit.disabled = true;
          try {
            mutate(new FormData(form), target);
            if (!await save()) throw new Error(t("could_not_save_rack_settings_check_the_save_notification_and_try_again"));
            if (!stillCurrent()) return;
            closeModal(); render(); toast(t("rack_settings_saved"));
          } catch (error) {
            Object.assign(target, backup);
            if (!stillCurrent()) return;
            const message = form.querySelector('#rack-error');
            message.textContent = error.message; message.hidden = false;
            submit.disabled = false;
          }
        });
        return form;
      }
      function openRackForm(existing = null) {
        const defaultName = existing?.name || `Rack ${Math.max(0, ...(data.racks || []).map(rack => Number(rack.name.match(/^Rack (\d+)$/)?.[1]) || 0)) + 1}`;
        openRackModal(existing ? 'Edit rack cabinet' : 'New rack cabinet', html`<div class="field"><label>[[cabinet_name]]<input name="name" required maxlength="240" value="${esc(defaultName)}"></label></div><div class="field"><label>[[capacity_u]]<input name="capacityU" type="number" min="1" max="100" required value="${existing?.capacityU || 42}"></label></div><div class="field"><label>[[order_in_room]]<input name="displayOrder" type="number" min="1" max="100000" step="1" required value="${existing?.displayOrder || (data.racks || []).length + 1}"></label><span class="secondary-cell">[[lower_numbers_appear_first_within_the_room]]</span></div><div class="field"><label>[[location]]<input name="location" maxlength="240" value="${esc(existing?.location || '')}"></label></div><div class="field"><label>[[room]]<select name="roomId"><option value="">[[not_assigned]]</option>${(data.rooms || []).map(room => html`<option value="${esc(room.id)}" ${existing?.roomId === room.id ? 'selected' : ''}>${esc(room.name)}</option>`).join('')}</select></label></div>`, (values, target) => {
          const next = {id: existing?.id || createId('rack'), name: String(values.get('name') || '').trim(), capacityU: Number(values.get('capacityU')), displayOrder: Number(values.get('displayOrder')), location: String(values.get('location') || '').trim(), roomId: String(values.get('roomId') || '')};
          if (!next.name) throw new Error(t("enter_a_cabinet_name"));
          target.racks = existing ? (target.racks || []).map(rack => rack.id === existing.id ? next : rack) : [...(target.racks || []), next];
        });
      }
      function openRoomForm(existing = null) {
        openRackModal(existing ? 'Edit room' : 'New room', html`<div class="field"><label>[[room_name]]<input name="name" required maxlength="240" value="${esc(existing?.name || '')}"></label></div>`, (values, target) => {
          const room = {id: existing?.id || createId('room'), name: String(values.get('name') || '').trim()};
          target.rooms = existing ? (target.rooms || []).map(item => item.id === existing.id ? room : item) : [...(target.rooms || []), room];
        });
      }
      function openRackPlacement(asset, cabinetId = asset.rackId || '') {
        const physical = data.assets.filter(item => item.type !== 'Virtual server');
        const draft = {...asset, rackEnabled: true, rackId: cabinetId, rackStartU: asset.rackId === cabinetId ? asset.rackStartU : firstFreeRackUnit(data, cabinetId, asset.rackUnits || 1, asset.id)};
        const form = openRackModal('Assign device to cabinet', html`<div class="field"><label>[[device]]<select name="assetId">${physical.map(item => html`<option value="${esc(item.id)}" ${asset.id === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select></label></div>${rackAssetFields(draft, data.racks || [])}<p class="panel-sub">[[starting_u_is_the_lowest_occupied_unit_placements_cannot_overlap]]</p>`, (values, target) => {
          const enabled = values.get('rackEnabled') === 'on';
          const rackId = enabled ? String(values.get('rackId') || '') : '';
          target.assets = target.assets.map(item => item.id === values.get('assetId') ? {...item, rackEnabled: enabled, rackUnits: enabled ? Number(values.get('rackUnits')) : null, rackId, rackStartU: rackId ? Number(values.get('rackStartU')) : null} : item);
        });
        bindRackFields(form);
          bindPowerSupplyFields(form);
          bindManagementController(form);
        const suggestPosition = () => {
          const cabinet = form.querySelector('[name="rackId"]').value;
          const height = Number(form.querySelector('[name="rackUnits"]').value);
          form.querySelector('[name="rackStartU"]').value = firstFreeRackUnit(data, cabinet, height, asset.id) ?? '';
        };
        form.querySelector('[name="rackId"]').addEventListener('change', suggestPosition);
        form.querySelector('[name="rackUnits"]').addEventListener('change', suggestPosition);
        form.querySelector('[name="assetId"]').addEventListener('change', event => {
          const next = data.assets.find(item => item.id === event.target.value);
          if (next) openRackPlacement(next, form.querySelector('[name="rackId"]').value);
        });
      }
      function openEnvironmentManager() {
        const isAdmin = Boolean(currentUser?.is_admin);
        const rows = portfolio.environments.map(item => html`<div class="license-row"><div style="min-width:0"><div class="primary-cell">${esc(item.name)}${item.id === activeEnvironmentId ? html([" <span class=\"tag\">[[active]]</span>"]) : ''}</div><div class="secondary-cell">${(item.data.assets || []).length} assets · ${(item.data.vlans || []).length} VLANs · ${(item.data.lans || []).length} Networks · ${(item.data.wlans || []).length} WLANs · ${(item.data.licenses || []).length} licenses</div></div><div class="row-actions">${item.id !== activeEnvironmentId ? html`<button data-env-activate="${esc(item.id)}">[[open]]</button>` : ''}${isAdmin ? html`<button data-env-copy="${esc(item.id)}">[[copy]]</button><button data-env-rename="${esc(item.id)}">[[rename]]</button>${portfolio.environments.length > 1 ? html`<button data-env-delete="${esc(item.id)}">[[delete]]</button>` : ''}` : ''}</div></div>`).join('');
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><section class="modal"><div class="modal-head"><div><div class="eyebrow">[[client_portfolio]]</div><h2>[[manage_environments]]</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="panel-sub" style="margin:0 0 8px">[[each_environment_has_separate_assets_networks_licenses_hypervisors_and_accounts]]</p><div class="license-list" style="padding:0">${rows}</div></div><div class="modal-foot">${isAdmin ? html(["<button type=\"button\" class=\"button\" data-env-create>[[new_environment_848396]]</button><button type=\"button\" class=\"button\" data-env-copy-all>[[copy_all_environments]]</button><button type=\"button\" class=\"button\" data-user-manager>[[manage_users]]</button>"]) : ''}<button type="button" class="button" data-close>[[done]]</button></div></section></div>`;
      }
      function openEnvironmentForm(existing = null, copySource = null) {
        document.getElementById('modal-root').innerHTML = html`<div class="modal-backdrop" id="modal-backdrop"><form class="modal" id="environment-form"><div class="modal-head"><div><div class="eyebrow">[[client_portfolio]]</div><h2>${copySource ? t("copy_environment") : existing ? t("rename_environment") : t("new_environment")}</h2></div><button type="button" class="button icon-only" data-close aria-label="[[close]]">×</button></div><div class="modal-body"><p class="form-error" id="environment-error" role="alert" hidden></p><div class="field"><label for="environment-name">[[environment_name_a444b7]]</label><input id="environment-name" name="name" required maxlength="80" placeholder="[[for_example_acme_production]]" value="${esc(copySource ? `${copySource.name.slice(0, 73)} (copy)` : existing?.name || '')}"></div></div><div class="modal-foot"><button type="button" class="button" data-close>[[cancel]]</button><button type="submit" class="button primary">${copySource ? t("create_copy") : existing ? t("save_name") : t("create_environment")}</button></div></form></div>`;
        const input = document.getElementById('environment-name'); input.focus();
        document.getElementById('environment-form').addEventListener('submit', async event => {
          event.preventDefault();
          const form = event.currentTarget;
          const actor = currentUser;
          const targetPortfolio = portfolio;
          const stillCurrent = () => currentUser === actor && portfolio === targetPortfolio && form.isConnected;
          const name = new FormData(form).get('name').trim();
          if (!name) return;
          const submit = event.currentTarget.querySelector('[type="submit"]');
          submit.disabled = true;
          try {
            if (existing) {
              await apiRequest(`/api/environments/${encodeURIComponent(existing.id)}`, { method: 'PATCH', body: JSON.stringify({ name }) });
              existing.name = name;
            } else {
              if (copySource && await saveQueue === false) throw new Error(t("wait_for_the_current_inventory_to_save_successfully_before_copying"));
              if (!stillCurrent()) return;
              const environment = await apiRequest(copySource ? `/api/environments/${encodeURIComponent(copySource.id)}/copy` : '/api/environments', { method: 'POST', body: JSON.stringify({ name }) });
              if (!stillCurrent()) return;
              environment.role = 'admin';
              portfolio.environments.push(environment);
              activeEnvironmentId = environment.id;
              portfolio.activeEnvironmentId = activeEnvironmentId;
              data = { ...emptyData(), ...environment.data };
            }
            current = 'overview'; query = ''; closeModal(); render(); toast(copySource ? 'Environment copied' : existing ? 'Client renamed' : 'Client created');
          } catch (error) {
            if (!stillCurrent()) return;
            const message = document.getElementById('environment-error');
            message.textContent = error.message;
            message.hidden = false;
            submit.disabled = false;
          }
        });
      }
      document.addEventListener('click', async event => {
        if (event.target.closest('[data-dashboard-config]') && currentUser) {
          openDashboardConfiguration({saved: environmentDashboard(currentUser.dashboard, activeEnvironmentId), environmentId: activeEnvironmentId, apiRequest, closeModal, onSaved: preferences => { currentUser.dashboard = preferences; render(); toast(t("dashboard_preferences_saved")); }});
          return;
        }
        const pageButton = event.target.closest('[data-page]');
        if (pageButton) {
          if (pageButton.dataset.page === 'settings' && !currentUser?.is_admin) return;
          current = pageButton.dataset.page; query = ''; render(); return;
        }
        if (event.target.closest('[data-environment-manager]') && currentUser?.is_admin) { openEnvironmentManager(); return; }
        if (event.target.closest('[data-asset-trash]') && currentUser?.is_admin) {
          const accountId = currentUser.id;
          await openAssetTrash(apiRequest, esc, () => Boolean(currentUser?.is_admin && currentUser.id === accountId), async () => {
            const state = await apiRequest('/api/state');
            if (currentUser?.id === accountId) applyRemoteState(state);
          });
          return;
        }
        if (event.target.closest('[data-activity-logs]') && currentUser?.is_admin) { await openActivityLogs(); return; }
        if (event.target.closest('[data-network-map-settings]') && currentUser?.is_admin) { await openNetworkMapSettings(); return; }
        if (event.target.closest('[data-session-timeout]') && currentUser?.is_admin) { await openSessionTimeoutSettings(); return; }
        if (event.target.closest('[data-ai-providers]') && currentUser?.is_admin) { await openAIProviders(apiRequest, esc); return; }
        if (event.target.closest('[data-os-manager]') && currentUser?.is_admin) {
          try {
            await openOSManager({ apiRequest, onChanged: async catalog => {
              operatingSystems = catalog;
              applyRemoteState(await apiRequest('/api/state'));
            } });
          } catch (error) { toast(error.message); }
          return;
        }
        if (event.target.closest('[data-login-protection]') && currentUser?.is_admin) { await openLoginProtectionSettings(); return; }
        if (event.target.closest('[data-administration-settings]') && currentUser?.is_admin) { closeModal(); current = 'settings'; render(); return; }
        if (event.target.closest('#user-settings-button')) { openUserSettings(); return; }
        if (event.target.closest('[data-user-settings]')) { openUserSettings(); return; }
        if (event.target.closest('[data-change-own-password]')) { openOwnPasswordChange(); return; }
        if (event.target.closest('[data-user-manager]')) { await openUserManager(); return; }
        const userPassword = event.target.closest('[data-user-password]');
        if (userPassword) { openPasswordReset(userPassword.dataset.userPassword); return; }
        const userDelete = event.target.closest('[data-user-delete]');
        if (userDelete) {
          const username = userDelete.dataset.username;
          if (!confirm(t('message_29', {0: (username)}))) return;
          userDelete.disabled = true;
          try {
            await apiRequest(`/api/users/${encodeURIComponent(userDelete.dataset.userDelete)}`, { method: 'DELETE' });
            await openUserManager();
            toast(t('message_30', {0: (username)}));
          } catch (error) {
            toast(t('message_31', {0: (error.message)}));
            userDelete.disabled = false;
          }
          return;
        }
        const userStatus = event.target.closest('[data-user-active]');
        if (userStatus) {
          const isActive = userStatus.dataset.active === 'true';
          const action = isActive ? 'activate' : 'deactivate';
          if (!confirm(t('message_32', {0: (action[0].toUpperCase()), 1: (action.slice(1))}))) return;
          userStatus.disabled = true;
          try {
            await apiRequest(`/api/users/${encodeURIComponent(userStatus.dataset.userActive)}`, {
              method: 'PATCH', body: JSON.stringify({ is_active: isActive })
            });
            await openUserManager();
            toast(`User ${isActive ? 'activated' : 'deactivated'}`);
          } catch (error) {
            toast(t('message_33', {0: (action), 1: (error.message)}));
            userStatus.disabled = false;
          }
          return;
        }
        const roomAction = event.target.closest('[data-room-new], [data-room-edit], [data-room-delete]');
        if (roomAction) {
          if (!(currentUser?.is_admin || portfolio.environments.find(item => item.id === activeEnvironmentId)?.role === 'editor')) return;
          const room = (data.rooms || []).find(item => item.id === (roomAction.dataset.roomEdit || roomAction.dataset.roomDelete));
          if (roomAction.hasAttribute('data-room-new')) openRoomForm();
          else if (roomAction.hasAttribute('data-room-edit') && room) openRoomForm(room);
          else if (room) {
            if ((data.racks || []).some(rack => rack.roomId === room.id)) { toast(t("reassign_the_cabinets_before_deleting_this_room")); return; }
            const target = data, previous = target.rooms;
            target.rooms = target.rooms.filter(item => item.id !== room.id);
            roomAction.disabled = true;
            if (!await save()) target.rooms = previous;
            if (data === target && currentUser) render();
          }
          return;
        }
        const rackAction = event.target.closest('[data-rack-new], [data-rack-edit], [data-rack-delete], [data-rack-assign], [data-rack-device]');
        if (rackAction) {
          if (!(currentUser?.is_admin || portfolio.environments.find(item => item.id === activeEnvironmentId)?.role === 'editor')) return;
          const rack = (data.racks || []).find(item => item.id === (rackAction.dataset.rackEdit || rackAction.dataset.rackDelete || rackAction.dataset.rackAssign));
          if (rackAction.hasAttribute('data-rack-new')) openRackForm();
          else if (rackAction.hasAttribute('data-rack-edit') && rack) openRackForm(rack);
          else if (rackAction.hasAttribute('data-rack-device')) {
            const asset = data.assets.find(item => item.id === rackAction.dataset.rackDevice);
            if (asset && asset.type !== 'Virtual server') openRackPlacement(asset);
          } else if (rackAction.hasAttribute('data-rack-assign') && rack) {
            const asset = data.assets.find(item => item.rackEnabled && !item.rackId) || data.assets.find(item => item.type !== 'Virtual server');
            if (asset) openRackPlacement(asset, rack.id); else toast(t("add_a_physical_asset_first"));
          } else if (rackAction.hasAttribute('data-rack-delete') && rack) {
            if (data.assets.some(item => item.rackId === rack.id)) { toast(t("unassign_the_devices_before_deleting_this_cabinet")); return; }
            const target = data, previous = target.racks;
            target.racks = target.racks.filter(item => item.id !== rack.id);
            rackAction.disabled = true;
            if (!await save()) target.racks = previous;
            if (data === target && currentUser) render();
          }
          return;
        }
        if (event.target.closest('[data-env-copy-all]') && currentUser?.is_admin) {
          const button = event.target.closest('[data-env-copy-all]');
          const actor = currentUser;
          const targetPortfolio = portfolio;
          const stillCurrent = () => currentUser === actor && portfolio === targetPortfolio;
          button.disabled = true;
          try {
            if (await saveQueue === false) throw new Error(t("save_the_current_inventory_successfully_before_copying"));
            if (!stillCurrent() || !button.isConnected) return;
            const result = await apiRequest('/api/environments/copy-all', {method: 'POST', body: JSON.stringify({})});
            if (!stillCurrent()) return;
            portfolio.environments.push(...result.environments);
            if (button.isConnected) openEnvironmentManager();
            toast(t('message_34', {0: (result.environments.length)}));
          } catch (error) { if (stillCurrent()) { toast(t('message_35', {0: (error.message)})); button.disabled = false; } }
          return;
        }
        if (event.target.closest('[data-env-create]')) { openEnvironmentForm(); return; }
        const copyEnvironment = event.target.closest('[data-env-copy]');
        if (copyEnvironment) { openEnvironmentForm(null, portfolio.environments.find(item => item.id === copyEnvironment.dataset.envCopy)); return; }
        const renameEnvironment = event.target.closest('[data-env-rename]');
        if (renameEnvironment) { openEnvironmentForm(portfolio.environments.find(item => item.id === renameEnvironment.dataset.envRename)); return; }
        const activateEnvironment = event.target.closest('[data-env-activate]');
        if (activateEnvironment) {
          await save(); activeEnvironmentId = activateEnvironment.dataset.envActivate;
          portfolio.activeEnvironmentId = activeEnvironmentId;
          data = portfolio.environments.find(item => item.id === activeEnvironmentId).data;
          current = 'overview'; query = ''; closeModal(); render(); return;
        }
        const deleteEnvironment = event.target.closest('[data-env-delete]');
        if (deleteEnvironment) {
          const environment = portfolio.environments.find(item => item.id === deleteEnvironment.dataset.envDelete);
          if (environment && confirm(t('message_36', {0: (environment.name)}))) {
            try {
              if (activeEnvironmentId === environment.id) await save();
              await apiRequest(`/api/environments/${encodeURIComponent(environment.id)}`, { method: 'DELETE' });
              portfolio.environments = portfolio.environments.filter(item => item.id !== environment.id);
              if (activeEnvironmentId === environment.id) {
                activeEnvironmentId = portfolio.environments[0]?.id || null;
                portfolio.activeEnvironmentId = activeEnvironmentId;
                data = portfolio.environments[0]?.data || emptyData();
                current = 'overview';
              }
              openEnvironmentManager(); render();
            } catch (error) { toast(t('message_37', {0: (error.message)})); }
          }
          return;
        }
        if (event.target.closest('#add-button') && current === 'rooms') { openRoomForm(); return; }
        if (event.target.closest('#add-button') && current === 'racks') { openRackForm(); return; }
        if (event.target.closest('#add-button')) {
          const assetCategory = isAssetCategory(current) ? current : null;
          openForm(current === 'overview' || assetCategory ? 'assets' : current, null, assetCategory);
          return;
        }
        if (event.target.closest('[data-close]') || event.target.id === 'modal-backdrop') { closeModal(); return; }
        const copyAsset = event.target.closest('[data-copy-asset]');
        if (copyAsset && (currentUser?.is_admin || portfolio.environments.find(item => item.id === activeEnvironmentId)?.role === 'editor')) {
          const source = data.assets.find(item => item.id === copyAsset.dataset.copyAsset);
          if (source) {
            const draft = assetCopyDraft(source);
            const category = Object.entries(assetCategoryTypes).find(([, types]) => types.includes(source.type))?.[0] || null;
            openForm('assets', null, category, draft);
          }
          return;
        }
        const edit = event.target.closest('[data-edit]');
        if (edit) {
          const section = isAssetCategory(current) ? 'assets' : current;
          const row = data[section].find(item => item.id === edit.dataset.edit);
          if (row) openForm(section, row, isAssetCategory(current) ? current : null);
          return;
        }
        const remove = event.target.closest('[data-delete]');
        if (remove) {
          const wlan = (data.wlans || []).find(wlan => (current === 'vlans' && wlan.vlanInterfaceId === remove.dataset.delete) || (isAssetCategory(current) && wlan.parentDeviceId === remove.dataset.delete));
          if (wlan) { toast(t('message_38', {0: (wlan.name)})); return; }
          const referenced = (data.lans || []).find(network =>
            (current === 'vlans' && network.parentInterface?.type === 'vlan' && network.parentInterface.vlanId === remove.dataset.delete) ||
            (network.parentInterface?.type === 'physical' && network.parentInterface.deviceId === remove.dataset.delete));
          if (referenced) { toast(t('message_39', {0: (referenced.name)})); return; }
        }
        if (remove && current === 'vlans') {
          const vlan = data.vlans.find(item => item.id === remove.dataset.delete);
          if (vlan?.isDefault) {
            toast(t("the_predefined_vlan_1_cannot_be_deleted"));
            return;
          }
          const assignedPorts = vlan ? portsUsingVlan(vlan.idValue ?? vlan.id) : [];
          if (assignedPorts.length) {
            const locations = assignedPorts.slice(0, 3).map(item => `${item.assetName} port ${item.port}`).join(', ');
            toast(t('message_40', {0: (vlan.idValue), 1: (locations), 2: (assignedPorts.length > 3 ? ', and other ports' : '')}));
            return;
          }
        }
        if (remove && confirm(isAssetCategory(current) || current === 'assets' ? 'Move this asset to Trash? Only a superadmin can permanently delete it.' : 'Delete this record? This cannot be undone.')) {
          const removedId = remove.dataset.delete;
          const assetPage = isAssetCategory(current) || current === 'assets';
          const section = assetPage ? 'assets' : current;
          if (section === 'licenses') {
            const license = data.licenses.find(item => item.id === removedId);
            if (!license) return;
            try {
              await saveLicense(license, true);
              data.licenses = data.licenses.filter(item => item.id !== removedId);
              render(); toast(t("record_deleted"));
            } catch (error) { toast(t('message_41', {0: (error.message)})); }
            return;
          }
          data[section] = data[section].filter(item => item.id !== removedId);
          if (assetPage) {
            data.vlans = data.vlans.map(vlan => ({ ...vlan, masterDeviceId: vlan.masterDeviceId === removedId ? '' : vlan.masterDeviceId }));
            data.assets = data.assets.map(asset => ({ ...asset, hypervisorId: asset.hypervisorId === removedId ? '' : asset.hypervisorId, backupUpsId: asset.backupUpsId === removedId ? '' : asset.backupUpsId, backupPowerEnabled: asset.backupUpsId === removedId ? false : asset.backupPowerEnabled }));
            data.connections = (data.connections || []).filter(link => link.deviceAId !== removedId && link.deviceBId !== removedId);
            data.clusters = (data.clusters || []).flatMap(cluster => {
              const memberAssetIds = (cluster.memberAssetIds || []).filter(id => id !== removedId);
              return memberAssetIds.length >= 2 ? [{ ...cluster, memberAssetIds }] : [];
            });
            data.assets = data.assets.map(asset => ({ ...asset,
              hypervisorClusterId: (data.clusters || []).some(cluster => cluster.id === asset.hypervisorClusterId) ? asset.hypervisorClusterId : ''
            }));
            data.stacks = (data.stacks || []).flatMap(stack => {
              const memberAssetIds = (stack.memberAssetIds || []).filter(id => id !== removedId);
              return memberAssetIds.length >= 2 ? [{ ...stack, memberAssetIds }] : [];
            });
            data.lags = (data.lags || []).flatMap(lag => {
              if (!lag.stackAId && lag.deviceAId === removedId || !lag.stackBId && lag.deviceBId === removedId) return [];
              if (lag.stackAId && !data.stacks.some(stack => stack.id === lag.stackAId) ||
                  lag.stackBId && !data.stacks.some(stack => stack.id === lag.stackBId)) return [];
              const membersA = lagMemberTokens(lag, 'A')
                .map(token => token.slice(0, token.lastIndexOf(':')) === removedId ? null : token)
                .filter(Boolean);
              const membersB = lagMemberTokens(lag, 'B')
                .map(token => token.slice(0, token.lastIndexOf(':')) === removedId ? null : token)
                .filter(Boolean);
              if (membersA.length < 2 || membersA.length !== membersB.length) return [];
              const normalizedA = selectedLagMembers(
                lag.stackAId ? `stack:${lag.stackAId}` : `asset:${lag.deviceAId}`, membersA
              );
              const normalizedB = selectedLagMembers(
                lag.stackBId ? `stack:${lag.stackBId}` : `asset:${lag.deviceBId}`, membersB
              );
              return [{
                ...lag,
                deviceAId: normalizedA[0].deviceId,
                portsA: normalizedA.map(member => member.port),
                membersA: normalizedA,
                deviceBId: normalizedB[0].deviceId,
                portsB: normalizedB.map(member => member.port),
                membersB: normalizedB
              }];
            });
            data.licenses = data.licenses.map(license => ({ ...license, assignedAssetIds: (license.assignedAssetIds || []).filter(id => id !== removedId) }));
          } else if (section === 'clusters') {
            data.assets = data.assets.map(asset => ({ ...asset, hypervisorClusterId: asset.hypervisorClusterId === removedId ? '' : asset.hypervisorClusterId }));
          } else if (section === 'stacks') {
            data.lags = (data.lags || []).filter(lag =>
              lag.stackAId !== removedId && lag.stackBId !== removedId
            );
          }
          if (assetPage) {
            const saved = await save();
            render();
            if (saved) toast(t("asset_moved_to_trash"));
          } else { save(); render(); toast(t("record_deleted")); }
        }
      });
      document.addEventListener('input', event => {
        if (event.target.id === 'search-input') {
          const cursor = event.target.selectionStart;
          query = event.target.value;
          render();
          const input = document.getElementById('search-input'); input.focus(); input.setSelectionRange(cursor, cursor);
        }
      });
      document.addEventListener('change', event => {
        const environmentRole = event.target.closest?.('[data-user-environment]');
        if (environmentRole) {
          const { currentRole, userId, userEnvironment: environmentId } = environmentRole.dataset;
          const nextRole = environmentRole.value;
          if (currentRole === nextRole) return;
          environmentRole.disabled = true;
          const pendingKey = `${userId}:${environmentId}`;
          permissionPending.add(pendingKey);
          let request;
          if (!nextRole) {
            request = apiRequest(`/api/environments/${encodeURIComponent(environmentId)}/members/${encodeURIComponent(userId)}`, {
              method: 'DELETE'
            });
          } else if (!currentRole) {
            request = apiRequest(`/api/environments/${encodeURIComponent(environmentId)}/members`, {
            method: 'POST', body: JSON.stringify({ user_id: userId, role: nextRole })
            });
          } else {
            request = apiRequest(`/api/environments/${encodeURIComponent(environmentId)}/members/${encodeURIComponent(userId)}`, {
              method: 'PATCH', body: JSON.stringify({ role: nextRole })
            });
          }
          request.then(() => {
            environmentRole.dataset.currentRole = nextRole;
            const updatedUser = permissionUsers.find(user => user.id === userId);
            if (updatedUser) {
              updatedUser.environment_roles ||= {};
              if (nextRole) updatedUser.environment_roles[environmentId] = nextRole;
              else delete updatedUser.environment_roles[environmentId];
              document.querySelectorAll('[data-access-count]').forEach(count => {
                if (count.dataset.accessCount === userId) count.textContent = Object.keys(updatedUser.environment_roles).length;
              });
            }
            renderPermissionAssignments();
            toast(t("environment_access_updated"));
          }).catch(error => {
            environmentRole.value = currentRole;
            toast(t('message_42', {0: (error.message)}));
          }).finally(() => {
            permissionPending.delete(pendingKey);
            environmentRole.disabled = false;
            renderPermissionAssignments();
          });
          return;
        }
        const columnCheckbox = event.target.closest?.('[data-column-visibility]');
        if (!columnCheckbox) return;
        const checkboxes = [...document.querySelectorAll(`[data-column-section="${columnCheckbox.dataset.columnSection}"]`)];
        const selectedColumns = checkboxes.filter(checkbox => checkbox.checked).map(checkbox => checkbox.dataset.columnVisibility);
        if (!selectedColumns.length) {
          columnCheckbox.checked = true;
          toast(t("keep_at_least_one_column_visible"));
          return;
        }
        columnVisibility[columnCheckbox.dataset.columnSection] = selectedColumns;
        try { localStorage.setItem(columnVisibilityStorageKey, JSON.stringify(columnVisibility)); } catch { /* Keep the choice for this session. */ }
        render();
      });
      document.getElementById('environment-select').addEventListener('change', async event => {
        const selectedEnvironmentId = event.target.value;
        await save();
        const selectedEnvironment = portfolio.environments.find(item => item.id === selectedEnvironmentId);
        if (!currentUser || !selectedEnvironment) return;
        activeEnvironmentId = selectedEnvironmentId;
        portfolio.activeEnvironmentId = activeEnvironmentId;
        data = selectedEnvironment.data;
        current = 'overview'; query = ''; render();
      });
      document.getElementById('logout-button').addEventListener('click', async () => {
        await saveQueue;
        try { await apiRequest('/api/logout', { method: 'POST' }); } catch (error) { toast(error.message); }
        currentUser = null;
        portfolio = { environments: [], activeEnvironmentId: null };
        activeEnvironmentId = null;
        data = emptyData();
        showLogin();
      });
      let lastActivityPing = 0;
      function reportActivity(event) {
        if (!event.isTrusted || !currentUser || document.hidden || Date.now() - lastActivityPing < 10000) return;
        lastActivityPing = Date.now();
        apiRequest('/api/session/activity', {method: 'POST'}).catch(() => {});
      }
      for (const event of ['pointerdown', 'pointermove', 'keydown', 'scroll', 'touchstart']) {
        document.addEventListener(event, reportActivity, {passive: true, capture: true});
      }
      setInterval(() => {
        if (currentUser) apiRequest('/api/session/status').catch(() => {});
      }, 10000);
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden && currentUser) apiRequest('/api/session/status').catch(() => {});
      });
      bootstrap();
    })();
